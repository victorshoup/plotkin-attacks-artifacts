# codec/ — the C driver and both codecs

Holds `rs_point.c`, `rs_common.h`, `fft_kernels.S` and the `Makefile`, extracted
from the working tree's `isal/`. Renamed because the old name was misleading:
this is our code, not Intel's. ISA-L is a dependency, fetched at a pinned
version by `../bootstrap-isal.sh`.

## rs_point.c is NOT split, deliberately

An earlier plan called for cutting it into `rs8.c` / `rs16.c` / driver. The
dependency analysis says don't:

* **28 functions and 9 file-scope `static` variables cross the proposed
  boundaries.** The variables are the problem — `fft_affine`, `g16_node`,
  `g16_cantor`, `apply_fused`, `fft_tail_tab`, `fft_pool_inter`. Splitting turns
  file-private mutable state into exported globals shared across translation
  units, which is worse code than what is there now.
* **It is one translation unit at `-O3` with no LTO and ~200 `static` functions
  that inline freely inside it.** A split puts every measured number back in
  question and demands a full re-verification, for no measurement gain.
* **The benefit was for a goal this artifact disclaims.** The split was
  motivated by "shipping a 6 000-line driver publishes a harness, not a
  library" — but this *is* a harness, and no API is being designed.

What a reader needs is not three files but knowing where things are in one.
`../docs/MAPPING.md` carries the section map.
