# `rs-point` knobs, and which are load-bearing

Two classes, and the distinction matters when reading a result: some knobs
select what the codec *does*, and some exist only so that a claim about a
change can be measured against the configuration it replaced. The second kind
should never be set to get a number — they are there so the number can be
checked.

## Selection — these change what is computed

| knob | values | default | effect |
|---|---|---|---|
| `--field` | `8` \| `16` \| `auto` | `auto` | `auto` picks GF(2⁸) wherever T ≤ 256 allows. See `PERF-NOTES-FFT-GF8.md`: below the boundary neither field dominates, so a decode-weighted caller wants 8 and an encode- or sum-weighted one wants 16. |
| `--plan` | `cauchy` \| `ge` | `cauchy` | Closed-form O(r²) inverse against stock ISA-L's O(k³) elimination. `ge` is the independent oracle for `cauchy`. |
| `--fold` | `closed-form` \| `naive` | `closed-form` | O(r(k−r)) fold against the explicit O(r²(k−r)) product. `naive` is the oracle. |
| `--k` / `--m` | `<n>` | `k=f+1, m=2f` | an explicit shape instead of the harness's rate. `fd-point` spells them the same way. Grid legs never pass them; the null is that `--k f+1 --m 2f` reproduces the default digest. |
| `--arrivals` | `random` \| `first` \| `parity` | `random` | which k shards the receiver got. `first` collapses the survivor span, which is the Turbine regime; it is a probe, not a measurement configuration. **`parity` gives the receiver ONLY parity shards**, so every original is missing and r = k -- the largest residual system, and the arrival set a Byzantine disperser may choose in the AVID setting. It is a stable partition of the SAME seeded shuffle, so only the class of the arriving shard differs from `random` and a delta between them isolates that. GF(2^16) accepts `random|parity` only; it never had `first`. Gated by `check.sh`'s ALL-PARITY ARRIVALS section, which is where r = k is asserted at all -- every other decode in the suite runs at r ~ 2k/3. The Rust driver carries the identical partition (`arrivals_parity_first`) so the codecs still select the same arrivals at one seed; `--codec r10` refuses the mode, being non-systematic. |
| `ISAL8_NODES` | `cauchy` \| `eval` | **`eval`** (was `cauchy`; flipped 2026-08-26) | Which GF(2⁸) code. `eval` is the classical evaluation code on the nodes 0..T−1 — the one an additive FFT can encode, and byte-for-byte **firedancer's**. `cauchy` is what every revision has measured. Both are MDS, both decode by the same closed-form plan, and they produce different parity. **`ISAL8_ENCODE=fft` requires `eval`.** `PERF-NOTES-FFT-GF8-PPT.md`. |
| `ISAL8_ENCODE` | `matrix` \| `fft` | **`fft`** (was `matrix`; flipped 2026-08-26) | The GF(2⁸) encoder. `fft` is the additive FFT with the principal pivot transform, which reaches **every** shape with T ≤ 256 — f ≤ 85, where the padded construction stops at f ≤ 64. Same code as `matrix`, so their parity must agree byte for byte, and both must agree with `references/fd-point`. |
| `ISAL8_INTERP` | `ppt` \| `pad` \| `auto` \| `<kp>` | **`auto`** (was `ppt`; flipped 2026-08-26) | The **pivot base** `kp`, and therefore **which code** the `eval` family is. Interpolate the degree-`< kp` polynomial through the data at 0…k−1 and *zeros* at k…kp−1, pivoting only the top `chunk − kp` coordinates; parity starts at `kp`. `ppt` is `kp = k` — firedancer's code, most parity nodes, most glue, so `references/fd-point` is an oracle for **this setting only**. `pad` is `kp = chunk` — no glue at all, but it burns `chunk − k` nodes on zeros, so it needs `chunk + m ≤ 256` and is refused above that. **`auto` is the RULE `kp = min(chunk, 256 − m)`** — the most padding the node budget admits, which is feasible iff T ≤ 256. Pure arithmetic: no constants, no kernel knowledge, no search. **This REPLACED a cost model that scored every feasible base in shard touches**, and the replacement was measured rather than preferred; `fft8_plan_cost` is deleted. `../docs/ALGORITHMS.md` §5.4 carries the two regimes, including the one where no constant-free rule can be optimal. An explicit `<kp>` in `[k, min(chunk, 256−m)]` is the sweep knob. **This selects a code, not an encoder** — unlike every other knob in this table, different values MUST produce different parity, and `check.sh` asserts that, together with the invariant that `auto` does not move under any of six kernel knobs. The oracle at any `kp` is the matrix encoder over the same node set. `PERF-NOTES-FFT-GF8-PPT.md` §10, §12, §18. |
| `ISAL16_NODES` | `linear` \| `cantor` | **`cantor`** (was `linear`; flipped 2026-08-26) | Which Cauchy nodes. `cantor` is the code an additive FFT encodes; `linear` is what every revision through 18 measured. **`ISAL16_ENCODE=fft` requires `cantor`.** |
| `ISAL16_ENCODE` | `matrix` \| `fft` | **`fft`** (was `matrix`; flipped 2026-08-26) | The encoder. Both compute the *same code*, so their parity must agree byte for byte — which is the standing oracle above T = 256, where no cross-library digest exists. |
| `ISAL16_ENC_LAYOUT` | `plane` \| `inter` | **`inter` when the transform encoder runs, else `plane`** (was `plane`; flipped 2026-08-26) | The layout of the **shard pool itself**, i.e. what the codec emits. `inter` gives the encoder's two transforms -- ~74% of its cost -- the same layout win the decoder gets, worth 1.09x-1.23x on transform encode at 4 MiB. **Changes the parity bytes**: same code over a different element ordering, not a different code, and decode still returns the source exactly. Requires `ISAL16_ENCODE=fft` (the matrix encoder writes parity through ISA-L, which addresses the pool as planes); nothing else is refused. The matrix decoder works under it — it de-interleaves the k survivors inside its own timer (`run_gf16`, `fft_pool_inter`) — and so does the matrix tail coset, which reads a plane-form copy of the originals and permutes its output back. `isal_x16_imat`, the paper's RS–16 matrix-decode label, is exactly `inter` + `ISAL16_DECODE=matrix` + the tail. Until 11 September 2026 this row, and the comment above `fft_pool_inter` in `rs_point.c`, said `ISAL16_DECODE=fft` was required and the tail was refused; that was true for a few hours on 24 August 2026. Both are corrected. `PERF-NOTES-LARGE-F.md` G. |
| `ISAL16_DEC_LAYOUT` | `plane` \| `inter` | **`inter`** (was `plane`; flipped 2026-08-26) | The transform decoder's work-buffer layout. `inter` is `reed-solomon-simd`'s: each 64-byte chunk is lo32\|hi32, so a butterfly touches one memory stream per shard instead of two. **Decode only** -- the encoder writes the parity pool the matrix decoder reads, so it cannot move. Worth 1.05x-1.15x on transform decode and it never loses; `PERF-NOTES-LARGE-F.md` D. ~~Default is `plane` only because that is what the published figures were taken at.~~ **Flipped to `inter` on 2026-08-26.** |
| `ISAL16_APPLY` | `isal` \| `fused` | `isal` | The r × k decode apply. `fused` is 0.79×–0.94× and exists as evidence, not as an option — `PERF-NOTES-GF16-KERNEL.md`. |
| `ISAL16_FFT_TAIL` | `<n>` | `4` | Encode the last recovery coset by matrix when its live count is ≤ n. **The one genuine tuning threshold here**, and the only knob that would want recalibrating on another machine. **Default is 4 since 2026-08-26** (was 12); §5.31. **And its crossover moved when `ISAL16_ENC_LAYOUT=inter` became the default the same day** — the calibration table in `rs_point.c` above `fft_tail_rows` was measured under `plane`, where the tail path writes parity directly; under `inter` it also pays a plane-form copy of the k originals and a permute of its output. Measured at f = 134 (`last = 12`, k = 135, m = 268, five processes, ASLR off): matrix-tail speedup is **0.907×–1.041× under `plane`** — which reproduces the table's 1.06 at 4 MiB — but **0.775×–0.819× under `inter`**, i.e. losing at every size. So at chunk = 256 the crossover is now below 12, not ≈ 13. **`inter` is the default and stays the default** — it is worth 3.5×–45× on encode and this knob is a few percent at one shape; the `plane` figures above are the control that identifies why the crossover moved, not an alternative. **The default of 4 is likewise unaffected and still safe** (it sits below the moved crossover on both layouts). What is stale is the comment's stated justification, not either value. `PERF-NOTES-GF16-PIVOT-PROBE.md` §7. |

## Nulls — these exist to be measured against, not to be set

| knob | restores | what it establishes |
|---|---|---|
| `ISAL16_KARATSUBA=0` | the dense 2k × 2m expansion | §4.5's three-products-instead-of-four, and a byte-identity oracle against `=1` |
| `ISAL16_LOGTAB=0` | plan arithmetic without log tables | §4.10 |
| `ISAL16_FFT_BLOCK=0` | one transform layer at a time | the unblocked null for §4.8's register blocking |
| `ISAL16_FFT_BLOCK3=1` | three-layer blocking | **off by default here, against upstream.** Three layers is eight shards, which is sixteen memory streams under plane-split planes where upstream's interleave makes it eight. Measured 0.92×–0.98× in the grid, i.e. slower — and re-measured outside it, where the worry was that the trade flips with k: transform decode at 1 MiB is 1.335/1.419 at f = 255, 1.754/1.708 at 511, 1.857/1.918 at 1023, 2.082/2.156 at 2047 (`=0`/`=1`). Slower at three of four. `PERF-NOTES-LARGE-F.md` 1.1. |
| `ISAL16_FFT_ASM=0` | the C butterfly | **The assembly is now the slower of the two and its justification is void.** It was written at `-O2`, where the C form spilled 151 stack operands out of 672, and even then it was only 0.98x-1.00x -- the block is memory-bound, not issue-bound. At `-O3` the intrinsics form spills **nothing**, so there is nothing left to remove, and `ASM=1` measures 1.03x-1.09x SLOWER (f=1023: 1.178/5.212 against 1.080/4.876 enc/dec; f=2047: 1.422/6.972 against 1.355/6.769; ASLR off, five draws, non-overlapping). It is also unreachable by default -- `fft_b3` runs only under `ISAL16_FFT_BLOCK3=1` -- and it hard-codes PLANE addressing, so `ISAL16_DEC_LAYOUT=inter` has to guard against it. `PERF-NOTES-LARGE-F.md` E. |
| `ISAL16_FWHT=scalar` | the C Walsh-Hadamard transform | the null for the explicit AVX2 form. The two must decode identically -- the locator feeds every recovered shard's scaling, so a wrong transform fails verification at once. Worth 1.35x on the locator phase, 1.04x-1.06x on a 1 MiB decode and 1.01x on 4 MiB; its real purpose is that instruction *selection* is no longer the compiler's to choose. `PERF-NOTES-LARGE-F.md` F. |
| `ISAL16_FFT_KERNEL=scalar` | a scalar butterfly | correctness oracle for the vector kernels, independent of GFNI |
| `ISAL8_COSET_FUSE=0` | each later coset's coefficient copy as its own pass | the unfused null. Cosets 2+ each need their own copy of the coefficient vector, because the first coset's walk runs in place and destroys it — so `coset_copy` read `w` and wrote the coset's destination, and that coset's first forward pass read and wrote the destination again. Fused they are one pass. Legal because the widest forward pass covers **all** `chunk` slots whatever `trunc` is, which is also why the slots at and above `nlive` need no memset — they read the zero shard. Worth **≈1.10×** at every shape with a full second coset (f = 31, 48, 56, 63); no effect where `ncos == 1`. `PERF-NOTES-FFT-GF8-PPT.md` §17. |
| `ISAL8_PPT_FUSE=0` | PPT's glue as separate one-shard passes | the unfused null. `ppt_build` emits `COPY`+`SCALE` and `SCALE`+`MULACC_SCRATCH` as adjacent pairs on the SAME shard; fused they are one pass each — four shard-touches become three, and five become three. `single` ops fall exactly 25% (336 → 252 at f = 85) and the `COPY` memcpy disappears. Worth **1.018×–1.116×** wherever the glue runs, most where `chunk − kp` is largest. `PERF-NOTES-FFT-GF8-PPT.md` §16. |
| `ISAL8_FFT_BLOCK3=1` | three transform layers per pass, over eight shards | opt-in; its null is the two-layer default. Worth **1.045×–1.151×** on the grid (median ≈1.09) and **1.13×** at k = m = 32. Needs AVX-512VL, and needed an **in-place** kernel to get it: the sixteen-pointer form put 137 stack-operand instructions of 603 in the inner loop against `fft8_b2_v`'s 28 of 245 — scalar pointer reloads, not vector spills, sixteen live pointers against ~14 GPRs — and it measured 0.88×–0.95×, i.e. slower, until that was split out (74 of 495). The tower ships this OFF because there a shard is two streams and eight shards is sixteen; here a shard is one. `PERF-NOTES-FFT-GF8-PPT.md` §14. |
| `ISAL8_FUSE=0` | the copy in as its own pass | the unfused null. With it on, the interpolation's **first butterfly layer reads the caller's shards directly and writes the work buffer**, so the message is not read and written twice. Worth **1.05×–1.07×** on the n = 3f+1 grid and **1.12×–1.15×** at k = m = 32, where there is only one coset and the duplicate pass is a larger share. Only on the plain-IFFT path (`ISAL8_INTERP` giving `kp == chunk`) — under a partial pivot the first thing to touch the buffer is a PPT op, not a butterfly. `PERF-NOTES-FFT-GF8-PPT.md` §13. |
| `ISAL8_FFT_KERNEL=scalar` | a scalar GF(2⁸) butterfly | correctness oracle for the vector kernels, independent of GFNI. It is what caught `fft_affine` being read before `gf16_affine_init` had built it — a table of zeros, i.e. every multiply returning 0, which only the vector path touches. |
| `ISAL8_FFT_BLOCK=0` | one transform layer at a time | the unblocked null. Two layers is worth **1.2×–1.45×** on the GF(2⁸) transform encode. |
| `ISAL8_FFT_W=512` | 512-bit lanes instead of 256 | measured **0.93×–1.03×**, median 1.00 — a wash, which says this kernel is memory-bound and not issue-bound. Report §9.1's conclusion reached a third way. Off by default for that reason, not because it is untested. **Why the bad end is a loss rather than a tie is UNRESOLVED and was retired from the work queue on 1 September 2026 rather than answered** — the marker block on `fft8_b2_z` in `rs_point.c` carries the two unprobed hypotheses. That comment cites this row for the figures, so this row is the authority and the source comment is the back-link; keep them pointing at each other. |
| `ISAL_ALLOC_PER_CALL=0` | process-lifetime buffers | §3.9's rule 3; under the `warm` allocator contract this and `=1` agree to 0.998× |
| `ISAL_SHARD_PAD` | shard stride | §3.1 / §3.4 |
| `ISAL_ENC_TIMER=full` | the pre-rev-12 encode region | §3.2 |

## Harness

`robust_benchmark.py` drives `rs-point` for both ISA-L labels, passing
`--field 8` for `isal_cauchy` and `--field 16` for `isal_cauchy16`.
**`BENCH_ISAL_SPLIT=1`** falls back to the two separate drivers `rs-point`
replaced, which is the null for the merge over the full grid.

## Build flags

`-O3 -march=native`, since `PERF-NOTES-LARGE-F.md` 3. It was `-O2`, against a
Rust side built at opt-level 3 with thin LTO and `-C target-cpu=native`, which
is a handicap on one of two implementations being compared. Worth 1.10×–1.12×
on transform decode and 1.05×–1.17× on transform encode; the matrix legs, whose
kernels are ISA-L assembly, move under 1%.

## The compiled defaults ARE the recommended configuration

This was not always so. Through 25 August 2026 the compiled defaults were an
earlier codec's behaviour while the recommended values lived only in prose, and
that gap inverted two published ratios before it was closed. **All eight settled
constants were flipped on 26 August**, every historical value remains reachable
as its null, and `robust_benchmark.py` pins every label's knobs rather than
inheriting them.

**It is asserted rather than trusted.** `check.sh`'s `COMPILED DEFAULTS` section
runs the bare driver against the driver told to use the recommended block and
requires byte-identical parity in both fields.

`../docs/DEFAULTS.md` is the current record: every default, what it changes, and
the null it is measured against. **Where this file and that one disagree, that
one is right** — it was written from this driver's own `getenv` sites.

## A note on the citations in this file

Names like `PERF-NOTES-FFT-GF8-PPT.md`, and references to "report §1.9" or
"§4.5", are the project's **internal working notes and its internal status
report. Neither is part of this artifact** and neither is published. They are
kept because each one says which measurement licensed a line of code, and
stripping them would remove the audit trail. `../docs/MAPPING.md` §8 decodes
them and names the shipped document that covers the same ground.
