/*
 * rs_common.h -- what the GF(2^8) and GF(2^16) drivers share.
 *
 * Both were separate programs with these pieces duplicated verbatim: the timer,
 * the SplitMix64 the Rust harness uses so both generate identical source bytes
 * and identical arrival orders, ISA-L's GF(2^8) tables, and the digest. The
 * GF(2^16) driver's GF(2^16) is a tower over exactly this GF(2^8), so it needs
 * these too rather than merely resembling them.
 *
 * Extracted rather than rewritten: every function here is byte-identical to the
 * copy it replaced, so the merge cannot have changed what either driver
 * computes. The one exception was `sm64_fill`, whose two copies differed by a
 * comment.
 */
#ifndef RS_COMMON_H
#define RS_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <erasure_code.h>

/* ---------------------------------------------------------------- timing */

static double now_ms(void)
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1e3 + ts.tv_nsec / 1e6;
}

/* ------------------------------------------------- SplitMix64, from main.rs */

typedef struct {
	uint64_t s;
} sm64;

static uint64_t sm64_next(sm64 *r)
{
	r->s += 0x9e3779b97f4a7c15ULL;
	uint64_t z = r->s;
	z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
	z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
	return z ^ (z >> 31);
}

static void sm64_fill(sm64 *r, unsigned char *dst, size_t n)
{
	size_t i = 0;
	while (i < n) {
		uint64_t x = sm64_next(r);
		size_t m = (n - i < 8) ? (n - i) : 8;
		for (size_t b = 0; b < m; b++)
			dst[i + b] = (unsigned char)(x >> (8 * b));
		i += m;
	}
}

static void sm64_shuffle(sm64 *r, int *a, int n)
{
	for (int i = n - 1; i >= 1; i--) {
		int j = (int)(sm64_next(r) % (uint64_t)(i + 1));
		int t = a[i];
		a[i] = a[j];
		a[j] = t;
	}
}

/* -------------------------------------------------------- GF(2^8), 0x11d */

static unsigned char gf_exp[512], gf_log[256];

static void gf_init(void)
{
	int b = 1;
	for (int i = 0; i < 255; i++) {
		gf_exp[i] = (unsigned char)b;
		gf_log[b] = (unsigned char)i;
		b <<= 1;
		if (b >= 256)
			b = (b - 256) ^ 0x1d;
	}
	for (int i = 255; i < 512; i++)
		gf_exp[i] = gf_exp[i - 255];
}

static inline unsigned char gmul(unsigned char a, unsigned char b)
{
	if (!a || !b)
		return 0;
	return gf_exp[(int)gf_log[a] + (int)gf_log[b]];
}

static inline unsigned char ginv8(unsigned char a)
{
	return gf_exp[255 - (int)gf_log[a]];
}


/* a / b, which the GF(2^8) Cauchy plan needs and the GF(2^16) one reaches
 * through g16div instead. */
static inline unsigned char gdiv8(unsigned char a, unsigned char b)
{
	if (!a)
		return 0;
	return gmul(a, ginv8(b));
}

/* ------------------------------------------------------------- the digest */
static uint64_t fnv1a(const unsigned char *p, size_t n, uint64_t h)
{
	for (size_t i = 0; i < n; i++) {
		h ^= p[i];
		h *= 0x100000001b3ULL;
	}
	return h;
}

/* --------------------------------------------------- the shard pool layout */
/*
 * Moved here verbatim from rs_point.c so that a second driver measuring the
 * same shard pool cannot drift from the rule rs-point uses. Extracted, not
 * rewritten: both functions are byte-identical to the copies they replaced,
 * and ISAL_SHARD_PAD still spells the same thing.
 */

/* stride/64 odd -- hence coprime with 64, so consecutive shards walk all 64 L1
 * sets -- and not 31 or 33, report section 5.13's class. See shard_stride(). */
static int stride_ok(size_t stride)
{
	size_t n = stride / 64;
	return n % 2 == 1 && n != 31 && n != 33;
}

/* Distance between consecutive shards in the pool.
 *
 * The shards live in one pool, so the stride decides which L1 set each shard
 * starts in. Two conflict classes have to be dodged, and dodging one is what
 * used to walk into the other:
 *
 *   - a stride whose 64-byte chunk count shares factors of 2 with 64 confines
 *     the shards to few L1 sets -- Zen 4's L1d indexes on address bits 6-11 --
 *     so the k source streams contend for 8 ways. At the limit, a multiple of
 *     4096 starts every shard in one set. sz = msg_bytes / k with msg_bytes a
 *     power of two, so that is exactly when k is a power of two;
 *   - a stride whose 64-byte chunk count has odd part 31 or 33 -- within one
 *     thirty-second of a power of two -- is the class report section 5.13 found
 *     inside reed-solomon-simd's work buffer, worth 1.2x-1.7x there.
 *
 * Through rev 19 this was "the next odd multiple of 64 at or above sz", which
 * handles the first class and ignores the second -- and forcing stride/64 odd
 * means it lands *on* the second whenever that quotient comes out 31 or 33,
 * i.e. stride 1984 or 2112. sz = 2048 gives 2112 = 64*33, precisely the
 * f = 2048 outlier: the rule meant to avoid conflicts was steering into one.
 *
 * So keep the odd requirement -- it is the stronger form of the first
 * condition, coprimality with 64 rather than merely not 4096 -- and add the
 * second, stepping up by 64 until both hold. Six of the grid's 96 shapes
 * change, all of them 33*64 -> 35*64. Measured at f = 2048, 2048-byte shards:
 * encode 5.45 -> 2.85 ms, decode 15.53 -> 10.12 ms.
 *
 * ISAL_SHARD_PAD:
 *   unset / auto  DEFAULT. The rule above, shared with pool_stride() in the
 *                 Rust harness. NOT the same as stride_64_for() inside the
 *                 crate, though comments here and there once said so:
 *                 stride_64_for excludes only the 31/33 class and does not
 *                 force stride/64 odd, so at a power-of-two shard size it
 *                 leaves the stride alone where this pads it -- 1024 against
 *                 1088 at f = 1023 / 1 MiB, 2048 against 2240 at f = 511.
 *                 Measured at a few percent, in the crate's favour outside the
 *                 grid; left as found because stride = sz is pathological when
 *                 it is a multiple of 4096, which is section 4.1's defect.
 *                 PERF-NOTES-LARGE-F.md 1.2.
 *   odd           the rev-19 rule, the next odd multiple of 64, kept so figures
 *                 taken before this stay reproducible.
 *   0             historical layout, stride = sz, kept so the pre-rev-10
 *                 numbers stay reproducible.
 *   <n>           stride = sz + n. A fixed pad is NOT safe: sz + 64 is a
 *                 multiple of 4096 whenever sz = -64 mod 4096, which is
 *                 f = 40 / 4 MiB and f = 56 / 2 MiB, and there it *creates*
 *                 the collision it removes elsewhere.
 * `recov` is strided the same way for the same reason.
 */
static size_t shard_stride(size_t sz)
{
	const char *sp = getenv("ISAL_SHARD_PAD");
	size_t stride = (sz + 63) & ~(size_t)63;
	if (stride == 0)
		stride = 64;
	if (sp && strcmp(sp, "auto") != 0) {
		if (strcmp(sp, "odd") == 0) {
			if ((stride / 64) % 2 == 0)
				stride += 64;
			return stride;
		}
		return sz + (size_t)atol(sp);
	}
	while (!stride_ok(stride))
		stride += 64;
	return stride;
}


#endif /* RS_COMMON_H */
