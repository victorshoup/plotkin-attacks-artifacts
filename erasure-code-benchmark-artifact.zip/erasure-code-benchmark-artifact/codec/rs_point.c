/*
 * rs_point.c -- one driver, both fields, every encoder and every decoder.
 *
 *   --field 8    GF(2^8) Cauchy.        matrix encode | matrix decode
 *   --field 16   GF(2^16) Cauchy, a tower over that same GF(2^8).
 *                matrix or additive-FFT encode | matrix decode
 *   --field auto DEFAULT: 8 where T <= 256 allows it, 16 otherwise.
 *
 * WHY ONE FILE. These were two programs, `isal_point.c` and `isal_point16.c`,
 * with the timer, the SplitMix64, ISA-L's GF(2^8) tables and the digest
 * duplicated verbatim between them -- and the GF(2^16) is a tower over exactly
 * that GF(2^8), so the duplication was not even incidental. The shared pieces
 * now live in `rs_common.h` and each field keeps its own driver body, because
 * the kernels genuinely differ: a GF(2^8) symbol is a byte and a GF(2^16)
 * symbol is a plane-split pair, and making one body serve both would put a
 * branch inside the loops that exist to have none.
 *
 * The two bodies are the previous files' `main` functions verbatim, renamed.
 * That is deliberate: the merge must not change what either driver measures,
 * and the check for it is that this binary reproduces both of them.
 *
 * The codes, and which parts of them are ours, are documented in the sections
 * below; PERF-NOTES-FFT-CAUCHY.md carries the algebra that makes the GF(2^16)
 * transform and the GF(2^16) matrix decode two views of one code.
 */

#include "rs_common.h"
#include <immintrin.h>
#include <cpuid.h>

/* ======================================================================== */
/*                                 GF(2^8)                                  */
/* ======================================================================== */

/* --------------------------------------------- systematic Cauchy generator */

/* y_j = j for j in [0,k); x_i = k+i for i in [0,T-k). Disjoint, so never 0. */
/*
 * --phase decode: the setup encode is NOT A MEASUREMENT. It exists only to
 * produce a codeword for the decoder to work on, so it is neither reported nor
 * treated as a timing, and the encode field is emitted EMPTY.
 *
 * Empty rather than zero and rather than the value: a consumer that reaches for
 * it gets nothing instead of a wrong number. Reporting it was a mistake. It is
 * ONE COLD ENCODE PER PROCESS, paying that process's page faults on the shard
 * pool and the transform work buffer, and it read 5.1x the interleaved figure
 * at f = 33 / 0.5 MiB while looking like an ordinary encode_ms.
 */
static const char *enc_field(char *buf, size_t n, int phase_decode, double ms)
{
	if (phase_decode)
		buf[0] = '\0';
	else
		snprintf(buf, n, "%.6f", ms);
	return buf;
}

static inline unsigned char cauchy_entry(int k, int i, int j)
{
	return ginv8((unsigned char)((k + i) ^ j));
}

/* ------------------------------- the evaluation-node code, ISAL8_NODES=eval */

/*
 * The SAME nodes as cauchy_entry -- source j at field element j, parity i at
 * k+i -- but the systematic generator of the classical *evaluation* Reed-Solomon
 * code on them rather than the pure Cauchy matrix:
 *
 *     G[i][j] = A_i / ( ((k+i) ^ j) * W_j )
 *     A_i = prod_{l<k} ((k+i) ^ l)        W_j = prod_{l<k, l!=j} (j ^ l)
 *
 * which is report section 2.1's G = diag(A) C diag(1/W) with the nodes taken to
 * be the plain integers. Two reasons this code and not the Cauchy one:
 *
 *  1. it is the code an additive FFT over this field computes, because the FFT
 *     is multipoint evaluation and these are the evaluation points. The Cauchy
 *     code is a different GRS code on the same nodes and no transform reaches it.
 *  2. it is byte-for-byte firedancer's code, verified against their encoder at
 *     seven shapes through k=86 -- see fd_code_check.py and
 *     PERF-NOTES-FFT-GF8-PPT.md section 2. So `references/fd-point --digest` is an
 *     independent-implementation oracle for everything below.
 *
 * W_j and A_i are functions of (k, m) alone, so they are built once per process
 * -- shape-only work, hoisted, as section 3.1 rule 1 requires of every codec.
 * The decoder pays O(k) for them per decode and nothing in the kernel; see
 * cauchy_inverse's sx/sy and fold_closed_form8's spu.
 */
/*
 * ev_D: THE SIZE OF THE DATA NODE SET, and the only thing the padded and the
 * PPT constructions disagree about.
 *
 * The transform interpolates over an aligned block of nodes and evaluates on
 * the blocks above it. PPT solves for the degree-<k polynomial through the k
 * real points, so its node set is 0..k-1 and parity starts at k: ev_D = k.
 * Zero padding instead interpolates the degree-<chunk polynomial that is the
 * data on 0..k-1 and ZERO on k..chunk-1, so its node set is 0..chunk-1 and
 * parity starts at chunk: ev_D = chunk. That is a shortened Reed-Solomon code
 * -- the [chunk+m, chunk] evaluation code restricted to the subspace where
 * coordinates k..chunk-1 vanish -- and shortening preserves MDS.
 *
 * Both are diag(A) C diag(1/W) on their own node set, so ONE parameter covers
 * both and nothing downstream branches:
 *
 *     W_j = prod_{l < ev_D, l != j} (j ^ l)          for j < k
 *     A_i = prod_{l < ev_D}        ((ev_D + i) ^ l)  for i < m
 *
 * One consequence worth knowing at the decoder. When ev_D is a power of two the
 * node set 0..ev_D-1 is a GF(2)-subspace, so W_j = prod_{u != 0, u < ev_D} u is
 * the SAME value for every j -- section 2's observation that W collapses
 * exactly when k is a power of two, seen from the padded side, where it holds
 * at every shape. The 1/W diagonals then cancel identically in B^-1 E and only
 * the A diagonal survives. Nothing below special-cases that; it falls out.
 */
static int ev_on = 1;			/* ISAL8_NODES; DEFAULT eval since 2026-08-26 */
static unsigned ev_kp;			/* ISAL8_INTERP: the pivot base, k..chunk */
static unsigned ev_D;			/* data node set is 0..ev_D-1; == ev_kp */
static unsigned char *ev_W, *ev_Wi;	/* k entries: W_j and 1/W_j */
static unsigned char *ev_A, *ev_Ai;	/* m entries: A_i and 1/A_i */

/* Shard index -> evaluation node. Data shards sit at their own index under both
 * constructions; parity shard k+i sits at ev_D+i, which is k+i only when the
 * node set stops at k. Every place that treats a shard index as a field element
 * must go through this. */
static inline unsigned char node_of(int k, int idx)
{
	return (unsigned char)(idx < k ? idx : (int)ev_D + (idx - k));
}

static void eval_tables_init(int k, int m, unsigned D)
{
	ev_D = D;
	ev_W = malloc((size_t)k); ev_Wi = malloc((size_t)k);
	ev_A = malloc((size_t)m); ev_Ai = malloc((size_t)m);
	if (!ev_W || !ev_Wi || !ev_A || !ev_Ai) {
		fprintf(stderr, "eval node table allocation failed\n");
		exit(1);
	}
	for (int j = 0; j < k; j++) {
		unsigned char w = 1;
		for (unsigned l = 0; l < D; l++)
			if ((int)l != j)
				w = gmul(w, (unsigned char)(j ^ (int)l));
		ev_W[j] = w;
		ev_Wi[j] = ginv8(w);
	}
	for (int i = 0; i < m; i++) {
		unsigned char a = 1;
		for (unsigned l = 0; l < D; l++)
			a = gmul(a, (unsigned char)(((int)D + i) ^ (int)l));
		ev_A[i] = a;
		ev_Ai[i] = ginv8(a);
	}
}

static inline unsigned char eval_entry(int k, int i, int j)
{
	(void)k;
	return gmul(gmul(ev_A[i], ev_Wi[j]),
		    ginv8((unsigned char)(((int)ev_D + i) ^ j)));
}

/* The generator entry actually in force, for the naive fold and the ge plan. */
static inline unsigned char gen_entry(int k, int i, int j)
{
	return ev_on ? eval_entry(k, i, j) : cauchy_entry(k, i, j);
}

/*
 * Closed-form inverse of the Cauchy matrix C[a][b] = 1/(xs[a]^ys[b]), O(n^2).
 *
 *   (C^-1)[b][a] = ( prod_l (x_a^y_l) * prod_l (x_l^y_b) )
 *                / ( (x_a^y_b) * prod_{l!=a}(x_a^x_l) * prod_{l!=b}(y_b^y_l) )
 *
 * out is n*n, row-major, out[b*n + a].
 */
/*
 * sx and sy carry the two diagonals of the evaluation-node code, or are NULL
 * for the pure Cauchy one. B = diag(A) C_B diag(1/W_y) inverts to
 * diag(W_y) C_B^-1 diag(1/A), so scaling nx[a] by 1/A and ny[b] by W_y here --
 * n multiplies each, before the n^2 loop -- turns this into that inverse
 * without touching the O(n^2) term or the kernel. PERF-NOTES-FFT-GF8-PPT.md
 * section 3; fd_code_check.py checks it against a Gaussian-elimination inverse.
 */
static void cauchy_inverse(const unsigned char *xs, const unsigned char *ys,
			   int n, unsigned char *out,
			   unsigned char *nx, unsigned char *ny,
			   const unsigned char *sx, const unsigned char *sy)
{
	for (int a = 0; a < n; a++) {
		unsigned char num = 1, den = 1;
		for (int l = 0; l < n; l++) {
			num = gmul(num, (unsigned char)(xs[a] ^ ys[l]));
			if (l != a)
				den = gmul(den, (unsigned char)(xs[a] ^ xs[l]));
		}
		nx[a] = gdiv8(num, den);
	}
	for (int b = 0; b < n; b++) {
		unsigned char num = 1, den = 1;
		for (int l = 0; l < n; l++) {
			num = gmul(num, (unsigned char)(xs[l] ^ ys[b]));
			if (l != b)
				den = gmul(den, (unsigned char)(ys[b] ^ ys[l]));
		}
		ny[b] = gdiv8(num, den);
	}
	if (sx)
		for (int a = 0; a < n; a++)
			nx[a] = gmul(nx[a], sx[a]);
	if (sy)
		for (int b = 0; b < n; b++)
			ny[b] = gmul(ny[b], sy[b]);
	for (int b = 0; b < n; b++)
		for (int a = 0; a < n; a++)
			out[b * n + a] =
				gdiv8(gmul(nx[a], ny[b]),
				     (unsigned char)(xs[a] ^ ys[b]));
}

/*
 * The received-source columns of the decode matrix, in O(r * n_orig).
 *
 * The rows we need are  R = [ B^-1 | B^-1 E ]  where B[a][b] = 1/(xs_a ^ ys_b)
 * is the r x r residual Cauchy system on the received parity shards xs and the
 * missing source shards ys, and E[a][c] = 1/(xs_a ^ u_c) covers the received
 * source shards u. B^-1 is cauchy_inverse above. Forming B^-1 E as an actual
 * matrix product costs r^2 * n_orig multiplies, ~0.148 k^3; it collapses to
 *
 *     (B^-1 E)[b][c] = ny_b * P(u_c) / (ys_b ^ u_c),
 *     P(w) = prod_l (w ^ ys_l) / prod_l (w ^ xs_l),
 *
 * by partial fractions in characteristic 2. The derivation is written out in
 * full in isal_point16.c::fold_closed_form; this is the same twenty lines with
 * uint16_t replaced by unsigned char, and nothing in it is field-specific.
 * P(u_c) is 2r multiplies and one inversion per column, computed once for all
 * b, and every entry is then one multiply and one division. Both products are
 * nonzero: u_c is a received source index, so it differs from every missing
 * ys_l and, being < k, from every parity xs_l >= k.
 *
 * --fold naive computes the same rows by the explicit product. Both are checked
 * per trial against the original source bytes, and check.sh additionally holds
 * this driver against tape_cauchy, which computes the identical code on a
 * different library's kernels.
 */
static void fold_closed_form8(const unsigned char *xs, const unsigned char *ys,
			     const unsigned char *ny, int r,
			     const int *recv_orig, const int *orig_col, int n_orig,
			     unsigned char *pu, int k, unsigned char *rows,
			     const unsigned char *spu)
{
	for (int c = 0; c < n_orig; c++) {
		unsigned char u = (unsigned char)recv_orig[c], num = 1, den = 1;
		for (int l = 0; l < r; l++) {
			num = gmul(num, (unsigned char)(u ^ ys[l]));
			den = gmul(den, (unsigned char)(u ^ xs[l]));
		}
		pu[c] = gdiv8(num, den);
	}
	/* B^-1 E = diag(W_y) (C_B^-1 C_E) diag(1/W_u): ny already carries W_y from
	 * cauchy_inverse, and this is the other diagonal -- n_orig multiplies. The
	 * parity-side diag(A) cancels, because B and E share their rows. */
	if (spu)
		for (int c = 0; c < n_orig; c++)
			pu[c] = gmul(pu[c], spu[c]);
	for (int b = 0; b < r; b++)
		for (int c = 0; c < n_orig; c++)
			rows[(size_t)b * k + orig_col[c]] =
				gdiv8(gmul(ny[b], pu[c]),
				     (unsigned char)(ys[b] ^ (unsigned char)recv_orig[c]));
}

/*
 * FNV-1a 64 over the whole coded block, shard 0..T-1 in index order. Used by
 * --digest to compare this driver's encoder against tape_cauchy's: the two
 * compute the same systematic Cauchy code over the same GF(2^8), so at a given
 * --f/--shard-bytes/--seed the digests must match. Nothing else in the harness
 * checks that; see rev 7 section 9.6.
 */

/* The GF(2^8) additive-FFT encoder, defined below with the rest of the
 * transform because it needs ISA-L's affine table. ISAL8_ENCODE=fft. */
/* ISAL8_ENC_PHASES: where the transform encode's time goes, in the same buckets
 * ISAL16_ENC_PHASES uses so the two encoders can be read side by side. */
static int  fft8_phases;
static double fft8_ph[4];		/* copy_in, ppt, coset_copy, coset_fft */
static long fft8_ph_n;
static unsigned long fft8_cnt_b1, fft8_cnt_b2, fft8_cnt_b3;
static unsigned long fft8_cnt_mm22, fft8_cnt_single;
static unsigned fft8_chunk, fft8_ncos, fft8_direct;
static int  fft8_init(int k, int m, size_t stride);
static unsigned fft8_pick_kp(int k, int m, unsigned chunk);
static void fft8_encode(int k, int m, size_t sz,
			unsigned char *const *src, unsigned char *const *par);

/* ------------------------------------------------------------------- args */

/* ------------------------------------------------- arrival selection */

/*
 * The receiver takes order[0..k-1]. `random` is the seeded shuffle exactly as
 * rs_common.h's sm64_shuffle leaves it; this rewrites it for the other modes.
 *
 * `parity` STABLY PARTITIONS that shuffle so parity nodes (index >= k) come
 * first. The receiver then holds k parity shards and NO original, which is the
 * maximum residual system, r = k. That is an arrival pattern the AVID setting's
 * Byzantine disperser can choose outright: it picks which k parties hold a
 * fragment and nothing obliges it to pick the systematic ones.
 *
 * STABLE, and over the SAME seeded shuffle, on purpose. The shuffle still
 * decides which parity shards arrive and in what column order; only the CLASS
 * of the arriving shard differs between the two modes, so a random-vs-parity
 * delta isolates that and not the RNG. `sm64_shuffle` is the bit-exact contract
 * with the Rust driver -- MANIFEST.md -- and this partition joins that
 * contract: src/main.rs carries the identical function, so both drivers select
 * the same arrivals at the same seed.
 *
 * NAMED FOR WHAT IT SELECTS, NOT WHAT IT COSTS. It is the matrix decoder's
 * worst case; the transform decoder cannot tell it from `random`, and RS--16
 * being measured under both decoders in this mode is the point of having it.
 *
 * Feasible iff t - k >= k. At this project's rate t = 3f+1 and k = f+1, so
 * there are 2f parity nodes against the f+1 wanted and it cannot fail for
 * f >= 1. The check is here so the result is right by construction rather than
 * by that argument holding at every caller, as fft8_pick_kp's clamp is.
 */
static int arrivals_parity_first(int *a, int *scratch, int k, int n)
{
	if (n - k < k) {
		fprintf(stderr, "--arrivals parity needs t-k>=k (t=%d k=%d)\n", n, k);
		return -1;
	}
	int w = 0;
	for (int i = 0; i < n; i++)
		if (a[i] >= k)
			scratch[w++] = a[i];
	for (int i = 0; i < n; i++)
		if (a[i] < k)
			scratch[w++] = a[i];
	for (int i = 0; i < n; i++)
		a[i] = scratch[i];
	return 0;
}

static void usage_gf8(const char *p)
{
	fprintf(stderr,
		"usage: %s --f F --shard-bytes N [options]\n"
		"  --plan P     ge|cauchy   (default: ge)\n"
		"  --fold F     closed-form|naive  received-source columns of the\n"
		"               --plan cauchy rows (default: closed-form)\n"
		"  --gen G      rs|cauchy1  ISA-L generator for --plan ge (default: cauchy1;\n"
		"               rs is NOT MDS at these shapes and will fail ~0.4%% of patterns)\n"
		"  --trials N   measured trials (default 20)\n"
		"  --warmup N   warmup trials (default 3)\n"
		"  --seed N     base seed (default 1)\n"
		"  --k K --m M  explicit shape instead of k=f+1, m=2f\n"
		"  --arrivals A random|first|parity  which k shards the receiver got\n"
		"  --stripes N  split each shard into N byte-ranges; plan and tables\n"
		"               are built once and reused across them (default 1)\n"
		"  --no-verify  skip the reconstruction check\n"
		"  --digest     encode once and print an FNV-1a 64 digest of all T coded\n"
		"               shards, then exit; for cross-library comparison\n",
		p);
}
static int run_gf8(int argc, char **argv)
{
	int f = -1;
	long shard_bytes = -1;
	int stripes = 1;
	int trials = 20, warmup = 3, verify = 1;
	uint64_t seed = 1;
	int use_cauchy = 0, naive_fold = 0, digest_only = 0;
	/* --phase decode: encode ONCE before the loop, then time decode alone.
	 * Default 0 = the interleaved loop, unchanged and byte-identical, which
	 * stays the null. See the block above the trial loop. */
	int phase_decode = 0;
	int phase_encode = 0;
	int gen_rs = 0; /* 0 = gf_gen_cauchy1_matrix (MDS), 1 = gf_gen_rs_matrix */
	int k_arg = -1, m_arg = -1, arrivals_first = 0, arrivals_parity = 0;

	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--f") && i + 1 < argc)
			f = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--shard-bytes") && i + 1 < argc)
			shard_bytes = atol(argv[++i]);
		else if (!strcmp(argv[i], "--stripes") && i + 1 < argc)
			stripes = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--trials") && i + 1 < argc)
			trials = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--warmup") && i + 1 < argc)
			warmup = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--seed") && i + 1 < argc)
			seed = strtoull(argv[++i], NULL, 10);
		/* Consumed by main() to pick the body; each body ignores it so the
		 * argument vector it sees is otherwise the one it always saw. */
		else if (!strcmp(argv[i], "--field") && i + 1 < argc)
			i++;
		else if (!strcmp(argv[i], "--no-verify"))
			verify = 0;
		else if (!strcmp(argv[i], "--digest"))
			digest_only = 1;
		else if (!strcmp(argv[i], "--phase") && i + 1 < argc) {
			const char *ph = argv[++i];
			if (!strcmp(ph, "decode"))
				phase_decode = 1;
			else if (!strcmp(ph, "encode"))
				phase_encode = 1;
			else if (strcmp(ph, "both")) {
				fprintf(stderr, "--phase must be both, encode or decode\n");
				return 2;
			}
		}
		else if (!strcmp(argv[i], "--plan") && i + 1 < argc) {
			const char *p = argv[++i];
			if (!strcmp(p, "cauchy"))
				use_cauchy = 1;
			else if (!strcmp(p, "ge"))
				use_cauchy = 0;
			else {
				fprintf(stderr, "unknown --plan %s\n", p);
				return 2;
			}
		} else if (!strcmp(argv[i], "--fold") && i + 1 < argc) {
			const char *fd = argv[++i];
			if (!strcmp(fd, "naive"))
				naive_fold = 1;
			else if (!strcmp(fd, "closed-form"))
				naive_fold = 0;
			else {
				fprintf(stderr, "unknown --fold %s\n", fd);
				return 2;
			}
		} else if (!strcmp(argv[i], "--gen") && i + 1 < argc) {
			const char *g = argv[++i];
			if (!strcmp(g, "rs"))
				gen_rs = 1;
			else if (!strcmp(g, "cauchy1"))
				gen_rs = 0;
			else {
				fprintf(stderr, "unknown --gen %s; use rs or cauchy1\n", g);
				return 2;
			}
		} else if (!strcmp(argv[i], "--k") && i + 1 < argc) {
			k_arg = atoi(argv[++i]);
		} else if (!strcmp(argv[i], "--m") && i + 1 < argc) {
			m_arg = atoi(argv[++i]);
		} else if (!strcmp(argv[i], "--arrivals") && i + 1 < argc) {
			const char *a = argv[++i];
			if (!strcmp(a, "random")) { arrivals_first = 0; arrivals_parity = 0; }
			else if (!strcmp(a, "first")) { arrivals_first = 1; arrivals_parity = 0; }
			else if (!strcmp(a, "parity")) { arrivals_first = 0; arrivals_parity = 1; }
			else { fprintf(stderr, "unknown --arrivals %s\n", a); return 2; }
		} else if (!strcmp(argv[i], "--codec") && i + 1 < argc) {
			i++; /* accepted and ignored, for driver symmetry */
		} else {
			usage_gf8(argv[0]);
			return 2;
		}
	}
	/* --k/--m give an explicit shape instead of the harness's k=f+1, m=2f, so
	 * shapes off the n = 3f+1 rate can be probed. fd-point has the same pair and
	 * spells them the same way; `f` is then only a label. Grid legs never pass
	 * them, and the null is that --k f+1 --m 2f reproduces the default digest. */
	if ((k_arg > 0) != (m_arg > 0)) {
		fprintf(stderr, "--k and --m must be given together\n");
		return 2;
	}
	if (k_arg > 0 && f < 1)
		f = k_arg - 1;
	if (f < 1 || shard_bytes < 1) {
		usage_gf8(argv[0]);
		return 2;
	}

	int k = k_arg > 0 ? k_arg : f + 1;
	int m = m_arg > 0 ? m_arg : 2 * f;
	int t = k + m;
	if (t > 256) {
		fprintf(stderr, "ISA-L GF(2^8) needs T<=256, but f=%d gives T=%d\n", f, t);
		return 2;
	}
	size_t sz = (size_t)shard_bytes;
	gf_init();

	/* ISAL8_NODES: `eval` -- THE DEFAULT, see the block immediately below -- is
	 * the evaluation code on the nodes, the one an additive FFT can encode, and
	 * is firedancer's. `cauchy` is the pure Cauchy generator this driver used
	 * originally and is now the reachable null. Both are MDS and both are
	 * decoded by the same closed-form plan; they produce different parity
	 * bytes. See eval_tables_init above.
	 *
	 * CORRECTED 1 September 2026: this paragraph called `cauchy` the default,
	 * contradicting the block below it and `ev_on`'s initialiser ever since the
	 * 26 August flip. NO MEASUREMENT WAS EVER AFFECTED -- robust_benchmark.py
	 * pins ISAL8_NODES per label and never inherits a compiled default, which
	 * is exactly the rule the block below explains. Keep the two in agreement:
	 * they sit one directly against the other and drifted anyway. */
	{
		/* DEFAULT `eval` since 2026-08-26: DEFAULTS.md policy 1, the default
		 * is the best measured configuration. `eval` is X's code and X takes
		 * encode, decode and the sum from every codec in the report at all 48
		 * sub-boundary points (section 6.1). `cauchy` is the reachable null
		 * (policy 3) and is what `isal_cauchy` means -- robust_benchmark.py
		 * pins it explicitly for that label rather than inheriting it, which
		 * is the lesson of the 26 Aug leopard note: a LABEL must never depend
		 * on a compiled default. */
		const char *nv = getenv("ISAL8_NODES");
		ev_on = 1;
		if (nv && !strcmp(nv, "cauchy"))
			ev_on = 0;
		else if (nv && strcmp(nv, "eval")) {
			fprintf(stderr, "unknown ISAL8_NODES=%s; use cauchy or eval\n", nv);
			return 2;
		}
	}
	/*
	 * ISAL8_INTERP: which interpolation the eval-node code is built on.
	 *
	 *   ppt   parity at k+i, reaches every shape with ceil((k+m)/chunk)*chunk
	 *         <= 256, i.e. f <= 85. Firedancer's code, so `fd-point --digest`
	 *         is an oracle for it. THE DEFAULT -- the null this driver has
	 *         measured since aeed769, and it does not move without a leg.
	 *   pad   parity at chunk+i, needs chunk + m <= 256, i.e. f <= 64 at
	 *         n = 3f+1. A DIFFERENT CODE from firedancer's, so it forfeits
	 *         that oracle; the matrix encoder on the same nodes remains one,
	 *         and is the stronger of the two anyway (section 10.6).
	 *   auto  pad where it fits, ppt above it.
	 *
	 * This selects a CODE, not an encoder: it moves the parity nodes, so the
	 * matrix path must compute the same thing the transform does. That is the
	 * point -- ISAL8_ENCODE=matrix under =pad is the oracle for =fft under
	 * =pad, exactly as it is for ppt.
	 */
	unsigned ev_chunk = 1;
	while (ev_chunk < (unsigned)k)
		ev_chunk <<= 1;
	{
		/*
		 * THE PIVOT BASE kp, which is what ppt and pad are the two ends of.
		 *
		 * Interpolate the degree-<kp polynomial through the data at 0..k-1 AND
		 * ZEROS at k..kp-1, pivoting only on the top chunk-kp coordinates.
		 * Parity then starts at kp. So:
		 *
		 *   kp = k       every coordinate above k is pivoted -- plain PPT,
		 *                firedancer's code, most parity nodes, most glue
		 *   kp = chunk   nothing is pivoted, the block is a plain zero-padded
		 *                IFFT -- no glue at all, but it burns chunk-k nodes on
		 *                zeros, so it needs chunk + m <= 256
		 *   between      partial pivot: glue scales with chunk - kp, and the
		 *                node cost with kp
		 *
		 * The node budget is the binding constraint and it is exact: parity
		 * occupies kp .. kp+m-1, so kp <= 256 - m. Maximising the padding
		 * therefore means
		 *
		 *     kp = min(chunk, 256 - m)
		 *
		 * which is feasible iff k <= 256 - m, i.e. iff T <= 256 -- the whole
		 * reachable region, same as plain PPT. That is `auto`, and it is at
		 * least as good as both endpoints at every shape.
		 *
		 * WHAT THIS CORRECTS. A matrix tail on the last coset cannot substitute
		 * for this. A tail changes how a parity shard is COMPUTED, not which
		 * node it sits at, so it does not move the budget: at f = 65 padding
		 * wants nodes 128..257 and there is no 257. Section 10.5's "regime B"
		 * -- pad plus a tail reaching f = 65..70 -- is wrong for that reason.
		 * Trading pivots against nodes is what actually reaches there.
		 */
		const char *iv = getenv("ISAL8_INTERP");
		unsigned kp_max = (unsigned)(256 - m);		/* T <= 256 => >= k */
		unsigned kp_best = ev_chunk < kp_max ? ev_chunk : kp_max;
		/* Without the eval nodes there is no pivot base to choose: the pure
		 * Cauchy code puts parity shard i at node k+i by definition, so kp is
		 * k and `auto` must say so rather than costing a choice it cannot
		 * apply. Defaulting to `auto` without this made every isal_cauchy
		 * shape with k != chunk refuse to run. Same shape of leak as the ev_D
		 * one: eval-only logic reaching the path that does not use it. */
		if (!iv || !strcmp(iv, "auto"))
			ev_kp = ev_on ? fft8_pick_kp(k, m, ev_chunk) : (unsigned)k;
		else if (!strcmp(iv, "ppt"))
			ev_kp = (unsigned)k;
		else if (!strcmp(iv, "pad")) {
			if (ev_chunk > kp_max) {
				fprintf(stderr, "ISAL8_INTERP=pad needs chunk+m<=256; "
					"k=%d gives chunk=%u and m=%d, so %u. Use auto, "
					"which pivots just enough to fit (kp=%u).\n",
					k, ev_chunk, m, ev_chunk + m, kp_best);
				return 2;
			}
			ev_kp = ev_chunk;
		} else {
			const char *e = NULL;
			long v = strtol(iv, (char **)&e, 10);
			if (e && *e == '\0' && v >= k && (unsigned)v <= kp_max
			    && (unsigned)v <= ev_chunk)
				ev_kp = (unsigned)v;	/* explicit kp, for the sweep */
			else {
				fprintf(stderr, "unknown ISAL8_INTERP=%s; use ppt, pad, auto, "
					"or an explicit pivot base in [%d,%u]\n",
					iv, k, kp_best);
				return 2;
			}
		}
		if (ev_kp != (unsigned)k && !ev_on) {
			fprintf(stderr, "ISAL8_INTERP=%s requires ISAL8_NODES=eval\n", iv);
			return 2;
		}
		/* UNCONDITIONALLY, and this block is the only place that runs for
		 * every ISAL8_NODES setting. node_of() reads ev_D on the pure Cauchy
		 * path too, where the parity node IS the shard index -- which is what
		 * ev_D = k gives. Leaving it at 0 there mapped parity shard k+i to node
		 * i, silently, and check.sh's materialized-source oracle caught it at
		 * all 12 shapes; eval-only testing did not, because eval sets it. */
		ev_D = ev_kp;
	}
	if (ev_on) {
		eval_tables_init(k, m, ev_kp);
		if (!use_cauchy) {
			fprintf(stderr, "ISAL8_NODES=eval needs --plan cauchy\n");
			return 2;
		}
	}

	/* ISAL8_ENCODE=fft routes encode through the additive transform instead of
	 * ec_encode_data. It computes the SAME code -- the one ISAL8_NODES=eval
	 * selects -- so it must emit the same parity bytes, and the decoder does not
	 * change by a line. That equality is the oracle: `--digest` under
	 * ISAL8_ENCODE=matrix and under =fft must agree, and both must agree with
	 * references/fd-point. */
	/* DEFAULT `fft` since 2026-08-26. It is worth 1.61 / 3.29 / 5.37 against
	 * the matrix encoder (section 5.33) and is the whole point of X. `matrix`
	 * is the reachable null and is what `isal_x_dec` selects. */
	int enc_fft = 1;
	{
		const char *ev = getenv("ISAL8_ENCODE");
		if (ev && !strcmp(ev, "matrix"))
			enc_fft = 0;
		else if (ev && strcmp(ev, "fft")) {
			fprintf(stderr, "unknown ISAL8_ENCODE=%s; use matrix or fft\n", ev);
			return 2;
		}
	}
	if (enc_fft && !ev_on) {
		fprintf(stderr, "ISAL8_ENCODE=fft requires ISAL8_NODES=eval\n");
		return 2;
	}

	/* Generator matrix, t x k, row-major. Rows [0,k) are the identity. */
	unsigned char *gen = malloc((size_t)t * k);
	if (use_cauchy) {
		memset(gen, 0, (size_t)t * k);
		for (int j = 0; j < k; j++)
			gen[j * k + j] = 1;
		for (int i = 0; i < m; i++)
			for (int j = 0; j < k; j++)
				gen[(k + i) * k + j] = gen_entry(k, i, j);
	} else if (gen_rs) {
		gf_gen_rs_matrix(gen, t, k);
	} else {
		gf_gen_cauchy1_matrix(gen, t, k);
	}

	size_t stride = shard_stride(sz);

	/* Encode timer. DEFAULT lean: ec_encode_data alone, which is what the Rust
	 * harness's encode timer contains. ISAL_ENC_TIMER=full restores the
	 * pre-rev-10 region, which also timed the k*sz scatter into the shard pool
	 * and a per-trial ec_init_tables that the generator never invalidates. */
	/* Decode working memory: allocated inside the timed region, per call.
	 *
	 * R10's decode timer holds `ManagedDecoder::new` and a freshly allocated
	 * message; RaptorQ's holds its decoder; reed-solomon-simd's now holds its
	 * work buffer. Those are the codecs this one is compared against, so
	 * holding these above the trial loop measured a different contract. The
	 * rule adopted is: hoist out of the stripes, never out of the decode.
	 *
	 * ISAL_ALLOC_PER_CALL=0 restores the held buffers, for reproducing figures
	 * taken before the rule. The free is outside the timer, as every other
	 * codec's is -- R10 drops its decoder when the function returns. */
	int alloc_per_call = !getenv("ISAL_ALLOC_PER_CALL")
			     || strcmp(getenv("ISAL_ALLOC_PER_CALL"), "0") != 0;
	const char *et = getenv("ISAL_ENC_TIMER");
	int enc_timer_lean = !et || strcmp(et, "full") != 0;

	/* Buffers.
	 *
	 * The shard pool is page-aligned, not malloc-aligned. A 12.5 MB malloc is
	 * served by mmap and the chunk header puts the payload at page + 16, so
	 * every shard starts 16 bytes into a cache line and every 64-byte vector
	 * access straddles two. Measured at f = 80 / 4 MiB that is worth up to
	 * 1.29x on encode, and it moved with the base address alone -- same stride,
	 * same code, same pool size. Both harnesses now align the pool, so neither
	 * codec is measured on a misaligned buffer and neither is at the mercy of
	 * what the allocator happened to return.
	 *
	 * ISAL_POOL_SKEW=<n>: start the shards n bytes into the pool. The
	 * diagnostic that established the above; the Rust driver has TAPE_POOL_SKEW.
	 */
	size_t pool_skew = getenv("ISAL_POOL_SKEW") ? (size_t)atol(getenv("ISAL_POOL_SKEW")) : 0;
	unsigned char *src = malloc((size_t)k * sz);
	unsigned char **shard = malloc((size_t)t * sizeof(*shard));
	size_t pool_bytes = (size_t)t * stride + pool_skew;
	pool_bytes = (pool_bytes + 4095) & ~(size_t)4095;
	unsigned char *pool_base = aligned_alloc(4096, pool_bytes);
	unsigned char *pool = pool_base + pool_skew;
	memset(pool_base, 0, pool_bytes);
	for (int i = 0; i < t; i++)
		shard[i] = pool + (size_t)i * stride;
	if (getenv("ISAL_POOL_TRACE"))
		fprintf(stderr, "pool base=%p shards_at=%p stride=%zu\n",
			(void *)pool_base, (void *)pool, stride);

	unsigned char *enc_tab = malloc((size_t)k * m * 32);
	unsigned char **enc_out = malloc((size_t)m * sizeof(*enc_out));
	/* Striped pointer arrays. Allocated whether or not --stripes > 1 is used,
	 * so the two configurations differ only in the work inside the timer and
	 * not in what the allocator has been asked for -- rev 11 section 3.6. */
	unsigned char **str_in = malloc((size_t)k * sizeof(*str_in));
	/* t entries, not k: encode drives m = t - k outputs, and m exceeds k at
	 * every rate below 1/2 -- 170 against 86 at f = 85. Decode drives r <= k. */
	unsigned char **str_out = malloc((size_t)t * sizeof(*str_out));

	int *order = malloc((size_t)t * sizeof(int));
	int *order_scratch = malloc((size_t)t * sizeof(int));
	unsigned char *sub = malloc((size_t)k * k);
	unsigned char *inv = malloc((size_t)k * k);
	unsigned char *rows = malloc((size_t)k * k);
	unsigned char *dec_tab = malloc((size_t)k * k * 32);
	unsigned char **dec_in = malloc((size_t)k * sizeof(*dec_in));
	unsigned char **dec_out = malloc((size_t)k * sizeof(*dec_out));
	/* recov retired: reconstruction is in place into the shard pool. */
	unsigned char *whole = malloc((size_t)k * sz); /* materialized source */
	unsigned char *xs = malloc((size_t)k), *ys = malloc((size_t)k);
	unsigned char *nx = malloc((size_t)k), *ny = malloc((size_t)k);
	/* The per-decode selections out of the hoisted ev_* tables: 1/A on the
	 * received parity, W on the missing sources, 1/W on the received sources.
	 * r + r + n_orig <= 2k multiplies per decode, against an O(r^2) plan. */
	unsigned char *ev_sx = malloc((size_t)k), *ev_sy = malloc((size_t)k);
	unsigned char *ev_spu = malloc((size_t)k);
	unsigned char *binv = malloc((size_t)k * k);
	unsigned char *pu = malloc((size_t)k);
	int *missing = malloc((size_t)k * sizeof(int));
	int *par_col = malloc((size_t)k * sizeof(int));
	int *orig_col = malloc((size_t)k * sizeof(int));
	int *recv_par = malloc((size_t)k * sizeof(int));
	int *recv_orig = malloc((size_t)k * sizeof(int));
	char *got = malloc((size_t)t);
	/* --phase decode's codeword, built once at setup and never written
	 * again. NULL under the default interleaved loop. */
	unsigned char *code = NULL;

	/* Stripe length, rounded up to 64 so every stripe but the last is a whole
	 * number of the kernel's 64-byte blocks. --stripes 1 leaves `stripe == sz`,
	 * which takes the single-call path below and is byte-for-byte the released
	 * spelling. */
	if (stripes < 1)
		stripes = 1;
	size_t stripe = stripes == 1
		? sz
		: (((sz + (size_t)stripes - 1) / (size_t)stripes + 63) & ~(size_t)63);
	if (stripe > sz)
		stripe = sz;

	printf("f,k,T,symbol_bytes,trial,codec,tape_field,tape_gen,plan_algo,"
	       "encode_ms,decode_ms,plan_ms,code_ms,symbols_consumed,consumed_per_k\n");

	/*
	 * The encode tables, built ONCE -- above the loop, not merely above the
	 * timer.
	 *
	 * The comment below already said the generator does not change between
	 * trials, and rev 10 moved this call out of the *timer* on exactly that
	 * argument. It stayed inside the *loop*, so every trial still rebuilt it:
	 * k*m*32 bytes of writes that nothing had invalidated, immediately before
	 * the region being measured. Outside both timers, so no figure moves --
	 * measured -- but it is wall time and cache footprint that no deployment
	 * spends. `ISAL_ENC_TIMER=full` still rebuilds per trial inside the timer,
	 * which is the point of that null.
	 */
	if (enc_timer_lean)
		ec_init_tables(k, m, gen + (size_t)k * k, enc_tab);
	/* Shape-only, outside both timers, exactly as ec_init_tables is: the skew
	 * table, the PPT op list and the transform's work buffers. */
	if (enc_fft) {
		if (stripe != sz) {
			fprintf(stderr, "ISAL8_ENCODE=fft does not stripe\n");
			return 2;
		}
		if (fft8_init(k, m, stride) < 0) {
			fprintf(stderr,
				"GF(2^8) cannot host the transform at f=%d "
				"(k=%d m=%d): ceil((k+m)/next_pow2(k))*next_pow2(k) > 256\n",
				f, k, m);
			return 2;
		}
	}
	char encbuf[32];
	for (int trial = -warmup; trial < trials; trial++) {
		uint64_t s = seed ^ ((uint64_t)f << 48) ^ ((uint64_t)k << 32) ^ (uint64_t)t
			^ (((uint64_t)sz << 17) | ((uint64_t)sz >> 47))
			^ (trial < 0
			   ? (uint64_t)(trial + warmup) * 0x9e3779b97f4a7c15ULL
			   : (uint64_t)(trial + warmup) * 0xd1b54a32d192ed03ULL);

		/* Under --phase decode the message is filled and encoded ONCE, at the
		 * first warmup trial, and every later trial re-decodes that same
		 * codeword under a FRESH ERASURE PATTERN -- which is what decode time
		 * actually depends on. `order` therefore still varies per trial.
		 *
		 * NOTHING CARRIES BETWEEN TRIALS, and verification is not what makes
		 * that true. The codeword is snapshotted into `code` at setup and never
		 * written again; the copy-in below restores every slot this trial
		 * decodes from out of that snapshot, and the zeroing makes the erased
		 * message slots well-defined -- both before the timer starts. So the
		 * decoder's input is fully determined by this trial's erasure pattern
		 * whatever the previous trial's decode wrote. Verification is a plain
		 * correctness check, exactly as it is in the interleaved loop.
		 *
		 * WHAT THIS PARAGRAPH REPLACES, because the claim outlived the design
		 * and a defect note has already been written from it once: it used to
		 * say the pool returned to its encoded state ONLY because a verified
		 * decode had written the original bytes back, that verification was
		 * therefore load-bearing, and that `--no-verify` was refused with
		 * `--phase decode`. That refusal was real, it guarded the RESTORE
		 * design, and it was deliberately deleted together with that design
		 * when the copy-in landed -- see the copy-in's own comment for why a
		 * copy and not the narrower restore. Only this comment was left behind.
		 * DO NOT RE-ADD THE GUARD FROM THIS TEXT. */
		int do_encode = !phase_decode || trial == -warmup;
		if (do_encode) {
			sm64 rs = { s ^ 0x535243ULL };
			sm64_fill(&rs, src, (size_t)k * sz);
		}
		for (int i = 0; i < t; i++)
			order[i] = i;
		sm64 ro = { s ^ 0x4f52444552ULL };
		sm64_shuffle(&ro, order, t);
		/* `random` and `first` reach the selection below byte-identically to
		 * before this mode existed; only `parity` rewrites the order here. */
		if (arrivals_parity &&
		    arrivals_parity_first(order, order_scratch, k, t) < 0)
			return 2;

		/* --phase decode reports the ONE setup encode in every row, so the
		 * column stays populated and self-consistent. It is a single cold
		 * measurement and is NOT the encode number of record -- that still
		 * comes from the interleaved run, which is the null. */
		/* Zero and unused under --phase decode: the setup encode is not a
		 * measurement and no value is carried between trials. enc_field()
		 * emits the column EMPTY there. */
		double encode_ms = 0.0;
		if (do_encode) {
			/* ---- encode ----
			 * ISAL_ENC_TIMER=lean times ec_encode_data alone. The default also
			 * times the k*sz scatter into the shard pool and a full
			 * ec_init_tables, neither of which the Rust harness's encode timer
			 * contains: run_tape8 encodes straight out of the caller's contiguous
			 * source, and tape's RowTables are built once in the codec, not per
			 * trial. The generator does not change between trials, so building its
			 * tables here is repeated work, not required work. */
			if (enc_timer_lean) {
				for (int i = 0; i < k; i++)
					memcpy(shard[i], src + (size_t)i * sz, sz);
			}
			/* ISAL_ENC_REPEAT=N: same diagnostic as TAPE_ENC_REPEAT. */
			long enc_reps = getenv("ISAL_ENC_REPEAT") ? atol(getenv("ISAL_ENC_REPEAT")) : 1;
			double t0 = now_ms();
			/* Parity output buffer, inside the timer, per call.
			 *
			 * `reed-solomon-simd`, R10 and RaptorQ all allocate their coded outputs
			 * inside their own encode timers; writing parity into a pool allocated
			 * once for the process measured a different contract. Same argument as
			 * the decode working memory below, applied to the output side -- this is
			 * F2 in HARNESS-FAIRNESS-MATRIX.md.
			 *
			 * Same stride as the pool, so §3.1's non-aliasing layout is preserved and
			 * the only variable is where the memory came from. No memset: every byte
			 * is written by ec_encode_data before it is read, which is why this costs
			 * bookkeeping and not a zero-fill -- unlike R10, whose encode_symbol
			 * requires a zeroed destination.
			 *
			 * The copy back into the pool, which the decode phase reads from, is
			 * outside the timer, exactly as run_rs's copy of the recovery shards is.
			 */
			unsigned char *pc_par = NULL;
			if (alloc_per_call) {
				pc_par = aligned_alloc(4096,
					(((size_t)m * stride) + 4095) & ~(size_t)4095);
				if (!pc_par) {
					fprintf(stderr, "per-call parity allocation failed\n");
					return 1;
				}
				for (int i = 0; i < m; i++)
					enc_out[i] = pc_par + (size_t)i * stride;
			} else {
				for (int i = 0; i < m; i++)
					enc_out[i] = shard[k + i];
			}
			for (long rep = 0; rep < enc_reps; rep++)
			if (!enc_timer_lean) {
				for (int i = 0; i < k; i++)
					memcpy(shard[i], src + (size_t)i * sz, sz);
				ec_init_tables(k, m, gen + (size_t)k * k, enc_tab);
			}
			for (long rep = 0; rep < enc_reps; rep++) {
				if (enc_fft) {
					fft8_encode(k, m, sz, shard, enc_out);
					continue;
				}
				if (stripe == sz) {
					ec_encode_data((int)sz, k, m, enc_tab, shard, enc_out);
					continue;
				}
				/* Striped: the coefficient tables are built once above and every
				 * stripe reuses them, so what repeats per stripe is kernel work
				 * only. ec_encode_data walks the source ceil(m/6) times, so this
				 * shrinks the slice that is re-walked, not the number of walks. */
				for (size_t off = 0; off < sz; off += stripe) {
					size_t L = sz - off < stripe ? sz - off : stripe;
					for (int i = 0; i < k; i++)
						str_in[i] = shard[i] + off;
					for (int i = 0; i < m; i++)
						str_out[i] = enc_out[i] + off;
					ec_encode_data((int)L, k, m, enc_tab, str_in, str_out);
				}
			}
			encode_ms = (now_ms() - t0) / (double)enc_reps;
			/* Outside the timer: hand the parity to the pool the decode reads. */
			if (alloc_per_call) {
				for (int i = 0; i < m; i++)
					memcpy(shard[k + i], enc_out[i], sz);
				free(pc_par);
				for (int i = 0; i < m; i++)
					enc_out[i] = shard[k + i];
			}
		if (phase_decode) {
			/* The codeword, snapshotted once. Immutable from here on. */
			if (!code) {
				code = malloc((size_t)t * sz);
				if (!code) {
					fprintf(stderr, "codeword allocation failed\n");
					return 1;
				}
			}
			for (int i = 0; i < t; i++)
				memcpy(code + (size_t)i * sz, shard[i], sz);
		}
		}

		if (digest_only) {
			uint64_t hs = 0xcbf29ce484222325ULL, hp = 0xcbf29ce484222325ULL;
			for (int i = 0; i < k; i++)
				hs = fnv1a(shard[i], sz, hs);
			for (int i = k; i < t; i++)
				hp = fnv1a(shard[i], sz, hp);
			printf("digest f=%d k=%d T=%d shard_bytes=%zu seed=%llu gen=%s "
			       "src=%016llx parity=%016llx\n", f, k, t, sz,
			       (unsigned long long)seed,
			       use_cauchy ? (ev_on ? (enc_fft ? "eval-fft" : "eval")
						   : "cauchy")
					  : (gen_rs ? "rs" : "cauchy1"),
			       (unsigned long long)hs, (unsigned long long)hp);
			return 0;
		}

		/* --phase encode: THE DECODER DOES NOT RUN IN A MEASURED TRIAL. It runs
		 * once, at the first warmup trial, purely as the correctness gate; every
		 * measured trial is encode alone, with no decoder working set in cache
		 * when the encode timer starts. Report section 6.8 measured that mirror
		 * effect -- the decoder's buffers moving the ENCODE timer -- and this is
		 * what removes it, symmetrically with what --phase decode does for the
		 * encoder.
		 *
		 * decode_ms, plan_ms, code_ms, symbols_consumed and consumed_per_k are
		 * emitted EMPTY. Absent, not zero: a consumer that reaches for them gets
		 * nothing rather than a wrong number, which is the same rule the encode
		 * column follows under --phase decode. */
		if (phase_encode && trial != -warmup) {
			if (trial >= 0)
				printf("%d,%d,%d,%zu,%d,isal,gf8,%s,%s,%s,,,,,\n",
				       f, k, t, sz, trial,
				       use_cauchy ? "cauchy" : (gen_rs ? "isal-rs" : "isal-cauchy1"),
				       use_cauchy ? (naive_fold ? "closed-form-naivefold"
								: "closed-form")
						  : "full-ge",
				       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms));
			continue;
		}
		/* ---- decode: exactly the first k arrivals ---- */
		memset(got, 0, (size_t)t);
		if (arrivals_first)
			for (int i = 0; i < t; i++)
				order[i] = i;
		for (int i = 0; i < k; i++)
			got[order[i]] = 1;

		/* Zero the slots the receiver never got. The pool still holds the
		 * correct bytes from the encode above, and leaving them would let a
		 * decode that writes nothing pass verification. Outside both timers,
		 * as the equivalent loop in run_tape8 is. */
		/* --phase decode: COPY THE SHARDS THIS TRIAL DECODES FROM into the
		 * pool, out of the codeword built once at setup. The codeword itself is
		 * never written, so there is nothing to restore and no ordering between
		 * trials.
		 *
		 * WHY A COPY AND NOT THE NARROWER RESTORE IT REPLACES: what matters is
		 * not that the out-of-timer work be SMALL, it is that it be THE SAME IN
		 * BOTH MODES. The interleaved loop already does a k*sz copy-in above,
		 * before its timer starts. Matching it here makes `decode` equal `both`
		 * minus exactly the encoder, so the delta measures the encoder and
		 * nothing else. The restore did not match it, and that asymmetry is what
		 * made labels with no contamination read BELOW 1.0 -- leopard 0.947,
		 * tape_gf16 0.894 -- which was an artefact of the instrument, not a
		 * property of the codec. Outside both timers. */
		if (phase_decode)
			for (int j = 0; j < t; j++)
				if (got[j])
					memcpy(shard[j], code + (size_t)j * sz, sz);
		/* FIXME -- MEASUREMENT HYGIENE, KNOWN AND DELIBERATELY UNFIXED.
		 *
		 * This loop runs r times, where r is the number of originals the
		 * receiver did not get -- and r is EXACTLY THE QUANTITY --arrivals
		 * varies. Under `random` it is about 2k/3; under `parity` it is k. So
		 * the out-of-timer work is not matched across the two modes, and a
		 * random-vs-parity ratio carries a term that is not the decoder.
		 *
		 * It is outside both timers, which is not the same as being outside the
		 * measurement: it dirties cache and touches r shard-sized buffers just
		 * before the timed region.
		 *
		 * ITS SIZE IS UNMEASURED, and a previous version of this comment said
		 * ~6% on the strength of RS--8 reading 1.60x where r*k arithmetic
		 * predicted 1.51x. THAT ATTRIBUTION WAS WRONG TWICE OVER.
		 *
		 * First, decode = plan + code exactly and the two stages do not move
		 * together: plan runs at ~1.6x-1.7x and code at ~1.44x, because
		 * cauchy_inverse's O(r^2) block and fold_closed_form8's O(r*d) block do
		 * not cancel -- the inverse costs more per entry. So the aggregate is
		 * their weighted mean and there was no residual to explain.
		 *
		 * Second, the 1.60x itself was an artefact: it was measured at a FIXED
		 * 1 KiB shard, which is not a grid size. plan is scalar and identical at
		 * every shard size; code scales with shard bytes. So the plan share was
		 * 54-58% at 1 KiB against 0.9-19.1% on the grid, and the aggregate is
		 * 1.45 there, not 1.60. RS-8 and RS-16 land in the same place.
		 *
		 * THIS LOOP'S EFFECT REMAINS UNMEASURED. It is real -- the loop runs r
		 * times -- and nothing has ever isolated it.
		 *
		 * WHY IT IS NOT FIXED. The repair is easy -- zero all k original slots
		 * unconditionally, before the copy-in, so the work is constant in r --
		 * and that is exactly what makes it expensive: it changes the `random`
		 * path, so every decode figure in the report and the appendix would
		 * have to be re-taken to stay comparable. The confound is smaller than
		 * the effect it sits inside (1.5x), it is one-directional, and it is
		 * disclosed wherever the ratio is quoted.
		 *
		 * IF YOU DO FIX IT: re-take the full decode leg, do not mix vintages,
		 * and expect the parity ratios to fall by a few percent toward the
		 * predicted 1.5x. Nothing about the transform decoder should move --
		 * it is arrival-oblivious, so it is the null for this. Written up in
		 * HARNESS.md (this tree's docs/, where the artifact ships it) and in
		 * PERF-NOTES-ARRIVALS-ALL-PARITY.md. */
		for (int j = 0; j < k; j++)
			if (!got[j])
				memset(shard[j], 0, sz);

		double t1 = now_ms();

		int n_par = 0, n_orig = 0, n_miss = 0;
		for (int col = 0; col < k; col++) {
			int idx = order[col];
			if (idx < k) {
				recv_orig[n_orig] = idx;
				orig_col[n_orig++] = col;
			} else {
				recv_par[n_par] = idx;
				par_col[n_par++] = col;
			}
		}
		for (int j = 0; j < k; j++)
			if (!got[j])
				missing[n_miss++] = j;
		int r = n_miss;

		if (use_cauchy) {
			/* Reduce to the r x r residual Cauchy system, invert in
			 * closed form, then fold into r x k rows over the
			 * received shards in `order` column order. */
			/* The NODE, not the shard index -- they differ under
			 * ISAL8_INTERP=pad, where parity shard k+i lives at
			 * chunk+i. Data nodes are the index either way, so `ys`
			 * and fold_closed_form8's `recv_orig` are unaffected. */
			for (int a = 0; a < r; a++)
				xs[a] = node_of(k, recv_par[a]);
			for (int b = 0; b < r; b++)
				ys[b] = (unsigned char)missing[b];
			if (ev_on) {
				for (int a = 0; a < r; a++)
					ev_sx[a] = ev_Ai[recv_par[a] - k];
				for (int b = 0; b < r; b++)
					ev_sy[b] = ev_W[missing[b]];
				for (int c = 0; c < n_orig; c++)
					ev_spu[c] = ev_Wi[recv_orig[c]];
			}
			if (r)
				cauchy_inverse(xs, ys, r, binv, nx, ny,
					       ev_on ? ev_sx : NULL,
					       ev_on ? ev_sy : NULL);
			memset(rows, 0, (size_t)r * k);
			for (int b = 0; b < r; b++)
				for (int a = 0; a < r; a++)
					rows[b * k + par_col[a]] = binv[b * r + a];
			if (naive_fold) {
				for (int b = 0; b < r; b++)
					for (int c = 0; c < n_orig; c++) {
						unsigned char acc = 0;
						for (int a = 0; a < r; a++)
							acc ^= gmul(binv[b * r + a],
								    gen_entry(k, recv_par[a] - k,
									      recv_orig[c]));
						rows[b * k + orig_col[c]] = acc;
					}
			} else {
				fold_closed_form8(xs, ys, ny, r, recv_orig, orig_col, n_orig,
						 pu, k, rows, ev_on ? ev_spu : NULL);
			}
		} else {
			/* ISA-L stock: invert the full k x k survivor submatrix. */
			for (int col = 0; col < k; col++)
				memcpy(sub + (size_t)col * k,
				       gen + (size_t)order[col] * k, k);
			if (gf_invert_matrix(sub, inv, k) < 0) {
				fprintf(stderr,
					"gf_invert_matrix: singular survivor submatrix at "
					"f=%d k=%d T=%d trial=%d generator=%s.\n",
					f, k, t, trial, gen_rs ? "rs" : "cauchy1");
				if (gen_rs)
					fprintf(stderr,
						"This is expected: gf_gen_rs_matrix is not MDS at "
						"these shapes (see ISA-L erasure_code.h). Use the "
						"default --gen cauchy1.\n");
				else
					fprintf(stderr,
						"UNEXPECTED: gf_gen_cauchy1_matrix should be MDS. "
						"Please report with this command line.\n");
				return 1;
			}
			for (int b = 0; b < r; b++)
				memcpy(rows + (size_t)b * k,
				       inv + (size_t)missing[b] * k, k);
		}

		double plan_ms = now_ms() - t1;

		double t2 = now_ms();
		/* Decode working memory, inside the timer. See `alloc_per_call`. */
		unsigned char *pc_dec_tab = NULL, *pc_whole = NULL;
		if (alloc_per_call) {
			pc_dec_tab = malloc((size_t)k * k * 32);
			pc_whole = malloc((size_t)k * sz);
			if (!pc_dec_tab || !pc_whole) {
				fprintf(stderr, "per-call decode allocation failed\n");
				return 1;
			}
			dec_tab = pc_dec_tab;
			whole = pc_whole;
		}
		for (int col = 0; col < k; col++)
			dec_in[col] = shard[order[col]];
		/* Reconstruct in place, into the pool slot of each missing shard.
		 * run_tape8 does the same -- reconstruct_data writes back into the
		 * shard array it was handed -- so neither harness carries a separate
		 * output buffer the other does not. The missing slots are never inputs:
		 * the inputs are shard[order[col]] for col < k, all present. */
		for (int b = 0; b < r; b++)
			dec_out[b] = shard[missing[b]];
		if (r) {
			/* The plan above and these tables are functions of the erasure
			 * pattern alone, so they are built once and every stripe reuses
			 * them. That is the whole point of striping inside the codec
			 * rather than at the application level: a lost shard spans all
			 * stripes, so one plan serves them all. */
			ec_init_tables(k, r, rows, dec_tab);
			if (stripe == sz) {
				ec_encode_data((int)sz, k, r, dec_tab, dec_in, dec_out);
			} else {
				for (size_t off = 0; off < sz; off += stripe) {
					size_t L = sz - off < stripe ? sz - off : stripe;
					for (int col = 0; col < k; col++)
						str_in[col] = dec_in[col] + off;
					for (int b = 0; b < r; b++)
						str_out[b] = dec_out[b] + off;
					ec_encode_data((int)L, k, r, dec_tab, str_in, str_out);
				}
			}
		}
		/* Materialize the contiguous source, exactly as run_tape8 does inside
		 * its own timed `code` region. Without this the two drivers are not
		 * measuring the same thing: Tape pays k*sz of allocation and copy that
		 * ISA-L would not, which at f=85/4MiB is ~4.2 MB and dominates the
		 * apparent kernel gap. A validator does need the contiguous source, so
		 * charging both codecs for it is the honest choice. */
		{
			size_t off = 0;
			for (int i = 0; i < k; i++) {
				memcpy(whole + off, shard[i], sz);
				off += sz;
			}
		}
		double code_ms = now_ms() - t2;

		/* THE CORRECTNESS GATE MUST ACTUALLY GATE. Under --phase encode the
		 * decoder runs at this ONE warmup trial and nowhere else, purely so a
		 * configuration that computes wrong parity is caught. The comparison
		 * below is that gate's entire purpose, and it used to be skipped under
		 * --no-verify -- which paid the gate decode's full cost and then threw
		 * away the only reason it was run. Forcing the check for this trial is
		 * the cheap direction of the two: it runs once, outside every timer,
		 * and under --phase encode no MEASURED trial reaches this code at all
		 * (they take the `continue` above). Fixed 31 Aug 2026;
		 * HARNESS-DEFECT-verify-guard.md section 2. */
		int gate_trial = phase_encode && trial == -warmup;

		if (verify || gate_trial) {
			if (memcmp(whole, src, (size_t)k * sz)) {
				fprintf(stderr, "ISA-L materialized source mismatch f=%d\n", f);
				return 1;
			}
			for (int b = 0; b < r; b++) {
				if (memcmp(shard[missing[b]],
					   src + (size_t)missing[b] * sz, sz)) {
					fprintf(stderr,
						"ISA-L reconstruction mismatch f=%d shard=%d plan=%s\n",
						f, missing[b], use_cauchy ? "cauchy" : "ge");
					return 1;
				}
			}
		}

		if (alloc_per_call) {
			/* Outside the timer, as every other codec's free is. */
			free(pc_dec_tab);
			free(pc_whole);
		}

		if (trial >= 0)
			printf("%d,%d,%d,%zu,%d,isal,gf8,%s,%s,"
			       "%s,%.6f,%.6f,%.6f,%d,%.8f\n",
			       f, k, t, sz, trial,
			       use_cauchy ? "cauchy" : (gen_rs ? "isal-rs" : "isal-cauchy1"),
			       use_cauchy ? (naive_fold ? "closed-form-naivefold"
						       : "closed-form")
					  : "full-ge",
			       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms), plan_ms + code_ms, plan_ms, code_ms,
			       k, 1.0);
	}
	if (fft8_phases && fft8_ph_n) {
		long n = fft8_ph_n;
		fprintf(stderr,
			"enc copy_in=%.4f ppt=%.4f coset_copy=%.4f coset_fft=%.4f"
			" total=%.4f | b3=%lu b2=%lu b1=%lu mm22=%lu single=%lu"
			" | chunk=%u ncos=%u direct=%u shard=%zu\n",
			fft8_ph[0] / n, fft8_ph[1] / n, fft8_ph[2] / n, fft8_ph[3] / n,
			(fft8_ph[0] + fft8_ph[1] + fft8_ph[2] + fft8_ph[3]) / n,
			fft8_cnt_b3 / (unsigned long)n,
			fft8_cnt_b2 / (unsigned long)n, fft8_cnt_b1 / (unsigned long)n,
			fft8_cnt_mm22 / (unsigned long)n, fft8_cnt_single / (unsigned long)n,
			fft8_chunk, fft8_ncos, fft8_direct, sz);
	}
	return 0;
}


/* ======================================================================== */
/*                                GF(2^16)                                  */
/* ======================================================================== */

/* ------------------------- GF(2^16) = GF(2^8)[z]/(z^2 + z + BETA), BETA=0x20 */

#define BETA 0x20

/* Packed little: low byte = a0 (the z^0 coefficient), high byte = a1. */
static inline unsigned char lo8(uint16_t a) { return (unsigned char)(a & 0xff); }
static inline unsigned char hi8(uint16_t a) { return (unsigned char)(a >> 8); }
static inline uint16_t pack16(unsigned char a0, unsigned char a1)
{
	return (uint16_t)a0 | ((uint16_t)a1 << 8);
}

static uint16_t g16mul(uint16_t a, uint16_t b)
{
	unsigned char a0 = lo8(a), a1 = hi8(a), b0 = lo8(b), b1 = hi8(b);
	unsigned char p0 = gmul(a0, b0), p1 = gmul(a1, b1);
	unsigned char c0 = p0 ^ gmul(BETA, p1);
	unsigned char c1 = gmul(a0, b1) ^ gmul(a1, b0) ^ p1;
	return pack16(c0, c1);
}

/*
 * (a0 + a1 z)^-1 = ((a0 + a1) + a1 z) / N,  N = a0^2 + a0 a1 + BETA a1^2.
 * N is the norm down to GF(2^8) and is nonzero for every nonzero a, which is
 * exactly the statement that z^2 + z + BETA has no root in GF(2^8).
 */
static uint16_t g16inv(uint16_t a)
{
	unsigned char a0 = lo8(a), a1 = hi8(a);
	unsigned char n = gmul(a0, a0) ^ gmul(a0, a1) ^ gmul(BETA, gmul(a1, a1));
	unsigned char ni = ginv8(n);
	return pack16(gmul(a0 ^ a1, ni), gmul(a1, ni));
}

static inline uint16_t g16div(uint16_t a, uint16_t b)
{
	if (!a)
		return 0;
	return g16mul(a, g16inv(b));
}

/*
 * Log/exp tables for the composite field.
 *
 * The tower arithmetic above is correct and self-contained, but expensive:
 * g16mul is five GF(2^8) multiplies and g16inv is four more plus a GF(2^8)
 * inverse, so g16div costs about fourteen table lookups on a dependent chain.
 * cauchy16_inverse's final loop does one g16mul and one g16div per entry, which
 * measured 28 ns -- roughly 127 cycles -- per entry at f = 255.
 *
 * The multiplicative group is cyclic of order 65535, so one log and one exp
 * table reduce a multiply to two lookups and an add, and a divide to the same
 * with a subtract. The tables depend only on the field, not on the erasure
 * pattern, so they are built once per process next to gf_init -- the same
 * standing as ISA-L's own GF(2^8) tables.
 *
 * Cost: 128 KB of log plus 256 KB of exp, against the tower's 768 bytes. The
 * log lookups in the Cauchy loops are all of xs[a] ^ ys[b], which is bounded by
 * the next power of two above T and so touches only the first few KB; the exp
 * lookups are scattered over the whole 256 KB and are the remaining cost.
 *
 * ISAL16_LOGTAB=0 restores the tower arithmetic, so the two can be measured
 * against each other and checked for byte-identical output.
 */
static uint16_t g16_log[65536];
static uint16_t g16_exp[2 * 65535];
static int g16_use_logtab = 1;

static void g16_tables_init(void)
{
	/* 65535 = 3 * 5 * 17 * 257, so g generates iff g^(65535/p) != 1 for each. */
	static const uint16_t primes[4] = { 3, 5, 17, 257 };
	uint16_t g = 0;
	for (uint32_t cand = 2; cand < 65536 && !g; cand++) {
		int ok = 1;
		for (int i = 0; i < 4 && ok; i++) {
			uint32_t e = 65535u / primes[i];
			uint16_t acc = 1, base = (uint16_t)cand;
			while (e) {
				if (e & 1)
					acc = g16mul(acc, base);
				base = g16mul(base, base);
				e >>= 1;
			}
			if (acc == 1)
				ok = 0;
		}
		if (ok)
			g = (uint16_t)cand;
	}
	if (!g) {
		fprintf(stderr, "no generator for the composite field\n");
		exit(1);
	}
	uint16_t b = 1;
	for (uint32_t i = 0; i < 65535; i++) {
		g16_exp[i] = b;
		g16_log[b] = (uint16_t)i;
		b = g16mul(b, g);
	}
	if (b != 1) {
		fprintf(stderr, "composite field log table did not close\n");
		exit(1);
	}
	for (uint32_t i = 65535; i < 2 * 65535; i++)
		g16_exp[i] = g16_exp[i - 65535];
	g16_log[0] = 0; /* never read: every caller guards on a zero operand */

	/* Differential check against the tower, over the whole field on one axis
	 * and a stride on the other, plus every inverse. */
	for (uint32_t a = 0; a < 65536; a++) {
		uint16_t x = (uint16_t)a;
		for (uint32_t d = 1; d < 65536; d += 4099) {
			uint16_t y = (uint16_t)d;
			uint16_t want = g16mul(x, y);
			uint16_t got = x ? g16_exp[g16_log[x] + g16_log[y]] : 0;
			if (want != got) {
				fprintf(stderr, "logtab mul mismatch %u*%u\n", a, d);
				exit(1);
			}
		}
		if (x && g16mul(x, g16_exp[65535 - g16_log[x]]) != 1) {
			fprintf(stderr, "logtab inv mismatch %u\n", a);
			exit(1);
		}
	}
}

static inline uint16_t g16mul_t(uint16_t a, uint16_t b)
{
	if (!a || !b)
		return 0;
	return g16_exp[g16_log[a] + g16_log[b]];
}

static inline uint16_t g16div_t(uint16_t a, uint16_t b)
{
	if (!a)
		return 0;
	return g16_exp[g16_log[a] + 65535 - g16_log[b]];
}

static inline uint16_t g16inv_t(uint16_t a)
{
	return g16_exp[65535 - g16_log[a]];
}

static void field_selftest(void)
{
	/* z^2 + z + BETA must be irreducible: no x in GF(2^8) with x^2+x=BETA. */
	for (int x = 0; x < 256; x++)
		if ((gmul((unsigned char)x, (unsigned char)x) ^ (unsigned char)x) == BETA) {
			fprintf(stderr, "BETA=0x%02x is reducible; field is broken\n", BETA);
			exit(1);
		}
	/* a * a^-1 == 1 over a sweep, and 0 has no inverse to test. */
	for (uint32_t a = 1; a < 65536; a += 97)
		if (g16mul((uint16_t)a, g16inv((uint16_t)a)) != 1) {
			fprintf(stderr, "g16inv broken at %u\n", a);
			exit(1);
		}
}

/* ------------------------------------------------------- the Cauchy nodes */

/*
 * Two node conventions, selected by ISAL16_NODES.
 *
 * WHAT THE RELABELLING IS AND IS NOT. It is not a change of code family. A
 * systematic evaluation ("classical") Reed-Solomon code has generator
 * L_i(y_j) = A_j / ((y_j ^ x_i) * W_i), a generalized Cauchy matrix, in every
 * field and for every node set -- so evaluation RS and Cauchy RS are one family
 * written two ways, and both conventions below are Cauchy codes. What changes is
 * only WHERE THE NODES SIT, and that is what decides whether a transform can
 * encode them: the node set has to be a GF(2) subspace, which makes W_i
 * independent of i and A_j constant on each coset, collapsing the generator to
 * c_t / (y ^ x). Measured, that collapse happens for ANY basis of the subspace;
 * the Cantor basis merely normalises c_1 to 1 and is the basis the ported skew
 * table is built for. The linear convention fails for a different reason: it
 * puts the parity nodes at index k, which is not a coset boundary unless k is
 * already a power of two.
 *
 * `linear` (DEFAULT) is what every revision up to 18 measured: the node of
 * shard `idx` is `idx` itself, so y_j = j for j in [0,k) and x_i = k+i. Disjoint
 * by construction, so x ^ y is never 0.
 *
 * `cantor` relabels the same construction onto the Cantor basis of this field:
 * the node of data shard j is beta(j), and of parity shard k+i is
 * beta(chunk+i), where beta(z) is the Cantor-basis expansion of the index z and
 * chunk = k rounded up to a power of two. Still a Cauchy matrix, still MDS,
 * still distinct nodes -- beta is injective and the index sets [0,k) and
 * [chunk, chunk+m) are disjoint because chunk >= k.
 *
 * The point of the relabelling is that THIS code, and not the linear one, is
 * the code an additive FFT encodes. PERF-NOTES-FFT-CAUCHY.md establishes that
 * a systematic evaluation code over beta(0..chunk-1) has generator
 * c_t / (beta(chunk+i) ^ beta(j)) with c_t one scalar per recovery coset, and
 * `fft_cauchy_check.py` checks it against reed-solomon-simd's own encoder.
 * The coset scalars are absorbed by the encoder, not carried here, so what the
 * decode plan sees is a pure Cauchy matrix either way and NOTHING below this
 * point knows which convention is in force.
 *
 * That is what makes the switch a null: the op counts are identical and only
 * the constants differ, so encode and decode must not move.
 */
static uint16_t *g16_node;		/* node of each of the T shard slots */
static int g16_nodes_cantor;		/* 0 = linear, 1 = Cantor */
static uint16_t g16_cantor[16];		/* the Cantor basis, always computed */

/*
 * Cantor basis of GF(2^8)[z]/(z^2 + z + BETA): b[0] = 1 and
 * b[i]^2 ^ b[i] = b[i-1]. Solved as a 16x16 GF(2) system rather than hardcoded,
 * so it stays correct if BETA or the GF(2^8) polynomial ever change, and
 * checked against the recursion before use.
 */
static void cantor_basis16(uint16_t *b)
{
	uint16_t col[16];
	for (int i = 0; i < 16; i++) {
		uint16_t e = (uint16_t)(1u << i);
		col[i] = (uint16_t)(g16mul(e, e) ^ e);	/* the GF(2)-linear map u -> u^2 ^ u */
	}
	b[0] = 1;
	for (int step = 1; step < 16; step++) {
		/* rows[i] = bit i of each column, augmented with bit i of b[step-1] */
		uint32_t rows[16];
		for (int i = 0; i < 16; i++) {
			uint32_t rw = 0;
			for (int c = 0; c < 16; c++)
				if ((col[c] >> i) & 1)
					rw |= 1u << c;
			if ((b[step - 1] >> i) & 1)
				rw |= 1u << 16;
			rows[i] = rw;
		}
		int piv = 0, where[16];
		for (int c = 0; c < 16; c++)
			where[c] = -1;
		for (int c = 0; c < 16; c++) {
			int p = -1;
			for (int rw = piv; rw < 16; rw++)
				if (rows[rw] >> c & 1) { p = rw; break; }
			if (p < 0)
				continue;
			uint32_t tmp = rows[piv]; rows[piv] = rows[p]; rows[p] = tmp;
			for (int rw = 0; rw < 16; rw++)
				if (rw != piv && (rows[rw] >> c & 1))
					rows[rw] ^= rows[piv];
			where[c] = piv++;
		}
		for (int rw = piv; rw < 16; rw++)
			if (rows[rw] >> 16 & 1) {
				fprintf(stderr, "no Cantor basis: trace obstruction at %d\n",
					step);
				exit(1);
			}
		uint16_t u = 0;
		for (int c = 0; c < 16; c++)
			if (where[c] >= 0 && (rows[where[c]] >> 16 & 1))
				u |= (uint16_t)(1u << c);
		b[step] = u < (uint16_t)(u ^ 1) ? u : (uint16_t)(u ^ 1);
		if ((uint16_t)(g16mul(b[step], b[step]) ^ b[step]) != b[step - 1]) {
			fprintf(stderr, "Cantor recursion failed at %d\n", step);
			exit(1);
		}
	}
}

/* beta(z): XOR of the basis elements named by the set bits of z. */
static uint16_t cantor_span(unsigned z, const uint16_t *b)
{
	uint16_t v = 0;
	for (int i = 0; i < 16; i++)
		if (z >> i & 1)
			v ^= b[i];
	return v;
}

/* Smallest power of two at or above k -- the FFT chunk, and the parity offset. */
static unsigned chunk_of(int k)
{
	unsigned c = 1;
	while (c < (unsigned)k)
		c <<= 1;
	return c;
}

static void g16_nodes_init(int k, int t)
{
	/* DEFAULT `cantor` since 2026-08-26. It is the node set an additive FFT
	 * evaluates at, so it is what ISAL16_ENCODE=fft requires; `linear` is the
	 * reachable null and is the revision-18 code. NOTE this changes the CODE
	 * and therefore the parity bytes (DEFAULTS.md policy 5). */
	const char *nv = getenv("ISAL16_NODES");
	if (nv && strcmp(nv, "linear") && strcmp(nv, "cantor")) {
		fprintf(stderr, "unknown ISAL16_NODES=%s; use linear or cantor\n", nv);
		exit(2);
	}
	g16_nodes_cantor = !(nv && !strcmp(nv, "linear"));
	g16_node = malloc((size_t)t * sizeof(uint16_t));
	if (!g16_node) {
		fprintf(stderr, "node table allocation failed\n");
		exit(1);
	}
	/* Computed either way: the FFT encoder needs it even though the linear
	 * node set does not, and it is 16 solves of a 16x16 GF(2) system. */
	cantor_basis16(g16_cantor);
	if (!g16_nodes_cantor) {
		for (int i = 0; i < t; i++)
			g16_node[i] = (uint16_t)i;
		return;
	}
	const uint16_t *b = g16_cantor;
	unsigned chunk = chunk_of(k);
	if (chunk + (unsigned)(t - k) > 65536u) {
		fprintf(stderr, "cantor nodes need chunk+m<=65536; k=%d t=%d\n", k, t);
		exit(1);
	}
	for (int i = 0; i < k; i++)
		g16_node[i] = cantor_span((unsigned)i, b);
	for (int i = k; i < t; i++)
		g16_node[i] = cantor_span(chunk + (unsigned)(i - k), b);
	/* Distinctness is what makes the matrix Cauchy; assert it rather than
	 * trust the argument, since a collision would be silently non-MDS. */
	for (int i = 1; i < t; i++)
		for (int j = 0; j < i; j++)
			if (g16_node[i] == g16_node[j]) {
				fprintf(stderr, "cantor nodes collide at %d,%d\n", i, j);
				exit(1);
			}
}


/* ===================================================================
 * The additive-FFT encoder
 *
 * A port of reed-solomon-simd 3.1.0's `LowRateEncoder` and its GFNI engine
 * (`rate_low.rs`, `engine_gfni.rs`) onto this driver's composite tower field
 * and plane-split shard layout. Ported rather than reinvented: the layer walk,
 * the skew recurrence, the three-layer register blocking and the leftover-layer
 * peeling are upstream's, line for line where the field allows.
 *
 * WHY THIS ENCODES THE SAME CODE THE MATRIX ENCODER DOES. Under
 * ISAL16_NODES=cantor the generator is the Cauchy matrix over nodes beta(j) and
 * beta(chunk+i). A systematic evaluation code over beta(0..chunk-1) -- which is
 * exactly what an additive FFT over the Cantor basis computes -- has generator
 * c_t / (beta(chunk+i) ^ beta(j)), one scalar c_t per recovery coset. So the
 * transform produces this driver's own parity, scaled per coset. The encoder
 * divides it out as it copies (the transform is linear, so scaling the input
 * scales the output), and what leaves this function is the pure Cauchy code.
 * The decode plan is therefore untouched and cannot tell which encoder ran.
 *
 * PERF-NOTES-FFT-CAUCHY.md derives it; `fft_cauchy_check.py` checks it against
 * reed-solomon-simd's encoder; and the standing oracle is that
 * ISAL16_ENCODE=matrix and =fft must agree byte for byte at every shape.
 *
 * TWO THINGS THAT DIFFER FROM UPSTREAM, BOTH FORCED BY THIS DRIVER:
 *
 *  1. The field. reed-solomon-simd multiplies through log/exp tables in Cantor
 *     coordinates; here multiplication by g = g0 + g1*z is the 2x2 GF(2^8)
 *     block of `expand16`. On GFNI that is the same shape either way -- four
 *     8x8 GF(2) affine matrices, which is what `mul_256` consumes -- so the
 *     kernel is unchanged and only the table construction differs.
 *  2. The shard layout. Upstream splits lo/hi inside each 64-byte chunk; this
 *     driver keeps whole planes, `shard` then `shard + h`, because the ISA-L
 *     matrix decode needs contiguous planes. Same registers, different
 *     addressing, and it means the transform and the decode share one shard
 *     format with no conversion between them.
 */


/* ISA-L's constant -> 8x8 GF(2) affine matrix table. Exported but not in
 * erasure_code.h; used here so this kernel and ISA-L's cannot disagree about
 * the bit order inside a gf2p8affineqb qword. */
extern void ec_init_tables_gfni(int k, int rows, unsigned char *a, unsigned char *gftbls);

static uint64_t fft_affine[256];	/* fft_affine[c] = matrix of "multiply by c" */
static uint16_t *fft_skew;		/* 65535 tower elements; 0 means "no multiply" */
static uint16_t fft_coset_inv[4];	/* c_t^-1 for recovery coset t, t = 1.. */
static uint16_t fft_coset[4];		/* c_t itself, which the FFT DECODER needs */
static int fft_have_gfni, fft_block, fft_block3;

/*
 * THE WORK-BUFFER LAYOUT, as one variable.
 *
 * PLANE (default, and what every revision through 20 measured): a shard is its
 * low plane then its high plane, so chunk c is (lo + c*32, lo + h + c*32) --
 * two memory streams per shard, h apart.
 *
 * INTER (`ISAL16_DEC_LAYOUT=inter`): each 64-byte chunk is lo32|hi32, which is
 * reed-solomon-simd's layout, so chunk c is (base + c*64, base + c*64 + 32) --
 * one stream per shard.
 *
 * Setting `lo = base` and `hi = base + 32` makes the two forms differ in
 * exactly one number, the distance between consecutive chunks: 32 or 64. Every
 * kernel below therefore takes `cs` and nothing else changes, which is what
 * keeps this an A/B rather than a rewrite. `layout_probe.c` -- a development
 * instrument NOT extracted into this artifact -- prices the
 * same variable in isolation at 1.31x-1.39x.
 *
 * DECODE ONLY. The encoder transforms directly into the parity pool, whose
 * layout the GF(2^8) matrix decoder reads, so it cannot move without moving
 * that too; `fft16_encode` forces PLANE on entry. The decoder's work buffer is
 * private to `fft16_decode`, which is what makes this self-contained.
 */
static size_t fft_cstep = 32;		/* 32 = plane, 64 = interleaved */
static int fft_dec_inter;		/* ISAL16_DEC_LAYOUT=inter */

/*
 * `ISAL16_ENC_LAYOUT=inter` moves the SHARD POOL ITSELF to the interleaved
 * form, which is a change to what the codec emits and not only to how it works
 * internally.
 *
 * The layout is purely a convention for reading a shard's bytes as field
 * elements: the source shards are the message either way, and the decode
 * reproduces them byte for byte either way. What changes is which elements the
 * generator combines, so the PARITY bytes differ -- the same code over a
 * different element ordering, not a different code.
 *
 * What it buys: the encoder's two transforms are ~74% of its cost and run in
 * whatever the pool is, so they get the layout win directly; the copy-in stays
 * a flat memcpy because bytes are bytes; and the transform decoder stops
 * converting on ingest, since the pool already matches its work buffer.
 *
 * What it costs. It is the DEFAULT whenever the transform encoder runs, and it
 * requires `ISAL16_ENCODE=fft` -- the matrix encoder writes parity through
 * ISA-L, which addresses the pool as planes, and `run_gf16` refuses the pair.
 * Nothing else is refused:
 *   - the GF(2^8) MATRIX decoder addresses `shard[i]` and `shard[i] + h`, so it
 *     cannot read this pool directly; `run_gf16` de-interleaves the k survivors
 *     into `whole` inside the decode timer (`srcv`) and permutes each
 *     reconstruction back on materialize.
 *   - the matrix TAIL coset (`fft_tail_tab`) addresses the source the same way,
 *     so under this pool `fft16_encode` hands it a plane-form copy of the
 *     originals (`fft_tail_in`) and permutes its output into the parity slots.
 *   - `--digest` compares parity bytes, so it is not comparable across layouts.
 * The paper's RS--16 matrix-decode configuration is exactly this pool with the
 * matrix decoder and the tail. This comment said, until 11 September 2026, that
 * `ISAL16_DECODE=fft` was required and `fft_tail_rows` had to be zero; both
 * stopped being true on 24 August 2026 when the two paths above were added.
 * The oracle that matters still holds: decode must return the source exactly.
 */
static int fft_pool_inter;		/* ISAL16_ENC_LAYOUT=inter */
static unsigned char **fft_tail_in;	/* 2k plane pointers, interleaved pool only */

static int cpu_has_gfni(void)
{
	unsigned a, b, c, d;
	if (!__get_cpuid_count(7, 0, &a, &b, &c, &d))
		return 0;
	return (c >> 8) & 1;		/* CPUID.7.0:ECX.GFNI */
}

/* The assembly block needs ymm16-31 and the EVEX broadcast operand, both
 * AVX512VL, on top of GFNI. See codec/fft_kernels.S. */
static int cpu_has_avx512vl(void)
{
	unsigned a, b, c, d;
	if (!__get_cpuid_count(7, 0, &a, &b, &c, &d))
		return 0;
	return (b >> 31) & 1;		/* CPUID.7.0:EBX.AVX512VL */
}

void gf16_apply_8(const unsigned char *const *in, unsigned char *const *out,
		  size_t k, size_t h, const uint64_t *tab);
static int apply_fused;		/* ISAL16_APPLY=fused */

void fft16_b3_fwd(unsigned char *const *p, size_t h, size_t nchunk,
		  const uint64_t *lut);
void fft16_b3_inv(unsigned char *const *p, size_t h, size_t nchunk,
		  const uint64_t *lut);
static int fft_use_asm;

/* ISA-L's constant -> affine matrix table, needed by every GFNI kernel here.
 * Taken from ISA-L rather than derived so this and its kernels cannot disagree
 * about the bit order inside a gf2p8affineqb qword. */
static void gf16_affine_init(void)
{
	unsigned char cs[256];
	for (int i = 0; i < 256; i++)
		cs[i] = (unsigned char)i;
	ec_init_tables_gfni(256, 1, cs, (unsigned char *)fft_affine);
}



static void gf16_affine_init(void);

/* ======================================================================== */
/*        GF(2^8) additive FFT, with the principal pivot transform          */
/* ======================================================================== */

/*
 * The transform encoder for the evaluation-node code of eval_entry, reaching
 * every shape with T <= 256 -- which is the whole region GF(2^8) can host.
 *
 * NODES. The evaluation point of index i IS the field element i, so the data
 * nodes 0..chunk-1 are span{1,2,4,...}, a GF(2)-subspace, and the recovery
 * cosets are the aligned blocks [t*chunk, (t+1)*chunk). No Cantor basis is
 * involved: in GF(2^8) the natural index-to-element map already puts the nodes
 * where an additive FFT needs them, which is why firedancer's generate_fft.py
 * writes `svals[0,x] = GF(x)` and why the node set coincides with the one
 * cauchy_entry uses.
 *
 * SKEW. s_j(x) = prod_{t < 2^j} (x ^ t) and S_j(x) = s_j(x) / s_j(2^j); the
 * butterfly at layer j over the block starting at w uses S_j(w). Stored at
 * fft8_skew[w + 2^j - 1] so the walk indexes it exactly as ifft_plain does its
 * tower twin -- `skew[r + dist + skd - 1]` -- and 0 still means "no multiply",
 * since S_j(0) = 0.
 *
 * PPT. The padded transform interpolates over the whole subspace with the
 * chunk-k unused slots forced to zero, so parity starts at `chunk` and the code
 * needs chunk + m <= 256 points -- which fails from f = 65 up (report 2.5).
 * The principal pivot transform of Lin, Alloum and Al-Naffouri (ISIT 2017)
 * instead solves for the degree-<k polynomial through the k real points and
 * hands back its coefficients AND its values at k..chunk-1, so parity starts at
 * k and the condition becomes ceil((k+m)/chunk)*chunk <= 256, which holds to
 * f = 85. The recursion below is firedancer's generate_ppt.py
 * `principal_pivot_transform_k_no_x`, carried over unchanged; ppt_check.py is
 * the same recursion in Python and PERF-NOTES-FFT-GF8-PPT.md section 1 is the
 * reach table.
 *
 * The op list is a function of (chunk, k) alone, so it is built once per
 * process, like every other plan here.
 */

static unsigned char fft8_skew[255];
static int fft8_ready;

static void fft8_skew_init(void)
{
	static unsigned char sv[8][256];
	for (int x = 0; x < 256; x++)
		sv[0][x] = (unsigned char)x;
	for (int j = 1; j < 8; j++)
		for (int x = 0; x < 256; x++)
			sv[j][x] = gmul(sv[j - 1][x], sv[j - 1][x ^ (1 << (j - 1))]);
	for (int j = 0; j < 8; j++) {
		unsigned char d = sv[j][1u << j];
		unsigned step = 1u << (j + 1);
		for (unsigned w = 0; w < 256; w += step) {
			unsigned idx = w + (1u << j) - 1;
			if (idx < sizeof(fft8_skew))
				fft8_skew[idx] = gdiv8(sv[j][w], d);
		}
	}
}

/* ---------------------------------------------------- the scalar reference */

/* One walk over x[off .. off+size), skd = off. Byte-for-byte the shape of
 * fft_plain / ifft_plain, on scalars: it builds the PPT's 2x2 blocks and is the
 * oracle ISAL8_FFT_KERNEL=scalar checks the vector kernels against. */
static void fft8_walk_s(unsigned char *x, unsigned off, unsigned size, int inverse)
{
	if (inverse) {
		for (unsigned dist = 1; dist < size; dist <<= 1)
			for (unsigned r = 0; r < size; r += 2 * dist) {
				unsigned char s = fft8_skew[r + dist + off - 1];
				for (unsigned i = off + r; i < off + r + dist; i++) {
					x[i + dist] ^= x[i];
					if (s)
						x[i] ^= gmul(x[i + dist], s);
				}
			}
	} else {
		for (unsigned dist = size / 2; dist > 0; dist >>= 1)
			for (unsigned r = 0; r < size; r += 2 * dist) {
				unsigned char s = fft8_skew[r + dist + off - 1];
				for (unsigned i = off + r; i < off + r + dist; i++) {
					if (s)
						x[i] ^= gmul(x[i + dist], s);
					x[i + dist] ^= x[i];
				}
			}
	}
}

/* ------------------------------------------------------------ the op list */

/* P8_CPSC and P8_SCAC are the two FUSED glue ops. ppt_build emits COPY+SCALE
 * and SCALE+MULACC_SCRATCH as adjacent pairs on the SAME shard, and each was a
 * separate single-shard pass:
 *
 *   COPY;SCALE   sc[b] = w[a];  w[a] *= c0      read w, write sc, read w, write w
 *   -> P8_CPSC   one pass:                      read w, write sc, write w
 *
 *   SCALE;MULACCS  w[a] *= c0;  w[a] ^= sc[b]*c1   read w, write w, read w, read sc, write w
 *   -> P8_SCAC     one pass:                       read w, read sc, write w
 *
 * Four shard-passes become three and five become three. ISAL8_PPT_FUSE=0 emits
 * the unfused pairs and is the null; the two must produce identical bytes. */
enum { P8_IFFT, P8_FFT, P8_COPY, P8_SCALE, P8_MULACC, P8_MULACCS, P8_MM22,
       P8_CPSC, P8_SCAC };
static int ppt_fuse = 1;		/* ISAL8_PPT_FUSE=0 is the null */

typedef struct {
	unsigned char op;
	unsigned short a, b;
	unsigned char c[4];		/* MM22: m00 m01 m10 m11; others: c[0] */
} ppt_op;

static ppt_op *ppt_ops;
static unsigned ppt_nops, ppt_cap, ppt_scratch_max;

static void ppt_emit(unsigned char op, unsigned a, unsigned b, const unsigned char *c)
{
	if (ppt_nops == ppt_cap) {
		ppt_cap = ppt_cap ? ppt_cap * 2 : 256;
		ppt_ops = realloc(ppt_ops, ppt_cap * sizeof(*ppt_ops));
		if (!ppt_ops) {
			fprintf(stderr, "ppt op list allocation failed\n");
			exit(1);
		}
	}
	ppt_op *o = &ppt_ops[ppt_nops++];
	o->op = op; o->a = (unsigned short)a; o->b = (unsigned short)b;
	o->c[0] = c ? c[0] : 0;
	o->c[1] = c ? c[1] : 0;
	o->c[2] = c ? c[2] : 0;
	o->c[3] = c ? c[3] : 0;
	if (op == P8_COPY || op == P8_MULACCS || op == P8_CPSC || op == P8_SCAC)
		if (b + 1 > ppt_scratch_max)
			ppt_scratch_max = b + 1;
}

/* B of the PPT paper: blockdiag(IFFT_{n/2}) o FFT_n, read at rows/cols {0,n/2}. */
static void ppt_Bmatr(unsigned lg, unsigned off, unsigned char *M)
{
	unsigned n = 1u << lg, n2 = n / 2;
	unsigned char v[256];
	unsigned cols[2] = { 0, n2 };
	for (int q = 0; q < 2; q++) {
		memset(v, 0, sizeof(v));
		v[off + cols[q]] = 1;
		fft8_walk_s(v, off, n, 0);
		fft8_walk_s(v, off, n2, 1);
		fft8_walk_s(v, off + n2, n2, 1);
		M[0 + q] = v[off];		/* M[row][col] as M[2*row+col] */
		M[2 + q] = v[off + n2];
	}
}

static void ppt_inv22(const unsigned char *M, unsigned char *out)
{
	unsigned char det = gmul(M[0], M[3]) ^ gmul(M[1], M[2]);
	unsigned char di = ginv8(det);
	out[0] = gmul(M[3], di); out[1] = gmul(M[1], di);
	out[2] = gmul(M[2], di); out[3] = gmul(M[0], di);
}

/* The lower principal pivot of a 2x2, which is what a half-live pair needs. */
static void ppt_lower22(const unsigned char *M, unsigned char *out)
{
	out[0] = ginv8(M[0]);
	out[1] = gdiv8(M[1], M[0]);
	out[2] = gdiv8(M[2], M[0]);
	out[3] = M[3] ^ gdiv8(gmul(M[2], M[1]), M[0]);
}

static void ppt_build(unsigned lg, unsigned k, unsigned off)
{
	unsigned n = 1u << lg, n2 = n / 2;
	if (n >= 4) {
		if (k >= off + n) { ppt_emit(P8_IFFT, n, off, NULL); return; }
		if (k <= off)     { ppt_emit(P8_FFT,  n, off, NULL); return; }
	}
	if (n == 2) {
		unsigned char v0[256], v1[256], f[4], M[4];
		memset(v0, 0, sizeof(v0)); v0[off] = 1;     fft8_walk_s(v0, off, 2, 0);
		memset(v1, 0, sizeof(v1)); v1[off + 1] = 1; fft8_walk_s(v1, off, 2, 0);
		f[0] = v0[off];     f[1] = v1[off];
		f[2] = v0[off + 1]; f[3] = v1[off + 1];
		if (k <= off) {
			memcpy(M, f, 4);
		} else if (k >= off + 2) {
			unsigned char w0[256], w1[256];
			memset(w0, 0, sizeof(w0)); w0[off] = 1;     fft8_walk_s(w0, off, 2, 1);
			memset(w1, 0, sizeof(w1)); w1[off + 1] = 1; fft8_walk_s(w1, off, 2, 1);
			M[0] = w0[off];     M[1] = w1[off];
			M[2] = w0[off + 1]; M[3] = w1[off + 1];
		} else {
			ppt_lower22(f, M);
		}
		ppt_emit(P8_MM22, off, off + 1, M);
		return;
	}
	unsigned char Bm[4], Bu[4], Bl[4];
	ppt_Bmatr(lg, off, Bm);
	ppt_inv22(Bm, Bu);
	ppt_lower22(Bm, Bl);
	for (unsigned j = 0; j < n2; j++) {
		int a1 = (j + off < k), a2 = (j + off + n2 < k);
		if (a1 && a2)
			continue;
		if (a1) {
			if (ppt_fuse) {
				unsigned char cc[4] = { Bl[3], 0, 0, 0 };
				ppt_emit(P8_CPSC, j + n2 + off, j + n2, cc);
			} else {
				ppt_emit(P8_COPY, j + n2 + off, j + n2, NULL);
				unsigned char cc[4] = { Bl[3], 0, 0, 0 };
				ppt_emit(P8_SCALE, j + n2 + off, 0, cc);
			}
		} else {
			ppt_emit(P8_MM22, j + off, j + off + n2, Bm);
		}
	}
	ppt_build(lg - 1, k, off);
	for (unsigned j = 0; j < n2; j++)
		if ((j + off < k) && !(j + off + n2 < k))
			{ unsigned char cc[4] = { Bl[2], 0, 0, 0 };
			  ppt_emit(P8_MULACC, j + n2 + off, j + off, cc); }
	ppt_build(lg - 1, k, off + n2);
	for (unsigned j = 0; j < n2; j++) {
		int a1 = (j + off < k), a2 = (j + off + n2 < k);
		if (a2) {
			ppt_emit(P8_MM22, j + off, j + off + n2, Bu);
		} else if (a1) {
			if (ppt_fuse) {
				unsigned char cc[4] = { Bm[0], Bm[1], 0, 0 };
				ppt_emit(P8_SCAC, j + off, j + n2, cc);
			} else {
				unsigned char c0[4] = { Bm[0], 0, 0, 0 };
				ppt_emit(P8_SCALE, j + off, 0, c0);
				unsigned char c1[4] = { Bm[1], 0, 0, 0 };
				ppt_emit(P8_MULACCS, j + off, j + n2, c1);
			}
		}
	}
}

/* --------------------------------------------------------- the byte kernels */

static int fft8_gfni;
static int fft8_scalar_only;		/* ISAL8_FFT_KERNEL=scalar */

/* Every kernel handles a ragged tail in scalar. PERF-NOTES-PPT.md section 8
 * records what the tower's kernels cost by not doing that: fft_b2 and fft_b3
 * silently left the last h % 32 bytes untransformed, which no oracle caught
 * because the harness always rounds the shard to 64. Cheap insurance. */

__attribute__((target("avx2,gfni")))
static inline __m256i fft8_mul_v(__m256i v, uint64_t a)
{
	return _mm256_gf2p8affine_epi64_epi8(v, _mm256_set1_epi64x((long long)a), 0);
}

/* x ^= y*s; y ^= x   (forward)   |   y ^= x; x ^= y*s   (inverse) */
/*
 * SEPARATE DESTINATIONS, so the first pass of the interpolation can read the
 * caller's shards and write the work buffer -- which is the whole of what
 * `copy_in` used to do as its own pass over the message. Every other call site
 * passes d == s and compiles to what it did before. See fft8_copy_in_fused.
 */
__attribute__((target("avx2,gfni")))
static void fft8_b1_v(unsigned char *dx, unsigned char *dy,
		      const unsigned char *x, const unsigned char *y,
		      unsigned char s, size_t n, int inverse)
{
	uint64_t a = fft_affine[s];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i xv = _mm256_loadu_si256((const __m256i *)(x + i));
		__m256i yv = _mm256_loadu_si256((const __m256i *)(y + i));
		if (inverse) {
			yv = _mm256_xor_si256(yv, xv);
			if (s)
				xv = _mm256_xor_si256(xv, fft8_mul_v(yv, a));
		} else {
			if (s)
				xv = _mm256_xor_si256(xv, fft8_mul_v(yv, a));
			yv = _mm256_xor_si256(yv, xv);
		}
		_mm256_storeu_si256((__m256i *)(dx + i), xv);
		_mm256_storeu_si256((__m256i *)(dy + i), yv);
	}
	for (; i < n; i++) {
		unsigned char xa = x[i], yb = y[i];
		if (inverse) { yb ^= xa; if (s) xa ^= gmul(yb, s); }
		else         { if (s) xa ^= gmul(yb, s); yb ^= xa; }
		dx[i] = xa; dy[i] = yb;
	}
}

static void fft8_b1_io(unsigned char *dx, unsigned char *dy,
		       const unsigned char *x, const unsigned char *y,
		       unsigned char s, size_t n, int inverse)
{
	fft8_cnt_b1++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_b1_v(dx, dy, x, y, s, n, inverse);
		return;
	}
	for (size_t i = 0; i < n; i++) {
		unsigned char xa = x[i], yb = y[i];
		if (inverse) { yb ^= xa; if (s) xa ^= gmul(yb, s); }
		else         { if (s) xa ^= gmul(yb, s); yb ^= xa; }
		dx[i] = xa; dy[i] = yb;
	}
}

static inline void fft8_b1(unsigned char *x, unsigned char *y, unsigned char s,
			   size_t n, int inverse)
{
	fft8_b1_io(x, y, x, y, s, n, inverse);
}

__attribute__((target("avx2,gfni")))
static void fft8_mm22_v(unsigned char *x, unsigned char *y,
			const unsigned char *M, size_t n)
{
	uint64_t a00 = fft_affine[M[0]], a01 = fft_affine[M[1]];
	uint64_t a10 = fft_affine[M[2]], a11 = fft_affine[M[3]];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i xv = _mm256_loadu_si256((const __m256i *)(x + i));
		__m256i yv = _mm256_loadu_si256((const __m256i *)(y + i));
		__m256i nx = _mm256_xor_si256(fft8_mul_v(xv, a00), fft8_mul_v(yv, a01));
		__m256i ny = _mm256_xor_si256(fft8_mul_v(xv, a10), fft8_mul_v(yv, a11));
		_mm256_storeu_si256((__m256i *)(x + i), nx);
		_mm256_storeu_si256((__m256i *)(y + i), ny);
	}
	for (; i < n; i++) {
		unsigned char xa = x[i], yb = y[i];
		x[i] = gmul(xa, M[0]) ^ gmul(yb, M[1]);
		y[i] = gmul(xa, M[2]) ^ gmul(yb, M[3]);
	}
}

static void fft8_mm22(unsigned char *x, unsigned char *y,
		      const unsigned char *M, size_t n)
{
	fft8_cnt_mm22++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_mm22_v(x, y, M, n);
		return;
	}
	for (size_t i = 0; i < n; i++) {
		unsigned char xa = x[i], yb = y[i];
		x[i] = gmul(xa, M[0]) ^ gmul(yb, M[1]);
		y[i] = gmul(xa, M[2]) ^ gmul(yb, M[3]);
	}
}

/* d = s*c (set) or d ^= s*c (acc), and the in-place scale (s == d, acc == 0). */
__attribute__((target("avx2,gfni")))
static void fft8_mul_v2(unsigned char *d, const unsigned char *s,
			unsigned char c, size_t n, int acc)
{
	uint64_t a = fft_affine[c];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i v = fft8_mul_v(_mm256_loadu_si256((const __m256i *)(s + i)), a);
		if (acc)
			v = _mm256_xor_si256(v, _mm256_loadu_si256((const __m256i *)(d + i)));
		_mm256_storeu_si256((__m256i *)(d + i), v);
	}
	for (; i < n; i++)
		d[i] = acc ? (unsigned char)(d[i] ^ gmul(s[i], c)) : gmul(s[i], c);
}

/* sc = s;  d = s*c   -- one read of s, two writes. Fuses COPY+SCALE. */
__attribute__((target("avx2,gfni")))
static void fft8_cpsc_v(unsigned char *d, unsigned char *sc,
			const unsigned char *s, unsigned char c, size_t n)
{
	uint64_t a = fft_affine[c];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i v = _mm256_loadu_si256((const __m256i *)(s + i));
		_mm256_storeu_si256((__m256i *)(sc + i), v);
		_mm256_storeu_si256((__m256i *)(d + i), fft8_mul_v(v, a));
	}
	for (; i < n; i++) { unsigned char v = s[i]; sc[i] = v; d[i] = gmul(v, c); }
}

static void fft8_cpsc(unsigned char *d, unsigned char *sc,
		      const unsigned char *s, unsigned char c, size_t n)
{
	fft8_cnt_single++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_cpsc_v(d, sc, s, c, n);
		return;
	}
	for (size_t i = 0; i < n; i++) { unsigned char v = s[i]; sc[i] = v; d[i] = gmul(v, c); }
}

/* d = d*c0 ^ sc*c1 -- one read of each, one write. Fuses SCALE+MULACC_SCRATCH. */
__attribute__((target("avx2,gfni")))
static void fft8_scac_v(unsigned char *d, const unsigned char *sc,
			unsigned char c0, unsigned char c1, size_t n)
{
	uint64_t a0 = fft_affine[c0], a1 = fft_affine[c1];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i x = _mm256_loadu_si256((const __m256i *)(d + i));
		__m256i y = _mm256_loadu_si256((const __m256i *)(sc + i));
		x = fft8_mul_v(x, a0);
		if (c1)
			x = _mm256_xor_si256(x, fft8_mul_v(y, a1));
		_mm256_storeu_si256((__m256i *)(d + i), x);
	}
	for (; i < n; i++)
		d[i] = (unsigned char)(gmul(d[i], c0) ^ (c1 ? gmul(sc[i], c1) : 0));
}

static void fft8_scac(unsigned char *d, const unsigned char *sc,
		      unsigned char c0, unsigned char c1, size_t n)
{
	fft8_cnt_single++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_scac_v(d, sc, c0, c1, n);
		return;
	}
	for (size_t i = 0; i < n; i++)
		d[i] = (unsigned char)(gmul(d[i], c0) ^ (c1 ? gmul(sc[i], c1) : 0));
}

static void fft8_mul(unsigned char *d, const unsigned char *s,
		     unsigned char c, size_t n, int acc)
{
	fft8_cnt_single++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_mul_v2(d, s, c, n, acc);
		return;
	}
	for (size_t i = 0; i < n; i++)
		d[i] = acc ? (unsigned char)(d[i] ^ gmul(s[i], c)) : gmul(s[i], c);
}

/* Two layers per load, over four shards -- the GF(2^8) twin of fft_b2. This is
 * the whole of the kernel work in the tower (report 5.28 prices the three-layer
 * form as slower), and it matters more here: a GF(2^8) butterfly is one
 * `vgf2p8affineqb` against the tower's four, so the single-layer form is even
 * more load/store bound than its twin. ISAL8_FFT_BLOCK=0 restores the
 * one-layer walk, which is this one's null. */
__attribute__((target("avx2,gfni")))
static void fft8_b2_v(unsigned char *d0, unsigned char *d1,
		      unsigned char *d2, unsigned char *d3,
		      const unsigned char *s0, const unsigned char *s1,
		      const unsigned char *s2, const unsigned char *s3,
		      unsigned char m01, unsigned char m23, unsigned char m02,
		      size_t n, int inverse)
{
	uint64_t a01 = fft_affine[m01], a23 = fft_affine[m23], a02 = fft_affine[m02];
	size_t i = 0;
	for (; i + 32 <= n; i += 32) {
		__m256i x0 = _mm256_loadu_si256((const __m256i *)(s0 + i));
		__m256i x1 = _mm256_loadu_si256((const __m256i *)(s1 + i));
		__m256i x2 = _mm256_loadu_si256((const __m256i *)(s2 + i));
		__m256i x3 = _mm256_loadu_si256((const __m256i *)(s3 + i));
		if (!inverse) {
			if (m02) x0 = _mm256_xor_si256(x0, fft8_mul_v(x2, a02));
			x2 = _mm256_xor_si256(x2, x0);
			if (m02) x1 = _mm256_xor_si256(x1, fft8_mul_v(x3, a02));
			x3 = _mm256_xor_si256(x3, x1);
			if (m01) x0 = _mm256_xor_si256(x0, fft8_mul_v(x1, a01));
			x1 = _mm256_xor_si256(x1, x0);
			if (m23) x2 = _mm256_xor_si256(x2, fft8_mul_v(x3, a23));
			x3 = _mm256_xor_si256(x3, x2);
		} else {
			x1 = _mm256_xor_si256(x1, x0);
			if (m01) x0 = _mm256_xor_si256(x0, fft8_mul_v(x1, a01));
			x3 = _mm256_xor_si256(x3, x2);
			if (m23) x2 = _mm256_xor_si256(x2, fft8_mul_v(x3, a23));
			x2 = _mm256_xor_si256(x2, x0);
			if (m02) x0 = _mm256_xor_si256(x0, fft8_mul_v(x2, a02));
			x3 = _mm256_xor_si256(x3, x1);
			if (m02) x1 = _mm256_xor_si256(x1, fft8_mul_v(x3, a02));
		}
		_mm256_storeu_si256((__m256i *)(d0 + i), x0);
		_mm256_storeu_si256((__m256i *)(d1 + i), x1);
		_mm256_storeu_si256((__m256i *)(d2 + i), x2);
		_mm256_storeu_si256((__m256i *)(d3 + i), x3);
	}
	if (i < n) {
		/* Ragged tail, in scalar, in the same butterfly order. The FIRST
		 * butterfly of each pair reads s and writes d; the rest run in place
		 * on d, because d already holds the partial result by then. */
		size_t t = n - i;
		if (!inverse) {
			fft8_b1_io(d0 + i, d2 + i, s0 + i, s2 + i, m02, t, 0);
			fft8_b1_io(d1 + i, d3 + i, s1 + i, s3 + i, m02, t, 0);
			fft8_b1(d0 + i, d1 + i, m01, t, 0);
			fft8_b1(d2 + i, d3 + i, m23, t, 0);
		} else {
			fft8_b1_io(d0 + i, d1 + i, s0 + i, s1 + i, m01, t, 1);
			fft8_b1_io(d2 + i, d3 + i, s2 + i, s3 + i, m23, t, 1);
			fft8_b1(d0 + i, d2 + i, m02, t, 1);
			fft8_b1(d1 + i, d3 + i, m02, t, 1);
		}
	}
}

/* 512-bit lanes. The tower's fft_b2 is 256-bit for a reason its comment gives --
 * eight shards is 16 YMM of data and the multipliers spill. A GF(2^8) butterfly
 * carries one affine matrix where the tower carries four, so four shards is four
 * ZMM and three broadcast memory operands, and the pressure that forced 256-bit
 * there does not exist here. ISAL8_FFT_W=256 is the null.
 *
 * AND YET IT DOES NOT WIN, WHICH IS UNEXPLAINED AND IS STAYING THAT WAY.
 * The paragraph above predicts _z should beat _v. Measured, ISAL8_FFT_W=512 is
 * a wash -- KNOBS.md's ISAL8_FFT_W row carries the figures and is the
 * authority; this comment deliberately does not restate them, so it cannot go
 * stale against a re-measurement.
 *
 * The wash is itself informative: if doubling the lane width buys nothing, the
 * kernel is bound by its four load and four store streams rather than by vector
 * issue. What is NOT explained is why the bad end of the measured range is a
 * loss rather than a tie.
 *
 * Two hypotheses, NEITHER PROBED, written down so they are not re-derived:
 *   1. The measurement host is Zen 4 (Ryzen 9 7950X), which executes AVX-512 on
 *      256-bit datapaths, double-pumped. ZMM then halves the instruction count
 *      without raising bytes/cycle -- that predicts a tie, and predicts nothing
 *      about the tail.
 *   2. The tail path. _z handles whole 64-byte blocks and calls _v for the
 *      remainder, so any n not a multiple of 64 runs both kernels.
 * Separating them needs a single-variable probe, not a grid sweep.
 *
 * THIS IS A MARKER, NOT A TODO. It was removed from the work queue on
 * 1 September 2026 as not worth resolving: _v is the default, the knob's null
 * is measured, and no published figure depends on the answer. It lives here
 * rather than in a note because this is where anyone who wonders why the first
 * paragraph did not hold will actually be standing. */
__attribute__((target("avx512f,avx512bw,avx512vl,gfni")))
static void fft8_b2_z(unsigned char *d0, unsigned char *d1,
		      unsigned char *d2, unsigned char *d3,
		      const unsigned char *s0, const unsigned char *s1,
		      const unsigned char *s2, const unsigned char *s3,
		      unsigned char m01, unsigned char m23, unsigned char m02,
		      size_t n, int inverse)
{
	__m512i a01 = _mm512_set1_epi64((long long)fft_affine[m01]);
	__m512i a23 = _mm512_set1_epi64((long long)fft_affine[m23]);
	__m512i a02 = _mm512_set1_epi64((long long)fft_affine[m02]);
	size_t i = 0;
	for (; i + 64 <= n; i += 64) {
		__m512i x0 = _mm512_loadu_si512((const void *)(s0 + i));
		__m512i x1 = _mm512_loadu_si512((const void *)(s1 + i));
		__m512i x2 = _mm512_loadu_si512((const void *)(s2 + i));
		__m512i x3 = _mm512_loadu_si512((const void *)(s3 + i));
		if (!inverse) {
			if (m02) x0 = _mm512_xor_si512(x0, _mm512_gf2p8affine_epi64_epi8(x2, a02, 0));
			x2 = _mm512_xor_si512(x2, x0);
			if (m02) x1 = _mm512_xor_si512(x1, _mm512_gf2p8affine_epi64_epi8(x3, a02, 0));
			x3 = _mm512_xor_si512(x3, x1);
			if (m01) x0 = _mm512_xor_si512(x0, _mm512_gf2p8affine_epi64_epi8(x1, a01, 0));
			x1 = _mm512_xor_si512(x1, x0);
			if (m23) x2 = _mm512_xor_si512(x2, _mm512_gf2p8affine_epi64_epi8(x3, a23, 0));
			x3 = _mm512_xor_si512(x3, x2);
		} else {
			x1 = _mm512_xor_si512(x1, x0);
			if (m01) x0 = _mm512_xor_si512(x0, _mm512_gf2p8affine_epi64_epi8(x1, a01, 0));
			x3 = _mm512_xor_si512(x3, x2);
			if (m23) x2 = _mm512_xor_si512(x2, _mm512_gf2p8affine_epi64_epi8(x3, a23, 0));
			x2 = _mm512_xor_si512(x2, x0);
			if (m02) x0 = _mm512_xor_si512(x0, _mm512_gf2p8affine_epi64_epi8(x2, a02, 0));
			x3 = _mm512_xor_si512(x3, x1);
			if (m02) x1 = _mm512_xor_si512(x1, _mm512_gf2p8affine_epi64_epi8(x3, a02, 0));
		}
		_mm512_storeu_si512((void *)(d0 + i), x0);
		_mm512_storeu_si512((void *)(d1 + i), x1);
		_mm512_storeu_si512((void *)(d2 + i), x2);
		_mm512_storeu_si512((void *)(d3 + i), x3);
	}
	if (i < n)
		fft8_b2_v(d0 + i, d1 + i, d2 + i, d3 + i,
			  s0 + i, s1 + i, s2 + i, s3 + i, m01, m23, m02, n - i, inverse);
}

/*
 * THREE LAYERS AT A TIME, over eight shards -- the GF(2^8) twin of fft_b3, and
 * the one the tower's own note predicts will behave differently here.
 *
 * THE BINDING RESOURCE IS MEMORY STREAMS, not registers. rs_point.c's fft_b3
 * comment prices the tower's forms at f = 255 / 4 MiB: plain (4 streams) 1.64,
 * two-layer (8 streams) 0.896, three-layer (16 streams) 0.941 -- and rules out
 * register pressure, because the hand-written assembly removes all 151 stack
 * operands and still only reaches 0.98x-1.00x. Eight streams is the optimum on
 * this machine and sixteen is past it.
 *
 * A tower shard is TWO streams, lo and hi being whole planes; a GF(2^8) shard
 * is ONE. So the stream counts are halved throughout:
 *
 *   layers  shards   tower streams   GF(2^8) streams
 *     1        2           4               2
 *     2        4           8  <- optimum   4  <- fft8_b2, the current default
 *     3        8          16               8  <- this
 *
 * i.e. this form sits where the tower's two-layer form sits, and the current
 * GF(2^8) default sits where the tower's one-layer form sits. The measured
 * 1.2x-1.45x for two-layer over one-layer here is the 2 -> 4 stream step; this
 * is the 4 -> 8 one. ISAL8_FFT_BLOCK3=1 opts in; ISAL8_FFT_BLOCK=1 is its null.
 *
 * Named locals rather than an x[8] array, for the reason fft_b3 records: an
 * array leaves the block on the stack, which is the opposite of the point.
 * Destinations are separate so the fused copy-in can use this form too.
 */
/*
 * EVEX, not VEX, and the reason is in the compiler output rather than the ISA.
 * Under target("avx2,gfni") this body carries 137 stack-operand instructions of
 * 603 against fft8_b2_v's 28 of 245, and they are SCALAR movs, not vector
 * spills: eight source and eight destination pointers exceed the ~14 usable
 * GPRs, so every iteration reloads them. That is the same failure fft_b3's
 * comment records one field up. avx512vl gives 32 vector registers and lets the
 * seven multipliers be broadcast memory operands, which frees the pointers.
 * Still 256-bit lanes -- this is about register naming, not width.
 */
__attribute__((target("avx512vl,avx512bw,gfni")))
static void fft8_b3_v(unsigned char *const *d, const unsigned char *const *sp,
		      unsigned char m4, const unsigned char *m2,
		      const unsigned char *m1, size_t n, int inverse)
{
	uint64_t a4 = fft_affine[m4];
	uint64_t a20 = fft_affine[m2[0]], a21 = fft_affine[m2[1]];
	uint64_t a10 = fft_affine[m1[0]], a11 = fft_affine[m1[1]];
	uint64_t a12 = fft_affine[m1[2]], a13 = fft_affine[m1[3]];
	const unsigned char *s0 = sp[0], *s1 = sp[1], *s2 = sp[2], *s3 = sp[3];
	const unsigned char *s4 = sp[4], *s5 = sp[5], *s6 = sp[6], *s7 = sp[7];
	unsigned char *d0 = d[0], *d1 = d[1], *d2 = d[2], *d3 = d[3];
	unsigned char *d4 = d[4], *d5 = d[5], *d6 = d[6], *d7 = d[7];
	size_t i = 0;

#define FB(X, Y, A, C) do { if (C) (X) = _mm256_xor_si256((X), fft8_mul_v((Y), (A))); \
			    (Y) = _mm256_xor_si256((Y), (X)); } while (0)
#define IB(X, Y, A, C) do { (Y) = _mm256_xor_si256((Y), (X)); \
			    if (C) (X) = _mm256_xor_si256((X), fft8_mul_v((Y), (A))); } while (0)
	for (; i + 32 <= n; i += 32) {
		__m256i x0 = _mm256_loadu_si256((const __m256i *)(s0 + i));
		__m256i x1 = _mm256_loadu_si256((const __m256i *)(s1 + i));
		__m256i x2 = _mm256_loadu_si256((const __m256i *)(s2 + i));
		__m256i x3 = _mm256_loadu_si256((const __m256i *)(s3 + i));
		__m256i x4 = _mm256_loadu_si256((const __m256i *)(s4 + i));
		__m256i x5 = _mm256_loadu_si256((const __m256i *)(s5 + i));
		__m256i x6 = _mm256_loadu_si256((const __m256i *)(s6 + i));
		__m256i x7 = _mm256_loadu_si256((const __m256i *)(s7 + i));
		if (!inverse) {
			FB(x0, x4, a4, m4);   FB(x1, x5, a4, m4);
			FB(x2, x6, a4, m4);   FB(x3, x7, a4, m4);
			FB(x0, x2, a20, m2[0]); FB(x1, x3, a20, m2[0]);
			FB(x4, x6, a21, m2[1]); FB(x5, x7, a21, m2[1]);
			FB(x0, x1, a10, m1[0]); FB(x2, x3, a11, m1[1]);
			FB(x4, x5, a12, m1[2]); FB(x6, x7, a13, m1[3]);
		} else {
			IB(x0, x1, a10, m1[0]); IB(x2, x3, a11, m1[1]);
			IB(x4, x5, a12, m1[2]); IB(x6, x7, a13, m1[3]);
			IB(x0, x2, a20, m2[0]); IB(x1, x3, a20, m2[0]);
			IB(x4, x6, a21, m2[1]); IB(x5, x7, a21, m2[1]);
			IB(x0, x4, a4, m4);   IB(x1, x5, a4, m4);
			IB(x2, x6, a4, m4);   IB(x3, x7, a4, m4);
		}
		_mm256_storeu_si256((__m256i *)(d0 + i), x0);
		_mm256_storeu_si256((__m256i *)(d1 + i), x1);
		_mm256_storeu_si256((__m256i *)(d2 + i), x2);
		_mm256_storeu_si256((__m256i *)(d3 + i), x3);
		_mm256_storeu_si256((__m256i *)(d4 + i), x4);
		_mm256_storeu_si256((__m256i *)(d5 + i), x5);
		_mm256_storeu_si256((__m256i *)(d6 + i), x6);
		_mm256_storeu_si256((__m256i *)(d7 + i), x7);
	}
#undef FB
#undef IB
	if (i < n) {
		/* Ragged tail in scalar, same butterfly order. The first butterfly
		 * each shard meets moves s -> d; the rest run in place on d. */
		size_t t = n - i;
		if (!inverse) {
			fft8_b1_io(d0 + i, d4 + i, s0 + i, s4 + i, m4, t, 0);
			fft8_b1_io(d1 + i, d5 + i, s1 + i, s5 + i, m4, t, 0);
			fft8_b1_io(d2 + i, d6 + i, s2 + i, s6 + i, m4, t, 0);
			fft8_b1_io(d3 + i, d7 + i, s3 + i, s7 + i, m4, t, 0);
			fft8_b1(d0 + i, d2 + i, m2[0], t, 0);
			fft8_b1(d1 + i, d3 + i, m2[0], t, 0);
			fft8_b1(d4 + i, d6 + i, m2[1], t, 0);
			fft8_b1(d5 + i, d7 + i, m2[1], t, 0);
			fft8_b1(d0 + i, d1 + i, m1[0], t, 0);
			fft8_b1(d2 + i, d3 + i, m1[1], t, 0);
			fft8_b1(d4 + i, d5 + i, m1[2], t, 0);
			fft8_b1(d6 + i, d7 + i, m1[3], t, 0);
		} else {
			fft8_b1_io(d0 + i, d1 + i, s0 + i, s1 + i, m1[0], t, 1);
			fft8_b1_io(d2 + i, d3 + i, s2 + i, s3 + i, m1[1], t, 1);
			fft8_b1_io(d4 + i, d5 + i, s4 + i, s5 + i, m1[2], t, 1);
			fft8_b1_io(d6 + i, d7 + i, s6 + i, s7 + i, m1[3], t, 1);
			fft8_b1(d0 + i, d2 + i, m2[0], t, 1);
			fft8_b1(d1 + i, d3 + i, m2[0], t, 1);
			fft8_b1(d4 + i, d6 + i, m2[1], t, 1);
			fft8_b1(d5 + i, d7 + i, m2[1], t, 1);
			fft8_b1(d0 + i, d4 + i, m4, t, 1);
			fft8_b1(d1 + i, d5 + i, m4, t, 1);
			fft8_b1(d2 + i, d6 + i, m4, t, 1);
			fft8_b1(d3 + i, d7 + i, m4, t, 1);
		}
	}
}

static void fft8_b3_io(unsigned char *const *d, const unsigned char *const *sp,
		       unsigned char m4, const unsigned char *m2,
		       const unsigned char *m1, size_t n, int inverse);

/*
 * IN PLACE, eight pointers instead of sixteen, and that is the whole point.
 * The io form above needs a source and a destination for each of eight shards;
 * sixteen live pointers against ~14 usable GPRs is what put 116 scalar reloads
 * in its inner loop. Every walk pass is in place, so every walk pass uses this;
 * only the fused copy in, which runs once per encode, needs the other.
 */
__attribute__((target("avx512vl,avx512bw,gfni")))
static void fft8_b3_ip(unsigned char *p0, unsigned char *p1, unsigned char *p2,
		       unsigned char *p3, unsigned char *p4, unsigned char *p5,
		       unsigned char *p6, unsigned char *p7,
		       unsigned char m4, const unsigned char *m2,
		       const unsigned char *m1, size_t n, int inverse)
{
	__m256i a4 = _mm256_set1_epi64x((long long)fft_affine[m4]);
	__m256i a20 = _mm256_set1_epi64x((long long)fft_affine[m2[0]]);
	__m256i a21 = _mm256_set1_epi64x((long long)fft_affine[m2[1]]);
	__m256i a10 = _mm256_set1_epi64x((long long)fft_affine[m1[0]]);
	__m256i a11 = _mm256_set1_epi64x((long long)fft_affine[m1[1]]);
	__m256i a12 = _mm256_set1_epi64x((long long)fft_affine[m1[2]]);
	__m256i a13 = _mm256_set1_epi64x((long long)fft_affine[m1[3]]);
	unsigned char c4 = m4, c20 = m2[0], c21 = m2[1];
	unsigned char c10 = m1[0], c11 = m1[1], c12 = m1[2], c13 = m1[3];
	size_t i = 0;
#define MU(V, A) _mm256_gf2p8affine_epi64_epi8((V), (A), 0)
#define FB(X, Y, A, C) do { if (C) (X) = _mm256_xor_si256((X), MU((Y), (A))); \
			    (Y) = _mm256_xor_si256((Y), (X)); } while (0)
#define IB(X, Y, A, C) do { (Y) = _mm256_xor_si256((Y), (X)); \
			    if (C) (X) = _mm256_xor_si256((X), MU((Y), (A))); } while (0)
	for (; i + 32 <= n; i += 32) {
		__m256i x0 = _mm256_loadu_si256((const __m256i *)(p0 + i));
		__m256i x1 = _mm256_loadu_si256((const __m256i *)(p1 + i));
		__m256i x2 = _mm256_loadu_si256((const __m256i *)(p2 + i));
		__m256i x3 = _mm256_loadu_si256((const __m256i *)(p3 + i));
		__m256i x4 = _mm256_loadu_si256((const __m256i *)(p4 + i));
		__m256i x5 = _mm256_loadu_si256((const __m256i *)(p5 + i));
		__m256i x6 = _mm256_loadu_si256((const __m256i *)(p6 + i));
		__m256i x7 = _mm256_loadu_si256((const __m256i *)(p7 + i));
		if (!inverse) {
			FB(x0, x4, a4, c4);   FB(x1, x5, a4, c4);
			FB(x2, x6, a4, c4);   FB(x3, x7, a4, c4);
			FB(x0, x2, a20, c20); FB(x1, x3, a20, c20);
			FB(x4, x6, a21, c21); FB(x5, x7, a21, c21);
			FB(x0, x1, a10, c10); FB(x2, x3, a11, c11);
			FB(x4, x5, a12, c12); FB(x6, x7, a13, c13);
		} else {
			IB(x0, x1, a10, c10); IB(x2, x3, a11, c11);
			IB(x4, x5, a12, c12); IB(x6, x7, a13, c13);
			IB(x0, x2, a20, c20); IB(x1, x3, a20, c20);
			IB(x4, x6, a21, c21); IB(x5, x7, a21, c21);
			IB(x0, x4, a4, c4);   IB(x1, x5, a4, c4);
			IB(x2, x6, a4, c4);   IB(x3, x7, a4, c4);
		}
		_mm256_storeu_si256((__m256i *)(p0 + i), x0);
		_mm256_storeu_si256((__m256i *)(p1 + i), x1);
		_mm256_storeu_si256((__m256i *)(p2 + i), x2);
		_mm256_storeu_si256((__m256i *)(p3 + i), x3);
		_mm256_storeu_si256((__m256i *)(p4 + i), x4);
		_mm256_storeu_si256((__m256i *)(p5 + i), x5);
		_mm256_storeu_si256((__m256i *)(p6 + i), x6);
		_mm256_storeu_si256((__m256i *)(p7 + i), x7);
	}
#undef MU
#undef FB
#undef IB
	if (i < n) {
		unsigned char *q[8] = { p0, p1, p2, p3, p4, p5, p6, p7 };
		size_t t = n - i;
		if (!inverse) {
			for (int j = 0; j < 4; j++) fft8_b1(q[j] + i, q[j + 4] + i, m4, t, 0);
			fft8_b1(q[0] + i, q[2] + i, m2[0], t, 0);
			fft8_b1(q[1] + i, q[3] + i, m2[0], t, 0);
			fft8_b1(q[4] + i, q[6] + i, m2[1], t, 0);
			fft8_b1(q[5] + i, q[7] + i, m2[1], t, 0);
			for (int j = 0; j < 4; j++)
				fft8_b1(q[2 * j] + i, q[2 * j + 1] + i, m1[j], t, 0);
		} else {
			for (int j = 0; j < 4; j++)
				fft8_b1(q[2 * j] + i, q[2 * j + 1] + i, m1[j], t, 1);
			fft8_b1(q[0] + i, q[2] + i, m2[0], t, 1);
			fft8_b1(q[1] + i, q[3] + i, m2[0], t, 1);
			fft8_b1(q[4] + i, q[6] + i, m2[1], t, 1);
			fft8_b1(q[5] + i, q[7] + i, m2[1], t, 1);
			for (int j = 0; j < 4; j++) fft8_b1(q[j] + i, q[j + 4] + i, m4, t, 1);
		}
	}
}

static void fft8_b3(unsigned char *const *bl, unsigned char m4,
		    const unsigned char *m2, const unsigned char *m1,
		    size_t n, int inverse)
{
	fft8_cnt_b3++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_b3_ip(bl[0], bl[1], bl[2], bl[3], bl[4], bl[5], bl[6], bl[7],
			   m4, m2, m1, n, inverse);
		return;
	}
	fft8_b3_io(bl, (const unsigned char *const *)bl, m4, m2, m1, n, inverse);
}

static void fft8_b3_io(unsigned char *const *d, const unsigned char *const *sp,
		       unsigned char m4, const unsigned char *m2,
		       const unsigned char *m1, size_t n, int inverse)
{
	fft8_cnt_b3++;
	if (fft8_gfni && !fft8_scalar_only) {
		fft8_b3_v(d, sp, m4, m2, m1, n, inverse);
		return;
	}
	if (!inverse) {
		fft8_b1_io(d[0], d[4], sp[0], sp[4], m4, n, 0);
		fft8_b1_io(d[1], d[5], sp[1], sp[5], m4, n, 0);
		fft8_b1_io(d[2], d[6], sp[2], sp[6], m4, n, 0);
		fft8_b1_io(d[3], d[7], sp[3], sp[7], m4, n, 0);
		fft8_b1(d[0], d[2], m2[0], n, 0); fft8_b1(d[1], d[3], m2[0], n, 0);
		fft8_b1(d[4], d[6], m2[1], n, 0); fft8_b1(d[5], d[7], m2[1], n, 0);
		fft8_b1(d[0], d[1], m1[0], n, 0); fft8_b1(d[2], d[3], m1[1], n, 0);
		fft8_b1(d[4], d[5], m1[2], n, 0); fft8_b1(d[6], d[7], m1[3], n, 0);
	} else {
		fft8_b1_io(d[0], d[1], sp[0], sp[1], m1[0], n, 1);
		fft8_b1_io(d[2], d[3], sp[2], sp[3], m1[1], n, 1);
		fft8_b1_io(d[4], d[5], sp[4], sp[5], m1[2], n, 1);
		fft8_b1_io(d[6], d[7], sp[6], sp[7], m1[3], n, 1);
		fft8_b1(d[0], d[2], m2[0], n, 1); fft8_b1(d[1], d[3], m2[0], n, 1);
		fft8_b1(d[4], d[6], m2[1], n, 1); fft8_b1(d[5], d[7], m2[1], n, 1);
		fft8_b1(d[0], d[4], m4, n, 1); fft8_b1(d[1], d[5], m4, n, 1);
		fft8_b1(d[2], d[6], m4, n, 1); fft8_b1(d[3], d[7], m4, n, 1);
	}
}

static int fft8_block3;			/* ISAL8_FFT_BLOCK3 */

static int fft8_w512;

static void fft8_b2_io(unsigned char *d0, unsigned char *d1,
		       unsigned char *d2, unsigned char *d3,
		       const unsigned char *s0, const unsigned char *s1,
		       const unsigned char *s2, const unsigned char *s3,
		       unsigned char m01, unsigned char m23, unsigned char m02,
		       size_t n, int inverse)
{
	fft8_cnt_b2++;
	if (fft8_gfni && !fft8_scalar_only) {
		if (fft8_w512)
			fft8_b2_z(d0, d1, d2, d3, s0, s1, s2, s3, m01, m23, m02, n, inverse);
		else
			fft8_b2_v(d0, d1, d2, d3, s0, s1, s2, s3, m01, m23, m02, n, inverse);
		return;
	}
	/* Scalar fallback: the first butterfly of each pair moves s -> d, the
	 * second runs in place on d. Same order as the vector kernels. */
	if (!inverse) {
		fft8_b1_io(d0, d2, s0, s2, m02, n, 0);
		fft8_b1_io(d1, d3, s1, s3, m02, n, 0);
		fft8_b1(d0, d1, m01, n, 0); fft8_b1(d2, d3, m23, n, 0);
	} else {
		fft8_b1_io(d0, d1, s0, s1, m01, n, 1);
		fft8_b1_io(d2, d3, s2, s3, m23, n, 1);
		fft8_b1(d0, d2, m02, n, 1); fft8_b1(d1, d3, m02, n, 1);
	}
}

static inline void fft8_b2(unsigned char *s0, unsigned char *s1,
			   unsigned char *s2, unsigned char *s3,
			   unsigned char m01, unsigned char m23, unsigned char m02,
			   size_t n, int inverse)
{
	fft8_b2_io(s0, s1, s2, s3, s0, s1, s2, s3, m01, m23, m02, n, inverse);
}

/* -------------------------------------------------------------- the walks */

static void fft8_fwd(unsigned char *const *sh, unsigned size, unsigned trunc,
		     unsigned skd, size_t n, int skip1)
{
	for (unsigned dist = skip1 ? size / 4 : size / 2; dist > 0; dist /= 2)
		for (unsigned r = 0; r < trunc; r += dist * 2) {
			unsigned char s = fft8_skew[r + dist + skd - 1];
			for (unsigned i = r; i < r + dist; i++)
				fft8_b1(sh[i], sh[i + dist], s, n, 0);
		}
}

static void fft8_inv(unsigned char *const *sh, unsigned size, unsigned trunc,
		     unsigned skd, size_t n, int skip1)
{
	for (unsigned dist = skip1 ? 2 : 1; dist < size; dist *= 2)
		for (unsigned r = 0; r < trunc; r += dist * 2) {
			unsigned char s = fft8_skew[r + dist + skd - 1];
			for (unsigned i = r; i < r + dist; i++)
				fft8_b1(sh[i], sh[i + dist], s, n, 1);
		}
}

static int fft8_block = 1;		/* ISAL8_FFT_BLOCK */

static void fft8_fwd2(unsigned char *const *sh, unsigned size, unsigned trunc,
		      unsigned skd, size_t n, int skip1)
{
	/* skip1: the widest pass has already run, fused with the coset copy, and
	 * `dist4` must carry the value it would have left behind. */
	unsigned dist4 = skip1 ? (size >> 2) : size;
	for (unsigned dist = skip1 ? (size >> 4) : (size >> 2); dist != 0; dist >>= 2) {
		for (unsigned r = 0; r < trunc; r += dist4) {
			unsigned b = r + dist + skd - 1;
			for (unsigned i = r; i < r + dist; i++)
				fft8_b2(sh[i], sh[i + dist], sh[i + 2 * dist],
					sh[i + 3 * dist], fft8_skew[b],
					fft8_skew[b + dist * 2], fft8_skew[b + dist],
					n, 0);
		}
		dist4 = dist;
	}
	if (dist4 == 2)
		for (unsigned r = 0; r < trunc; r += 2)
			fft8_b1(sh[r], sh[r + 1], fft8_skew[r + skd], n, 0);
}

static void fft8_inv2(unsigned char *const *sh, unsigned size, unsigned trunc,
		      unsigned skd, size_t n, int skip1)
{
	/* skip1: the dist = 1 pass has already run, fused with the copy in.
	 * Resuming means starting at dist = 4, i.e. dist4 = 16. The b1 tail below
	 * is unaffected -- it is the LAST pass, not the first. */
	unsigned dist = skip1 ? 4 : 1;
	for (unsigned dist4 = skip1 ? 16 : 4; dist4 <= size; dist4 <<= 2) {
		for (unsigned r = 0; r < trunc; r += dist4) {
			unsigned b = r + dist + skd - 1;
			for (unsigned i = r; i < r + dist; i++)
				fft8_b2(sh[i], sh[i + dist], sh[i + 2 * dist],
					sh[i + 3 * dist], fft8_skew[b],
					fft8_skew[b + dist * 2], fft8_skew[b + dist],
					n, 1);
		}
		dist = dist4;
	}
	if (dist < size) {
		unsigned char s = fft8_skew[dist + skd - 1];
		for (unsigned i = 0; i < dist; i++)
			fft8_b1(sh[i], sh[i + dist], s, n, 1);
	}
}

/* Three layers per pass. Shape and leftover peeling are fft_three/ifft_three's,
 * one field down: log2(size) mod 3 layers remain and are taken by the two-layer
 * form when that is 2 and by a single layer when it is 1. */
static void fft8_fwd3(unsigned char *const *sh, unsigned size, unsigned trunc,
		      unsigned skd, size_t n, int skip1)
{
	unsigned dist4 = skip1 ? (size >> 3) : size;
	for (unsigned d = skip1 ? (size >> 6) : (size >> 3); d != 0; d >>= 3) {
		for (unsigned r = 0; r < trunc; r += d * 8) {
			unsigned b = r + skd - 1;
			unsigned char m4 = fft8_skew[b + 4 * d];
			unsigned char m2[2] = { fft8_skew[b + 2 * d], fft8_skew[b + 6 * d] };
			unsigned char m1[4] = { fft8_skew[b + d], fft8_skew[b + 3 * d],
						fft8_skew[b + 5 * d], fft8_skew[b + 7 * d] };
			for (unsigned i = r; i < r + d; i++) {
				unsigned char *bl[8];
				for (int j = 0; j < 8; j++)
					bl[j] = sh[i + (unsigned)j * d];
				fft8_b3(bl, m4, m2, m1, n, 0);
			}
		}
		dist4 = d;
	}
	if (dist4 == 4) {
		for (unsigned r = 0; r < trunc; r += 4) {
			unsigned b = r + skd;
			fft8_b2(sh[r], sh[r + 1], sh[r + 2], sh[r + 3], fft8_skew[b],
				fft8_skew[b + 2], fft8_skew[b + 1], n, 0);
		}
	} else if (dist4 == 2) {
		for (unsigned r = 0; r < trunc; r += 2)
			fft8_b1(sh[r], sh[r + 1], fft8_skew[r + skd], n, 0);
	}
}

static void fft8_inv3(unsigned char *const *sh, unsigned size, unsigned trunc,
		      unsigned skd, size_t n, int skip1)
{
	unsigned d = skip1 ? 8 : 1;
	for (unsigned d8 = skip1 ? 64 : 8; d8 <= size; d8 <<= 3) {
		for (unsigned r = 0; r < trunc; r += d8) {
			unsigned b = r + skd - 1;
			unsigned char m4 = fft8_skew[b + 4 * d];
			unsigned char m2[2] = { fft8_skew[b + 2 * d], fft8_skew[b + 6 * d] };
			unsigned char m1[4] = { fft8_skew[b + d], fft8_skew[b + 3 * d],
						fft8_skew[b + 5 * d], fft8_skew[b + 7 * d] };
			for (unsigned i = r; i < r + d; i++) {
				unsigned char *bl[8];
				for (int j = 0; j < 8; j++)
					bl[j] = sh[i + (unsigned)j * d];
				fft8_b3(bl, m4, m2, m1, n, 1);
			}
		}
		d = d8;
	}
	if (d * 4 <= size) {
		for (unsigned r = 0; r < trunc; r += d * 4) {
			unsigned b = r + d + skd - 1;
			for (unsigned i = r; i < r + d; i++)
				fft8_b2(sh[i], sh[i + d], sh[i + 2 * d], sh[i + 3 * d],
					fft8_skew[b], fft8_skew[b + d * 2],
					fft8_skew[b + d], n, 1);
		}
		d = size;
	}
	if (d < size) {
		unsigned char sk = fft8_skew[d + skd - 1];
		for (unsigned i = 0; i < d; i++)
			fft8_b1(sh[i], sh[i + d], sk, n, 1);
	}
}

/* How many shards the FIRST pass of a walk of this width covers, so the fused
 * copy in and the walk that resumes after it cannot disagree. */
static unsigned fft8_grp(unsigned size)
{
	if (fft8_block3 && size >= 8) return 8;
	if (fft8_block && size >= 4) return 4;
	return 2;
}

static void fft8_run_s(unsigned char *const *sh, unsigned size, unsigned trunc,
		       unsigned skd, size_t n, int inverse, int skip1)
{
	if (fft8_block3 && size >= 8) {
		inverse ? fft8_inv3(sh, size, trunc, skd, n, skip1)
			: fft8_fwd3(sh, size, trunc, skd, n, skip1);
		return;
	}
	if (fft8_block && size >= 4) {
		inverse ? fft8_inv2(sh, size, trunc, skd, n, skip1)
			: fft8_fwd2(sh, size, trunc, skd, n, skip1);
		return;
	}
	inverse ? fft8_inv(sh, size, trunc, skd, n, skip1)
		: fft8_fwd(sh, size, trunc, skd, n, skip1);
}

static void fft8_run(unsigned char *const *sh, unsigned size, unsigned trunc,
		     unsigned skd, size_t n, int inverse)
{
	fft8_run_s(sh, size, trunc, skd, n, inverse, 0);
}

/* ------------------------------------------------------------ the encoder */

static unsigned char **fft8_w;		/* chunk work shards */
static unsigned char **fft8_sc;		/* ppt_scratch_max scratch shards */
static unsigned char **fft8_ov;		/* chunk coset-overflow shards */
static unsigned char **fft8_cs;		/* chunk pointers, coset 1 */
static unsigned char **fft8_ct;		/* chunk pointers, cosets 2.. */
static unsigned char *fft8_pool;
static unsigned char *fft8_zero;	/* one shard, zero, never written */
static int fft8_fuse = 1;		/* ISAL8_FUSE=0 is the null */
static int fft8_cfuse = 1;		/* ISAL8_COSET_FUSE=0 is the null */

static unsigned fft8_np2(unsigned x)
{
	unsigned c = 1;
	while (c < x)
		c <<= 1;
	return c;
}

/*
 * AUTO'S CHOICE OF PIVOT BASE: the maximum feasible one, by rule.
 *
 * The node budget is exact and it is the only constraint -- parity occupies
 * kp .. kp+m-1, so kp <= 256 - m, and there is nothing above chunk to pivot.
 * Hence
 *
 *     kp = min(chunk, 256 - m)
 *
 * which is the rule the ISAL8_INTERP comment block above already states. It
 * reads no constants and no kernel knobs, so it CANNOT be made to read one:
 * that removes section 16.3's whole hazard class at the root rather than
 * guarding against it, and it is why this is a rule and not a repaired model.
 *
 * THIS REPLACED A COST MODEL, and section 18 of PERF-NOTES-FFT-GF8-PPT.md is
 * why. Both rules scored against the best base at each shape, 82 measured
 * points, results/gf8-kp-rule-20260827.csv:
 *
 *   rule            regime 1 (hi == chunk, 54 pts)  regime 2 (hi < chunk, 28)
 *   this one        max 1.095, median 1.000         max 1.150, median 1.002
 *   the cost model  max 1.424, median 1.145         max 1.150, median 1.000
 *
 * Regime 1 is settled: where the padding fits, the maximum base is optimal on
 * every kernel measured -- three-layer AVX-512VL down to pure scalar, section
 * 18.6 -- so no architecture dependence remains in it. Regime 2 is not
 * settleable by ANY constant-free rule, and section 18.8 measures 1.150 as the
 * floor for one rather than as a defect in this one: lowering kp genuinely
 * removes transform work and genuinely adds glue passes, so which you prefer
 * is the machine's compute-to-bandwidth ratio. Repairing the model instead
 * does not beat the rule and makes the pick MORE machine-tied, moving with B
 * at 34 of 85 shapes against the shipped model's 19: section 18.11.
 */
static unsigned fft8_pick_kp(int k, int m, unsigned chunk)
{
	unsigned kp = (unsigned)(256 - m);
	if (kp > chunk)
		kp = chunk;
	/* T <= 256 gives k <= 256 - m, so this clamp cannot fire. It is here so
	 * the result is a feasible base by construction rather than by that
	 * argument holding at every caller. */
	if (kp < (unsigned)k)
		kp = (unsigned)k;
	return kp;
}

/* Shape-only, once per process: the skew table, the op list and the buffers.
 * Returns -1 if the field cannot host the transform at this shape. */

static int fft8_init(int k, int m, size_t stride)
{
	unsigned chunk = fft8_np2((unsigned)k);
	/* Under padding the interpolation block yields NO parity -- its upper
	 * slots are the zeros that shorten the code -- so parity starts at chunk
	 * and every shard of it comes from a coset. Under PPT the block hands back
	 * chunk-k of them for free, which is what removes a coset at high f. */
	unsigned direct = chunk - ev_kp;
	if (direct > (unsigned)m)
		direct = (unsigned)m;
	unsigned rest = (unsigned)m - direct;
	unsigned ncos = (rest + chunk - 1) / chunk;
	if ((ncos + 1) * chunk > 256)
		return -1;

	fft8_chunk = chunk; fft8_ncos = ncos; fft8_direct = direct;
	fft8_gfni = cpu_has_gfni();
	{
		const char *kv = getenv("ISAL8_FFT_KERNEL");
		fft8_scalar_only = kv && !strcmp(kv, "scalar");
		const char *bv = getenv("ISAL8_FFT_BLOCK");
		fft8_block = !(bv && !strcmp(bv, "0")) && !fft8_scalar_only;
		/* 512-bit lanes measured 0.93x-1.03x of 256 over the grid, median
		 * 1.00 -- a wash, which says this kernel is memory-bound and not
		 * issue-bound, report 9.1's conclusion in a third place. Default is
		 * therefore 256, matching the tower's choice. ISAL8_FFT_W=512 opts in. */
		fft8_phases = getenv("ISAL8_ENC_PHASES") != NULL;
		const char *fv = getenv("ISAL8_FUSE");
		fft8_fuse = !(fv && !strcmp(fv, "0"));
		/* Three layers per pass -- eight shards, eight memory streams, which
		 * is where the tower's TWO-layer form sits and where its measurements
		 * put the optimum. Off by default until a leg says otherwise; its null
		 * is the two-layer form. */
		const char *cf = getenv("ISAL8_COSET_FUSE");
		fft8_cfuse = !(cf && !strcmp(cf, "0"));
		const char *pf = getenv("ISAL8_PPT_FUSE");
		ppt_fuse = !(pf && !strcmp(pf, "0"));
		/* DEFAULT ON since results/gf8-block3-pair-20260825.csv: 48 points,
		 * 1.046 / 1.102 / 1.183, zero losses. See DEFAULTS.md. The AVX-512VL
		 * gate stays -- without it the eight-shard block has nowhere to live
		 * and this silently falls back to two layers, which is correct. */
		const char *b3 = getenv("ISAL8_FFT_BLOCK3");
		fft8_block3 = !(b3 && !strcmp(b3, "0")) && !fft8_scalar_only
			      && cpu_has_avx512vl();
		const char *wv = getenv("ISAL8_FFT_W");
		fft8_w512 = cpu_has_avx512vl() && wv && !strcmp(wv, "512");
	}
	/* ISA-L's constant -> affine table. run_gf16 builds it on its own path; the
	 * GF(2^8) transform is the first thing in this driver to need it without
	 * going through there, and reading it unbuilt is a table of zeros -- i.e.
	 * every multiply returns 0 and the parity is silently wrong. The scalar
	 * kernel does not use it, which is exactly how that was caught. */
	if (fft8_gfni)
		gf16_affine_init();
	fft8_skew_init();
	ppt_nops = 0; ppt_scratch_max = 0;
	if (ev_kp < chunk) {
		unsigned lg = 0;
		while ((1u << lg) < chunk)
			lg++;
		if (chunk >= 2)
			ppt_build(lg, ev_kp, 0);
	}

	/* work + PPT scratch + the coset overflow slots. A coset wants `want`
	 * outputs but the transform is chunk wide, so chunk - want slots have
	 * nowhere in `par` to live; they go here. Same device as the tower's
	 * fft_coset_shards, and the point of it is that a coset's RESULTS are never
	 * copied: the walk writes them where the caller wants them. */
	/* FIXME -- DEAD ALLOCATION, KNOWN AND DELIBERATELY UNFIXED.
	 *
	 * The first `chunk` slots of this pool are `fft8_w`, and fft8_encode reads
	 * `fft8_w` ONLY on the fft8_ncos == 0 path: when a coset exists it
	 * immediately rebinds w = fft8_cs. So in X's domain those `chunk` shards
	 * are allocated, zeroed by the memset below, and then never read or
	 * written. At f = 85 / 4 MiB that is about 6.1 MB.
	 *
	 * AND ncos == 0 IS UNREACHABLE HERE, which is a proof and not an
	 * observation. ncos == 0 iff rest == 0 iff direct == m iff
	 * chunk - ev_kp >= m. ev_kp is min(chunk, 256 - m) clamped up to k, so
	 * chunk - ev_kp is either 0 (when 256 - m >= chunk) or chunk - 256 + m.
	 * The first needs m == 0; the second needs chunk >= 256. With T = 3f+1
	 * <= 256 we have f <= 85, k <= 86 and chunk <= 128, so neither can hold --
	 * checked over every f and every explicit pivot base in
	 * [k, min(chunk, 256-m)], zero hits.
	 *
	 * WHY IT IS NOT FIXED. In theory it cannot touch a measurement: fft8_init
	 * runs once per process, before the trial loop, and the region is never
	 * touched again. In practice a spare 6 MB of zeroed pages is not free of
	 * consequence -- page-table and TLB footprint, allocator state, and what
	 * the kernel does with pages nobody faults again -- and this project has
	 * been surprised by out-of-timer work before. It is left because removing
	 * it edits the encode setup path, which every published GF(2^8) encode
	 * figure was measured through.
	 *
	 * IF YOU DO FIX IT: the small change is to size this region conditionally,
	 *   unsigned nbuf = (ncos ? 0 : chunk) + ppt_scratch_max + chunk + 1;
	 * and bind fft8_w only when ncos == 0, which keeps the dead branch correct
	 * for any shape that could reach it rather than deleting a code path on
	 * the strength of the argument above. Re-take the GF(2^8) encode leg
	 * afterwards; do not mix vintages. Written up in HARNESS.md (this tree's
	 * docs/, where the artifact ships it). */
	unsigned nbuf = chunk + ppt_scratch_max + chunk + 1;	/* +1: fft8_zero */
	fft8_pool = aligned_alloc(4096, ((size_t)nbuf * stride + 4095) & ~(size_t)4095);
	if (!fft8_pool)
		return -1;
	memset(fft8_pool, 0, (size_t)nbuf * stride);
	fft8_w = malloc((size_t)chunk * sizeof(*fft8_w));
	fft8_sc = ppt_scratch_max ? malloc((size_t)ppt_scratch_max * sizeof(*fft8_sc)) : NULL;
	size_t at = 0;
	for (unsigned i = 0; i < chunk; i++)
		fft8_w[i] = fft8_pool + (size_t)(at++) * stride;
	for (unsigned i = 0; i < ppt_scratch_max; i++)
		fft8_sc[i] = fft8_pool + (size_t)(at++) * stride;
	fft8_ov = malloc((size_t)chunk * sizeof(*fft8_ov));
	fft8_cs = malloc((size_t)chunk * sizeof(*fft8_cs));
	fft8_ct = malloc((size_t)chunk * sizeof(*fft8_ct));
	if (!fft8_ov || !fft8_cs || !fft8_ct)
		return -1;
	for (unsigned i = 0; i < chunk; i++)
		fft8_ov[i] = fft8_pool + (size_t)(at++) * stride;
	/* The pool is memset above and this slot is the one nothing ever writes,
	 * so the fused first pass can read it as the value at a padded node. */
	fft8_zero = fft8_pool + (size_t)(at++) * stride;
	fft8_ready = 1;
	return 0;
}

/*
 * THE INTERPOLATION'S FIRST PASS, FUSED WITH THE COPY IN.
 *
 * `copy_in` used to be its own pass over the whole message -- read the caller's
 * k shards, write the work buffer -- and the interpolation's first pass then
 * read and wrote that buffer again. The two are one pass: the first butterfly
 * layer can take its inputs from the caller's shards directly and land its
 * outputs in the work buffer, so the message is read once and written once
 * instead of twice each. Only the FIRST pass can do this; every later one reads
 * what the previous one wrote.
 *
 * Firedancer's generated encoder never materialises a work buffer at all -- it
 * streams 32 bytes of every shred through registers -- and at k = m = 32 that
 * copy was measured at 26% of this encoder's total, about two thirds of the gap
 * to theirs. This closes that part of it.
 *
 * PADDED NODES. Slots k..chunk-1 hold zeros as VALUES, so the pass reads
 * fft8_zero for them; the slot stays in cache and costs nothing. Blocks the
 * walk skips entirely (r >= trunc) are never written here, and the walk's
 * pruning is only valid because they hold zeros -- so they are memset, exactly
 * as copy_in did.
 *
 * Only on the plain-IFFT path (ev_kp == chunk). Under a partial pivot the first
 * thing to touch the buffer is a PPT op, not a butterfly, and the op list would
 * have to carry the fusion. ISAL8_FUSE=0 is the null.
 *
 * Returns nonzero if it ran, i.e. if the walk must skip its dist = 1 pass.
 */
static int fft8_fused_in(unsigned char *const *w, unsigned char *const *src,
			 unsigned k, unsigned chunk, unsigned trunc, size_t n)
{
	const unsigned char *z = fft8_zero;
	unsigned covered = 0, grp;

	if (!fft8_fuse || chunk < 2 || trunc == 0)
		return 0;
	grp = fft8_grp(chunk);
#define FSRC(i) ((i) < k ? (const unsigned char *)src[i] : z)
	if (grp == 8)
		for (unsigned r = 0; r < trunc; r += 8, covered = r) {
			unsigned b = r - 1;		/* skd == 0 here */
			unsigned char m4 = fft8_skew[b + 4];
			unsigned char m2[2] = { fft8_skew[b + 2], fft8_skew[b + 6] };
			unsigned char m1[4] = { fft8_skew[b + 1], fft8_skew[b + 3],
						fft8_skew[b + 5], fft8_skew[b + 7] };
			unsigned char *bl[8];
			const unsigned char *sr[8];
			for (unsigned j = 0; j < 8; j++) {
				bl[j] = w[r + j];
				sr[j] = FSRC(r + j);
			}
			fft8_b3_io(bl, sr, m4, m2, m1, n, 1);
		}
	else if (grp == 4)
		for (unsigned r = 0; r < trunc; r += 4, covered = r)
			fft8_b2_io(w[r], w[r + 1], w[r + 2], w[r + 3],
				   FSRC(r), FSRC(r + 1), FSRC(r + 2), FSRC(r + 3),
				   fft8_skew[r], fft8_skew[r + 2], fft8_skew[r + 1],
				   n, 1);
	else
		for (unsigned r = 0; r < trunc; r += 2, covered = r)
			fft8_b1_io(w[r], w[r + 1], FSRC(r), FSRC(r + 1),
				   fft8_skew[r], n, 1);
#undef FSRC
	for (unsigned i = covered; i < chunk; i++)
		memset(w[i], 0, n);
	return 1;
}

/*
 * A LATER COSET'S FIRST FORWARD PASS, FUSED WITH ITS COEFFICIENT COPY.
 *
 * The same trade as fft8_fused_in, on the output side. Cosets 2 and up each
 * need their own copy of the coefficient vector, because the first coset's walk
 * runs in place and destroys it -- so `coset_copy` read w and wrote the coset's
 * destination, and the coset's first forward pass then read and wrote that
 * destination again. Fused they are one pass: read w, write the destination.
 *
 * The widest forward pass covers ALL `chunk` slots whatever `trunc` is -- its
 * r loop steps by `size`, so only r = 0 runs and its blocks span the block --
 * which is what makes this legal, and it is also why the slots at and above
 * `nlive` need no separate memset: they read the permanently-zero shard and the
 * pass writes them.
 *
 * MUST RUN BEFORE the first coset's walk, exactly as the copy it replaces did.
 * ISAL8_COSET_FUSE=0 is the null.
 */
static int fft8_fused_coset(unsigned char *const *ct, unsigned char *const *w,
			    unsigned nlive, unsigned chunk, unsigned skd, size_t n)
{
	const unsigned char *z = fft8_zero;
	unsigned grp = fft8_grp(chunk);

	if (!fft8_cfuse || chunk < 2)
		return 0;
#define CSRC(i) ((i) < nlive ? (const unsigned char *)w[i] : z)
	if (grp == 8) {
		unsigned d = chunk >> 3, b = skd - 1;
		unsigned char m4 = fft8_skew[b + 4 * d];
		unsigned char m2[2] = { fft8_skew[b + 2 * d], fft8_skew[b + 6 * d] };
		unsigned char m1[4] = { fft8_skew[b + d], fft8_skew[b + 3 * d],
					fft8_skew[b + 5 * d], fft8_skew[b + 7 * d] };
		for (unsigned i = 0; i < d; i++) {
			unsigned char *bl[8];
			const unsigned char *sr[8];
			for (unsigned j = 0; j < 8; j++) {
				bl[j] = ct[i + j * d];
				sr[j] = CSRC(i + j * d);
			}
			fft8_b3_io(bl, sr, m4, m2, m1, n, 0);
		}
	} else if (grp == 4) {
		unsigned d = chunk >> 2, b = d + skd - 1;
		for (unsigned i = 0; i < d; i++)
			fft8_b2_io(ct[i], ct[i + d], ct[i + 2 * d], ct[i + 3 * d],
				   CSRC(i), CSRC(i + d), CSRC(i + 2 * d), CSRC(i + 3 * d),
				   fft8_skew[b], fft8_skew[b + d * 2], fft8_skew[b + d],
				   n, 0);
	} else {
		unsigned d = chunk >> 1;
		unsigned char sk = fft8_skew[d + skd - 1];
		for (unsigned i = 0; i < d; i++)
			fft8_b1_io(ct[i], ct[i + d], CSRC(i), CSRC(i + d), sk, n, 0);
	}
#undef CSRC
	return 1;
}

static void fft8_run_ppt_on(unsigned char **w, size_t n)
{
	for (unsigned q = 0; q < ppt_nops; q++) {
		const ppt_op *o = &ppt_ops[q];
		switch (o->op) {
		case P8_IFFT:
			fft8_run(&w[o->b], o->a, o->a, o->b, n, 1);
			break;
		case P8_FFT:
			fft8_run(&w[o->b], o->a, o->a, o->b, n, 0);
			break;
		case P8_COPY:
			memcpy(fft8_sc[o->b], w[o->a], n);
			break;
		case P8_SCALE:
			fft8_mul(w[o->a], w[o->a], o->c[0], n, 0);
			break;
		case P8_MULACC:
			fft8_mul(w[o->a], w[o->b], o->c[0], n, 1);
			break;
		case P8_MULACCS:
			fft8_mul(w[o->a], fft8_sc[o->b], o->c[0], n, 1);
			break;
		case P8_CPSC:
			fft8_cpsc(w[o->a], fft8_sc[o->b], w[o->a], o->c[0], n);
			break;
		case P8_SCAC:
			fft8_scac(w[o->a], fft8_sc[o->b], o->c[0], o->c[1], n);
			break;
		case P8_MM22:
			fft8_mm22(w[o->a], w[o->b], o->c, n);
			break;
		}
	}
}

/*
 * One encode. The work buffer and the op list are process-lifetime; what is per
 * call is the k copies in, the transform, and the parity stores -- the same
 * contract fft16_encode runs under.
 */
static void fft8_encode(int k, int m, size_t sz,
			unsigned char *const *src, unsigned char *const *par)
{
	unsigned chunk = fft8_chunk;
	int ph = fft8_phases;
	double tp = ph ? now_ms() : 0.0;
	if (ph) fft8_ph_n++;

	/*
	 * The work buffer IS the first recovery coset's destination.
	 *
	 * That is the whole of what fft_coset_shards buys the tower encoder, and
	 * doing anything else costs a chunk-wide copy per coset. `copy_in` writes
	 * the sources straight into the parity pool, PPT runs there, and the first
	 * coset's forward walk runs there in place -- its outputs land exactly
	 * where the caller wants them and are never moved. The `chunk - want` slots
	 * with nowhere in `par` to live go to overflow scratch.
	 *
	 * Measured, f = 63 / 4 MiB: copying results back out instead cost 0.341 ms
	 * of coset_copy against the tower's 0.084 for the same two cosets, and that
	 * difference WAS the encode gap -- the butterfly phases were already at
	 * parity or ahead (ppt 0.119 against ifft 0.125, coset_fft 0.240 against
	 * 0.259, on identical b2 counts of 144).
	 */
	unsigned char **w = fft8_w;
	unsigned want1 = 0;
	if (fft8_ncos) {
		want1 = (unsigned)m - fft8_direct;
		if (want1 > chunk)
			want1 = chunk;
		for (unsigned j = 0; j < chunk; j++)
			fft8_cs[j] = j < want1 ? par[fft8_direct + j] : fft8_ov[j - want1];
		w = fft8_cs;
	}

	/* On the plain-IFFT path the copy in IS the first butterfly pass; see
	 * fft8_fused_in. It is charged to the copy_in phase because that is the
	 * phase it replaces, so the `ppt` phase below reports one pass less. */
	int fused = (ev_kp == chunk)
		    && fft8_fused_in(w, src, (unsigned)k, chunk, (unsigned)k, sz);
	if (!fused) {
		for (int i = 0; i < k; i++)
			memcpy(w[i], src[i], sz);
		for (unsigned i = (unsigned)k; i < chunk; i++)
			memset(w[i], 0, sz);
	}
	if (ph) { fft8_ph[0] += now_ms() - tp; tp = now_ms(); }

	/*
	 * THE INTERPOLATION. Padding needs only the plain inverse walk over the
	 * whole block: the k data values are in place and the chunk-k slots above
	 * them were zeroed by copy_in, which is exactly the input contract
	 * ifft_plain runs under with `trunc = k` -- entries past it known zero, so
	 * the walk prunes them. `nlive` below is what the two constructions leave
	 * behind, and it is the only thing the rest of this function branches on.
	 */
	if (ev_kp == chunk)
		fft8_run_s(w, chunk, (unsigned)k, 0, sz, 1, fused);
	else
		fft8_run_ppt_on(w, sz);
	if (ph) { fft8_ph[1] += now_ms() - tp; tp = now_ms(); }

	/*
	 * WHAT IS LIVE IN w AFTER THE INTERPOLATION, and it differs.
	 *
	 * PPT leaves the degree-<k coefficient vector in w[0..k) and P's values at
	 * k..chunk-1 in w[k..chunk) -- the `direct` parity shards, sitting in slots
	 * the first coset is about to overwrite, so they move now, and the slots
	 * are then zeroed so the coset walks see a degree-<k polynomial.
	 *
	 * Padding leaves the degree-<chunk coefficient vector of the SHORTENED
	 * code across ALL of w[0..chunk). There is no direct parity and nothing to
	 * zero -- zeroing here would silently truncate the polynomial. This is
	 * what fft16_encode does, and `nlive` makes the two share one body.
	 */
	unsigned nlive = ev_kp;
	/* w[ev_kp + j], NOT w[k + j]: the values begin where the coefficients end,
	 * and those coincide only at the two endpoints -- kp = k, where the old
	 * spelling was right, and kp = chunk, where direct is 0 and this loop never
	 * runs. Every partial pivot between them read the wrong shards. */
	for (unsigned j = 0; j < fft8_direct; j++)
		memcpy(par[j], w[ev_kp + j], sz);
	for (unsigned i = nlive; i < chunk; i++)
		memset(w[i], 0, sz);

	/* Every coset past the first needs its own copy of the coefficients, taken
	 * BEFORE the first coset's walk destroys them. Same two-loop shape as
	 * fft16_encode. */
	unsigned done = fft8_direct + want1;
	for (unsigned t = 2; t <= fft8_ncos; t++) {
		unsigned want = (unsigned)m - done;
		if (want > chunk)
			want = chunk;
		for (unsigned j = 0; j < chunk; j++)
			fft8_ct[j] = j < want ? par[done + j] : fft8_ov[j - want];
		if (!fft8_fused_coset(fft8_ct, w, nlive, chunk, t * chunk, sz)) {
			for (unsigned i = 0; i < nlive; i++)
				memcpy(fft8_ct[i], w[i], sz);
			for (unsigned i = nlive; i < chunk; i++)
				memset(fft8_ct[i], 0, sz);
		}
		done += want;
	}
	if (ph) { fft8_ph[2] += now_ms() - tp; tp = now_ms(); }

	/* `trunc` on a FORWARD walk bounds the live OUTPUTS, not the live inputs --
	 * the opposite of what it means on the inverse walk, where entries past it
	 * are known zero. Passing k here (the count of nonzero coefficients) drops
	 * whole blocks of outputs and is silently wrong above the first layer; what
	 * belongs here is how many parity shards this coset is asked for. */
	if (fft8_ncos)
		fft8_run(w, chunk, want1, chunk, sz, 0);
	done = fft8_direct + want1;
	for (unsigned t = 2; t <= fft8_ncos; t++) {
		unsigned want = (unsigned)m - done;
		if (want > chunk)
			want = chunk;
		for (unsigned j = 0; j < chunk; j++)
			fft8_ct[j] = j < want ? par[done + j] : fft8_ov[j - want];
		fft8_run_s(fft8_ct, chunk, want, t * chunk, sz, 0, fft8_cfuse);
		done += want;
	}
	if (ph) { fft8_ph[3] += now_ms() - tp; tp = now_ms(); }
}

/*
 * The skew (twist) table, upstream's `initialize_skew` rewritten in field terms
 * rather than logs. temp[i] starts at beta_{i+1}; step m forms d = e_m*(e_m^1)
 * and maps e_i -> e_i*(e_i^1)/d for every i > m. Upstream stores logs and marks
 * "no multiply" with log == GF_MODULUS; this stores elements and marks it with
 * 0, which is the same predicate since log[0] == GF_MODULUS.
 */
static void fft_skew_init(const uint16_t *b)
{
	fft_skew = calloc(65535, sizeof(uint16_t));
	if (!fft_skew) {
		fprintf(stderr, "skew table allocation failed\n");
		exit(1);
	}
	uint16_t temp[15];
	for (int i = 0; i < 15; i++)
		temp[i] = b[i + 1];
	for (int mm = 0; mm < 15; mm++) {
		unsigned step = 1u << (mm + 1);
		fft_skew[(1u << mm) - 1] = 0;
		for (int i = mm; i < 15; i++) {
			unsigned s = 1u << (i + 1);
			for (unsigned j = (1u << mm) - 1; j < s; j += step)
				fft_skew[j + s] = (uint16_t)(fft_skew[j] ^ temp[i]);
		}
		uint16_t d = g16inv(g16mul(temp[mm], (uint16_t)(temp[mm] ^ 1)));
		for (int i = mm + 1; i < 15; i++)
			temp[i] = g16mul(g16mul(temp[i], (uint16_t)(temp[i] ^ 1)), d);
	}
}

/*
 * c_t, the per-coset scale the transform applies on top of the Cauchy entry.
 *
 * G[j][i] = A_j / ((y_j ^ x_i) * W) with A_j = prod_{l<chunk} (y_j ^ x_l) and
 * W = prod_{l != i} (x_i ^ x_l), which the Cantor normalisation makes
 * independent of i. A_j is constant on a coset, so c_t = A_t / W. Computed
 * here rather than hardcoded, and checked against what the normalisation
 * predicts: c_1 = 1 and c_2 = beta_1.
 */
static void fft_coset_init(int k, int m, const uint16_t *basis)
{
	unsigned chunk = chunk_of(k);
	uint16_t x0 = cantor_span(0, basis), w = 1;
	for (unsigned l = 1; l < chunk; l++)
		w = g16mul(w, (uint16_t)(x0 ^ cantor_span(l, basis)));
	unsigned ncos = ((unsigned)m + chunk - 1) / chunk;
	if (ncos + 1 > sizeof(fft_coset_inv) / sizeof(fft_coset_inv[0])) {
		fprintf(stderr, "too many recovery cosets: %u\n", ncos);
		exit(1);
	}
	for (unsigned t = 1; t <= ncos; t++) {
		uint16_t y = cantor_span(t * chunk, basis), a = 1;
		for (unsigned l = 0; l < chunk; l++)
			a = g16mul(a, (uint16_t)(y ^ cantor_span(l, basis)));
		uint16_t c = g16div(a, w);
		fft_coset_inv[t] = g16inv(c);
		fft_coset[t] = c;
		uint16_t want = t == 1 ? 1 : (t == 2 ? basis[1] : c);
		if (c != want) {
			fprintf(stderr, "coset scale %u is %04x, expected %04x\n",
				t, c, want);
			exit(1);
		}
	}
}

/* ------------------------------------------------------------- the kernel */

/* The four 8x8 GF(2) blocks of "multiply by g" over the tower, in upstream's
 * order: out_lo from in_lo, out_lo from in_hi, out_hi from in_lo, out_hi from
 * in_hi. The 2x2 block is expand16's, so this and the matrix encoder cannot
 * drift apart. */
/*
 * Held as plain u64 and broadcast at the point of use, NOT as four live
 * __m256i. That is a departure from upstream and the reason the three-layer
 * block is worth anything here: eight shards is 16 YMM of data, and seven
 * multipliers materialised as vectors is 28 more, which spills. EVEX lets
 * `vgf2p8affineqb` take a broadcast memory operand, so a multiplier in memory
 * costs no vector register at all and the register file holds only data.
 *
 * Measured: with the multipliers materialised the three-layer form ran 0.55x
 * the two-layer one -- slower, where upstream measures 1.07x faster.
 */
typedef struct { uint64_t a[4]; } fft_lut;

static inline fft_lut fft_lut_of(uint16_t g)
{
	unsigned char g0 = lo8(g), g1 = hi8(g);
	fft_lut l;
	l.a[0] = fft_affine[g0];
	l.a[1] = fft_affine[gmul(BETA, g1)];
	l.a[2] = fft_affine[g1];
	l.a[3] = fft_affine[(unsigned char)(g0 ^ g1)];
	return l;
}

/* A shard, as the transform sees it: its two planes. */
typedef struct { unsigned char *lo, *hi; } fft_sh;
typedef struct { __m256i lo, hi; } fft_reg;

#define FFT_LOAD(s, c, cs) ((fft_reg){ \
	_mm256_loadu_si256((const __m256i *)((s).lo + (c) * (cs))), \
	_mm256_loadu_si256((const __m256i *)((s).hi + (c) * (cs))) })
#define FFT_STORE(s, c, cs, v) do { \
	_mm256_storeu_si256((__m256i *)((s).lo + (c) * (cs)), (v).lo); \
	_mm256_storeu_si256((__m256i *)((s).hi + (c) * (cs)), (v).hi); } while (0)

/* Byte index of element i within a plane pointer, for either layout:
 * cs = 32 gives i, cs = 64 gives (i/32)*64 + i%32. */
#define FFT_EI(i, cs) (((i) / 32) * (cs) + (i) % 32)

__attribute__((target("avx2,gfni")))
static inline fft_reg fft_mul(fft_reg v, const fft_lut *l)
{
	fft_reg r;
	r.lo = _mm256_xor_si256(
		_mm256_gf2p8affine_epi64_epi8(v.lo, _mm256_set1_epi64x((long long)l->a[0]), 0),
		_mm256_gf2p8affine_epi64_epi8(v.hi, _mm256_set1_epi64x((long long)l->a[1]), 0));
	r.hi = _mm256_xor_si256(
		_mm256_gf2p8affine_epi64_epi8(v.lo, _mm256_set1_epi64x((long long)l->a[2]), 0),
		_mm256_gf2p8affine_epi64_epi8(v.hi, _mm256_set1_epi64x((long long)l->a[3]), 0));
	return r;
}

/* `x ^= y * s; y ^= x` -- the fft butterfly, in registers. s == 0 skips the
 * multiply, which is upstream's GF_MODULUS check. */
__attribute__((target("avx2,gfni")))
static inline void fft_b(fft_reg *x, fft_reg *y, const fft_lut *l, int mul)
{
	if (mul) {
		fft_reg p = fft_mul(*y, l);
		x->lo = _mm256_xor_si256(x->lo, p.lo);
		x->hi = _mm256_xor_si256(x->hi, p.hi);
	}
	y->lo = _mm256_xor_si256(y->lo, x->lo);
	y->hi = _mm256_xor_si256(y->hi, x->hi);
}

/* `y ^= x; x ^= y * s` -- the ifft butterfly, in registers. */
__attribute__((target("avx2,gfni")))
static inline void ifft_b(fft_reg *x, fft_reg *y, const fft_lut *l, int mul)
{
	y->lo = _mm256_xor_si256(y->lo, x->lo);
	y->hi = _mm256_xor_si256(y->hi, x->hi);
	if (mul) {
		fft_reg p = fft_mul(*y, l);
		x->lo = _mm256_xor_si256(x->lo, p.lo);
		x->hi = _mm256_xor_si256(x->hi, p.hi);
	}
}

static unsigned long fft_cnt_b1, fft_cnt_b2, fft_cnt_b3;

/* Scalar reference for every layer width, so the kernel has an oracle that does
 * not depend on GFNI and ISAL16_FFT_KERNEL=scalar can check it directly. */
static void fft_b_scalar(fft_sh x, fft_sh y, uint16_t s, size_t h, int inverse)
{
	size_t cs = fft_cstep;
	for (size_t i = 0; i < h; i++) {
		size_t j = FFT_EI(i, cs);
		uint16_t a = pack16(x.lo[j], x.hi[j]), b = pack16(y.lo[j], y.hi[j]);
		if (inverse) {
			b ^= a;
			if (s) a ^= g16mul(b, s);
		} else {
			if (s) a ^= g16mul(b, s);
			b ^= a;
		}
		x.lo[j] = lo8(a); x.hi[j] = hi8(a);
		y.lo[j] = lo8(b); y.hi[j] = hi8(b);
	}
}

/* One layer over a shard pair. */
__attribute__((target("avx2,gfni")))
static void fft_b1(fft_sh x, fft_sh y, uint16_t s, size_t h, int inverse)
{
	fft_cnt_b1++;
	if (!fft_have_gfni || h % 32) {
		fft_b_scalar(x, y, s, h, inverse);
		return;
	}
	fft_lut l = fft_lut_of(s);
	size_t nc = h / 32, cs = fft_cstep;
	for (size_t c = 0; c < nc; c++) {
		fft_reg xv = FFT_LOAD(x, c, cs), yv = FFT_LOAD(y, c, cs);
		if (inverse)
			ifft_b(&xv, &yv, &l, s != 0);
		else
			fft_b(&xv, &yv, &l, s != 0);
		FFT_STORE(x, c, cs, xv);
		FFT_STORE(y, c, cs, yv);
	}
}

/*
 * Three layers of an eight-shard block, one load and one store per chunk --
 * upstream's `fft_three_layers_blocked`.  Like `fft_b2` and unlike `fft_b1`,
 * this has no ragged-tail fallback; see the `sz % 64` guard at the entry point.
 */
/* This, not the instruction set, is
 * where the headroom is: section 4.8 measures the two-layer form at 1.417x on
 * encode and section 4.11 the three-layer at a further 1.070x. It fits only
 * because of GFNI: eight shards is 16 YMM of data, and the multipliers are 4
 * YMM each of affine matrices rather than 8 of nibble tables.
 */
__attribute__((target("avx2,gfni")))
static void fft_b3(fft_sh *sh, uint16_t m4, const uint16_t *m2, const uint16_t *m1,
		   size_t h, int inverse)
{
	fft_cnt_b3++;
	fft_lut l4 = fft_lut_of(m4);
	fft_lut l20 = fft_lut_of(m2[0]), l21 = fft_lut_of(m2[1]);
	fft_lut l10 = fft_lut_of(m1[0]), l11 = fft_lut_of(m1[1]);
	fft_lut l12 = fft_lut_of(m1[2]), l13 = fft_lut_of(m1[3]);
	int c4 = m4 != 0, c20 = m2[0] != 0, c21 = m2[1] != 0;
	int c10 = m1[0] != 0, c11 = m1[1] != 0, c12 = m1[2] != 0, c13 = m1[3] != 0;

	/*
	 * Hand-unrolled into named locals rather than an `x[8]` array, and the
	 * eight bases lifted out of `sh` with the high plane derived as `lo + h`.
	 *
	 * Both are forced by -O2, which is this driver's build and stays that way
	 * so the matrix path it is measured against does not move. At -O2 GCC
	 * leaves an array of eight `fft_reg` on the STACK -- the block's whole
	 * point is holding them in registers -- and reloads the bases every chunk
	 * because a store through `sh[i].lo` might alias `sh` itself. Measured,
	 * the array form ran the three-layer block at 0.55x the two-layer one,
	 * where upstream has it 1.07x faster; at -O3 GCC unrolls and inlines it
	 * and the same source runs 1.79x quicker. `fft_b2` never had either
	 * problem because it takes four shards by value into named variables.
	 *
	 * Deriving hi also halves the live bases: upstream needs eight because its
	 * lo and hi share one 64-byte chunk, while whole planes would need sixteen
	 * against ~14 usable GPRs.
	 */
	unsigned char *p0 = sh[0].lo, *p1 = sh[1].lo, *p2 = sh[2].lo, *p3 = sh[3].lo;
	unsigned char *p4 = sh[4].lo, *p5 = sh[5].lo, *p6 = sh[6].lo, *p7 = sh[7].lo;
	size_t cs = fft_cstep, ho = cs == 64 ? 32 : h;
	for (int i = 0; i < 8; i++)
		if (sh[i].hi != sh[i].lo + ho) { /* what makes deriving hi legal */
			fprintf(stderr, "fft: non-adjacent planes\n");
			exit(1);
		}

	/* The hand-written block, which is this same body with the multipliers
	 * taken from memory by EVEX broadcast instead of held in registers.
	 * ISAL16_FFT_ASM=0 restores the C form, which is the null it is measured
	 * against and which must produce identical bytes. */
	/* The hand-written block hard-codes the PLANE addressing (it takes `h` and
	 * `h/32`), so it is only reachable in that layout. */
	if (fft_use_asm && cs == 32 && h % 32 == 0) {
		unsigned char *const pv[8] = { p0, p1, p2, p3, p4, p5, p6, p7 };
		uint64_t lut[28];
		const uint16_t ord[7] = { m4, m2[0], m2[1], m1[0], m1[1], m1[2], m1[3] };
		for (int i = 0; i < 7; i++) {
			fft_lut l = fft_lut_of(ord[i]);
			for (int j = 0; j < 4; j++)
				lut[i * 4 + j] = l.a[j];
		}
		if (inverse)
			fft16_b3_inv(pv, h, h / 32, lut);
		else
			fft16_b3_fwd(pv, h, h / 32, lut);
		return;
	}

#define LD(q, c) ((fft_reg){ \
	_mm256_loadu_si256((const __m256i *)((q) + (c) * cs)), \
	_mm256_loadu_si256((const __m256i *)((q) + ho + (c) * cs)) })
#define ST(q, c, v) do { \
	_mm256_storeu_si256((__m256i *)((q) + (c) * cs), (v).lo); \
	_mm256_storeu_si256((__m256i *)((q) + ho + (c) * cs), (v).hi); } while (0)

	size_t nc = h / 32;
	for (size_t c = 0; c < nc; c++) {
		fft_reg x0 = LD(p0, c), x1 = LD(p1, c), x2 = LD(p2, c), x3 = LD(p3, c);
		fft_reg x4 = LD(p4, c), x5 = LD(p5, c), x6 = LD(p6, c), x7 = LD(p7, c);
		if (!inverse) {
			fft_b(&x0, &x4, &l4, c4);  fft_b(&x1, &x5, &l4, c4);
			fft_b(&x2, &x6, &l4, c4);  fft_b(&x3, &x7, &l4, c4);
			fft_b(&x0, &x2, &l20, c20); fft_b(&x1, &x3, &l20, c20);
			fft_b(&x4, &x6, &l21, c21); fft_b(&x5, &x7, &l21, c21);
			fft_b(&x0, &x1, &l10, c10); fft_b(&x2, &x3, &l11, c11);
			fft_b(&x4, &x5, &l12, c12); fft_b(&x6, &x7, &l13, c13);
		} else {
			ifft_b(&x0, &x1, &l10, c10); ifft_b(&x2, &x3, &l11, c11);
			ifft_b(&x4, &x5, &l12, c12); ifft_b(&x6, &x7, &l13, c13);
			ifft_b(&x0, &x2, &l20, c20); ifft_b(&x1, &x3, &l20, c20);
			ifft_b(&x4, &x6, &l21, c21); ifft_b(&x5, &x7, &l21, c21);
			ifft_b(&x0, &x4, &l4, c4);  ifft_b(&x1, &x5, &l4, c4);
			ifft_b(&x2, &x6, &l4, c4);  ifft_b(&x3, &x7, &l4, c4);
		}
		ST(p0, c, x0); ST(p1, c, x1); ST(p2, c, x2); ST(p3, c, x3);
		ST(p4, c, x4); ST(p5, c, x5); ST(p6, c, x6); ST(p7, c, x7);
	}
#undef LD
#undef ST
}

/* Two layers of a four-shard block -- upstream's `fft_two_layers_blocked`,
 * which the three-layer walk still needs for its leftover when
 * log2(size) mod 3 == 2.
 *
 * NO RAGGED-TAIL FALLBACK, unlike `fft_b1`: `nc = h / 32` drops the last
 * `h % 32` bytes on the floor. `sz % 64 == 0` is insisted on at the transform's
 * entry point for exactly this reason. */
__attribute__((target("avx2,gfni")))
static void fft_b2(fft_sh s0, fft_sh s1, fft_sh s2, fft_sh s3,
		   uint16_t m01, uint16_t m23, uint16_t m02, size_t h, int inverse)
{
	fft_cnt_b2++;
	fft_lut l01 = fft_lut_of(m01), l23 = fft_lut_of(m23), l02 = fft_lut_of(m02);
	size_t nc = h / 32, cs = fft_cstep;
	for (size_t c = 0; c < nc; c++) {
		fft_reg x0 = FFT_LOAD(s0, c, cs), x1 = FFT_LOAD(s1, c, cs);
		fft_reg x2 = FFT_LOAD(s2, c, cs), x3 = FFT_LOAD(s3, c, cs);
		if (!inverse) {
			fft_b(&x0, &x2, &l02, m02 != 0);
			fft_b(&x1, &x3, &l02, m02 != 0);
			fft_b(&x0, &x1, &l01, m01 != 0);
			fft_b(&x2, &x3, &l23, m23 != 0);
		} else {
			ifft_b(&x0, &x1, &l01, m01 != 0);
			ifft_b(&x2, &x3, &l23, m23 != 0);
			ifft_b(&x0, &x2, &l02, m02 != 0);
			ifft_b(&x1, &x3, &l02, m02 != 0);
		}
		FFT_STORE(s0, c, cs, x0); FFT_STORE(s1, c, cs, x1);
		FFT_STORE(s2, c, cs, x2); FFT_STORE(s3, c, cs, x3);
	}
}

/* ---------------------------------------------------------- the layer walk */

/*
 * `sh` is an array of shard pairs, so a transform's destination need not be
 * contiguous: the last recovery coset points its first `count` slots at the
 * parity pool and the rest at scratch, and no copy-out is needed. That is the
 * one liberty taken over upstream, whose work buffer is one flat allocation.
 */

/* Unblocked, one layer at a time -- upstream's `engine_naive` walk. Reachable
 * with ISAL16_FFT_BLOCK=0, and it is the null the blocking is measured against. */
static void fft_plain(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	for (unsigned dist = size / 2; dist > 0; dist /= 2)
		for (unsigned r = 0; r < trunc; r += dist * 2) {
			uint16_t s = fft_skew[r + dist + skd - 1];
			for (unsigned i = r; i < r + dist; i++)
				fft_b1(sh[i], sh[i + dist], s, h, 0);
		}
}

static void ifft_plain(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	for (unsigned dist = 1; dist < size; dist *= 2)
		for (unsigned r = 0; r < trunc; r += dist * 2) {
			uint16_t s = fft_skew[r + dist + skd - 1];
			for (unsigned i = r; i < r + dist; i++)
				fft_b1(sh[i], sh[i + dist], s, h, 1);
		}
}

/* Two layers at a time -- upstream's `GFNI_BLOCK=1, GFNI_BLOCK3=0`. */
static void fft_two(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	unsigned dist4 = size;
	for (unsigned dist = size >> 2; dist != 0; dist >>= 2) {
		for (unsigned r = 0; r < trunc; r += dist4) {
			unsigned b = r + dist + skd - 1;
			for (unsigned i = r; i < r + dist; i++)
				fft_b2(sh[i], sh[i + dist], sh[i + 2 * dist],
				       sh[i + 3 * dist], fft_skew[b],
				       fft_skew[b + dist * 2], fft_skew[b + dist], h, 0);
		}
		dist4 = dist;
	}
	if (dist4 == 2)
		for (unsigned r = 0; r < trunc; r += 2)
			fft_b1(sh[r], sh[r + 1], fft_skew[r + skd], h, 0);
}

static void ifft_two(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	unsigned dist = 1;
	for (unsigned dist4 = 4; dist4 <= size; dist4 <<= 2) {
		for (unsigned r = 0; r < trunc; r += dist4) {
			unsigned b = r + dist + skd - 1;
			for (unsigned i = r; i < r + dist; i++)
				fft_b2(sh[i], sh[i + dist], sh[i + 2 * dist],
				       sh[i + 3 * dist], fft_skew[b],
				       fft_skew[b + dist * 2], fft_skew[b + dist], h, 1);
		}
		dist = dist4;
	}
	if (dist < size) {
		uint16_t s = fft_skew[dist + skd - 1];
		for (unsigned i = 0; i < dist; i++)
			fft_b1(sh[i], sh[i + dist], s, h, 1);
	}
}

/* Three layers at a time -- upstream's `GFNI_BLOCK3=1`, the shipping path, with
 * its own leftover peeling: `log2(size) mod 3` layers remain and are taken by
 * the two-layer form when that is 2 and by a single layer when it is 1. All
 * three fire on this grid -- chunk is 128, 256 or 512 for f in [86, 256]. */
static void fft_three(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	unsigned dist4 = size;
	for (unsigned d = size >> 3; d != 0; d >>= 3) {
		for (unsigned r = 0; r < trunc; r += d * 8) {
			unsigned b = r + skd - 1;
			uint16_t m4 = fft_skew[b + 4 * d];
			uint16_t m2[2] = { fft_skew[b + 2 * d], fft_skew[b + 6 * d] };
			uint16_t m1[4] = { fft_skew[b + d], fft_skew[b + 3 * d],
					   fft_skew[b + 5 * d], fft_skew[b + 7 * d] };
			for (unsigned i = r; i < r + d; i++) {
				fft_sh blk[8];
				for (int j = 0; j < 8; j++)
					blk[j] = sh[i + (unsigned)j * d];
				fft_b3(blk, m4, m2, m1, h, 0);
			}
		}
		dist4 = d;
	}
	if (dist4 == 4) {
		for (unsigned r = 0; r < trunc; r += 4) {
			unsigned b = r + skd;
			fft_b2(sh[r], sh[r + 1], sh[r + 2], sh[r + 3], fft_skew[b],
			       fft_skew[b + 2], fft_skew[b + 1], h, 0);
		}
	} else if (dist4 == 2) {
		for (unsigned r = 0; r < trunc; r += 2)
			fft_b1(sh[r], sh[r + 1], fft_skew[r + skd], h, 0);
	}
}

static void ifft_three(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h)
{
	unsigned d = 1;
	for (unsigned d8 = 8; d8 <= size; d8 <<= 3) {
		for (unsigned r = 0; r < trunc; r += d8) {
			unsigned b = r + skd - 1;
			uint16_t m4 = fft_skew[b + 4 * d];
			uint16_t m2[2] = { fft_skew[b + 2 * d], fft_skew[b + 6 * d] };
			uint16_t m1[4] = { fft_skew[b + d], fft_skew[b + 3 * d],
					   fft_skew[b + 5 * d], fft_skew[b + 7 * d] };
			for (unsigned i = r; i < r + d; i++) {
				fft_sh blk[8];
				for (int j = 0; j < 8; j++)
					blk[j] = sh[i + (unsigned)j * d];
				fft_b3(blk, m4, m2, m1, h, 1);
			}
		}
		d = d8;
	}
	if (d * 4 <= size) {
		for (unsigned r = 0; r < trunc; r += d * 4) {
			unsigned b = r + d + skd - 1;
			for (unsigned i = r; i < r + d; i++)
				fft_b2(sh[i], sh[i + d], sh[i + 2 * d], sh[i + 3 * d],
				       fft_skew[b], fft_skew[b + d * 2], fft_skew[b + d],
				       h, 1);
		}
		d = size;
	}
	if (d < size) {
		uint16_t s = fft_skew[d + skd - 1];
		for (unsigned i = 0; i < d; i++)
			fft_b1(sh[i], sh[i + d], s, h, 1);
	}
}

static void fft_run(fft_sh *sh, unsigned size, unsigned trunc, unsigned skd, size_t h,
		    int inverse)
{
	if (fft_block && fft_block3)
		inverse ? ifft_three(sh, size, trunc, skd, h)
			: fft_three(sh, size, trunc, skd, h);
	else if (fft_block)
		inverse ? ifft_two(sh, size, trunc, skd, h)
			: fft_two(sh, size, trunc, skd, h);
	else
		inverse ? ifft_plain(sh, size, trunc, skd, h)
			: fft_plain(sh, size, trunc, skd, h);
}

/* ------------------------------------------------- the transform decoder */

/*
 * The additive-FFT decoder, ported from reed-solomon-simd's `LowRateDecoder`.
 *
 * The matrix decoder of section 1.3 solves for the missing originals directly:
 * an O(r^2) closed-form inverse plus an r x k apply, so its cost scales with
 * how much was lost. This one does not look at r at all -- it runs one inverse
 * transform, a formal derivative and one forward transform over a work buffer
 * of next_pow2(chunk + m) shards, so it costs the same whether one shard is
 * missing or a third of them. Which wins is a question about shape, and having
 * both in one codec is the only way to ask it without also changing library,
 * field and node set at the same time.
 *
 * THREE OF THE FOUR PIECES ARE ALREADY HERE. The transforms are `fft_run`,
 * which already takes an arbitrary size, truncation and skew. What is new is
 * the erasure locator -- and most of that is field-independent.
 *
 *   fwht           a Walsh-Hadamard transform over Z/65535. Integer arithmetic,
 *                  no field at all; a straight port.
 *   log_walsh      the FWHT of the field's log table. Field-dependent, and the
 *                  one place the port has to think.
 *   eval_poly      FWHT, pointwise multiply by log_walsh, FWHT back. It
 *                  computes, in the log domain, the product over erased
 *                  positions of (i ^ j) for every i at once -- which works
 *                  because XOR of positions is addition of field elements, so
 *                  the sum of logs is an XOR-convolution.
 *   formal_deriv   XORs between shards. No field dependence.
 *
 * THE ONE ADAPTATION. Upstream converts its log table into Cantor coordinates
 * at start-up, so `log[i]` is the log of the element whose Cantor coordinates
 * are `i`, and the position-indexed transform above is then correct. This
 * driver keeps its log table in the tower representation, so the position-
 * indexed table is built here: `plog[i] = g16_log[beta(i)]`. Since beta is
 * GF(2)-linear, beta(i) ^ beta(j) = beta(i ^ j), which is exactly the property
 * the convolution needs.
 */

static void xor_into(unsigned char *dst, const unsigned char *a, size_t n);

static uint16_t *dec_log_walsh;		/* 65536 entries, the FWHT of plog */
static uint16_t *dec_erasures;		/* 65536, the locator, rebuilt per decode */
static fft_sh *dec_wsh;			/* work-buffer shard array */
static unsigned dec_work_count, dec_recovery_end;

static inline uint16_t add_mod16(uint16_t x, uint16_t y)
{
	uint32_t s = (uint32_t)x + (uint32_t)y;
	return (uint16_t)(s + (s >> 16));
}

static inline uint16_t sub_mod16(uint16_t x, uint16_t y)
{
	uint32_t d = (uint32_t)x - (uint32_t)y;
	return (uint16_t)(d + (d >> 16));
}

/* Decimation-in-time Walsh-Hadamard over Z/65535, four points at a time.
 * `trunc` is the count of possibly-non-zero entries at the front.
 *
 * The four points of a group are addressed through four `restrict` pointers
 * rather than as `d[o]`, `d[o + dist]`, ... , and the induction variables are
 * `size_t` rather than `unsigned`. Both are needed and neither changes what is
 * computed. With 32-bit indices GCC cannot prove the four index expressions are
 * affine and monotone once they are zero-extended to 64 bits, so it models the
 * accesses as gather/scatter and gives up:
 *
 *   rs_point.c:1664: missed: possible alias involving gather/scatter
 *
 * while LLVM vectorises the identical loop in `reed-solomon-simd`'s
 * `engine/fwht.rs` -- 512-bit `vpmovzxwd` / `vpaddd` / `vpsrld` / `vpmovdw`,
 * which is `add_mod16` and `sub_mod16` widened. That one codegen difference,
 * not the algorithm, was the whole of the locator gap: the full 65536-point
 * transform ran 0.32 ms here against about 0.12 ms there, and the decode's
 * locator phase 0.39 ms against 0.17 ms, at f = 1023 / 1 MiB.
 *
 * The `restrict` is true rather than convenient: within one `r` block the four
 * ranges [r, r+dist), [r+dist, r+2dist), [r+2dist, r+3dist), [r+3dist, r+4dist)
 * are disjoint by construction. GCC still versions the loop with a runtime
 * alias check, so the claim is also enforced at run time.
 *
 * Measured at f = 1023 / 1 MiB, -O3: fwht(65536) 0.323 -> 0.182 ms,
 * fwht(3070) 0.060 -> 0.016, locator 0.389 -> 0.227, whole transform decode
 * 1.72 -> 1.55 ms.
 */
/* One 4-point butterfly group, scalar. The oracle for the vector form, and the
 * path taken for dist < 16 where there are not enough elements to fill a
 * register. */
static void fwht_group(uint16_t *d, size_t r, size_t dist)
{
	uint16_t *restrict p0 = d + r;
	uint16_t *restrict p1 = d + r + dist;
	uint16_t *restrict p2 = d + r + dist * 2;
	uint16_t *restrict p3 = d + r + dist * 3;
	for (size_t o = 0; o < dist; o++) {
		uint16_t s0 = add_mod16(p0[o], p1[o]);
		uint16_t f0 = sub_mod16(p0[o], p1[o]);
		uint16_t s1 = add_mod16(p2[o], p3[o]);
		uint16_t f1 = sub_mod16(p2[o], p3[o]);
		p0[o] = add_mod16(s0, s1);
		p1[o] = add_mod16(f0, f1);
		p2[o] = sub_mod16(s0, s1);
		p3[o] = sub_mod16(f0, f1);
	}
}

/*
 * Z/65535 add and subtract on sixteen 16-bit lanes.
 *
 * These are one's-complement (end-around carry) operations: `add_mod16` is
 * `t = x + y` with the carry folded back in, and the carry is exactly `t < x`
 * -- strictly, which is why `y == 0` correctly produces none. `subs_epu16`
 * gives that comparison without an unsigned 16-bit compare instruction:
 * `max(x - t, 0)` is non-zero precisely when `t < x`, and `min(., 1)` turns it
 * into the 0/1 the fold needs. Four instructions per operation, sixteen lanes
 * at a time.
 *
 * WHY THIS IS WRITTEN OUT. Section 2 found GCC declining to vectorise the
 * scalar form at all -- "possible alias involving gather/scatter" -- which cost
 * 2.5x on a phase that is ~18% of a 1 MiB decode, and it went unnoticed for
 * eight revisions because nothing in the source said "this must be vector".
 * Restructuring the C fixed it, but left the property being relied on
 * (GCC proving four `restrict` pointers affine) unstated and unenforced.
 * Intrinsics pin the instruction SELECTION, which is the thing that failed;
 * scheduling stays with the compiler, which section E measures as the half
 * that does not matter here. GCC's own vectorisation of the scalar form
 * widens to 32-bit lanes (`vpmovzxwd`/`vpaddd`/`vpsrld`/`vpmovdw`), so it
 * carries eight elements per register where this carries sixteen.
 */
__attribute__((target("avx2")))
static inline __m256i fwht_add(__m256i x, __m256i y, __m256i one)
{
	__m256i t = _mm256_add_epi16(x, y);
	__m256i c = _mm256_min_epu16(_mm256_subs_epu16(x, t), one);
	return _mm256_add_epi16(t, c);
}

__attribute__((target("avx2")))
static inline __m256i fwht_sub(__m256i x, __m256i y, __m256i one)
{
	__m256i t = _mm256_sub_epi16(x, y);
	__m256i b = _mm256_min_epu16(_mm256_subs_epu16(y, x), one);
	return _mm256_sub_epi16(t, b);
}

/* The same group, sixteen elements at a time. Requires dist % 16 == 0, so it
 * is taken for dist >= 16 -- six of the eight passes over the field. */
__attribute__((target("avx2")))
static void fwht_group_avx2(uint16_t *d, size_t r, size_t dist)
{
	const __m256i one = _mm256_set1_epi16(1);
	uint16_t *p0 = d + r, *p1 = p0 + dist, *p2 = p1 + dist, *p3 = p2 + dist;
	for (size_t o = 0; o < dist; o += 16) {
		__m256i a0 = _mm256_loadu_si256((const __m256i *)(p0 + o));
		__m256i a1 = _mm256_loadu_si256((const __m256i *)(p1 + o));
		__m256i a2 = _mm256_loadu_si256((const __m256i *)(p2 + o));
		__m256i a3 = _mm256_loadu_si256((const __m256i *)(p3 + o));
		__m256i s0 = fwht_add(a0, a1, one), f0 = fwht_sub(a0, a1, one);
		__m256i s1 = fwht_add(a2, a3, one), f1 = fwht_sub(a2, a3, one);
		_mm256_storeu_si256((__m256i *)(p0 + o), fwht_add(s0, s1, one));
		_mm256_storeu_si256((__m256i *)(p1 + o), fwht_add(f0, f1, one));
		_mm256_storeu_si256((__m256i *)(p2 + o), fwht_sub(s0, s1, one));
		_mm256_storeu_si256((__m256i *)(p3 + o), fwht_sub(f0, f1, one));
	}
}

/* ISAL16_FWHT=scalar restores the C form, which is the null this is measured
 * against and which must produce identical bytes. */
static int fwht_vec = -1;

static void fwht(uint16_t *d, unsigned trunc)
{
	if (fwht_vec < 0) {
		const char *v = getenv("ISAL16_FWHT");
		fwht_vec = __builtin_cpu_supports("avx2")
			   && !(v && !strcmp(v, "scalar"));
	}
	size_t dist = 1, dist4 = 4;
	while (dist4 <= 65536u) {
		for (size_t r = 0; r < trunc; r += dist4) {
			if (fwht_vec && dist >= 16)
				fwht_group_avx2(d, r, dist);
			else
				fwht_group(d, r, dist);
		}
		dist = dist4;
		if (dist4 > 65536u / 4)
			break;
		dist4 <<= 2;
	}
}

/* log(prod over erased j of (i ^ j)) for every position i, in the log domain. */
static void eval_poly(uint16_t *er, unsigned trunc)
{
	fwht(er, trunc);
	for (unsigned i = 0; i < 65536u; i++) {
		uint32_t p = (uint32_t)er[i] * (uint32_t)dec_log_walsh[i];
		er[i] = add_mod16((uint16_t)p, (uint16_t)(p >> 16));
	}
	fwht(er, 65536u);
}

/*
 * Section 5.9's truncation, ported. The decoder's erasure vector is ones from
 * `recovery_end` to the end of the field, so the first transform is not
 * truncatable as written -- its input is non-zero all the way out. But
 * `eval_poly` is linear over Z/65535, so it splits: the head is the erasure
 * indicator, zero past `recovery_end` and therefore truncatable, and the tail
 * is the all-ones vector, which depends only on `recovery_end` and so is
 * computed once here rather than per decode.
 */
static uint16_t *dec_tail;		/* eval_poly of the all-ones tail */

static void eval_poly_low(uint16_t *er, unsigned recovery_end)
{
	eval_poly(er, recovery_end);
	for (unsigned i = 0; i < 65536u; i++)
		er[i] = add_mod16(er[i], dec_tail[i]);
}

/* The explicit AVX2 XOR of section 5.12, which the formal derivative lives on:
 * it performs about n*log2(n)/2 whole-shard XORs, 5120 of them at
 * work_count = 1024. Left to the compiler this was a 64-bit loop. */
__attribute__((target("avx2")))
static void xor_simd(unsigned char *d, const unsigned char *a, size_t n)
{
	size_t i = 0;
	for (; i + 128 <= n; i += 128)
		for (int q = 0; q < 4; q++) {
			__m256i x = _mm256_loadu_si256((const __m256i *)(d + i + q * 32));
			__m256i y = _mm256_loadu_si256((const __m256i *)(a + i + q * 32));
			_mm256_storeu_si256((__m256i *)(d + i + q * 32),
					    _mm256_xor_si256(x, y));
		}
	for (; i + 32 <= n; i += 32) {
		__m256i x = _mm256_loadu_si256((const __m256i *)(d + i));
		__m256i y = _mm256_loadu_si256((const __m256i *)(a + i));
		_mm256_storeu_si256((__m256i *)(d + i), _mm256_xor_si256(x, y));
	}
	for (; i < n; i++)
		d[i] ^= a[i];
}

/* shard[i - w] ^= shard[i], for w the low bit of i. Pure XOR, no field. */
static void formal_derivative(fft_sh *sh, unsigned n, size_t sz)
{
	for (unsigned i = 1; i < n; i++) {
		unsigned w = 1u << __builtin_ctz(i);
		for (unsigned j = 0; j < w; j++)
			xor_simd(sh[i - w + j].lo, sh[i + j].lo, sz);
	}
}

/* x *= c, in place, over one shard's two planes. */
__attribute__((target("avx2,gfni")))
static void fft_mul_inplace(fft_sh x, uint16_t c, size_t h)
{
	if (c == 1)
		return;
	size_t cs = fft_cstep;
	if (!fft_have_gfni || h % 32) {
		for (size_t i = 0; i < h; i++) {
			size_t j = FFT_EI(i, cs);
			uint16_t v = g16mul(pack16(x.lo[j], x.hi[j]), c);
			x.lo[j] = lo8(v);
			x.hi[j] = hi8(v);
		}
		return;
	}
	fft_lut l = fft_lut_of(c);
	for (size_t ch = 0; ch < h / 32; ch++) {
		fft_reg v = FFT_LOAD(x, ch, cs);
		FFT_STORE(x, ch, cs, fft_mul(v, &l));
	}
}

/*
 * PLANE <-> INTER, on the way into and out of the decode work buffer.
 *
 * The harness's shard pool is PLANE and stays PLANE -- it is what the GF(2^8)
 * kernels and the matrix decoder read. So the interleaved decoder converts at
 * its own boundary, which costs nothing extra in traffic: `mul_in` already
 * copies every byte of every present shard into the work buffer, and the
 * reveal already copies every byte of every erased one back out. Only the
 * addressing inside those two copies changes. What is NOT fused in is the
 * multiply -- it stays a separate pass exactly as in the PLANE path, so that
 * this remains one variable and not two.
 */
__attribute__((target("avx2")))
static void plane_to_inter(unsigned char *d, const unsigned char *s, size_t sz)
{
	size_t h = sz / 2, nc = h / 32;
	for (size_t c = 0; c < nc; c++) {
		__m256i lo = _mm256_loadu_si256((const __m256i *)(s + c * 32));
		__m256i hi = _mm256_loadu_si256((const __m256i *)(s + h + c * 32));
		_mm256_storeu_si256((__m256i *)(d + c * 64), lo);
		_mm256_storeu_si256((__m256i *)(d + c * 64 + 32), hi);
	}
}

__attribute__((target("avx2")))
static void inter_to_plane(unsigned char *d, const unsigned char *s, size_t sz)
{
	size_t h = sz / 2, nc = h / 32;
	for (size_t c = 0; c < nc; c++) {
		__m256i lo = _mm256_loadu_si256((const __m256i *)(s + c * 64));
		__m256i hi = _mm256_loadu_si256((const __m256i *)(s + c * 64 + 32));
		_mm256_storeu_si256((__m256i *)(d + c * 32), lo);
		_mm256_storeu_si256((__m256i *)(d + h + c * 32), hi);
	}
}

static size_t fft16_decode_scratch(int k, int m, size_t stride)
{
	unsigned chunk = chunk_of(k), wc = 1;
	while (wc < chunk + (unsigned)m)
		wc <<= 1;
	return (size_t)wc * stride;
}

static void fft16_decode_init(int k, int m, const uint16_t *basis)
{
	unsigned chunk = chunk_of(k);
	const char *lv = getenv("ISAL16_DEC_LAYOUT");
	/* An interleaved pool forces an interleaved work buffer -- converting it
	 * back to planes to transform would be the cost without the benefit -- and
	 * then the ingest and reveal are flat copies. */
	/* DEFAULT `inter` since 2026-08-26: decode-only, changes no parity byte,
	 * worth 1.05x-1.15x on transform decode and it never loses. `plane` is the
	 * reachable null and is what the published figures through rev 21 used. */
	fft_dec_inter = fft_pool_inter || !(lv && !strcmp(lv, "plane"));
	dec_recovery_end = chunk + (unsigned)m;
	dec_work_count = 1;
	while (dec_work_count < dec_recovery_end)
		dec_work_count <<= 1;

	/* plog[i] = log(beta(i)) -- the log table indexed by POSITION, which is
	 * what makes the position-indexed convolution of eval_poly correct. */
	dec_log_walsh = malloc(65536u * sizeof(uint16_t));
	dec_erasures = malloc(65536u * sizeof(uint16_t));
	dec_wsh = malloc((size_t)dec_work_count * sizeof(fft_sh));
	if (!dec_log_walsh || !dec_erasures || !dec_wsh) {
		fprintf(stderr, "fft decode table allocation failed\n");
		exit(1);
	}
	for (unsigned i = 0; i < 65536u; i++)
		dec_log_walsh[i] = g16_log[cantor_span(i, basis)];
	dec_log_walsh[0] = 0;
	fwht(dec_log_walsh, 65536u);

	dec_tail = malloc(65536u * sizeof(uint16_t));
	if (!dec_tail) {
		fprintf(stderr, "fft decode tail allocation failed\n");
		exit(1);
	}
	memset(dec_tail, 0, 65536u * sizeof(uint16_t));
	for (unsigned i = dec_recovery_end; i < 65536u; i++)
		dec_tail[i] = 1;
	eval_poly(dec_tail, 65536u);
}

/*
 * `shard[i]` for i in [0,t) with `present[i]`; missing originals are filled in.
 * The work buffer holds the whole [0, work_count) transform domain: originals
 * at their own indices, zeros through the chunk padding, recovery shards at
 * chunk + j, zeros to the end.
 */
static void fft16_decode(int k, int m, int t, size_t sz, size_t stride,
			 unsigned char **shard, const char *present,
			 unsigned char *scratch)
{
	(void)m; (void)t;
	size_t h = sz / 2;
	unsigned chunk = chunk_of(k);

	/* PLANE: hi is half a shard away. INTER: hi is the second half of the
	 * first 64-byte chunk, and the chunk stride below carries the rest. */
	fft_cstep = fft_dec_inter ? 64 : 32;
	for (unsigned i = 0; i < dec_work_count; i++) {
		dec_wsh[i].lo = scratch + (size_t)i * stride;
		dec_wsh[i].hi = dec_wsh[i].lo + (fft_dec_inter ? 32 : h);
	}

	/* the erasure indicator, over positions */
	double _t0 = now_ms();
	memset(dec_erasures, 0, dec_recovery_end * sizeof(uint16_t));
	for (int i = 0; i < k; i++)
		if (!present[i])
			dec_erasures[i] = 1;
	for (unsigned i = chunk; i < dec_recovery_end; i++)
		if (!present[(int)(i - chunk) + k])
			dec_erasures[i] = 1;
	memset(dec_erasures + dec_recovery_end, 0,
	       (65536u - dec_recovery_end) * sizeof(uint16_t));
	eval_poly_low(dec_erasures, dec_recovery_end);

	double _t1 = now_ms();
	/* present shards scaled by their locator value, absent ones zeroed */
	for (int i = 0; i < k; i++) {
		if (present[i]) {
			if (fft_dec_inter && !fft_pool_inter)
				plane_to_inter(dec_wsh[i].lo, shard[i], sz);
			else
				memcpy(dec_wsh[i].lo, shard[i], sz);
			fft_mul_inplace(dec_wsh[i], g16_exp[dec_erasures[i]], h);
		} else {
			memset(dec_wsh[i].lo, 0, sz);
		}
	}
	for (unsigned i = (unsigned)k; i < chunk; i++)
		memset(dec_wsh[i].lo, 0, sz);
	/*
	 * The recovery shards carry c_t^-1, because the encoder divides it out so
	 * that what the MATRIX decoder sees is a pure Cauchy matrix (section 2.5).
	 * The transform decoder wants the raw transform output, so c_t goes back
	 * on here -- folded into the same multiply as the locator value, so it
	 * costs nothing. Getting this wrong decodes correctly whenever the erasure
	 * pattern happens to miss the second coset, which is why it needs saying
	 * rather than testing at one shape.
	 */
	for (unsigned i = chunk; i < dec_recovery_end; i++) {
		int src = (int)(i - chunk) + k;
		if (present[src]) {
			if (fft_dec_inter && !fft_pool_inter)
				plane_to_inter(dec_wsh[i].lo, shard[src], sz);
			else
				memcpy(dec_wsh[i].lo, shard[src], sz);
			fft_mul_inplace(dec_wsh[i],
				g16mul(fft_coset[i / chunk], g16_exp[dec_erasures[i]]), h);
		} else {
			memset(dec_wsh[i].lo, 0, sz);
		}
	}
	for (unsigned i = dec_recovery_end; i < dec_work_count; i++)
		memset(dec_wsh[i].lo, 0, sz);

	/* A non-destructive read of the whole work buffer before the inverse
	 * transform. If the transform then costs what the forward one does, the
	 * asymmetry was first-touch on the buffer's first full traversal rather
	 * than anything about the layer walk. */
	double _w0 = now_ms(), _w1 = _w0;
	if (getenv("ISAL16_DEC_PHASES")) {
		unsigned long acc = 0;
		for (unsigned q = 0; q < dec_work_count; q++)
			for (size_t byt = 0; byt < sz; byt += 64)
				acc += dec_wsh[q].lo[byt];
		__asm__ volatile("" :: "r"(acc));
		_w1 = now_ms();
	}
	fft_cnt_b1 = fft_cnt_b2 = fft_cnt_b3 = 0;
	double _p1 = now_ms();
	fft_run(dec_wsh, dec_work_count, dec_recovery_end, 0, h, 1);
	double _p1b = now_ms();
	unsigned long ib1 = fft_cnt_b1, ib2 = fft_cnt_b2, ib3 = fft_cnt_b3;
	double _p2 = now_ms();
	formal_derivative(dec_wsh, dec_work_count, sz);
	double _p3 = now_ms();
	fft_cnt_b1 = fft_cnt_b2 = fft_cnt_b3 = 0;
	fft_run(dec_wsh, dec_work_count, dec_recovery_end, 0, h, 0);
	double _p4 = now_ms();
	unsigned long fb1 = fft_cnt_b1, fb2 = fft_cnt_b2, fb3 = fft_cnt_b3;
	if (getenv("ISAL16_DEC_PHASES"))
		fprintf(stderr,
			"locator=%.3f mul_in=%.3f warm=%.3f ifft=%.3f deriv=%.3f "
			"fft=%.3f | ifft b1=%lu b2=%lu  fft b1=%lu b2=%lu | "
			"work=%u shard=%zu\n",
			_t1 - _t0, _w0 - _t1, _w1 - _w0, _p1b - _p1,
			_p3 - _p2, _p4 - _p3, ib1, ib2, fb1, fb2,
			dec_work_count, sz);

	/* the erased originals, revealed by the reciprocal locator value */
	for (int i = 0; i < k; i++)
		if (!present[i]) {
			fft_mul_inplace(dec_wsh[i], g16_exp[65535u - dec_erasures[i]], h);
			if (fft_dec_inter && !fft_pool_inter)
				inter_to_plane(shard[i], dec_wsh[i].lo, sz);
			else
				memcpy(shard[i], dec_wsh[i].lo, sz);
		}
}

/* --------------------------------------------------------- the encoder */

static fft_sh *fft_wsh, *fft_dsh;	/* shard-pointer arrays, chunk entries each */
static unsigned fft_chunk, fft_ncos, fft_tail_shards;

/*
 * The last recovery coset, by matrix instead of by transform.
 *
 * A coset costs a whole chunk however few of its outputs are live: the copy in
 * is `chunk` shards and the pruned transform still touches all of them on its
 * first layer. When `m mod chunk` is small that is a very bad trade -- at
 * f = 129, chunk = 256 and m = 258, so 256 shards move to produce TWO, and the
 * 254-shard dead tail is 8.2 MB that evicts the log tables and the pool the
 * following decode reads. It showed up as a decode null of 1.087-1.129 on a
 * decode whose input is byte-identical either way.
 *
 * Those few rows are far cheaper by matrix -- 2 x k = 260 multiply-accumulates
 * against a 256-shard transform -- and the matrix is already here and already
 * produces exactly those bytes, since it is the same code. Taking that branch
 * also drops the dead tail to nothing, so the scratch buffer disappears.
 *
 * ISAL16_FFT_TAIL=<n>: use the matrix when the last coset's live count is <= n.
 * 0 disables it, which is the null.
 */
static unsigned fft_tail_rows;		/* live outputs of the last coset, 0 = transform it */
static unsigned char *fft_tail_tab;	/* ISA-L tables for exactly those rows */
static unsigned char **fft_tail_out;	/* 2 * fft_tail_rows parity planes */

/* `dst = src * c` over whole shards. c == 1 is the common case (the first
 * recovery coset) and is a straight copy. */
__attribute__((target("avx2,gfni")))
static void fft_mulcopy(fft_sh d, fft_sh s, uint16_t c, size_t sz, size_t h)
{
	if (c == 1) {
		memcpy(d.lo, s.lo, sz);
		return;
	}
	size_t cs = fft_cstep;
	if (!fft_have_gfni || h % 32) {
		for (size_t i = 0; i < h; i++) {
			size_t j = FFT_EI(i, cs);
			uint16_t v = g16mul(pack16(s.lo[j], s.hi[j]), c);
			d.lo[j] = lo8(v);
			d.hi[j] = hi8(v);
		}
		return;
	}
	fft_lut l = fft_lut_of(c);
	for (size_t ch = 0; ch < h / 32; ch++) {
		fft_reg v = FFT_LOAD(s, ch, cs);
		FFT_STORE(d, ch, cs, fft_mul(v, &l));
	}
}

/*
 * Scratch is only ever the DEAD TAIL of the last recovery coset.
 *
 * The transform needs a whole chunk of slots but the last coset's live output
 * is `m mod chunk` of them, so `chunk - that` slots have nowhere real to go.
 * Everything else -- the inverse transform's result and every full coset --
 * lands directly in the parity pool, which has m >= chunk slots at every shape
 * here (m = 2f and chunk = next_pow2(f+1)).
 *
 * Upstream instead rounds a separate work buffer up to a whole multiple of the
 * chunk: 512 shards at f = 255 where this needs 2. That is not just memory --
 * the buffer is streamed, and at 4 MiB it evicted enough of the log tables and
 * the shard pool to slow the FOLLOWING decode by 1.054x-1.129x, on a decode
 * that reads byte-identical input either way. Sizing it down took that null to
 * within 1.01x. The lever is what the encoder leaves behind, not what it costs.
 */
static size_t fft16_scratch_bytes(int k, int m, size_t stride)
{
	unsigned chunk = chunk_of(k);
	unsigned ncos = ((unsigned)m + chunk - 1) / chunk;
	unsigned last = (unsigned)m - (ncos - 1) * chunk;
	/* With the last coset handed to the matrix, every transformed coset is
	 * whole and there is no dead tail at all. */
	if (fft_tail_rows) {
		/* Except under the interleaved pool, where the tail's ISA-L call
		 * cannot read the source: it needs a plane-form copy of the k
		 * originals, and a place to put its own plane-form output before
		 * that is permuted into the parity slots. Sized here so it reuses
		 * the per-call slot this function already owns rather than opening
		 * a second allocation inside the encode timer. It is SMALLER than
		 * the dead tail the tail-off configuration allocates at the same
		 * shape -- 132 shards against 254 at f = 129. */
		if (fft_pool_inter)
			return (size_t)((unsigned)k + fft_tail_rows) * stride;
		return 0;
	}
	return (size_t)(chunk - last) * stride;
}

/* The shard array for recovery coset `t`: live outputs into the parity pool,
 * the dead tail into scratch. Only the last coset has a tail. */
static unsigned fft_coset_shards(fft_sh *out, unsigned t, int m, size_t sz,
				 size_t stride, unsigned char **par,
				 unsigned char *scratch)
{
	unsigned chunk = fft_chunk, base = (t - 1) * chunk;
	unsigned left = (unsigned)m - base;
	unsigned count = left < chunk ? left : chunk;
	for (unsigned j = 0; j < chunk; j++) {
		unsigned char *p = j < count ? par[base + j]
					     : scratch + (size_t)(j - count) * stride;
		out[j].lo = p;
		out[j].hi = p + (fft_pool_inter ? 32 : sz / 2);
	}
	return count;
}

/*
 * Upstream's `LowRateEncoder::encode`: zero-pad the originals to the chunk, one
 * inverse transform over it, then one forward transform per recovery coset with
 * `skew_delta = t * chunk`.
 *
 * Two departures. The inverse transform runs directly in the first coset's
 * parity slots, so there is no work buffer to allocate, stream or evict with --
 * see `fft16_scratch_bytes`. And the copy into each later coset carries the
 * c_t^-1 scale, so what leaves here is the pure Cauchy code the decode plan
 * expects; the transform is linear, so scaling its input scales its output, and
 * the copy had to happen anyway. Every later coset must be copied out BEFORE
 * the first coset's forward transform, which destroys the inverse result.
 */
static void fft16_encode(int k, int m, size_t sz, size_t stride,
			 unsigned char **data, unsigned char **par,
			 unsigned char *scratch, unsigned char **enc_in)
{
	size_t h = sz / 2;
	unsigned chunk = fft_chunk;
	unsigned ncos_fft = fft_tail_rows ? fft_ncos - 1 : fft_ncos;
	/* The pool's layout, which is the encoder's output format. Set explicitly
	 * because the decoder shares these kernels and leaves `fft_cstep` at
	 * whatever it last used. */
	fft_cstep = fft_pool_inter ? 64 : 32;
	double _estart = now_ms();
	unsigned count1 = fft_coset_shards(fft_wsh, 1, m, sz, stride, par, scratch);

	for (int i = 0; i < k; i++)
		memcpy(fft_wsh[i].lo, data[i], sz);
	/*
	 * THE TAIL'S SOURCE, UNDER THE INTERLEAVED POOL.
	 *
	 * The matrix tail reads the k ORIGINALS through ISA-L, which takes a
	 * contiguous byte vector and has no stride parameter -- the same wall the
	 * matrix decoder hits. So the originals are de-interleaved once into the
	 * scratch this call already owns (`fft16_scratch_bytes` sizes it; there is
	 * no dead tail to hold when the tail is live) and the tail is handed those
	 * pointers instead of the caller's `enc_in`.
	 *
	 * In this loop and not a later one because the loop above has already read
	 * every `data[i]`; a separate pass would read them twice. Not hand-fused
	 * into a single load with two stores -- that is a further step and it
	 * should not be taken before a measurement asks for it.
	 *
	 * Inside the timer: it is work the interleaved representation requires of
	 * this encoder.
	 *
	 * MARKER, NOT A TODO -- UNMEASURED AT k = m = 32, AND RETIRED THAT WAY.
	 *
	 * This fusion was verified four ways and measured across the grid, which is
	 * n = 3f+1, i.e. m = 2k-2. It has never been measured at k = m = 32. That
	 * shape is Firedancer's native one, reachable only through explicit --k/--m
	 * (fd_shape_probe.sh), and the 28 August re-measurement did not go there.
	 * Nothing is suspected wrong; it is unvisited, and only as a PERFORMANCE
	 * question -- correctness at every shape is what the four verifications in
	 * the report's 13.3 cover.
	 *
	 * AND THE PAPER DOES QUOTE k = m = 32, so do not dismiss it as off-grid
	 * without reading the next sentence. The published claim there is RS--8
	 * against firedancer's reedsol (encoder 1.25x-1.40x faster than RS--8).
	 * THIS FUSION CANNOT REACH THAT FIGURE: it is RS--16, the fd-native leg
	 * carries only fd_reedsol_ms and rs8_ms with no RS--16 column at all, and
	 * fd_shape_probe.sh runs --field 8 only. GF(2^16)-only by construction --
	 * there is no ISAL8_FFT_TAIL. Wrong field, wrong label, wrong code path.
	 *
	 * The rule that came out of checking it: "off-grid" describes the SHAPE,
	 * not the exposure. A shape being off the measurement grid says nothing
	 * about whether the paper quotes it, and this one does.
	 *
	 * IF YOU DO MEASURE IT: no code change is needed. ISAL16_FFT_TAIL=00 turns
	 * the tail off, so it is two legs at --k 32 --m 32 with the tail on and
	 * off, plus the random-vs-random null beside them -- see
	 * PERF-NOTES-RQ-ARRIVAL-SENSITIVITY.md for why the null is not optional.
	 */
	if (fft_pool_inter && fft_tail_rows)
		for (int i = 0; i < k; i++) {
			unsigned char *p = scratch + (size_t)i * stride;
			inter_to_plane(p, data[i], sz);
			fft_tail_in[2 * i] = p;
			fft_tail_in[2 * i + 1] = p + h;
		}
	for (unsigned i = (unsigned)k; i < chunk; i++)
		memset(fft_wsh[i].lo, 0, sz);

	double _e0 = now_ms();
	fft_cnt_b1 = fft_cnt_b2 = fft_cnt_b3 = 0;
	fft_run(fft_wsh, chunk, (unsigned)k, 0, h, 1);
	double _e1 = now_ms();
	unsigned long _ib2 = fft_cnt_b2;
	fft_cnt_b1 = fft_cnt_b2 = fft_cnt_b3 = 0;

	/* ncos_fft, not fft_ncos: a coset the matrix owns must not be copied into,
	 * because with the tail handed to the matrix there is no scratch left for
	 * its dead slots. Getting this wrong wrote past a zero-length buffer and
	 * the parity oracle caught it. */
	for (unsigned t = 2; t <= ncos_fft; t++) {
		fft_coset_shards(fft_dsh, t, m, sz, stride, par, scratch);
		for (unsigned j = 0; j < chunk; j++)
			fft_mulcopy(fft_dsh[j], fft_wsh[j], fft_coset_inv[t], sz, h);
	}
	double _e2 = now_ms();
	fft_run(fft_wsh, chunk, count1, chunk, h, 0);
	for (unsigned t = 2; t <= ncos_fft; t++) {
		unsigned c = fft_coset_shards(fft_dsh, t, m, sz, stride, par, scratch);
		fft_run(fft_dsh, chunk, c, t * chunk, h, 0);
	}
	if (getenv("ISAL16_ENC_PHASES"))
		fprintf(stderr, "enc copy_in=%.3f ifft=%.3f coset_copy=%.3f fft=%.3f | "
			"ifft b2=%lu fft b2=%lu | chunk=%u ncos=%u shard=%zu\n",
			_e0 - _estart, _e1 - _e0, _e2 - _e1, now_ms() - _e2,
			_ib2, fft_cnt_b2, chunk, fft_ncos, sz);

	/* The last coset by matrix, over the same 2k source planes the matrix
	 * encoder uses. Reads the ORIGINAL data shards, not the transform's
	 * output, so it is independent of everything above. */
	if (fft_tail_rows) {
		unsigned base = (fft_ncos - 1) * chunk;
		/* Under the interleaved pool ISA-L writes plane form, so it writes
		 * into scratch and the result is permuted into the parity slots
		 * below -- `fft_tail_rows` shards, 12 at the very most, against the
		 * whole coset this path exists to avoid transforming. */
		for (unsigned j = 0; j < fft_tail_rows; j++) {
			unsigned char *o = fft_pool_inter
				? scratch + (size_t)((unsigned)k + j) * stride
				: par[base + j];
			fft_tail_out[2 * j] = o;
			fft_tail_out[2 * j + 1] = o + h;
		}
		ec_encode_data((int)h, 2 * k, (int)(2 * fft_tail_rows), fft_tail_tab,
			       fft_pool_inter ? fft_tail_in : enc_in, fft_tail_out);
		if (fft_pool_inter)
			for (unsigned j = 0; j < fft_tail_rows; j++)
				plane_to_inter(par[base + j],
					       scratch + (size_t)((unsigned)k + j) * stride,
					       sz);
	}
}

static void fft16_init(int k, int m, const uint16_t *basis,
		       const unsigned char *gen8, size_t tab_entry)
{
	const char *kv = getenv("ISAL16_FFT_KERNEL");
	fft_have_gfni = cpu_has_gfni() && !(kv && !strcmp(kv, "scalar"));
	fft_block = !(getenv("ISAL16_FFT_BLOCK") &&
		      !strcmp(getenv("ISAL16_FFT_BLOCK"), "0"));
	/*
	 * DEFAULT OFF, which diverges from upstream, for a measured reason.
	 *
	 * Upstream ships three-layer blocking (GFNI_BLOCK3=1) and measures it
	 * 1.07x faster than two-layer. Here it is 0.92x-0.98x -- SLOWER -- and the
	 * cause is the shard layout, not the block. A three-layer block holds
	 * eight shards; upstream's lo and hi share one 64-byte chunk so that is
	 * eight memory streams, while whole planes make it sixteen. Two-layer
	 * holds four shards, which is eight streams here, and wins:
	 *
	 *   f=255/4MiB   plain (4 streams, n passes)   1.64 ms
	 *                two-layer  (8 streams, n/2)   0.896
	 *                three-layer (16 streams, n/3) 0.941
	 *
	 * It is not register pressure. The hand-written block of fft_kernels.S
	 * removes every spill -- 151 stack-operand instructions out of 672 in the
	 * C form, 0 in the assembly -- and is 0.98x-1.00x. The block is
	 * memory-bound at these shapes and the streams are what bind.
	 *
	 * ISAL16_FFT_BLOCK3=1 restores it, and it is expected to pay in GF(2^8),
	 * where a shard is one stream rather than two.
	 */
	fft_block3 = getenv("ISAL16_FFT_BLOCK3")
		     && !strcmp(getenv("ISAL16_FFT_BLOCK3"), "1");
	/* The blocked forms hold eight shards plus their multipliers in the
	 * register file, which is what GFNI buys; without it there is nothing to
	 * block into. */
	if (!fft_have_gfni)
		fft_block = fft_block3 = 0;
	/* DEFAULT OFF since 2026-08-26. codec/KNOBS.md: at -O3 the intrinsics form
	 * spills nothing and the assembly measures 1.03x-1.09x SLOWER, so its
	 * justification is void. It is in any case unreachable unless
	 * ISAL16_FFT_BLOCK3=1, which is off. `=1` is the reachable null. */
	fft_use_asm = fft_have_gfni && cpu_has_avx512vl()
		      && getenv("ISAL16_FFT_ASM")
		      && !strcmp(getenv("ISAL16_FFT_ASM"), "1");

	fft_skew_init(basis);
	fft_coset_init(k, m, basis);
	/*
	 * A COST PROBE, NOT A CODEC. `ISAL16_FFT_ZEROSKEW=1` zeroes the skew
	 * table AFTER the coset constants have been derived from it, so every
	 * butterfly keeps its loads, its stores and its XOR and loses only the
	 * affine multiply: `fft_b1`, `fft_b2` and `fft_b3` each gate the multiply
	 * on `s != 0` and none of them gates the memory. **The parity it emits is
	 * wrong by construction** -- run it with `--no-verify` and never quote a
	 * ratio from it as a codec figure.
	 *
	 * What it measures is the one number that decides whether an affine-op
	 * count predicts this encoder at all: the share of the transform that is
	 * multiply rather than traffic. `PERF-NOTES-PPT.md`'s estimate is an
	 * affine-op count, and §5.19 concluded this block is not
	 * instruction-bound -- so the two want reconciling before anything is
	 * built on either.
	 */
	if (getenv("ISAL16_FFT_ZEROSKEW")
	    && !strcmp(getenv("ISAL16_FFT_ZEROSKEW"), "1"))
		memset(fft_skew, 0, 65535 * sizeof(uint16_t));

	fft_chunk = chunk_of(k);
	fft_ncos = ((unsigned)m + fft_chunk - 1) / fft_chunk;
	/* Every coset but the last must fit the parity pool whole, which is what
	 * lets the inverse transform run there. m = 2f and chunk = next_pow2(f+1)
	 * give it at every shape, but it is cheap to insist. */
	if (fft_ncos > 1 && (unsigned)m < fft_chunk) {
		fprintf(stderr, "fft: m=%d below chunk=%u\n", m, fft_chunk);
		exit(1);
	}
	fft_tail_shards = fft_chunk - ((unsigned)m - (fft_ncos - 1) * fft_chunk);
	fft_wsh = malloc((size_t)fft_chunk * sizeof(fft_sh));
	fft_dsh = malloc((size_t)fft_chunk * sizeof(fft_sh));
	if (!fft_wsh || !fft_dsh) {
		fprintf(stderr, "fft shard array allocation failed\n");
		exit(1);
	}

	/* The last coset by matrix when its live count is small enough. Needs at
	 * least two cosets, so that what remains for the transform is whole. */
	unsigned last = (unsigned)m - (fft_ncos - 1) * fft_chunk;
	/*
	 * DEFAULT 12, and unlike everything else here this IS a tuning threshold
	 * -- a real performance crossover, not an algebraic condition, so it would
	 * want recalibrating on another machine. Measured at 4 MiB:
	 *
	 *   chunk 256   last  2  8 10 12 14 16     chunk 128   last  4  8 12 16 20
	 *   matrix/fft     1.48 1.18 1.10 1.06 0.98 0.90            1.27 1.11 0.97 0.86 0.75
	 *
	 * so the crossover is last ~ 13 at chunk 256 and ~ 10 at chunk 128 --
	 * near-constant, because the matrix costs last*k and the transform costs
	 * a fixed multiple of chunk, and k ~ chunk. 12 takes both grid points that
	 * have a small tail (f = 129 at last 2, f = 134 at last 12) and the
	 * smallest tail anywhere at chunk 128 on this grid is 44, so nothing is
	 * exposed to the 0.97x. Getting it wrong costs a few percent, and only at
	 * shapes where the tail is small.
	 */
	/* DEFAULT 4 since 2026-08-26, was 12. Section 5.31: the choice is a
	 * separator placed in an empty interval, not a constant fitted to a
	 * crossover, and on this grid it changes exactly one shape. */
	const char *tv = getenv("ISAL16_FFT_TAIL");
	unsigned thresh = tv ? (unsigned)atoi(tv) : 4;
	fft_tail_rows = (fft_ncos >= 2 && last <= thresh) ? last : 0;
	if (fft_tail_rows) {
		unsigned base = (fft_ncos - 1) * fft_chunk;
		/* gen8 is the 2m x 2k expansion; parity shard i owns rows 2i and
		 * 2i+1, each 2k bytes wide. The tables are built once here, not
		 * per call -- same class as the encoder's own, section 3.2. */
		fft_tail_tab = malloc((size_t)(2 * k) * (2 * fft_tail_rows) * tab_entry);
		fft_tail_out = malloc((size_t)(2 * fft_tail_rows) * sizeof(*fft_tail_out));
		/* Under the interleaved pool the tail cannot be handed the caller's
		 * `enc_in`, which addresses the pool as planes. */
		if (fft_pool_inter)
			fft_tail_in = malloc((size_t)(2 * k) * sizeof(*fft_tail_in));
		if (!fft_tail_tab || !fft_tail_out
		    || (fft_pool_inter && !fft_tail_in)) {
			fprintf(stderr, "fft tail allocation failed\n");
			exit(1);
		}
		ec_init_tables(2 * k, (int)(2 * fft_tail_rows),
			       (unsigned char *)gen8 + (size_t)(2 * base) * (2 * k),
			       fft_tail_tab);
	}
}

/* --------------------------------------------- systematic Cauchy generator */

/* Entry (i,j) of the m x k parity block: 1 / (node(k+i) ^ node(j)). */
static inline uint16_t cauchy16_entry(int k, int i, int j)
{
	return g16inv((uint16_t)(g16_node[k + i] ^ g16_node[j]));
}

/* Closed-form inverse of C[a][b] = 1/(xs[a]^ys[b]); out[b*n + a]. O(n^2). */
static void cauchy16_inverse_tower(const uint16_t *xs, const uint16_t *ys, int n,
				   uint16_t *out, uint16_t *nx, uint16_t *ny)
{
	for (int a = 0; a < n; a++) {
		uint16_t num = 1, den = 1;
		for (int l = 0; l < n; l++) {
			num = g16mul(num, (uint16_t)(xs[a] ^ ys[l]));
			if (l != a)
				den = g16mul(den, (uint16_t)(xs[a] ^ xs[l]));
		}
		nx[a] = g16div(num, den);
	}
	for (int b = 0; b < n; b++) {
		uint16_t num = 1, den = 1;
		for (int l = 0; l < n; l++) {
			num = g16mul(num, (uint16_t)(xs[l] ^ ys[b]));
			if (l != b)
				den = g16mul(den, (uint16_t)(ys[b] ^ ys[l]));
		}
		ny[b] = g16div(num, den);
	}
	for (int b = 0; b < n; b++)
		for (int a = 0; a < n; a++)
			out[b * n + a] = g16div(g16mul(nx[a], ny[b]),
						(uint16_t)(xs[a] ^ ys[b]));
}

/*
 * The same function over the log tables.
 *
 * Three things change beyond swapping the multiply. The prefix products become
 * sums of logs, so the whole inner loop is xor, one lookup and one add, with no
 * multiply and no dependent chain through the field. The final loop hoists
 * log(nx[a]) into a scratch array and log(ny[b]) into a register, so each entry
 * costs one lookup for log(xs[a]^ys[b]), two adds and one exp lookup. And every
 * xs[a]^ys[b] is below the next power of two above T, so that lookup stays in
 * the first few KB of the log table however large the field is.
 *
 * None of the products can be zero: xs and ys are disjoint index sets, so
 * xs[a]^ys[b] != 0, and l != a / l != b guard the two same-set products.
 */
static void cauchy16_inverse_log(const uint16_t *xs, const uint16_t *ys, int n,
				 uint16_t *out, uint16_t *nx, uint16_t *ny,
				 uint16_t *lnx)
{
	/* Exponents are reduced with a conditional add, never a modulo: a `%` here
	 * is a divide in the inner loop and costs more than the multiply it
	 * replaced. g16_exp holds two periods, so any index in [0, 2*65535) is
	 * valid without reduction at all. */
	for (int a = 0; a < n; a++) {
		uint32_t num = 0, den = 0;
		for (int l = 0; l < n; l++) {
			num += g16_log[xs[a] ^ ys[l]];
			if (l != a)
				den += g16_log[xs[a] ^ xs[l]];
		}
		int32_t e = (int32_t)(num % 65535u) - (int32_t)(den % 65535u);
		e += (e >> 31) & 65535;
		nx[a] = g16_exp[e];
	}
	for (int b = 0; b < n; b++) {
		uint32_t num = 0, den = 0;
		for (int l = 0; l < n; l++) {
			num += g16_log[xs[l] ^ ys[b]];
			if (l != b)
				den += g16_log[ys[b] ^ ys[l]];
		}
		int32_t e = (int32_t)(num % 65535u) - (int32_t)(den % 65535u);
		e += (e >> 31) & 65535;
		ny[b] = g16_exp[e];
	}
	for (int a = 0; a < n; a++)
		lnx[a] = g16_log[nx[a]];
	for (int b = 0; b < n; b++) {
		int32_t lny = g16_log[ny[b]];
		uint16_t yb = ys[b];
		uint16_t *o = out + (size_t)b * n;
		for (int a = 0; a < n; a++) {
			/* lnx + lny is in [0, 131068] and the log subtracted is in
			 * [0, 65534], so e is in [-65534, 131068]; one conditional
			 * add lands it in [0, 131068], inside g16_exp's two periods. */
			int32_t e = (int32_t)lnx[a] + lny
				  - (int32_t)g16_log[xs[a] ^ yb];
			e += (e >> 31) & 65535;
			o[a] = g16_exp[e];
		}
	}
}

static uint16_t *g16_lnx;	/* scratch for cauchy16_inverse_log, k entries */

static void cauchy16_inverse(const uint16_t *xs, const uint16_t *ys, int n,
			     uint16_t *out, uint16_t *nx, uint16_t *ny)
{
	if (g16_use_logtab)
		cauchy16_inverse_log(xs, ys, n, out, nx, ny, g16_lnx);
	else
		cauchy16_inverse_tower(xs, ys, n, out, nx, ny);
}

/* Textbook GE inverse over GF(2^16), for --plan ge. n x n, row-major. */
static int g16_invert(const uint16_t *in, uint16_t *out, int n)
{
	uint16_t *m = malloc((size_t)n * n * sizeof(uint16_t));
	memcpy(m, in, (size_t)n * n * sizeof(uint16_t));
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			out[i * n + j] = (i == j);
	for (int c = 0; c < n; c++) {
		int p = -1;
		for (int rw = c; rw < n; rw++)
			if (m[rw * n + c]) { p = rw; break; }
		if (p < 0) { free(m); return -1; }
		if (p != c)
			for (int j = 0; j < n; j++) {
				uint16_t t = m[c * n + j]; m[c * n + j] = m[p * n + j]; m[p * n + j] = t;
				t = out[c * n + j]; out[c * n + j] = out[p * n + j]; out[p * n + j] = t;
			}
		uint16_t iv = g16inv(m[c * n + c]);
		for (int j = 0; j < n; j++) {
			m[c * n + j] = g16mul(m[c * n + j], iv);
			out[c * n + j] = g16mul(out[c * n + j], iv);
		}
		for (int rw = 0; rw < n; rw++) {
			if (rw == c) continue;
			uint16_t f = m[rw * n + c];
			if (!f) continue;
			for (int j = 0; j < n; j++) {
				m[rw * n + j] ^= g16mul(f, m[c * n + j]);
				out[rw * n + j] ^= g16mul(f, out[c * n + j]);
			}
		}
	}
	free(m);
	return 0;
}

/*
 * The received-source columns of the decode matrix, in O(r * n_orig).
 *
 * The rows we need are  R = [ B^-1 | B^-1 E ]  where B[a][b] = 1/(xs_a ^ ys_b)
 * is the r x r residual Cauchy system on the received parity shards xs and the
 * missing source shards ys, and E[a][c] = 1/(xs_a ^ u_c) covers the received
 * source shards u. B^-1 is the closed form above. Forming B^-1 E as an actual
 * matrix product costs r^2 * n_orig multiplies, which is ~0.148 k^3 and was
 * measured to dominate the whole decode above f = 129 -- 10.2 ms of a 21.9 ms
 * decode at f = 255. It collapses:
 *
 * With (B^-1)[b][a] = nx_a ny_b / (xs_a ^ ys_b) and, in characteristic 2,
 *
 *     1 / ((x ^ y)(x ^ u)) = ( 1/(x ^ y) + 1/(x ^ u) ) / (y ^ u),
 *
 *     (B^-1 E)[b][c] = ny_b * ( S(ys_b) + S(u_c) ) / (ys_b ^ u_c),
 *     S(w) = sum_a nx_a / (xs_a ^ w).
 *
 * S is a partial-fraction expansion in disguise. Put
 * P(w) = prod_l (w ^ ys_l) / prod_l (w ^ xs_l): numerator and denominator are
 * both monic of degree r, so P = 1 + N/D with deg N < r, and the residue of
 * N/D at xs_a is prod_l(xs_a ^ ys_l) / prod_{l!=a}(xs_a ^ xs_l), which is
 * exactly nx_a. Hence S(w) = 1 + P(w). At w = ys_b the numerator of P has a
 * zero factor, so S(ys_b) = 1 and the two S terms leave just P(u_c):
 *
 *     (B^-1 E)[b][c] = ny_b * P(u_c) / (ys_b ^ u_c).
 *
 * P(u_c) is 2r multiplies and one inversion per column, computed once for all
 * b, and every entry is then one multiply and one division. Both products are
 * nonzero: u_c is a received source index so it differs from every missing ys_l
 * and, being < k, from every parity xs_l >= k.
 *
 * --fold naive computes the same rows by the explicit product; check.sh-style
 * validation compares the two.
 */
static void fold_closed_form16(const uint16_t *xs, const uint16_t *ys,
			     const uint16_t *ny, int r,
			     const int *recv_orig, const int *orig_col, int n_orig,
			     uint16_t *pu, int k, uint16_t *rows16)
{
	if (!g16_use_logtab) {
		for (int c = 0; c < n_orig; c++) {
			uint16_t u = g16_node[recv_orig[c]], num = 1, den = 1;
			for (int l = 0; l < r; l++) {
				num = g16mul(num, (uint16_t)(u ^ ys[l]));
				den = g16mul(den, (uint16_t)(u ^ xs[l]));
			}
			pu[c] = g16div(num, den);
		}
		for (int b = 0; b < r; b++)
			for (int c = 0; c < n_orig; c++)
				rows16[(size_t)b * k + orig_col[c]] =
					g16div(g16mul(ny[b], pu[c]),
					       (uint16_t)(ys[b] ^ g16_node[recv_orig[c]]));
		return;
	}
	/* Same identity over the log tables; see cauchy16_inverse_log. log(pu[c])
	 * is what the second loop actually wants, so it is kept rather than the
	 * value -- the exp lookup that would produce pu[c] is pure loss here. */
	for (int c = 0; c < n_orig; c++) {
		uint16_t u = g16_node[recv_orig[c]];
		uint32_t num = 0, den = 0;
		for (int l = 0; l < r; l++) {
			num += g16_log[u ^ ys[l]];
			den += g16_log[u ^ xs[l]];
		}
		int32_t e = (int32_t)(num % 65535u) - (int32_t)(den % 65535u);
		e += (e >> 31) & 65535;
		pu[c] = (uint16_t)e;		/* log(pu), not pu */
	}
	for (int b = 0; b < r; b++) {
		int32_t lny = g16_log[ny[b]];
		uint16_t yb = ys[b];
		uint16_t *row = rows16 + (size_t)b * k;
		for (int c = 0; c < n_orig; c++) {
			uint16_t u = g16_node[recv_orig[c]];
			int32_t e = (int32_t)pu[c] + lny - (int32_t)g16_log[yb ^ u];
			e += (e >> 31) & 65535;
			row[orig_col[c]] = g16_exp[e];
		}
	}
}

/*
 * Expand an nr x nc GF(2^16) matrix into the 2nr x 2nc GF(2^8) matrix that acts
 * on planar operands. Input plane order is [lo(col0), hi(col0), lo(col1), ...]
 * and output plane order matches, which is why the 2x2 blocks land contiguously.
 */
static void expand16(const uint16_t *a, int nr, int nc, unsigned char *out)
{
	int w = 2 * nc;
	for (int b = 0; b < nr; b++) {
		for (int j = 0; j < nc; j++) {
			uint16_t v = a[b * nc + j];
			unsigned char a0 = lo8(v), a1 = hi8(v);
			out[(2 * b) * w + 2 * j] = a0;
			out[(2 * b) * w + 2 * j + 1] = gmul(BETA, a1);
			out[(2 * b + 1) * w + 2 * j] = a1;
			out[(2 * b + 1) * w + 2 * j + 1] = a0 ^ a1;
		}
	}
}

/*
 * Karatsuba over the composite field, for encode.
 *
 * The plain expansion hands ISA-L a 2k x 2m GF(2^8) matrix, so each output pair
 * costs 4k multiply-accumulates: the 2x2 block
 *
 *     [ g0        BETA*g1 ]   applied to   [ v0 ]
 *     [ g1        g0+g1   ]                [ v1 ]
 *
 * has four non-trivial entries. Karatsuba turns those four products into three.
 * With w = v0 + v1,
 *
 *     P0 = g0 v0,  P1 = g1 v1,  P2 = (g0 + g1) w
 *     low  = P0 + BETA P1
 *     high = P2 + P0
 *
 * -- because P2 + P0 = g0v1 + g1v0 + g1v1, which is exactly the high term. So
 * three k-column dot products per output pair instead of four, at the cost of
 * one XOR pass over the k source shards to form w and two over the m outputs.
 * Those passes are O((k + 2m) h) against the kernel's O(3 k m h); at k = 256
 * the ratio is three orders of magnitude.
 *
 * The three coefficient matrices are g0, BETA*g1 (folded, so the low half needs
 * no constant-multiply pass) and g0 + g1, each m x k. Decode still uses the
 * plain expansion -- it is the same identity, but one thing at a time.
 *
 * ISAL16_KARATSUBA=0 restores the plain 2k x 2m expansion.
 */

static void xor_into(unsigned char *dst, const unsigned char *a, size_t n)
{
	size_t i = 0;
	for (; i + 8 <= n; i += 8) {
		uint64_t x, y;
		memcpy(&x, dst + i, 8);
		memcpy(&y, a + i, 8);
		x ^= y;
		memcpy(dst + i, &x, 8);
	}
	for (; i < n; i++)
		dst[i] ^= a[i];
}

static void xor3_into(unsigned char *dst, const unsigned char *a,
		      const unsigned char *b, size_t n)
{
	size_t i = 0;
	for (; i + 8 <= n; i += 8) {
		uint64_t x, y;
		memcpy(&x, a + i, 8);
		memcpy(&y, b + i, 8);
		x ^= y;
		memcpy(dst + i, &x, 8);
	}
	for (; i < n; i++)
		dst[i] = a[i] ^ b[i];
}

/*
 * The three m x k GF(2^8) coefficient matrices of the Karatsuba form, from the
 * m x k GF(2^16) generator.
 */
static void karatsuba_coeffs(const uint16_t *g16, int nr, int nc,
			     unsigned char *ga, unsigned char *gb, unsigned char *gc)
{
	for (int b = 0; b < nr; b++)
		for (int j = 0; j < nc; j++) {
			uint16_t v = g16[(size_t)b * nc + j];
			unsigned char g0 = lo8(v), g1 = hi8(v);
			ga[(size_t)b * nc + j] = g0;
			gb[(size_t)b * nc + j] = gmul(BETA, g1);
			gc[(size_t)b * nc + j] = g0 ^ g1;
		}
}

/* ------------------------------------------------------------------- args */

static void usage_gf16(const char *p)
{
	fprintf(stderr,
		"usage: %s --f F --shard-bytes N [options]\n"
		"  --plan P     cauchy|ge   (default: cauchy)\n"
		"  --fold F     closed-form|naive  received-source columns (default: closed-form)\n"
		"  --arrivals A random|parity  which k shards the receiver got\n"
		"  --trials N   measured trials (default 20)\n"
		"  --warmup N   warmup trials (default 3)\n"
		"  --seed N     base seed (default 1)\n"
		"  --k K --m M  explicit shape instead of k=f+1, m=2f\n"
		"  --enc-probe P  all|w|p2|p1|p0|fold|plain -- time one encode phase\n"
		"  --stripes N  split each shard plane into N byte-ranges; the plan and\n"
		"               all coefficient tables are built once and reused (default 1)\n"
		"  --no-verify  skip the reconstruction check\n"
		"  --digest     encode once and print an FNV-1a 64 digest of the source\n"
		"               and parity halves, for comparing encoders\n",
		p);
}

static int run_gf16(int argc, char **argv)
{
	int f = -1;
	long shard_bytes = -1;
	int stripes = 1;
	int trials = 20, warmup = 3, verify = 1;
	uint64_t seed = 1;
	int use_ge = 0, naive_fold = 0, digest_only = 0, arrivals_parity = 0;
	/* --phase decode: see the GF(2^8) main. Same contract, same default. */
	int phase_decode = 0;
	int phase_encode = 0;
	int k_arg = -1, m_arg = -1;
	const char *plan_probe = NULL;
	const char *enc_probe = NULL;
	int probe_iters = 200;

	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--f") && i + 1 < argc)
			f = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--shard-bytes") && i + 1 < argc)
			shard_bytes = atol(argv[++i]);
		else if (!strcmp(argv[i], "--stripes") && i + 1 < argc)
			stripes = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--trials") && i + 1 < argc)
			trials = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--warmup") && i + 1 < argc)
			warmup = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--seed") && i + 1 < argc)
			seed = strtoull(argv[++i], NULL, 10);
		else if (!strcmp(argv[i], "--digest"))
			digest_only = 1;
		else if (!strcmp(argv[i], "--k") && i + 1 < argc)
			k_arg = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--m") && i + 1 < argc)
			m_arg = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--plan-probe") && i + 1 < argc)
			plan_probe = argv[++i];
		else if (!strcmp(argv[i], "--enc-probe") && i + 1 < argc)
			enc_probe = argv[++i];
		else if (!strcmp(argv[i], "--probe-iters") && i + 1 < argc)
			probe_iters = atoi(argv[++i]);
		/* Consumed by main() to pick the body; each body ignores it so the
		 * argument vector it sees is otherwise the one it always saw. */
		else if (!strcmp(argv[i], "--field") && i + 1 < argc)
			i++;
		else if (!strcmp(argv[i], "--no-verify"))
			verify = 0;
		else if (!strcmp(argv[i], "--phase") && i + 1 < argc) {
			const char *ph = argv[++i];
			if (!strcmp(ph, "decode"))
				phase_decode = 1;
			else if (!strcmp(ph, "encode"))
				phase_encode = 1;
			else if (strcmp(ph, "both")) {
				fprintf(stderr, "--phase must be both, encode or decode\n");
				return 2;
			}
		}
		else if (!strcmp(argv[i], "--fold") && i + 1 < argc) {
			const char *fd = argv[++i];
			if (!strcmp(fd, "naive")) naive_fold = 1;
			else if (!strcmp(fd, "closed-form")) naive_fold = 0;
			else { fprintf(stderr, "unknown --fold %s\n", fd); return 2; }
		}
		else if (!strcmp(argv[i], "--plan") && i + 1 < argc) {
			const char *p = argv[++i];
			if (!strcmp(p, "cauchy")) use_ge = 0;
			else if (!strcmp(p, "ge")) use_ge = 1;
			else { fprintf(stderr, "unknown --plan %s\n", p); return 2; }
		} else if (!strcmp(argv[i], "--arrivals") && i + 1 < argc) {
			/* No `first` here: GF(2^16) never had this option at all, and
			 * adding an untested mode alongside the one that is wanted
			 * would ship a second thing nothing measures. */
			const char *a = argv[++i];
			if (!strcmp(a, "random")) arrivals_parity = 0;
			else if (!strcmp(a, "parity")) arrivals_parity = 1;
			else { fprintf(stderr, "unknown --arrivals %s\n", a); return 2; }
		} else if (!strcmp(argv[i], "--codec") && i + 1 < argc) {
			i++; /* accepted and ignored, for driver symmetry */
		} else {
			usage_gf16(argv[0]);
			return 2;
		}
	}
	/* --k/--m give an explicit shape instead of the harness's k=f+1, m=2f.
	 * Added 26 Aug 2026 so that isal_cauchy16 can be measured at the rates
	 * leopard natively supports (m <= k), which the n = 3f+1 rate never is;
	 * run_gf8 and fd_point.c have had the same pair, spelled the same way,
	 * since rev 22. `f` is then only a label and appears only in the seed
	 * derivation and the CSV's first column, exactly as it does there. Grid
	 * legs never pass them, and the null is that `--k f+1 --m 2f` reproduces
	 * the default `--f f` digest -- check.sh asserts it. */
	if ((k_arg > 0) != (m_arg > 0)) {
		fprintf(stderr, "--k and --m must be given together\n");
		return 2;
	}
	if (k_arg > 0 && f < 1)
		f = k_arg - 1;
	if (f < 1 || shard_bytes < 1) {
		usage_gf16(argv[0]);
		return 2;
	}

	int k = k_arg > 0 ? k_arg : f + 1;
	int m = m_arg > 0 ? m_arg : 2 * f;
	int t = k + m;
	if (t > 65536) {
		fprintf(stderr, "GF(2^16) needs T<=65536, but k=%d m=%d gives T=%d\n",
			k, m, t);
		return 2;
	}
	if (shard_bytes % 2) {
		fprintf(stderr, "shard-bytes must be even for 16-bit symbols\n");
		return 2;
	}
	size_t sz = (size_t)shard_bytes, h = sz / 2;
	gf_init();
	{
		const char *lt = getenv("ISAL16_LOGTAB");
		g16_use_logtab = !(lt && !strcmp(lt, "0"));
	}
	g16_tables_init();
	field_selftest();
	gf16_affine_init();
	apply_fused = getenv("ISAL16_APPLY")
		      && !strcmp(getenv("ISAL16_APPLY"), "fused");
	g16_nodes_init(k, t);

	/* ISAL16_ENCODE=fft routes encode through the additive transform instead
	 * of the k x m matrix. It encodes the SAME code -- the standing oracle is
	 * that matrix and fft parity must agree byte for byte -- but only over the
	 * Cantor node set, because that is the code a transform computes. */
	int use_fft = 0, use_fft_decode = 0;
	{
		/* DEFAULT `fft` since 2026-08-26: 3.5x-45x on encode against the
		 * matrix encoder, rising with f. `matrix` is the reachable null. */
		const char *ev = getenv("ISAL16_ENCODE");
		use_fft = !(ev && !strcmp(ev, "matrix"));
		const char *dv = getenv("ISAL16_DECODE");
		use_fft_decode = dv && !strcmp(dv, "fft");
		/* DEFAULT `inter` since 2026-08-26 -- but only when the transform
		 * encoder is actually running, because the matrix encoder writes
		 * parity through ISA-L, which addresses the pool as planes. Defaulting
		 * it unconditionally would make ISAL16_ENCODE=matrix -- the null --
		 * fail with the error below instead of running. */
		const char *pl = getenv("ISAL16_ENC_LAYOUT");
		fft_pool_inter = pl ? !strcmp(pl, "inter") : use_fft;
		if (fft_pool_inter && !use_fft) {
			fprintf(stderr, "ISAL16_ENC_LAYOUT=inter needs ISAL16_ENCODE=fft: "
				"the matrix encoder writes parity through ISA-L, which "
				"addresses the pool as separate planes.\n");
			return 2;
		}
		if (use_fft_decode && !g16_nodes_cantor) {
			fprintf(stderr, "ISAL16_DECODE=fft needs ISAL16_NODES=cantor, for "
				"the same reason the encoder does\n");
			return 2;
		}
		if (use_fft && !g16_nodes_cantor) {
			fprintf(stderr, "ISAL16_ENCODE=fft needs ISAL16_NODES=cantor: "
				"the linear convention puts the parity nodes at "
				"index k rather than on a coset boundary, and the "
				"ported skew table is built for the Cantor basis\n");
			return 2;
		}
	}

	/* Parity rows of the systematic Cauchy generator, m x k over GF(2^16). */
	uint16_t *gen16 = malloc((size_t)m * k * sizeof(uint16_t));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < k; j++)
			gen16[(size_t)i * k + j] = cauchy16_entry(k, i, j);
	unsigned char *gen8 = malloc((size_t)(2 * m) * (2 * k));
	expand16(gen16, m, k, gen8);

	size_t stride = shard_stride(sz);

	/* Page-aligned shard pool. A malloc this size is served by mmap and the
	 * chunk header puts the payload at page + 16, which starts every shard 16
	 * bytes into a cache line and makes every 64-byte access straddle two --
	 * 1.29x on encode in the GF(2^8) drivers. See report rev 11 section 3.4.
	 * ISAL_POOL_SKEW=<n> puts the shards back off the boundary. */
	size_t pool_skew = getenv("ISAL_POOL_SKEW") ? (size_t)atol(getenv("ISAL_POOL_SKEW")) : 0;
	unsigned char *src = malloc((size_t)k * sz);
	unsigned char **shard = malloc((size_t)t * sizeof(*shard));
	size_t pool_bytes = (size_t)t * stride + pool_skew;
	pool_bytes = (pool_bytes + 4095) & ~(size_t)4095;
	unsigned char *pool_base = aligned_alloc(4096, pool_bytes);
	unsigned char *pool = pool_base + pool_skew;
	memset(pool_base, 0, pool_bytes);
	for (int i = 0; i < t; i++)
		shard[i] = pool + (size_t)i * stride;
	if (getenv("ISAL_POOL_TRACE"))
		fprintf(stderr, "pool base=%p shards_at=%p stride=%zu\n",
			(void *)pool_base, (void *)pool, stride);

	/* Decode sub-phase breakdown. Same knob name as src/main.rs, so the two
	 * drivers can be compared phase by phase -- section 3.7 is the fourth time
	 * a fix landed in one driver and not its twin. The decode timer's contents
	 * are unchanged: `decode_ms` still holds plan + kernel + materialize, and
	 * this only says how the total divides. This driver has no `alloc` or
	 * `ingest` phase to report, and that is the finding, not an omission: the
	 * shard pool is allocated once above the trial loop and reconstruction is
	 * in place into it, so there is no per-decode buffer and no copy of the
	 * received shards. reed-solomon-simd's decoder owns its work buffer, so it
	 * has both. */
	/* Decode working memory: allocated inside the timed region, per call.
	 *
	 * R10's decode timer holds `ManagedDecoder::new` and a freshly allocated
	 * message; RaptorQ's holds its decoder; reed-solomon-simd's now holds its
	 * work buffer. Those are the codecs this one is compared against, so
	 * holding these above the trial loop measured a different contract. The
	 * rule adopted is: hoist out of the stripes, never out of the decode.
	 *
	 * ISAL_ALLOC_PER_CALL=0 restores the held buffers, for reproducing figures
	 * taken before the rule. The free is outside the timer, as every other
	 * codec's is -- R10 drops its decoder when the function returns. */
	int alloc_per_call = !getenv("ISAL_ALLOC_PER_CALL")
			     || strcmp(getenv("ISAL_ALLOC_PER_CALL"), "0") != 0;
	int dec_breakdown = getenv("BENCH_DECODE_BREAKDOWN")
			    && !strcmp(getenv("BENCH_DECODE_BREAKDOWN"), "1");
	/*
	 * A PROBE, and a single-variable one. `ISAL16_DEC_PACK=1` gives the PLANE
	 * matrix decoder the same densely-packed survivor buffer the interleaved
	 * one gets -- same extra k*sz pass, same destination, same everything --
	 * but a `memcpy` where the interleaved path does an `inter_to_plane`. So
	 * it moves PACKING without moving LAYOUT.
	 *
	 * It exists because the interleaved matrix decoder measures FASTER than
	 * the plane one at 4 and 2 MiB, which a pure conversion cost cannot
	 * explain. The candidate is that the shard pool carries ISAL_SHARD_PAD
	 * stride while this buffer is dense, and the Karatsuba apply re-reads the
	 * survivors 3*ceil(r/6) times -- ~45 passes at f = 129 -- so a small
	 * per-read gain is paid once and collected many times. This separates that
	 * from the layout. Correct in both settings: it is a pure copy.
	 */
	int dec_pack = getenv("ISAL16_DEC_PACK")
		       && !strcmp(getenv("ISAL16_DEC_PACK"), "1");

	/* Encode timer contents; see the encode region below. */
	const char *et = getenv("ISAL_ENC_TIMER");
	int enc_timer_lean = !et || strcmp(et, "full") != 0;

	/* 8 bytes per entry: on a GFNI host ec_init_tables dispatches to
	 * ec_init_tables_gfni, which writes one 64-bit affine matrix per entry, not
	 * the 32 bytes erasure_code.h documents. Checked under ASan. On a host
	 * without GFNI this would be a 4x under-allocation, so it is sized for the
	 * documented contract when GFNI is absent. */
	size_t tab_entry = 32;
	unsigned char *enc_tab = malloc((size_t)(2 * k) * (2 * m) * tab_entry);

	/* After gen8, because the last-coset matrix path slices its rows out of
	 * the same expansion the matrix encoder uses. */
	size_t fftw_bytes = 0;
	unsigned char *fftpool = NULL;
	size_t fftd_bytes = 0;
	unsigned char *fftdpool = NULL;
	if (use_fft || use_fft_decode) {
		/*
		 * The transform's kernels are whole-32-byte-chunk kernels over a
		 * plane, and only `fft_b1` and `fft_mul_inplace` carry a scalar
		 * fallback for a ragged tail: `fft_b2` and `fft_b3` compute
		 * `nc = h / 32` and silently leave the last `h % 32` bytes of every
		 * plane untransformed. With `sz % 64` that produces wrong parity and
		 * no diagnostic -- only the reconstruction check catches it.
		 *
		 * The harness rounds every shard up to a multiple of 64 (check.sh,
		 * robust_benchmark.py) so no measured shape reaches this, which is
		 * why it went unnoticed. Insisting is cheaper than a fallback nobody
		 * needs; if a ragged shard is ever wanted, give `fft_b2`/`fft_b3` the
		 * decomposition into `fft_b1` calls rather than a tail loop, since
		 * `fft_b1` already handles it and the butterfly order is identical.
		 */
		if (sz % 64) {
			fprintf(stderr, "fft: shard_bytes=%zu is not a multiple of "
				"64; the transform needs whole 32-byte chunks in "
				"each of the two planes\n", sz);
			exit(1);
		}
		fft16_init(k, m, g16_cantor, gen8, tab_entry);
		if (use_fft_decode) {
			fft16_decode_init(k, m, g16_cantor);
			fftd_bytes = fft16_decode_scratch(k, m, stride);
			fftdpool = aligned_alloc(4096,
				(fftd_bytes + 4095) & ~(size_t)4095);
			if (!fftdpool) {
				fprintf(stderr, "fft decode buffer allocation failed\n");
				return 1;
			}
		}
		if (!use_fft)
			goto fft_sized;
		/* Sized after init, because whether the last coset goes to the
		 * matrix decides whether there is a dead tail to hold at all. */
		fftw_bytes = fft16_scratch_bytes(k, m, stride);
		if (fftw_bytes) {
			fftpool = aligned_alloc(4096,
				(fftw_bytes + 4095) & ~(size_t)4095);
			if (!fftpool) {
				fprintf(stderr, "fft work buffer allocation failed\n");
				return 1;
			}
		}
fft_sized: ;
	}

	/* Karatsuba encode: three m x k coefficient matrices, their tables, a plane
	 * of w = v0 + v1 per source shard, and one m-plane accumulator. Allocated
	 * whether or not the path is taken, so the two configurations differ only in
	 * the work inside the timer and not in what the allocator has been asked
	 * for -- rev 11 section 3.6 is what that is guarding against. */
	int kara = !getenv("ISAL16_KARATSUBA") || strcmp(getenv("ISAL16_KARATSUBA"), "0") != 0;
	unsigned char *ka = malloc((size_t)m * k);
	unsigned char *kb = malloc((size_t)m * k);
	unsigned char *kc = malloc((size_t)m * k);
	unsigned char *ktab_a = malloc((size_t)k * m * tab_entry);
	unsigned char *ktab_b = malloc((size_t)k * m * tab_entry);
	unsigned char *ktab_c = malloc((size_t)k * m * tab_entry);
	unsigned char *wpool = aligned_alloc(4096, ((size_t)k * h + 4095) & ~(size_t)4095);
	unsigned char *spool = aligned_alloc(4096, ((size_t)m * h + 4095) & ~(size_t)4095);
	/* The transform's work buffer: one chunk of shards for the inverse
	 * transform's result, plus the dead tail of a partial last recovery coset.
	 * At f = 255 that is 256 + 2 shards, against the 512 upstream rounds up to,
	 * because the destination is an array of shard pointers and the live
	 * outputs go straight into the parity pool. */

	/* Gather/scatter staging for striped encode and decode.
	 *
	 * ISAL_STRIPE_GATHER=1: read the stripe of every input shard into a dense
	 * k*stripe buffer, run the kernel entirely inside dense buffers, and write
	 * the dense outputs back out. Without it a stripe is k scattered pieces at
	 * shard stride and m scattered output streams, so striping shrinks the
	 * range walked but leaves the access pattern alone.
	 *
	 * The copies are one pass over the sources and one over the outputs across
	 * the whole encode, against the kernel's ceil(m/6) = 85 passes over the
	 * sources at f = 255, so they are cheap if the locality is worth anything.
	 * Sized at the full length and indexed by `stripe`, so unstriped runs are
	 * unaffected. */
	unsigned char *gin0 = aligned_alloc(4096, ((size_t)k * h + 4095) & ~(size_t)4095);
	unsigned char *gin1 = aligned_alloc(4096, ((size_t)k * h + 4095) & ~(size_t)4095);
	unsigned char *glo = aligned_alloc(4096, ((size_t)m * h + 4095) & ~(size_t)4095);
	unsigned char *ghi = aligned_alloc(4096, ((size_t)m * h + 4095) & ~(size_t)4095);
	int stripe_gather = getenv("ISAL_STRIPE_GATHER")
			    && !strcmp(getenv("ISAL_STRIPE_GATHER"), "1");
	unsigned char **kin = malloc((size_t)k * sizeof(*kin));
	unsigned char **kout = malloc((size_t)m * sizeof(*kout));
	karatsuba_coeffs(gen16, m, k, ka, kb, kc);

	/* Decode side: the reconstruction matrix is at most k x k, and its three
	 * Karatsuba coefficient matrices are rebuilt every trial because the
	 * erasure pattern is. That build is plan work, exactly as expand16 is. */
	unsigned char *da = malloc((size_t)k * k);
	unsigned char *db = malloc((size_t)k * k);
	unsigned char *dc = malloc((size_t)k * k);
	/* ceil(r/6) tiles x k inputs x 6 outputs x 3 matrices x 8 bytes, at the
	 * worst case r = k. NOT k*k*24: the tile count rounds up, so that is short
	 * by one tile's worth whenever r is near k -- 12 KB at k = 256, which
	 * segfaulted. */
	size_t apply_tab_bytes = (size_t)((k + 7) / 8) * k * 192;
	unsigned char *dtab_f = apply_fused ? malloc(apply_tab_bytes) : NULL;
	/* Where a short last tile sends its dead outputs. The tile stays six wide
	 * with zero coefficients rather than growing a ragged case. */
	unsigned char *apply_sink = apply_fused ? malloc(sz) : NULL;
	unsigned char *dtab_a = malloc((size_t)k * k * tab_entry);
	unsigned char *dtab_b = malloc((size_t)k * k * tab_entry);
	unsigned char *dtab_c = malloc((size_t)k * k * tab_entry);
	unsigned char *dspool = aligned_alloc(4096, ((size_t)k * h + 4095) & ~(size_t)4095);
	unsigned char **enc_in = malloc((size_t)(2 * k) * sizeof(*enc_in));
	unsigned char **enc_out = malloc((size_t)(2 * m) * sizeof(*enc_out));
	/* Where parity goes. Points into the shard pool, or into the per-call
	 * output buffer when the allocation rule is on -- see the encode timer. */
	unsigned char **par = malloc((size_t)m * sizeof(*par));

	int *order = malloc((size_t)t * sizeof(int));
	int *order_scratch = malloc((size_t)t * sizeof(int));
	uint16_t *rows16 = malloc((size_t)k * k * sizeof(uint16_t));
	uint16_t *sub16 = malloc((size_t)k * k * sizeof(uint16_t));
	uint16_t *inv16 = malloc((size_t)k * k * sizeof(uint16_t));
	unsigned char *rows8 = malloc((size_t)(2 * k) * (2 * k));
	unsigned char *dec_tab = malloc((size_t)(2 * k) * (2 * k) * tab_entry);
	unsigned char **dec_in = malloc((size_t)(2 * k) * sizeof(*dec_in));
	unsigned char **dec_out = malloc((size_t)(2 * k) * sizeof(*dec_out));
	/* recov retired: reconstruction is in place into the shard pool. */
	unsigned char *whole = malloc((size_t)k * sz);
	/* The k survivors as the GF(2^8) kernels must see them: plane-addressed.
	 * Under the plane pool these are pool pointers and nothing is copied;
	 * under the interleaved pool they point into `whole`. See `srcv` below. */
	unsigned char **srcv = malloc((size_t)k * sizeof(*srcv));
	uint16_t *xs = malloc((size_t)k * sizeof(uint16_t));
	uint16_t *ys = malloc((size_t)k * sizeof(uint16_t));
	uint16_t *nx = malloc((size_t)k * sizeof(uint16_t));
	uint16_t *ny = malloc((size_t)k * sizeof(uint16_t));
	g16_lnx = malloc((size_t)k * sizeof(uint16_t));
	uint16_t *binv = malloc((size_t)k * k * sizeof(uint16_t));
	uint16_t *ecau = malloc((size_t)k * k * sizeof(uint16_t));
	uint16_t *pu = malloc((size_t)k * sizeof(uint16_t));
	int *missing = malloc((size_t)k * sizeof(int));
	int *par_col = malloc((size_t)k * sizeof(int));
	int *orig_col = malloc((size_t)k * sizeof(int));
	int *recv_par = malloc((size_t)k * sizeof(int));
	int *recv_orig = malloc((size_t)k * sizeof(int));
	char *got = malloc((size_t)t);
	/* --phase decode's codeword, built once at setup and never written
	 * again. NULL under the default interleaved loop. */
	unsigned char *code = NULL;

	/* --enc-probe: decompose the Karatsuba encode into its five phases.
	 *
	 * One phase per process, named as an argument -- section 3.6's rule, the
	 * same one --plan-probe follows. Each phase is re-run N times inside one
	 * timed region: the three dot products are pure functions of their inputs,
	 * and `fold` and `w` are idempotent in cost though not in value, so N
	 * repeats cost N times one call in every case. This measures warm
	 * throughput, not the cold entry the driver's own encode timer sees.
	 *
	 * `all` is the whole Karatsuba body and `plain` the 2k x 2m expansion, so
	 * the two are the ISAL16_KARATSUBA=1 and =0 encode paths.
	 */
	if (enc_probe) {
		int N = probe_iters > 0 ? probe_iters : 1;
		int mode = !strcmp(enc_probe, "all")   ? 0
			 : !strcmp(enc_probe, "w")     ? 1
			 : !strcmp(enc_probe, "p2")    ? 2
			 : !strcmp(enc_probe, "p1")    ? 3
			 : !strcmp(enc_probe, "p0")    ? 4
			 : !strcmp(enc_probe, "fold")  ? 5
			 : !strcmp(enc_probe, "plain") ? 6
			 : !strcmp(enc_probe, "tiled") ? 7 : -1;
		if (mode < 0) {
			fprintf(stderr, "--enc-probe: all|w|p2|p1|p0|fold|plain|tiled\n");
			return 2;
		}
		/* `tiled` is `all` strip-mined over the shard length: the whole
		 * Karatsuba body -- w, the three dot products, the fold -- runs on one
		 * chunk of every plane before moving on. ec_encode_data walks the source
		 * ceil(m/6) times, so untiled it reads a k*h source plane 85 times at
		 * f = 255; tiled it reads a k*CHUNK slice that many times instead. Set
		 * k*CHUNK to fit L2. ENC_TILE=<bytes>, 0 or unset means untiled. */
		size_t tile = getenv("ENC_TILE") ? (size_t)atol(getenv("ENC_TILE")) : 4096;
		if (tile == 0 || tile > h)
			tile = h;
		sm64 rp = { seed ^ 0x50524245ULL };
		sm64_fill(&rp, src, (size_t)k * sz);
		for (int i = 0; i < k; i++)
			memcpy(shard[i], src + (size_t)i * sz, sz);
		for (int j = 0; j < k; j++) {
			enc_in[2 * j] = shard[j];
			enc_in[2 * j + 1] = shard[j] + h;
		}
		for (int i = 0; i < m; i++) {
			enc_out[2 * i] = shard[k + i];
			enc_out[2 * i + 1] = shard[k + i] + h;
		}
		ec_init_tables(k, m, ka, ktab_a);
		ec_init_tables(k, m, kb, ktab_b);
		ec_init_tables(k, m, kc, ktab_c);
		ec_init_tables(2 * k, 2 * m, gen8, enc_tab);
		/* Warm every buffer the timed region touches, so the probe measures
		 * the kernel and not first-touch faulting -- rev 9's trap. */
		for (int i = 0; i < k; i++)
			xor3_into(wpool + (size_t)i * h, shard[i], shard[i] + h, h);
		memset(spool, 0, (size_t)m * h);

		double tp = now_ms();
		for (int it = 0; it < N; it++) {
			if (mode == 6) {
				ec_encode_data((int)h, 2 * k, 2 * m, enc_tab, enc_in, enc_out);
				continue;
			}
			if (mode == 0 || mode == 1)
				for (int i = 0; i < k; i++) {
					kin[i] = wpool + (size_t)i * h;
					xor3_into(kin[i], shard[i], shard[i] + h, h);
				}
			if (mode == 0 || mode == 2) {
				for (int i = 0; i < k; i++)
					kin[i] = wpool + (size_t)i * h;
				for (int j = 0; j < m; j++)
					kout[j] = shard[k + j] + h;
				ec_encode_data((int)h, k, m, ktab_c, kin, kout);
			}
			if (mode == 0 || mode == 3) {
				for (int i = 0; i < k; i++)
					kin[i] = shard[i] + h;
				for (int j = 0; j < m; j++)
					kout[j] = shard[k + j];
				ec_encode_data((int)h, k, m, ktab_b, kin, kout);
			}
			if (mode == 0 || mode == 4) {
				for (int i = 0; i < k; i++)
					kin[i] = shard[i];
				for (int j = 0; j < m; j++)
					kout[j] = spool + (size_t)j * h;
				ec_encode_data((int)h, k, m, ktab_a, kin, kout);
			}
			if (mode == 0 || mode == 5)
				for (int j = 0; j < m; j++) {
					xor_into(shard[k + j], spool + (size_t)j * h, h);
					xor_into(shard[k + j] + h, spool + (size_t)j * h, h);
				}
	
			if (mode == 7)
				for (size_t off = 0; off < h; off += tile) {
					size_t L = h - off < tile ? h - off : tile;
					for (int i = 0; i < k; i++)
						xor3_into(wpool + (size_t)i * h + off,
							  shard[i] + off, shard[i] + h + off, L);
					for (int i = 0; i < k; i++)
						kin[i] = wpool + (size_t)i * h + off;
					for (int j = 0; j < m; j++)
						kout[j] = shard[k + j] + h + off;
					ec_encode_data((int)L, k, m, ktab_c, kin, kout);
					for (int i = 0; i < k; i++)
						kin[i] = shard[i] + h + off;
					for (int j = 0; j < m; j++)
						kout[j] = shard[k + j] + off;
					ec_encode_data((int)L, k, m, ktab_b, kin, kout);
					for (int i = 0; i < k; i++)
						kin[i] = shard[i] + off;
					for (int j = 0; j < m; j++)
						kout[j] = spool + (size_t)j * h + off;
					ec_encode_data((int)L, k, m, ktab_a, kin, kout);
					for (int j = 0; j < m; j++) {
						xor_into(shard[k + j] + off,
							 spool + (size_t)j * h + off, L);
						xor_into(shard[k + j] + h + off,
							 spool + (size_t)j * h + off, L);
					}
				}
		}
		double ms = (now_ms() - tp) / (double)N;
		/* Digest of the m parity shards: `all`, `plain` and `tiled` are three
		 * spellings of the same encode and must agree. The phase modes that
		 * compute only part of it will not, and are not meant to. */
		uint64_t hp = 0xcbf29ce484222325ULL;
		for (int i = 0; i < m; i++)
			hp = fnv1a(shard[k + i], sz, hp);
		printf("enc_probe f=%d k=%d m=%d h=%zu phase=%s iters=%d ms=%.6f "
		       "parity=%016llx\n",
		       f, k, m, h, enc_probe, N, ms, (unsigned long long)hp);
		return 0;
	}

	/* Stripe length over the half-shard planes, rounded up to 64. --stripes 1
	 * leaves `stripe == h`, which takes the single-call path and is byte for
	 * byte the released spelling. The plan, the Karatsuba coefficient matrices
	 * and ec_init_tables are all functions of the erasure pattern alone, so
	 * they stay outside the stripe loop: one plan serves every stripe, because
	 * a lost shard spans them all. */
	if (stripes < 1)
		stripes = 1;
	size_t stripe = stripes == 1
		? h
		: (((h + (size_t)stripes - 1) / (size_t)stripes + 63) & ~(size_t)63);
	if (stripe > h)
		stripe = h;

	printf("f,k,T,symbol_bytes,trial,codec,tape_field,tape_gen,plan_algo,"
	       "encode_ms,decode_ms,plan_ms,code_ms,symbols_consumed,consumed_per_k\n");

	/*
	 * The encode tables, built ONCE. Same correction as the GF(2^8) driver
	 * above, and here it is not a rounding error: these are `k * m * 32` bytes
	 * EACH and there are three of them, so f = 2047 rebuilt 805 MB every
	 * trial. Under `ISAL16_ENCODE=fft` nothing ever reads them -- the
	 * transform encoder uses `fft_tail_tab`, built once in `fft16_init` -- so
	 * 59% of a trial's instructions went into tables that were both unchanged
	 * and unused. Found with per-trial hardware counters, not with a timer:
	 * it sits outside both timers, so no encode or decode figure moves
	 * (measured at f = 1023 and f = 2047, no change), and wall-clock
	 * comparison could never have seen it.
	 *
	 * PERF-NOTES-LARGE-F.md A.4. `ISAL_ENC_TIMER=full` still rebuilds per
	 * trial inside the timer, which is what that null exists to reproduce.
	 */
	if (enc_timer_lean) {
		if (kara) {
			ec_init_tables(k, m, ka, ktab_a);
			ec_init_tables(k, m, kb, ktab_b);
			ec_init_tables(k, m, kc, ktab_c);
		} else {
			ec_init_tables(2 * k, 2 * m, gen8, enc_tab);
		}
	}
	char encbuf[32];
	for (int trial = -warmup; trial < trials; trial++) {
		uint64_t s = seed ^ ((uint64_t)f << 48) ^ ((uint64_t)k << 32) ^ (uint64_t)t
			^ (((uint64_t)sz << 17) | ((uint64_t)sz >> 47))
			^ (trial < 0
			   ? (uint64_t)(trial + warmup) * 0x9e3779b97f4a7c15ULL
			   : (uint64_t)(trial + warmup) * 0xd1b54a32d192ed03ULL);

		/* --phase decode: fill and encode ONCE, at the first warmup trial;
		 * every later trial re-decodes that codeword under a fresh erasure
		 * pattern. Nothing carries between trials: the codeword is snapshotted
		 * into `code` at setup and the copy-in below restores this trial's
		 * arrivals out of it, before the timer. Verification is a plain check,
		 * NOT what returns the pool to its encoded state -- which is what this
		 * comment used to say, left over from the restore design that really
		 * did refuse `--no-verify`. Same contract as the GF(2^8) main, whose
		 * comment carries the full history. */
		int do_encode = !phase_decode || trial == -warmup;
		if (do_encode) {
			sm64 rs = { s ^ 0x535243ULL };
			sm64_fill(&rs, src, (size_t)k * sz);
		}
		for (int i = 0; i < t; i++)
			order[i] = i;
		sm64 ro = { s ^ 0x4f52444552ULL };
		sm64_shuffle(&ro, order, t);
		/* `random` reaches the selection below byte-identically to before this
		 * mode existed; only `parity` rewrites the order here. */
		if (arrivals_parity &&
		    arrivals_parity_first(order, order_scratch, k, t) < 0)
			return 2;

		/* Under --phase decode this is the ONE setup encode, reported in every
		 * row. Not the encode number of record; the interleaved run is. */
		/* Zero and unused under --phase decode: the setup encode is not a
		 * measurement and no value is carried between trials. enc_field()
		 * emits the column EMPTY there. */
		double encode_ms = 0.0;
		if (do_encode) {
			/* ---- encode ----
			 * DEFAULT lean: ec_encode_data alone, which is what the Rust harness's
			 * encode timer holds. ISAL_ENC_TIMER=full restores the pre-rev-12
			 * region, which also timed the k*sz scatter into the pool and a full
			 * ec_init_tables(2k, 2m) -- 4.2 MB of table writes at f = 255, every
			 * trial, though the generator never changes between trials. This is
			 * section 3.2 of the report, applied here a revision late: the GF(2^8)
			 * driver got it in rev 10 and this one did not. */
			for (int j = 0; j < k; j++) {
				enc_in[2 * j] = shard[j];
				enc_in[2 * j + 1] = shard[j] + h;
			}
			for (int i = 0; i < m; i++) {
				enc_out[2 * i] = shard[k + i];
				enc_out[2 * i + 1] = shard[k + i] + h;
			}
			if (enc_timer_lean) {
				for (int i = 0; i < k; i++)
					memcpy(shard[i], src + (size_t)i * sz, sz);
			}
			long enc_reps = getenv("ISAL_ENC_REPEAT") ? atol(getenv("ISAL_ENC_REPEAT")) : 1;
			double t0 = now_ms();
			/* Encode scratch, inside the timer, per call. The coefficient TABLES
			 * stay hoisted above -- they are a function of the generator alone, the
			 * same class as RaptorQ's SourceBlockEncodingPlan, and §3.2 is why they
			 * are not rebuilt per trial. These two are working buffers, not tables.
			 *
			 * `aligned_alloc(4096)` and not `malloc`: §3.4 found that leaving the
			 * pool's alignment to glibc was worth 1.29x on encode, drawn fresh per
			 * process. Allocating cold is the point; drawing a new alignment
			 * lottery is not, and page alignment costs nothing to ask for. */
			unsigned char *pc_ew = NULL, *pc_es = NULL, *pc_par = NULL, *pc_fft = NULL;
			/* Parity output, inside the timer, per call. reed-solomon-simd, R10 and
			 * RaptorQ all allocate their coded outputs inside their own encode
			 * timers; writing parity into a pool allocated once for the process
			 * measured a different contract. F2 in HARNESS-FAIRNESS-MATRIX.md.
			 * Same stride as the pool, so §3.1's layout is unchanged, and no memset:
			 * every byte is written before it is read. The copy back into the pool
			 * that the decode reads is outside the timer. */
			if (alloc_per_call) {
				pc_par = aligned_alloc(4096,
					(((size_t)m * stride) + 4095) & ~(size_t)4095);
				if (!pc_par) {
					fprintf(stderr, "per-call parity allocation failed\n");
					return 1;
				}
				for (int i = 0; i < m; i++)
					par[i] = pc_par + (size_t)i * stride;
			} else {
				for (int i = 0; i < m; i++)
					par[i] = shard[k + i];
			}
			if (alloc_per_call) {
				pc_ew = aligned_alloc(4096,
					((size_t)k * stripe + 4095) & ~(size_t)4095);
				pc_es = aligned_alloc(4096,
					((size_t)m * stripe + 4095) & ~(size_t)4095);
				if (!pc_ew || !pc_es) {
					fprintf(stderr, "per-call encode allocation failed\n");
					return 1;
				}
				wpool = pc_ew;
				spool = pc_es;
				if (use_fft && fftw_bytes) {
					pc_fft = aligned_alloc(4096,
						(fftw_bytes + 4095) & ~(size_t)4095);
					if (!pc_fft) {
						fprintf(stderr, "per-call fft work buffer "
							"allocation failed\n");
						return 1;
					}
					fftpool = pc_fft;
				}
			}
			if (!enc_timer_lean) {
				for (int i = 0; i < k; i++)
					memcpy(shard[i], src + (size_t)i * sz, sz);
				if (kara) {
					ec_init_tables(k, m, ka, ktab_a);
					ec_init_tables(k, m, kb, ktab_b);
					ec_init_tables(k, m, kc, ktab_c);
				} else {
					ec_init_tables(2 * k, 2 * m, gen8, enc_tab);
				}
			}
			if (use_fft) {
				for (long rep = 0; rep < enc_reps; rep++)
					fft16_encode(k, m, sz, stride, shard, par, fftpool,
						     enc_in);
			} else
			for (long rep = 0; rep < enc_reps; rep++)
			for (size_t off = 0; off < h; off += stripe) {
				size_t L = h - off < stripe ? h - off : stripe;
				if (!kara) {
					for (int j = 0; j < k; j++) {
						enc_in[2 * j] = shard[j] + off;
						enc_in[2 * j + 1] = shard[j] + h + off;
					}
					for (int i = 0; i < m; i++) {
						enc_out[2 * i] = par[i] + off;
						enc_out[2 * i + 1] = par[i] + h + off;
					}
					ec_encode_data((int)L, 2 * k, 2 * m, enc_tab, enc_in, enc_out);
					continue;
				}
				if (stripe_gather) {
					/* gather */
					for (int i = 0; i < k; i++) {
						memcpy(gin0 + (size_t)i * stripe, shard[i] + off, L);
						memcpy(gin1 + (size_t)i * stripe, shard[i] + h + off, L);
						kin[i] = wpool + (size_t)i * stripe;
						xor3_into(kin[i], gin0 + (size_t)i * stripe,
							  gin1 + (size_t)i * stripe, L);
					}
					/* transform, dense in and dense out */
					for (int j = 0; j < m; j++)
						kout[j] = ghi + (size_t)j * stripe;
					ec_encode_data((int)L, k, m, ktab_c, kin, kout);
					for (int i = 0; i < k; i++)
						kin[i] = gin1 + (size_t)i * stripe;
					for (int j = 0; j < m; j++)
						kout[j] = glo + (size_t)j * stripe;
					ec_encode_data((int)L, k, m, ktab_b, kin, kout);
					for (int i = 0; i < k; i++)
						kin[i] = gin0 + (size_t)i * stripe;
					for (int j = 0; j < m; j++)
						kout[j] = spool + (size_t)j * stripe;
					ec_encode_data((int)L, k, m, ktab_a, kin, kout);
					/* fold, then scatter */
					for (int j = 0; j < m; j++) {
						xor_into(glo + (size_t)j * stripe,
							 spool + (size_t)j * stripe, L);
						xor_into(ghi + (size_t)j * stripe,
							 spool + (size_t)j * stripe, L);
						memcpy(par[j] + off, glo + (size_t)j * stripe, L);
						memcpy(par[j] + h + off, ghi + (size_t)j * stripe, L);
					}
					continue;
				}
				/* w_i = v0_i + v1_i, once per source shard.
				 *
				 * Indexed by `stripe`, not by `h`: the w and P0 planes hold only
				 * the stripe in hand, so they are a dense k*stripe and m*stripe
				 * region rather than k scattered pieces inside a full-length
				 * buffer. That is the point of striping -- shrinking the working
				 * set, not just the range walked. `stripe == h` when unstriped, so
				 * this is the released layout at --stripes 1. */
				for (int i = 0; i < k; i++) {
					kin[i] = wpool + (size_t)i * stripe;
					xor3_into(kin[i], shard[i] + off, shard[i] + h + off, L);
				}
				/* high half of each parity pair := P2 = (g0+g1) w */
				for (int j = 0; j < m; j++)
					kout[j] = par[j] + h + off;
				ec_encode_data((int)L, k, m, ktab_c, kin, kout);
				/* low half := BETA g1 v1 */
				for (int i = 0; i < k; i++)
					kin[i] = shard[i] + h + off;
				for (int j = 0; j < m; j++)
					kout[j] = par[j] + off;
				ec_encode_data((int)L, k, m, ktab_b, kin, kout);
				/* P0 = g0 v0 into the accumulator, then fold into both halves */
				for (int i = 0; i < k; i++)
					kin[i] = shard[i] + off;
				for (int j = 0; j < m; j++)
					kout[j] = spool + (size_t)j * stripe;
				ec_encode_data((int)L, k, m, ktab_a, kin, kout);
				for (int j = 0; j < m; j++) {
					xor_into(par[j] + off, spool + (size_t)j * stripe, L);
					xor_into(par[j] + h + off, spool + (size_t)j * stripe, L);
				}
			}
			encode_ms = (now_ms() - t0) / (double)enc_reps;
			if (alloc_per_call) {
				/* Outside the timer: hand the parity to the pool the decode reads. */
				for (int i = 0; i < m; i++)
					memcpy(shard[k + i], par[i], sz);
				free(pc_par);
				for (int i = 0; i < m; i++)
					par[i] = shard[k + i];
				/* Outside the timer, as every other codec's free is. */
				free(pc_ew);
				free(pc_es);
				free(pc_fft);
				wpool = NULL;
				spool = NULL;
				fftpool = NULL;
			}
		if (phase_decode) {
			/* The codeword, snapshotted once. Immutable from here on. */
			if (!code) {
				code = malloc((size_t)t * sz);
				if (!code) {
					fprintf(stderr, "codeword allocation failed\n");
					return 1;
				}
			}
			for (int i = 0; i < t; i++)
				memcpy(code + (size_t)i * sz, shard[i], sz);
		}
		}

		/* --digest: FNV-1a 64 over the T coded shards, source and parity halves
		 * separately. The composite GF(2^16) is not the representation
		 * reed-solomon-simd uses, so this is not a cross-library oracle the way
		 * isal_point.c's is; it is an oracle for THIS encoder against itself --
		 * ISAL16_KARATSUBA=0 and =1 must agree byte for byte. */
		if (digest_only) {
			uint64_t hs = 0xcbf29ce484222325ULL, hp = 0xcbf29ce484222325ULL;
			for (int i = 0; i < k; i++)
				hs = fnv1a(shard[i], sz, hs);
			for (int i = k; i < t; i++)
				hp = fnv1a(shard[i], sz, hp);
			printf("digest f=%d k=%d T=%d shard_bytes=%zu seed=%llu kara=%d "
			       "src=%016llx parity=%016llx\n", f, k, t, sz,
			       (unsigned long long)seed, kara,
			       (unsigned long long)hs, (unsigned long long)hp);
			return 0;
		}

		/* --phase encode: THE DECODER DOES NOT RUN IN A MEASURED TRIAL. It runs
		 * once, at the first warmup trial, purely as the correctness gate; every
		 * measured trial is encode alone, with no decoder working set in cache
		 * when the encode timer starts. Report section 6.8 measured that mirror
		 * effect -- the decoder's buffers moving the ENCODE timer -- and this is
		 * what removes it, symmetrically with what --phase decode does for the
		 * encoder.
		 *
		 * decode_ms, plan_ms, code_ms, symbols_consumed and consumed_per_k are
		 * emitted EMPTY. Absent, not zero: a consumer that reaches for them gets
		 * nothing rather than a wrong number, which is the same rule the encode
		 * column follows under --phase decode. */
		if (phase_encode && trial != -warmup) {
			if (trial >= 0)
				printf("%d,%d,%d,%zu,%d,isal16,gf16,cauchy,%s,%s,,,,,\n",
				       f, k, t, sz, trial,
				       use_ge ? "full-ge" : (naive_fold ? "closed-form-naivefold" : "closed-form"),
				       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms));
			continue;
		}
		/* ---- decode: exactly the first k arrivals ---- */
		memset(got, 0, (size_t)t);
		for (int i = 0; i < k; i++)
			got[order[i]] = 1;

		/* Zero the slots the receiver never got, so a decode that writes
		 * nothing cannot pass verification on data the encode left there.
		 * Outside both timers, as the equivalent loop in run_tape16 is. */
		/* --phase decode: COPY THE SHARDS THIS TRIAL DECODES FROM into the
		 * pool, out of the codeword built once at setup. The codeword itself is
		 * never written, so there is nothing to restore and no ordering between
		 * trials.
		 *
		 * WHY A COPY AND NOT THE NARROWER RESTORE IT REPLACES: what matters is
		 * not that the out-of-timer work be SMALL, it is that it be THE SAME IN
		 * BOTH MODES. The interleaved loop already does a k*sz copy-in above,
		 * before its timer starts. Matching it here makes `decode` equal `both`
		 * minus exactly the encoder, so the delta measures the encoder and
		 * nothing else. The restore did not match it, and that asymmetry is what
		 * made labels with no contamination read BELOW 1.0 -- leopard 0.947,
		 * tape_gf16 0.894 -- which was an artefact of the instrument, not a
		 * property of the codec. Outside both timers. */
		if (phase_decode)
			for (int j = 0; j < t; j++)
				if (got[j])
					memcpy(shard[j], code + (size_t)j * sz, sz);
		/* FIXME -- MEASUREMENT HYGIENE, KNOWN AND DELIBERATELY UNFIXED.
		 *
		 * This loop runs r times, where r is the number of originals the
		 * receiver did not get -- and r is EXACTLY THE QUANTITY --arrivals
		 * varies. Under `random` it is about 2k/3; under `parity` it is k. So
		 * the out-of-timer work is not matched across the two modes, and a
		 * random-vs-parity ratio carries a term that is not the decoder.
		 *
		 * It is outside both timers, which is not the same as being outside the
		 * measurement: it dirties cache and touches r shard-sized buffers just
		 * before the timed region.
		 *
		 * ITS SIZE IS UNMEASURED, and a previous version of this comment said
		 * ~6% on the strength of RS--8 reading 1.60x where r*k arithmetic
		 * predicted 1.51x. THAT ATTRIBUTION WAS WRONG TWICE OVER.
		 *
		 * First, decode = plan + code exactly and the two stages do not move
		 * together: plan runs at ~1.6x-1.7x and code at ~1.44x, because
		 * cauchy_inverse's O(r^2) block and fold_closed_form8's O(r*d) block do
		 * not cancel -- the inverse costs more per entry. So the aggregate is
		 * their weighted mean and there was no residual to explain.
		 *
		 * Second, the 1.60x itself was an artefact: it was measured at a FIXED
		 * 1 KiB shard, which is not a grid size. plan is scalar and identical at
		 * every shard size; code scales with shard bytes. So the plan share was
		 * 54-58% at 1 KiB against 0.9-19.1% on the grid, and the aggregate is
		 * 1.45 there, not 1.60. RS-8 and RS-16 land in the same place.
		 *
		 * THIS LOOP'S EFFECT REMAINS UNMEASURED. It is real -- the loop runs r
		 * times -- and nothing has ever isolated it.
		 *
		 * WHY IT IS NOT FIXED. The repair is easy -- zero all k original slots
		 * unconditionally, before the copy-in, so the work is constant in r --
		 * and that is exactly what makes it expensive: it changes the `random`
		 * path, so every decode figure in the report and the appendix would
		 * have to be re-taken to stay comparable. The confound is smaller than
		 * the effect it sits inside (1.5x), it is one-directional, and it is
		 * disclosed wherever the ratio is quoted.
		 *
		 * IF YOU DO FIX IT: re-take the full decode leg, do not mix vintages,
		 * and expect the parity ratios to fall by a few percent toward the
		 * predicted 1.5x. Nothing about the transform decoder should move --
		 * it is arrival-oblivious, so it is the null for this. Written up in
		 * HARNESS.md (this tree's docs/, where the artifact ships it) and in
		 * PERF-NOTES-ARRIVALS-ALL-PARITY.md. */
		for (int j = 0; j < k; j++)
			if (!got[j])
				memset(shard[j], 0, sz);

		/*
		 * The transform decoder needs no plan: the erasure locator is computed
		 * inside it from the presence pattern, and there is no matrix to invert
		 * or fold. `plan` is therefore zero and the whole cost lands in `code`.
		 * That is the honest split rather than a missing measurement -- the two
		 * decoders divide their work differently, and forcing a plan/code
		 * boundary onto this one would invent a phase it does not have.
		 */
		if (use_fft_decode) {
			/*
			 * Decode working memory and the materialization target, INSIDE
			 * the timer, per call -- section 4.8's contract.
			 *
			 * The matrix decode below has honoured it since revision 12 and
			 * both encoders honour it, but this path was added in 5.22 reading
			 * the process-lifetime `fftdpool` and writing the process-lifetime
			 * `whole`, so the transform decoder alone was measured under the
			 * held-buffer contract while `reed-solomon-simd` -- which
			 * allocates both its work buffer (`ReedSolomonDecoder::new`) and
			 * its reconstructed message inside its own decode timer -- was
			 * measured under the per-call one. Worth 0.03-0.05 ms at
			 * f = 1023 / 1 MiB, i.e. in ISA-L's favour, so no published
			 * transform-decode figure was ever conservative.
			 *
			 * ISAL_ALLOC_PER_CALL=0 restores the held buffers here as it does
			 * everywhere else. The frees are outside the timer, as every other
			 * codec's are.
			 */
			unsigned char *fd_pool = fftdpool, *fd_whole = whole;
			unsigned char *pc_fftd = NULL, *pc_fwhole = NULL;
			double td = now_ms();
			if (alloc_per_call) {
				pc_fftd = aligned_alloc(4096,
					(fftd_bytes + 4095) & ~(size_t)4095);
				pc_fwhole = aligned_alloc(4096,
					(((size_t)k * sz) + 4095) & ~(size_t)4095);
				if (!pc_fftd || !pc_fwhole) {
					fprintf(stderr, "per-call fft decode "
						"allocation failed\n");
					return 1;
				}
				fd_pool = pc_fftd;
				fd_whole = pc_fwhole;
			}
			fft16_decode(k, m, t, sz, stride, shard, got, fd_pool);
			size_t woff = 0;
			for (int i = 0; i < k; i++) {
				memcpy(fd_whole + woff, shard[i], sz);
				woff += sz;
			}
			double fd = now_ms() - td;
			free(pc_fftd);
			if (verify && memcmp(fd_whole, src, (size_t)k * sz)) {
				fprintf(stderr, "gf16 fft-decode mismatch f=%d\n", f);
				return 1;
			}
			if (trial >= 0)
				printf("%d,%d,%d,%zu,%d,isal16,gf16,cauchy,fft,"
				       "%s,%.6f,%.6f,%.6f,%d,%.8f\n",
				       f, k, t, sz, trial, enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms), fd, 0.0, fd, k, 1.0);
			free(pc_fwhole);
			continue;
		}

		double t1 = now_ms();

		int n_par = 0, n_orig = 0, n_miss = 0;
		for (int col = 0; col < k; col++) {
			int idx = order[col];
			if (idx < k) {
				recv_orig[n_orig] = idx;
				orig_col[n_orig++] = col;
			} else {
				recv_par[n_par] = idx;
				par_col[n_par++] = col;
			}
		}
		for (int j = 0; j < k; j++)
			if (!got[j])
				missing[n_miss++] = j;
		int r = n_miss;

		if (!use_ge) {
			for (int a = 0; a < r; a++)
				xs[a] = g16_node[recv_par[a]];
			for (int b = 0; b < r; b++)
				ys[b] = g16_node[missing[b]];
			if (r)
				cauchy16_inverse(xs, ys, r, binv, nx, ny);
			memset(rows16, 0, (size_t)r * k * sizeof(uint16_t));
			for (int b = 0; b < r; b++)
				for (int a = 0; a < r; a++)
					rows16[(size_t)b * k + par_col[a]] = binv[b * r + a];
			if (naive_fold) {
				for (int a = 0; a < r; a++)
					for (int c = 0; c < n_orig; c++)
						ecau[(size_t)a * n_orig + c] =
							cauchy16_entry(k, recv_par[a] - k,
								       recv_orig[c]);
				for (int b = 0; b < r; b++)
					for (int c = 0; c < n_orig; c++) {
						uint16_t acc = 0;
						for (int a = 0; a < r; a++)
							acc ^= g16mul(binv[b * r + a],
								      ecau[(size_t)a * n_orig + c]);
						rows16[(size_t)b * k + orig_col[c]] = acc;
					}
			} else {
				fold_closed_form16(xs, ys, ny, r, recv_orig, orig_col, n_orig,
						 pu, k, rows16);
			}
		} else {
			/* Full k x k survivor submatrix, inverted by GE. O(k^3). */
			for (int col = 0; col < k; col++) {
				int idx = order[col];
				if (idx < k) {
					for (int j = 0; j < k; j++)
						sub16[(size_t)col * k + j] = (j == idx);
				} else {
					for (int j = 0; j < k; j++)
						sub16[(size_t)col * k + j] =
							cauchy16_entry(k, idx - k, j);
				}
			}
			if (g16_invert(sub16, inv16, k) < 0) {
				fprintf(stderr, "singular survivor submatrix f=%d trial=%d "
					"(Cauchy is MDS; this should be impossible)\n", f, trial);
				return 1;
			}
			for (int b = 0; b < r; b++)
				memcpy(rows16 + (size_t)b * k,
				       inv16 + (size_t)missing[b] * k,
				       (size_t)k * sizeof(uint16_t));
		}

		/* Composite expansion is plan work, not kernel work. Under Karatsuba
		 * the same statement holds for the three r x k coefficient matrices,
		 * which cost 3rk byte-ops against expand16's 4rk. */
		if (kara)
			karatsuba_coeffs(rows16, r, k, da, db, dc);
		else
			expand16(rows16, r, k, rows8);

		/* --plan-probe: decompose the plan term.
		 *
		 * By this point one full plan pass has run, so every buffer is touched
		 * and every phase's inputs are valid -- fold_closed_form needs `ny` from
		 * cauchy16_inverse, karatsuba_coeffs needs `rows16` from the fold. That
		 * matters: PERF-NOTES-DECODE.md records sub-timer splits mis-attributing
		 * because whichever side of a boundary first touches memory is charged
		 * for it, and re-running after a warm pass is what removes that.
		 *
		 * One phase per process, named as an argument -- section 3.6's rule. The
		 * phases are re-run rather than timed in place because each is a pure
		 * function of the erasure pattern, so N repeats cost N times one call.
		 */
		if (plan_probe) {
			if (use_ge) {
				fprintf(stderr, "--plan-probe needs the closed-form plan\n");
				return 2;
			}
			int N = probe_iters > 0 ? probe_iters : 1;
			int mode = !strcmp(plan_probe, "all")       ? 0
				 : !strcmp(plan_probe, "inverse")   ? 1
				 : !strcmp(plan_probe, "scatter")   ? 2
				 : !strcmp(plan_probe, "fold")      ? 3
				 : !strcmp(plan_probe, "karatsuba") ? 4
				 : !strcmp(plan_probe, "expand")    ? 5 : -1;
			if (mode < 0) {
				fprintf(stderr, "--plan-probe: all|inverse|scatter|fold|"
					"karatsuba|expand\n");
				return 2;
			}
			double tp = now_ms();
			for (int it = 0; it < N; it++) {
				if (mode == 0 || mode == 1)
					cauchy16_inverse(xs, ys, r, binv, nx, ny);
				if (mode == 0 || mode == 2) {
					memset(rows16, 0, (size_t)r * k * sizeof(uint16_t));
					for (int b = 0; b < r; b++)
						for (int a = 0; a < r; a++)
							rows16[(size_t)b * k + par_col[a]] =
								binv[b * r + a];
				}
				if (mode == 0 || mode == 3)
					fold_closed_form16(xs, ys, ny, r, recv_orig, orig_col,
							 n_orig, pu, k, rows16);
				if (mode == 0 || mode == 4)
					karatsuba_coeffs(rows16, r, k, da, db, dc);
				if (mode == 5)
					expand16(rows16, r, k, rows8);
			}
			double ms = (now_ms() - tp) / (double)N;
			printf("plan_probe f=%d k=%d r=%d n_orig=%d phase=%s iters=%d "
			       "ms=%.6f\n", f, k, r, n_orig, plan_probe, N, ms);
			return 0;
		}

		double plan_ms = now_ms() - t1;

		double t2 = now_ms();
		/* Decode working memory, inside the timer. See `alloc_per_call`. The
		 * `whole` materialization target goes with them: R10's decode allocates
		 * its reconstructed message inside its timer too. */
		unsigned char *pc_dec_tab = NULL, *pc_da = NULL, *pc_db = NULL, *pc_dc = NULL;
		unsigned char *pc_df = NULL;
		unsigned char *pc_dspool = NULL, *pc_wpool = NULL, *pc_whole = NULL;
		/* `wpool` is the ENCODE w plane and is held for the process. Decode
		 * must not retarget it: it would be freed at the end of this trial and
		 * the next trial's encode would write through a dangling pointer. It
		 * segfaulted on the first run, which is what `decw` is for. */
		unsigned char *decw = alloc_per_call ? NULL : wpool;
		if (alloc_per_call) {
			/* Only what the selected path uses. The plain 2k x 2r expansion
			 * and the Karatsuba form need different tables, and an
			 * implementation would not ask for the one it never touches --
			 * 8.4 MB at f = 255 for `dec_tab`, which Karatsuba never reads.
			 * Sized from r's worst case, k, because r is a property of the
			 * erasure pattern and a deployment sizes for the worst one. */
			if (!kara)
				pc_dec_tab = aligned_alloc(4096,
					(((size_t)(2 * k) * (2 * k) * tab_entry) + 4095) & ~(size_t)4095);
			else {
				/* Only for the path that uses it. Allocated
				 * unconditionally this sits inside the decode timer
				 * and charges every measurement for a table the
				 * default configuration never reads -- 1.6 MB at
				 * k = 256, and section 4.8 is what that costs. */
				pc_df = apply_fused ? aligned_alloc(4096,
					(apply_tab_bytes + 4095) & ~(size_t)4095) : NULL;
				pc_da = aligned_alloc(4096,
					(((size_t)k * k * tab_entry) + 4095) & ~(size_t)4095);
				pc_db = aligned_alloc(4096,
					(((size_t)k * k * tab_entry) + 4095) & ~(size_t)4095);
				pc_dc = aligned_alloc(4096,
					(((size_t)k * k * tab_entry) + 4095) & ~(size_t)4095);
				/* Sized by the stripe. This is what striping is supposed to
				 * buy under the per-call rule: at f = 255 / 4 MiB these are
				 * 2 MB each unstriped and 512 KB at --stripes 4. The
				 * coefficient tables do not shrink -- they are k*k*32
				 * regardless of shard size -- and neither does `whole`, which
				 * is the output message. */
				pc_dspool = aligned_alloc(4096,
					((size_t)k * stripe + 4095) & ~(size_t)4095);
				pc_wpool = aligned_alloc(4096,
					((size_t)k * stripe + 4095) & ~(size_t)4095);
			}
			pc_whole = aligned_alloc(4096,
				(((size_t)k * sz) + 4095) & ~(size_t)4095);
			if ((kara && (!pc_da || !pc_db || !pc_dc || !pc_dspool || !pc_wpool
				      || (apply_fused && !pc_df)))
			    || (!kara && !pc_dec_tab) || !pc_whole) {
				fprintf(stderr, "per-call decode allocation failed\n");
				return 1;
			}
			if (kara) {
				dtab_a = pc_da; dtab_b = pc_db; dtab_c = pc_dc;
				if (pc_df)
					dtab_f = pc_df;
				dspool = pc_dspool; decw = pc_wpool;
			} else {
				dec_tab = pc_dec_tab;
			}
			whole = pc_whole;
		}
		/*
		 * THE SURVIVORS, AS THE GF(2^8) KERNELS MUST SEE THEM.
		 *
		 * ISA-L's kernels take a contiguous byte vector and have no stride
		 * parameter, so they cannot read an interleaved shard, whose low plane
		 * is 32-byte runs 64 bytes apart. Under `ISAL16_ENC_LAYOUT=inter` the k
		 * survivors are therefore de-interleaved once, up front; every kernel
		 * below then addresses `srcv[col]` and `srcv[col] + h` exactly as it
		 * addressed the pool before. Under the plane pool `srcv` IS the pool
		 * and nothing is copied, so the control path is untouched.
		 *
		 * The scratch is `whole` -- k*sz, already allocated inside this timer,
		 * and not written until the materialize pass at the end, by which point
		 * every read of `srcv` is finished. So the conversion costs one pass
		 * and no second allocation.
		 *
		 * INSIDE THE TIMER, deliberately. It is work this representation
		 * requires of this decoder, and section 3 charges required work to the
		 * operation that needs it.
		 *
		 * The OUTPUT side costs nothing, and that is not an accounting trick.
		 * Reconstruction lands in the pool slot in plane form, and the
		 * materialize pass permutes it into `whole` instead of copying it --
		 * the same single pass either way. That is section 5.26's "it rides on
		 * a copy that had to happen", applied to the reveal rather than the
		 * ingest.
		 */
		for (int col = 0; col < k; col++)
			srcv[col] = shard[order[col]];
		if (fft_pool_inter)
			for (int col = 0; col < k; col++) {
				srcv[col] = whole + (size_t)col * sz;
				inter_to_plane(srcv[col], shard[order[col]], sz);
			}
		else if (dec_pack)
			for (int col = 0; col < k; col++) {
				srcv[col] = whole + (size_t)col * sz;
				memcpy(srcv[col], shard[order[col]], sz);
			}
		for (int col = 0; col < k; col++) {
			dec_in[2 * col] = srcv[col];
			dec_in[2 * col + 1] = srcv[col] + h;
		}
		for (int b = 0; b < r; b++) {
			/* Reconstruct in place into the pool slot of each missing shard,
			 * as run_tape16 does; the missing slots are never inputs. */
			dec_out[2 * b] = shard[missing[b]];
			dec_out[2 * b + 1] = shard[missing[b]] + h;
		}
		if (r && !kara) {
			ec_init_tables(2 * k, 2 * r, rows8, dec_tab);
			for (size_t off = 0; off < h; off += stripe) {
				size_t L = h - off < stripe ? h - off : stripe;
				for (int col = 0; col < k; col++) {
					dec_in[2 * col] = srcv[col] + off;
					dec_in[2 * col + 1] = srcv[col] + h + off;
				}
				for (int b = 0; b < r; b++) {
					dec_out[2 * b] = shard[missing[b]] + off;
					dec_out[2 * b + 1] = shard[missing[b]] + h + off;
				}
				ec_encode_data((int)L, 2 * k, 2 * r, dec_tab, dec_in, dec_out);
			}
		} else if (r && apply_fused && h % 64 == 0) {
			/*
			 * The same Karatsuba identity, in one pass instead of three.
			 *
			 * ISA-L can only be asked for one product at a time, so the
			 * driver reads the k source planes three times and folds. Here
			 * lo and hi are read once, w = lo ^ hi is formed in a register,
			 * and all three products are accumulated before the next input.
			 * The multipliers are EVEX broadcast memory operands, so they
			 * cost no registers and the tile is bounded only by the
			 * accumulators. See codec/fft_kernels.S.
			 *
			 * Table build is inside the timer, exactly where the
			 * ec_init_tables calls it replaces are.
			 */
			uint64_t *ft = (uint64_t *)dtab_f;
			for (int b0 = 0; b0 < r; b0 += 8) {
				int nt = r - b0 < 8 ? r - b0 : 8;
				uint64_t *tile = ft + (size_t)(b0 / 8) * k * 8 * 3;
				for (int i = 0; i < k; i++)
					for (int j = 0; j < 8; j++) {
						uint64_t *e = tile + ((size_t)i * 8 + j) * 3;
						/* Rows past the tail contribute nothing: a
						 * zero coefficient is the zero matrix, whose
						 * product is zero, so the tile stays full
						 * width and needs no ragged case. */
						uint16_t v = j < nt
							? rows16[(size_t)(b0 + j) * k + i] : 0;
						unsigned char g0 = lo8(v), g1 = hi8(v);
						e[0] = fft_affine[g0];
						e[1] = fft_affine[gmul(BETA, g1)];
						e[2] = fft_affine[(unsigned char)(g0 ^ g1)];
					}
			}
			for (int col = 0; col < k; col++)
				kin[col] = srcv[col];
			unsigned char *outp[8];
			for (int b0 = 0; b0 < r; b0 += 8) {
				int nt = r - b0 < 8 ? r - b0 : 8;
				for (int j = 0; j < 8; j++)
					outp[j] = j < nt ? shard[missing[b0 + j]]
							 : apply_sink;
				gf16_apply_8((const unsigned char *const *)kin, outp,
					     (size_t)k, h,
					     ft + (size_t)(b0 / 8) * k * 8 * 3);
			}
		} else if (r) {
			/* Same identity as the encode: w = v0 + v1 over the k received
			 * shards, then P2 into the high halves, BETA g1 v1 into the low
			 * halves, and P0 once into a temp folded into both. */
			/* These three table builds are hoisted above the stripe loop with
			 * the plan: all of them are functions of the erasure pattern, which
			 * is the same for every stripe because a lost shard spans them all.
			 * That is what makes striping inside the codec free where striping
			 * at the application level is not. */
			ec_init_tables(k, r, da, dtab_a);
			ec_init_tables(k, r, db, dtab_b);
			ec_init_tables(k, r, dc, dtab_c);
			for (size_t off = 0; off < h; off += stripe) {
				size_t L = h - off < stripe ? h - off : stripe;
				for (int col = 0; col < k; col++) {
					kin[col] = decw + (size_t)col * stripe;
					xor3_into(kin[col], srcv[col] + off,
						  srcv[col] + h + off, L);
				}
				for (int b = 0; b < r; b++)
					kout[b] = shard[missing[b]] + h + off;
				ec_encode_data((int)L, k, r, dtab_c, kin, kout);
				for (int col = 0; col < k; col++)
					kin[col] = srcv[col] + h + off;
				for (int b = 0; b < r; b++)
					kout[b] = shard[missing[b]] + off;
				ec_encode_data((int)L, k, r, dtab_b, kin, kout);
				for (int col = 0; col < k; col++)
					kin[col] = srcv[col] + off;
				for (int b = 0; b < r; b++)
					kout[b] = dspool + (size_t)b * stripe;
				ec_encode_data((int)L, k, r, dtab_a, kin, kout);
				for (int b = 0; b < r; b++) {
					xor_into(shard[missing[b]] + off,
						 dspool + (size_t)b * stripe, L);
					xor_into(shard[missing[b]] + h + off,
						 dspool + (size_t)b * stripe, L);
				}
			}
		}
		double t_mat = now_ms();
		{
			size_t off = 0;
			for (int i = 0; i < k; i++) {
				/* A survivor already holds the message bytes, in either
				 * layout. Only a RECONSTRUCTED shard is in plane form,
				 * and permuting it out costs the one pass the memcpy
				 * cost -- the conversion is free on this side. */
				if (fft_pool_inter && !got[i])
					plane_to_inter(whole + off, shard[i], sz);
				else
					memcpy(whole + off, shard[i], sz);
				off += sz;
			}
		}
		double code_ms = now_ms() - t2;
		if (dec_breakdown && trial >= 0)
			fprintf(stderr,
				"decode_breakdown impl=isal_cauchy16 f=%d shard_bytes=%zu | "
				"index=0 alloc=0 ingest=0 plan=%.6f kernel=%.6f "
				"materialize=%.6f\n",
				f, sz, plan_ms, t_mat - t2, now_ms() - t_mat);

		/* THE CORRECTNESS GATE MUST ACTUALLY GATE. Under --phase encode the
		 * decoder runs at this ONE warmup trial and nowhere else, purely so a
		 * configuration that computes wrong parity is caught. The comparison
		 * below is that gate's entire purpose, and it used to be skipped under
		 * --no-verify -- which paid the gate decode's full cost and then threw
		 * away the only reason it was run. Forcing the check for this trial is
		 * the cheap direction of the two: it runs once, outside every timer,
		 * and under --phase encode no MEASURED trial reaches this code at all
		 * (they take the `continue` above). Fixed 31 Aug 2026;
		 * HARNESS-DEFECT-verify-guard.md section 2. */
		int gate_trial = phase_encode && trial == -warmup;

		if (verify || gate_trial) {
			/* `whole` is the deliverable and is already correct in both
			 * layouts. Under the interleaved pool the SLOT of a reconstructed
			 * shard still holds the plane form, so restore it here -- outside
			 * the timer, because it is oracle bookkeeping and not codec work:
			 * the pool's source shards are re-established from `src` at the
			 * top of every trial, also outside the timer, so nothing in the
			 * measured path ever reads a slot this fixes. */
			if (fft_pool_inter)
				for (int b = 0; b < r; b++)
					memcpy(shard[missing[b]],
					       whole + (size_t)missing[b] * sz, sz);
			if (memcmp(whole, src, (size_t)k * sz)) {
				fprintf(stderr, "gf16 materialized source mismatch f=%d\n", f);
				return 1;
			}
			for (int b = 0; b < r; b++)
				if (memcmp(shard[missing[b]],
					   src + (size_t)missing[b] * sz, sz)) {
					fprintf(stderr, "gf16 reconstruction mismatch f=%d "
						"shard=%d plan=%s\n", f, missing[b],
						use_ge ? "ge" : "cauchy");
					return 1;
				}
		}

		if (alloc_per_call) {
			/* Outside the timer, as every other codec's free is. */
			free(pc_dec_tab); free(pc_da); free(pc_db); free(pc_dc); free(pc_df);
			free(pc_dspool); free(pc_wpool); free(pc_whole);
		}

		if (trial >= 0)
			printf("%d,%d,%d,%zu,%d,isal16,gf16,cauchy,%s,"
			       "%s,%.6f,%.6f,%.6f,%d,%.8f\n",
			       f, k, t, sz, trial,
			       use_ge ? "full-ge" : (naive_fold ? "closed-form-naivefold" : "closed-form"),
			       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms), plan_ms + code_ms, plan_ms, code_ms,
			       k, 1.0);
	}
	return 0;
}


/* ======================================================================== */
/*                              field selection                             */
/* ======================================================================== */

/*
 * `--field` is read here and passed through untouched, so each body still sees
 * the argument vector it always saw. `auto` picks GF(2^8) wherever T <= 256
 * permits it, which is the choice a decode-weighted caller wants: below the
 * boundary GF(2^8) decodes 1.49x-2.07x faster than the GF(2^16) code at the
 * same shape. A caller that weights encode or the sum should ask for 16
 * explicitly even below T = 256 -- see PERF-NOTES-FFT-GF8.md, which measures
 * both and finds neither dominates.
 */
int main(int argc, char **argv)
{
	int field = 0;			/* 0 = auto */
	int f = -1;
	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--field") && i + 1 < argc) {
			const char *v = argv[i + 1];
			if (!strcmp(v, "8")) field = 8;
			else if (!strcmp(v, "16")) field = 16;
			else if (!strcmp(v, "auto")) field = 0;
			else {
				fprintf(stderr, "--field must be 8, 16 or auto\n");
				return 2;
			}
		} else if (!strcmp(argv[i], "--f") && i + 1 < argc) {
			f = atoi(argv[i + 1]);
		}
	}
	if (!field)
		field = (f >= 0 && 3 * f + 1 <= 256) ? 8 : 16;
	if (field == 8 && f >= 0 && 3 * f + 1 > 256) {
		fprintf(stderr, "--field 8 needs T <= 256, but f=%d gives T=%d\n",
			f, 3 * f + 1);
		return 2;
	}
	return field == 8 ? run_gf8(argc, argv) : run_gf16(argc, argv);
}
