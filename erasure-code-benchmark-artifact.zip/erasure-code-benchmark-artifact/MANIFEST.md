# Provenance manifest

**This is a record, not a build recipe.** The extracted files are *modified*
here — `check.sh` loses a retired codec and gains a CPUID refusal, the Rust
driver is trimmed by a third — so nothing regenerates this directory. Each row
records where a file came from and what was done to it.

Source tree: the project's working tree, `four-code-message-grid-tape-v9/`,
unless stated.

## Settled decisions

| | |
|---|---|
| licence | **MIT**, except `monad-raptor/` (GPL-3.0-or-later, vendored, own LICENSE) |
| R10 | **vendored**, not fetched — it carries three of the four appendix tables, and a build-time fetch of a company repository would be a single point of failure for most of Appendix A |
| `reed-solomon-simd` | **two distinct relations, and they must not be confused.** (1) A **dependency**: stock 3.1.0 from crates.io, the `rs` label, unpatched — the locally optimized variant is not shipped and not referenced. (2) A **source**: the STRUCTURE of `codec/rs_point.c`'s GF(2¹⁶) encoder and transform decoder is PORTED from it onto a different field and shard layout. **The GFNI and AVX-512 kernels are NOT** -- upstream ships no assembly and no GFNI or AVX-512 path; `codec/fft_kernels.S` is this project's. The port is attributed in `LICENSE` (MIT AND BSD-3-Clause, three copyright holders) and described in `docs/ALGORITHMS.md` §4.1. **The GF(2⁸) side is independent of both, and GENERALISES Firedancer's**: firedancer uses the principal pivot transform at `kp = k`, this project leaves `kp` free over `[k, min(chunk, 256−m)]`. They compute the same code at `ISAL8_INTERP=ppt` only, which is the one setting `references/fd-point` is an oracle for; the shipped default `auto` is a different code firedancer cannot express |
| `tape-reed-solomon`, `leopard` | **not shipped** — the paper uses neither |
| naming | **RS–8 / RS–16** on the surface; CSV labels unchanged (`isal_x`, `isal_x_dec`, `isal_x16_imat`, `isal_x16_inter`) because `compare.py` diffs against the reference files |
| hardware | AVX-512 + GFNI **required**, a refusal rather than a degradation story |
| `rs_point.c` | **not split.** 28 functions and 9 file-scope statics cross any sensible boundary, it is one `-O3` translation unit with no LTO, and the split served a library goal this artifact disclaims. See `codec/README.md` |

## Extracted files

| destination | source | modification |
|---|---|---|
| `src/main.rs` | `src/main.rs` | trimmed from ~1 900 to ~1 250 lines: the retired tape codec and its plan/generator decomposition removed. Package renamed `erasure-baseline` |
| `src/bin/gen_probe.rs` | `src/bin/gen_probe.rs` | de-taped: the `[rs\|tape]` third argument and the `tape-reed-solomon` encoder path removed, leaving the `reed-solomon-simd` path its only caller uses. **This file was dropped at the original extraction and should not have been** — it was counted under "the development probes no script here invokes" below, but `proofs/fft_cauchy_check.py` does invoke it, and without it that check could not run at all. Restored 9 September. Same lesson as the `robust_benchmark.py` row: a dropped-file list that is not checked against what the shipped scripts actually call is a list of what someone remembered |
| `Cargo.toml`, `Cargo.lock` | ditto | four dependencies and two path patches → **three plain dependencies, no `[patch.crates-io]`**. `reed-solomon-simd` is `=3.1.0` from the registry; `rand` pinned to the version the measured lockfile resolved |
| `monad-raptor/` | upstream, via `bootstrap.sh` | **vendored verbatim**, with the full GPLv3 text and `VENDORED.md`. Modifications: none |
| `codec/` | `isal/` | `rs_point.c`, `rs_common.h`, `fft_kernels.S`, `KNOBS.md`, and a Makefile that builds `rs-point` only. Renamed from `isal/`, which was misleading: this is our code, ISA-L is a dependency |
| `references/` | `isal/` | `fd_point.c`, `bootstrap-fdgen.sh`, the `fdrs/` tree, and **its own Makefile**. `CFLAGS` are identical to `codec/`'s and must stay so, because the binaries are compared against each other |
| `isal-patches/` | `isal/` | the GFNI kernel patch over stock ISA-L v2.31.1. A missing directory is **fatal** in `bootstrap-isal.sh` |
| `check.sh` | `check.sh` | retired codec removed; **hardware refusal added**; the four unfixable measurement-hygiene conditions now warn; **a `PROOFS` section added 9 September 2026** that builds `gen_probe` and runs all four of `proofs/`. The working tree's `check.sh` has no such section and the proof scripts live at its root rather than in `proofs/`, so this is a declared divergence, not a copy. It exists because nothing ran the proofs: `fft_cauchy_check.py` shipped unable to run at all and every automated check passed anyway. `check-verified.log` was **regenerated 9 September 2026** so the shipped log matches the shipped script: same host as the 8 September run (identical CPU, kernel and `rustc`), same protocol (`setarch -R`, `BENCH_CPU=4`, governor fixed, boost off), on an already-built tree so no build path is recorded. It differs from the 8 September log only in the timestamp, an instantaneous MHz reading, `check_links.py` counting 96 files rather than 95, and the added `PROOFS` section. **Regenerated again 11 September 2026**, from a fresh extraction of the revised archive: `check.sh` run once to build from scratch (exit 0), then again on the built tree for this log, same host and protocol. It differs from the 9 September log only in the timestamp, `check_links.py` counting 98 files (the two added in `results/paper-data/`), and the PROOFS section's title |
| `robust_benchmark.py` | ditto | retired codec removed; the paper's label set made the default; RS–16's two decoders added as two labels. **`BENCH_PHASE` was ALSO dropped at the original extraction and this row did not say so** — for eight days the artifact could not run the phase-isolated legs the paper's grid tables are measured from, while `docs/MAPPING.md` said `./benchmark.sh` produced their evidence. Restored 6 September with `phase_campaign_leg.sh`. **The lesson is this row, not the knob:** a modification list that is not checked is a list of what someone remembered. `audit_artifact_drift.py`, in the development tree this was extracted from, now checks it — it is not part of this artifact because it needs both trees |
| `grid.py`, `benchmark.sh`, `quick.sh`, `largef_sweep.py`, `bootstrap.sh`, `bootstrap-isal.sh` | ditto | paths repointed from `isal/` to `codec/` and `references/` |
| `compare.py` | `leg_compare.py`, `aslr_compare.py` | rewritten. Matches by name from the header, never by column position; reports and skips what is present in only one file |
| `proofs/` | tree root and `isal/` | `pivot_check.py`, `ppt_theorem_check.py`, `fft_cauchy_check.py`, `standalone_cauchy_check.rs` — they share no code with the driver, which is the point of them. `fft_cauchy_check.py` is de-taped: its third claim, that `tape_red`'s FFT generator is generalized Cauchy over different nodes, is about a library this artifact does not carry, so that claim and the node-recovery helpers that served only it are removed. The two claims that remain are the ones Appendix B rests on. It needs `src/bin/gen_probe.rs`, above |
| `results/reference-*.csv` | **not extracted — measured in this artifact's own tree** | the comparison baseline `compare.py` diffs against: the three grid legs from a `./phase_campaign_leg.sh` run on 6 September 2026 (committed as copies of that run's `robust-summary-*` outputs), and the beyond-grid sweep from `./largef_sweep.py` on 31 August 2026. **They are not the data the paper was computed from** — that is the next row. Until 11 September the docs said the paper's figures were "read from" these files; they were not, and a second run of the same benchmark agrees with the paper in shape but not at the third decimal. **Not** the per-trial detail CSVs |
| `results/paper-data/` | the working tree's `results/` | **added 11 September 2026: the measurements the paper's tables were computed from**, byte-identical, with their SHA-256 in its `README.md` — the 31 August 2026 grid campaign (encode, decode and interleaved legs), the 31 August beyond-grid and Firedancer-native legs with their printed summaries, and the 7 September all-parity leg. Plus `reproduce_tables.py`, which recomputes every archived table and quoted ratio from them and checks the frozen expected outputs recorded in the script. Their RS–16 labels are the working tree's (`isal_cauchy16` = this artifact's `isal_x16_imat`); the README maps them. **Not** the per-trial detail CSVs, which are recorded there by digest |
| `docs/` | written for this artifact | see `docs/README.md` |
| `check_links.py` | written for this artifact | every path reference must resolve and must stay inside the tree; run by `check.sh`. Exempts only the recorded `.txt` sweep summaries in `results/paper-data/`, whose paths are a record of where the campaign wrote them |
| `.gitignore` | new | the artifact ships as its own repository and cannot rely on the extraction repo's |

**What was dropped rather than carried:** the retired codecs' drivers, the
development probes no script here invokes, and a fallback switch that could only
ever have selected a file this artifact does not contain. `gen_probe` was
counted in the middle clause and did not belong there; see its row above.

## Third-party

| what | version / commit | licence | how it arrives |
|---|---|---|---|
| ISA-L | 2.31.1 (pinned) | BSD-3-Clause | `bootstrap-isal.sh`, **plus `isal-patches/`** |
| monad-raptor | `fcafa0d7cb96c18588530c992f25c3d4a73b13dd` | **GPL-3.0-or-later** | vendored in `monad-raptor/` |
| raptorq | 2.0.1 | — | crates.io |
| reed-solomon-simd | 3.1.0 | — | crates.io |
| Firedancer `reedsol` | `813cebdb1a029f95609c7a8f275fc1ae2a58323a` | Apache-2.0 | `references/bootstrap-fdgen.sh`, policy size ceilings raised |

## Revision of 11 September 2026

Documentation and data only. **No code that builds or runs a codec changed.**
`references/`, `src/`, `monad-raptor/` (bar its `VENDORED.md`), the Cargo
files and `isal-patches/` are byte-identical to the 9 September archive. In
`codec/`, only `KNOBS.md` and **one comment block in `rs_point.c`** changed.
The file's comment-stripped token stream is identical to the 9 September
version (`579d1054…` → `15815c25…`), so the compiled driver is the same.

* **`results/paper-data/` added**, and `results/README.md`, `docs/MAPPING.md` §3
  rewritten so the comparison baseline and the paper's data are never confused.
  See the two `results/` rows above.
* **`docs/MAPPING.md`**: RS–8's decode is `isal_x` (the "control leg" quotation
  came from an earlier version of the paper); §4 names the appendix by label and
  lists the RS–16 node and coset functions; §6 now limits itself to the stable publication-to-artifact mapping and
  points the RS–16 normalization to `ALGORITHMS.md` §4.3 rather than tracking
  manuscript-draft discrepancies.
* **`docs/ALGORITHMS.md` §4.3**: states the transform decoder's `c_t` restore,
  qualifies the byte-for-byte claim to the plane layout, and fixes its notation
  against the paper's.
* **`codec/KNOBS.md`** `ISAL16_ENC_LAYOUT`, and the comment above
  `fft_pool_inter` in **`codec/rs_point.c`**: both said `inter` needs the
  transform decoder and refuses the matrix tail. In fact it requires only
  `ISAL16_ENCODE=fft`: the matrix decoder de-interleaves its survivors, and
  the tail reads a plane-form copy. The comment is the only change to the
  source file.
* **The decoder-crossover wording** (`README.md`, `docs/LIMITS.md`,
  `docs/REPRODUCING.md`, `docs/DEFAULTS.md`) now gives the paper's per-size
  intervals and its receiver-local dispatch; **`docs/LIMITS.md` §3** no longer
  describes an optimized `reed-solomon-simd` the paper no longer mentions;
  **`docs/REPRODUCING.md` §4** describes `compare.py`'s phase-matched reference.
* **Appendix letters replaced by labels** throughout (`README.md`,
  `docs/ALGORITHMS.md`, `proofs/`, `check.sh`'s section title,
  `monad-raptor/VENDORED.md`): the paper's appendices were re-lettered and the
  labels are what stays fixed.
* **`proofs/fft_cauchy_check.py`**: docstring only — it now says that neither
  claim runs `rs_point.c`'s encoder, and that the FFT code is the plan's code
  once the per-coset scalar is divided out.

