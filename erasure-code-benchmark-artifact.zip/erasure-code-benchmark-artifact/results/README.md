# results/ — reference measurements, and the paper's data

This directory holds two sets of measurements, and they have different jobs:

| | what it is | used for |
|---|---|---|
| `reference-*.csv` (this directory) | **runs of this artifact's own code** on the measurement machine | the baseline `compare.py` diffs a local run against |
| [`paper-data/`](paper-data/README.md) | **the measurements underlying the publication benchmark figures**, byte-identical to what the campaigns wrote | recomputing the archived derived quantities: `python3 results/paper-data/reproduce_tables.py` |

**The reference files are not the publication-source measurements.** They are
the same benchmark run again later, with the same protocol and configurations,
so they agree in shape but not always at the third decimal. The full-grid
ratios agree to within about 1%. RaptorQ's encode is the exception, at about
10%, because its time is bimodal (`../docs/LIMITS.md`). A difference between
`reference-*` and `paper-data/` is two runs differing, not an error in either.
For the measurements underlying the publication figures, use `paper-data/`.

> **Encode figures come from the encode leg and decode figures from the decode
> leg; the interleaved leg is the null.** This holds for the references and for
> the paper alike. `compare.py` picks the reference that matches a run's phase,
> reading it from the run's filename, because a phase leg and an interleaved leg
> have the same shape and nothing inside either one says which it is. **A
> `both` run will not reproduce a paper number**, and that is a property of the
> measurement, not a defect.

| file | what it is |
|---|---|
| `reference-grid-encode.csv` | this artifact's ENCODE leg, `./phase_campaign_leg.sh`, run 6 September 2026. The baseline for a local encode leg |
| `reference-grid-decode.csv` | the DECODE leg of the same run. The baseline for a local decode leg |
| `reference-grid.csv` | the INTERLEAVED leg of the same run: the null |
| `reference-largef-*.csv` | this artifact's beyond-grid sweep, `./largef_sweep.py`, run 31 August 2026. **A different protocol**: 15 trials per invocation against the grid's 20. Its rows and the grid's must not be merged into one table |
| `paper-data/` | see its [README](paper-data/README.md). Its RS–16 labels are spelled differently from this artifact's: `isal_cauchy16` there is `isal_x16_imat` here |
| `robust-summary-*.csv`, `robust-detail-*.csv` | **not shipped.** A local run writes them here, stamped and phase-tagged. They are gitignored, so a fresh clone has none. The reference files above are the worked example of the summary format; the detail format has no shipped example, because those files run to hundreds of megabytes |

No per-trial detail CSV is shipped for any run. They run to hundreds of
megabytes, and no figure needs them: every `*_p50` in a summary is the median
of the five invocation medians.

**Never read a summary CSV by column position.** The count is
`10 + 11 × len(LABELS)`, and `LABELS` depends on `BENCH_LABELS` and on which
codecs are available at a shape. `compare.py` matches by name from the header.

All measurements: one core of an AMD Ryzen 9 7950X pinned to core 4 at 4.5 GHz
with boost disabled, under `setarch -R`, with the allocator contract
(`glibc.malloc.{mmap,trim}_threshold` pinned high). **Expect a different machine
to differ; that is the point.** `../docs/LIMITS.md` §2 says what does and does
not carry across.
