#!/usr/bin/env python3
"""Recompute the archived benchmark quantities from the measurement files beside this script.

    python3 results/paper-data/reproduce_tables.py

Standard library only; reads the CSVs in this directory and nothing else, and
runs no codec. Every quantity is recomputed from the saved measurements and
compared with the frozen expected output recorded here. The script exits 0
when every comparison matches at the recorded precision, and 1 otherwise.

Labels, as these files spell them (the 31 August 2026 development tree; the
same label can mean something else in this artifact's own runs -- see
README.md in this directory):

    RS-8   isal_x                      encode and decode
    RS-16  isal_cauchy16               encode; matrix decode
           isal_cauchy16_fft           transform decode
"""
import csv, os, statistics as st, sys
from decimal import Decimal, ROUND_HALF_UP

HERE = os.path.dirname(os.path.abspath(__file__))

def path(name):
    return os.path.join(HERE, name)

def load(name):
    with open(path(name)) as fh:
        return list(csv.DictReader(fh))

def keyed(rows):
    return {(int(r["f"]), float(r["target_MiB"])): r for r in rows}

def num(r, c):
    v = r.get(c, "")
    return float(v) if v not in ("", None) else None

def rnd(x, p=3):
    return str(Decimal(repr(x)).quantize(Decimal(1).scaleb(-p), rounding=ROUND_HALF_UP))

E = keyed(load("robust-summary-encode-20260831-155527.csv"))   # encode figures
D = keyed(load("robust-summary-decode-20260831-160228.csv"))   # decode figures

def below(f):
    return 3 * f + 1 <= 256

LAB = {"R10": "r10", "RaptorQ": "rq", "RS-8": "isal_x", "RS-16": "isal_cauchy16",
       "Firedancer": "fd_reedsol", "rs-simd": "rs"}

def enc(codec, r):
    return num(r, LAB[codec] + "_encode_p50")

def dec(codec, r, f, rule="grid"):
    if codec != "RS-16":
        return num(r, LAB[codec] + "_decode_p50")
    mat, tra = num(r, "isal_cauchy16_decode_p50"), num(r, "isal_cauchy16_fft_decode_p50")
    if rule == "matrix" or (rule == "grid" and below(f)):
        return mat
    if rule == "transform":
        return tra
    return min(x for x in (mat, tra) if x is not None)

results = []   # (item, expected, recomputed, ok)

def check(item, expected, got):
    ok = expected == got
    results.append((item, expected, got, ok))

# ---------------------------------------------------------------- tab:performance
# RS-16 decode: matrix decoder through f = 129, transform decoder at f = 256.
PERF = {  # (f, MiB): R10 e/d, RaptorQ e/d, RS-8 e/d, RS-16 e/d  -- as printed
    (32, 0.5): "0.145 0.232 0.466 0.361 0.049 0.055 0.067 0.110",
    (32, 1.0): "0.308 0.410 1.034 0.817 0.098 0.107 0.134 0.215",
    (32, 2.0): "0.626 0.779 2.068 1.835 0.204 0.214 0.266 0.441",
    (32, 4.0): "1.305 1.549 -- -- 0.422 0.443 0.549 0.889",
    (64, 0.5): "0.149 0.305 0.424 0.360 0.072 0.110 0.085 0.186",
    (64, 1.0): "0.301 0.481 0.869 0.788 0.142 0.220 0.177 0.359",
    (64, 2.0): "0.632 0.890 1.928 1.531 0.281 0.434 0.342 0.747",
    (64, 4.0): "1.305 1.709 4.182 3.329 0.573 0.896 0.688 1.566",
    (85, 0.5): "0.145 0.333 0.404 0.371 0.089 0.150 0.097 0.231",
    (85, 1.0): "0.289 0.479 0.816 0.795 0.182 0.291 0.202 0.452",
    (85, 2.0): "0.610 0.943 1.781 1.648 0.369 0.572 0.401 0.896",
    (85, 4.0): "1.264 1.736 3.990 3.238 0.763 1.157 0.822 1.991",
    (86, 0.5): "0.140 0.328 0.404 0.374 -- -- 0.096 0.236",
    (86, 1.0): "0.273 0.454 0.668 0.783 -- -- 0.200 0.460",
    (86, 2.0): "0.573 0.876 1.696 1.482 -- -- 0.393 0.955",
    (86, 4.0): "1.196 1.633 3.764 3.354 -- -- 0.822 1.897",
    (128, 0.5): "0.151 0.375 0.432 0.420 -- -- 0.087 0.343",
    (128, 1.0): "0.286 0.491 0.838 0.686 -- -- 0.177 0.651",
    (128, 2.0): "0.592 0.868 1.621 1.530 -- -- 0.347 1.375",
    (128, 4.0): "1.252 1.664 4.046 3.148 -- -- 0.693 2.802",
    (129, 0.5): "0.153 0.446 0.433 0.427 -- -- 0.107 0.345",
    (129, 1.0): "0.294 0.575 0.697 0.693 -- -- 0.216 0.665",
    (129, 2.0): "0.604 0.985 1.737 1.352 -- -- 0.423 1.376",
    (129, 4.0): "1.277 1.831 3.930 3.434 -- -- 0.937 2.807",
    (256, 0.5): "0.188 0.471 0.425 0.624 -- -- 0.114 0.601",
    (256, 1.0): "0.316 0.647 0.711 0.945 -- -- 0.222 1.013",
    (256, 2.0): "0.621 0.926 1.379 1.640 -- -- 0.434 1.909",
    (256, 4.0): "1.348 1.692 3.235 2.710 -- -- 0.861 4.351",
}
for (f, m), line in PERF.items():
    printed = line.split()
    got = []
    for codec in ("R10", "RaptorQ", "RS-8", "RS-16"):
        e = enc(codec, E[(f, m)])
        d = dec(codec, D[(f, m)], f, "transform" if f == 256 else "matrix")
        got += ["--" if e is None else rnd(e), "--" if d is None else rnd(d)]
    for i, (p, g) in enumerate(zip(printed, got)):
        check(f"tab:performance f={f} {m:g} MiB cell {i + 1}", p, g)

# ---------------------------------------------------------------- tab:performance-ratios
def ratio(a, b, term, region, rule="grid"):
    L = E if term == "enc" else D
    xs, wins = [], 0
    for (f, m), r in L.items():
        if (region == "low") != below(f):
            continue
        va = enc(a, r) if term == "enc" else dec(a, r, f, rule)
        vb = enc(b, r) if term == "enc" else dec(b, r, f, rule)
        if va is None or vb is None:
            continue
        xs.append(va / vb)
        wins += va < vb
    return st.median(xs), wins, len(xs)

RATIOS = [("low", "RS-8", "R10", "0.464 (48/48)", "0.411 (48/48)"),
          ("low", "RS-8", "RaptorQ", "0.151 (40/40)", "0.264 (40/40)"),
          ("low", "RS-8", "RS-16", "0.794 (48/48)", "0.572 (48/48)"),
          ("high", "RS-16", "R10", "0.619 (144/144)", "1.439 (18/144)"),
          ("high", "RS-16", "RaptorQ", "0.236 (144/144)", "0.959 (80/144)")]
for region, a, b, pe, pd in RATIOS:
    for term, printed in (("enc", pe), ("dec", pd)):
        v, w, n = ratio(a, b, term, region)
        check(f"tab:performance-ratios {a}/{b} {term}", printed, f"{rnd(v)} ({w}/{n})")

# ---------------------------------------------------------------- prose derived from the grid
def speedup(a, b, term, region):          # median over points of b/a
    L = E if term == "enc" else D
    xs = []
    for (f, m), r in L.items():
        if (region == "low") != below(f):
            continue
        va = enc(a, r) if term == "enc" else dec(a, r, f)
        vb = enc(b, r) if term == "enc" else dec(b, r, f)
        if va is not None and vb is not None:
            xs.append(vb / va)
    return st.median(xs)

check("RS-8 over R10 encode speedup", "2.2", rnd(speedup("RS-8", "R10", "enc", "low"), 1))
check("RS-8 over RaptorQ encode speedup", "6.6", rnd(speedup("RS-8", "RaptorQ", "enc", "low"), 1))
check("RS-8 over R10 decode speedup", "2.4", rnd(speedup("RS-8", "R10", "dec", "low"), 1))
check("RS-8 over RaptorQ decode speedup", "3.8", rnd(speedup("RS-8", "RaptorQ", "dec", "low"), 1))
check("RS-8 over RS-16 decode factor", "1.75", rnd(speedup("RS-8", "RS-16", "dec", "low"), 2))
check("RS-8 over RS-16 encode factor", "1.26", rnd(speedup("RS-8", "RS-16", "enc", "low"), 2))
er = [enc("RS-16", E[(86, m)]) / enc("RS-8", E[(85, m)]) for m in (0.5, 1.0, 2.0, 4.0)]
dr = [dec("RS-16", D[(86, m)], 86) / dec("RS-8", D[(85, m)], 85) for m in (0.5, 1.0, 2.0, 4.0)]
check("field transition, encode range", "1.06-1.10", f"{rnd(min(er), 2)}-{rnd(max(er), 2)}")
check("field transition, decode range low end", "1.58", rnd(min(dr), 2))
check("field transition, decode range high end", "1.67", rnd(max(dr), 2))
_, w_e, n_e = ratio("RS-8", "Firedancer", "enc", "low")
_, w_d, n_d = ratio("RS-8", "Firedancer", "dec", "low")
check("RS-8 faster than Firedancer, encode points", "48/48", f"{w_e}/{n_e}")
check("RS-8 faster than Firedancer, decode points", "48/48", f"{w_d}/{n_d}")
check("Firedancer n=3f+1 encode speedup", "1.80", rnd(speedup("RS-8", "Firedancer", "enc", "low"), 2))
check("Firedancer n=3f+1 decode speedup", "5.95", rnd(speedup("RS-8", "Firedancer", "dec", "low"), 2))
check("RS-16 over R10 encode speedup", "1.6", rnd(speedup("RS-16", "R10", "enc", "high"), 1))
check("RS-16 over RaptorQ encode speedup", "4.2", rnd(speedup("RS-16", "RaptorQ", "enc", "high"), 1))
check("RS-16 / RaptorQ decode advantage, %", "4.1", rnd((1 - ratio("RS-16", "RaptorQ", "dec", "high")[0]) * 100, 1))
for term, printed in (("enc", "0.464 (144/144)"), ("dec", "0.425 (144/144)")):
    v, w, n = ratio("RS-16", "rs-simd", term, "high")
    check(f"RS-16 / reed-solomon-simd {term}", printed, f"{rnd(v)} ({w}/{n})")
check("points without RaptorQ", "8", str(sum(1 for r in E.values() if num(r, "rq_encode_p50") is None)))

# decoder crossover: last f where the matrix decoder wins, first f where the transform wins
for m, printed in ((0.5, "206-212"), (1.0, "206-212"), (2.0, "200-206"), (4.0, "224-230")):
    fs = sorted(f for (f, mm) in D if mm == m and not below(f))
    t_first = min(f for f in fs if dec("RS-16", D[(f, m)], f, "transform") < dec("RS-16", D[(f, m)], f, "matrix"))
    m_last = max(f for f in fs if f < t_first)
    check(f"decoder crossover at {m:g} MiB", printed, f"{m_last}-{t_first}")

# ---------------------------------------------------------------- tab:consumption
for lab, printed in (("r10", "1.2752 1.3438 1.4286"), ("rq", "1.0000 1.0000 1.0312")):
    med = [num(r, f"{lab}_consumed_p50") for r in D.values() if num(r, f"{lab}_consumed_p50") is not None]
    mx = [num(r, f"{lab}_consumed_max") for r in D.values() if num(r, f"{lab}_consumed_max") is not None]
    check(f"tab:consumption {lab}", printed, f"{st.median(med):.4f} {max(med):.4f} {max(mx):.4f}")

# ---------------------------------------------------------------- tab:throughput-floors
def floor(term):
    best = None
    for (f, m), r in (E if term == "enc" else D).items():
        codec = "RS-8" if below(f) else "RS-16"
        t = enc(codec, r) if term == "enc" else dec(codec, r, f)
        B, K = int(r["shard_bytes"]), f + 1
        g = 8 * K * B / (t / 1000) / 1e9
        if best is None or g < best[0]:
            best = (g, f, m, K * B / 1048576 / (t / 1000))
    return best
g, f, m, mib = floor("enc")
check("encode throughput floor, location", "f=134 4 MiB", f"f={f} {m:g} MiB")
check("encode throughput floor, Gbit/s", "31.9", rnd(g, 1))
check("encode throughput floor, MiB/s", "3804", str(round(mib)))
g, f, m, mib = floor("dec")
check("decode throughput floor, location", "f=256 0.5 MiB", f"f={f} {m:g} MiB")
check("decode throughput floor, Gbit/s", "7.00", rnd(g, 2))
check("decode throughput floor, MiB/s", "~835", f"~{round(mib):.0f}")

# ---------------------------------------------------------------- beyond the grid (15 trials per invocation)
def sweep(name):
    g = {}
    for r in load(name):
        v = num(r, "decode_ms") if num(r, "decode_ms") is not None else num(r, "encode_ms")
        g.setdefault((int(r["f"]), r["leg"]), []).append(v)
    return {k: st.median(v) for k, v in g.items()}
L1, L4 = sweep("largef-decode-1mib-20260831-201046.csv"), sweep("largef-decode-4mib-20260831-201046.csv")
for f, printed in ((511, "2.786 1.196 2.33"), (1023, "7.129 1.145 6.23"), (2047, "24.925 1.403 17.76")):
    a, b = L1[(f, "imat/auto")], L1[(f, "inter/auto")]
    check(f"tab:large-f-decode f={f}", printed, f"{rnd(a)} {rnd(b)} {rnd(a / b, 2)}")
check("f=257 transform slower, 1 MiB", "1.34", rnd(L1[(257, "inter/auto")] / L1[(257, "imat/auto")], 2))
check("f=257 transform slower, 4 MiB", "2.11", rnd(L4[(257, "inter/auto")] / L4[(257, "imat/auto")], 2))
check("f=513 transform faster, 1 MiB", "1.33", rnd(L1[(513, "imat/auto")] / L1[(513, "inter/auto")], 2))
check("f=513 transform slower, 4 MiB", "1.08", rnd(L4[(513, "inter/auto")] / L4[(513, "imat/auto")], 2))

# ---------------------------------------------------------------- Firedancer at its native K = m = 32
fd = [num(r, "rs8_ms") / num(r, "fd_reedsol_ms") for r in load("fd-native-20260831-201046.csv") if r["term"] == "encode"]
check("Firedancer native encode advantage", "1.25-1.40", f"{rnd(min(fd), 2)}-{rnd(max(fd), 2)}")

# ---------------------------------------------------------------- all-parity arrivals (7 September)
A = {(r["label"], int(r["f"]), float(r["target_MiB"]), r["arrivals"]): num(r, "dec_ms")
     for r in load("arrivals-grid-20260907-100222.csv")}
def parity_ratio(label):
    xs = [v / A[(l, f, m, "random")] for (l, f, m, a), v in A.items()
          if l == label and a == "parity" and v is not None and A.get((l, f, m, "random"))]
    return st.median(xs)
for label, name, printed in (("isal_x_dec", "RS-8", "1.449"), ("isal_x16_imat", "RS-16 matrix", "1.462"),
                             ("isal_x16_inter", "RS-16 transform", "1.007")):
    check(f"all-parity / random decode, {name}", printed, rnd(parity_ratio(label)))

# ---------------------------------------------------------------- report
bad = [r for r in results if not r[3]]
print(f"{len(results)} expected values checked: {sum(r[3] for r in results)} match, "
      f"{len(bad)} mismatches")
for item, expected, got, ok in results:
    if not ok:
        print(f"  FAIL  {item}: expected {expected}, recomputed {got}")
sys.exit(1 if bad else 0)
