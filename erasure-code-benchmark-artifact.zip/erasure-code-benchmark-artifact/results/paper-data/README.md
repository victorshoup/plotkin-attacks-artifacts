# results/paper-data/ — measurements behind the publication benchmark figures

These are the saved measurement files that the paper's benchmark appendix
(`app:benchmarks`) was computed from. They are **not** the reference files one
directory up. Those are a later run of this artifact's own code, kept so that
`compare.py` has a baseline to diff against. See [`../README.md`](../README.md).

To recompute the archived tables and quoted ratios from these files and check
them against the frozen expected outputs recorded in the script:

    python3 results/paper-data/reproduce_tables.py

It uses only the Python standard library and runs no codec. On these files it
checks 276 expected values, all of which reproduce at the recorded precision.

**Every file is byte-identical to the one the campaign wrote.** The SHA-256
digests below are those of the original files.

## Where they came from

The files were produced by the project's development tree (the working tree
this artifact was extracted from), not by the copy of the code in this
directory. The benchmark configurations are the same (see *Labels* below).
`docs/MAPPING.md` §3 maps each table to its file.

| file | what | SHA-256 |
|---|---|---|
| `robust-summary-encode-20260831-155527.csv` | main grid, **encode leg** (`BENCH_PHASE=encode`), 192 points. Every encode figure | `6bdb858a02a67bd0506053c8b90a5712f55a9b1390031e9417f0297d8b3238dc` |
| `robust-summary-decode-20260831-160228.csv` | main grid, **decode leg**, same campaign. Every decode and consumption figure | `7af06b94f39d63b794e09bce11ac85e7443e6f130720143c3b5a6178ee17ae5d` |
| `robust-summary-20260831-154312.csv` | main grid, **interleaved leg** (`both`), same campaign. The null; no paper figure uses it | `87b3467aec3b8d4dc672d855913f38c6c44bbbebfceee31536fd9d9a3ea776d4` |
| `largef-decode-1mib-20260831-201046.csv`, `.txt` | beyond-grid sweep, decode, 1 MiB. `tab:large-f-decode` | `69d4de70…7042`, `.txt` `a1c2cb21…aaa5` |
| `largef-decode-4mib-20260831-201046.csv`, `.txt` | beyond-grid sweep, decode, 4 MiB. The f = 257 / 513 staircase figures | `0f23723b…caf9`, `.txt` `230c00bc…fdcc` |
| `largef-encode-1mib-20260831-201046.csv`, `.txt` | beyond-grid sweep, encode, 1 MiB. On record; no table uses it | `e858cb91…c6c7`, `.txt` `8fb58acc…eb40` |
| `fd-native-20260831-201046.csv`, `.txt` | Firedancer at its native K = m = 32 | `f46a846e…e562`, `.txt` `7ab50212…73f4` |
| `arrivals-grid-20260907-100222.csv` | the all-parity stress test, 7 September 2026 | `d6868a2e428746ba5c8f53a06d50d0e2f167193cb1d93f44a65f1d2435702082` |

The `.txt` files are each sweep's own printed summary. Paths inside them are as
the sweep wrote them, relative to the development tree.

**Not shipped:** the per-trial detail files of the grid campaign. There are
three, each 14–20 MB:

* `robust-detail-encode-20260831-155527.csv` `90c5df7b323c1f9bb08eb8d0593f92c2a03eec2754b7660f719b4cb9d6dad8ce`
* `robust-detail-decode-20260831-160228.csv` `1317ff5092602f91ebfb68d395cb161bf2b6d4bdefa703d30ea6409f16b59844`
* `robust-detail-20260831-154312.csv` `064491e47f9850cd7935737a53542974f8610ff0d160ced66f4ebaff7c682f63`

Every `*_p50` in the summaries is the median of the five invocations' medians,
and this was re-derived from those detail files.

## Protocol, per file

* **Grid legs** (`robust-summary-*`):
  * five fresh-process invocations per point, each with 3 discarded warmups and
    20 measured trials;
  * seeds 1, 1000003, 2000003, 3000017, 4000037;
  * `*_p50` is the median of the five invocation medians;
  * one core (core 4), `setarch -R`, warm allocator;
  * encode and decode in separate legs.

  This is `docs/HARNESS.md`'s protocol, run by the development tree's
  equivalent of `phase_campaign_leg.sh`.
* **Beyond-grid sweep** (`largef-*`):
  * five invocations × median of **15** trials, one CSV row per invocation;
  * **every invocation uses seed 1**, because the sweep passes no `--seed`;
  * legs `imat/auto` (matrix decoder) and `inter/auto` (transform decoder), on
    the same interleaved codewords.

  Do not merge these rows with the grid's.
* **Firedancer native** (`fd-native-*`): 5 processes × (3 warmup + 20 trials),
  encode from `--phase encode`, decode from `--phase decode`. The file stores
  per-size medians.
* **All-parity** (`arrivals-grid-*`):
  * a decode-only leg on 36 (f, message size) points of the main grid, at the
    grid's shard sizes;
  * five seeds, 3 warmup + 20 trials. The fourth seed is 3000007, where the
    grid uses 3000017;
  * `arrivals` is `random` (the grid's pattern), `parity` (every received
    symbol is parity) or `random2` (an independent second `random` leg, the
    null).
  * RaptorQ has no result at f = 32 / 4 MiB, because its symbol-size limit is
    exceeded there.
  * **Do not confuse this with a fixed-1-KiB all-parity experiment that
    preceded it and was withdrawn.** That experiment is not a grid size and is
    not shipped.

## Labels — the same name need not mean the same configuration

These files come from the development tree, whose label names differ from this
artifact's:

| paper name | label in these files | label in this artifact's own runs | configuration |
|---|---|---|---|
| RS–8 | `isal_x` | `isal_x` | `ISAL8_NODES=eval ISAL8_ENCODE=fft ISAL8_INTERP=auto ISAL8_FFT_BLOCK3=1 ISAL8_FUSE=1 ISAL8_PPT_FUSE=1 ISAL8_COSET_FUSE=1` |
| RS–16, matrix decode | **`isal_cauchy16`** | `isal_x16_imat` | `ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_DECODE=matrix ISAL16_ENC_LAYOUT=inter ISAL16_DEC_LAYOUT=inter ISAL16_FFT_TAIL=04` |
| RS–16, transform decode | `isal_cauchy16_fft` | `isal_x16_inter` | the same, with `ISAL16_DECODE=fft` |

**`isal_cauchy16` means different codecs in the two places.** In these files it
is RS–16. In this artifact's own runs it is the historical linear-node,
matrix-encoder null (`docs/MAPPING.md` §2). The development tree also carries
two RS–16 instrument labels, `isal_cauchy16_fft_dec` and `isal_cauchy16_plane`,
which the paper does not use.

The all-parity file uses the artifact-style names (`isal_x16_imat`,
`isal_x16_inter`). Its RS–8 is `isal_x_dec`, which runs the same decoder on the
same code as `isal_x` but encodes with the matrix encoder. The encoder does not
run inside a decode-only leg's timer.

## Rules the paper's tables use

* **Encode figures come from the encode leg; decode and consumption figures come
  from the decode leg.** The interleaved leg is never used.
* **RS–16 decoder:**
  * in `tab:performance`, the matrix decoder through f = 129 and the transform
    decoder at f = 256;
  * in `tab:performance-ratios` and `tab:throughput-floors`, the faster of the
    two at each point above n = 256, and the matrix decoder below it.
* **Full-grid ratios:**
  * the median over points of the pointwise ratio (not a ratio of medians);
  * the win count is the number of points where the first-named codec is
    faster;
  * n ≤ 256 has 48 points (40 for RaptorQ), and n > 256 has 144.
* **Throughput:** `R_src = 8·K·B/t`, with B the rounded shard size.
* **Rounding** happens only when a value is displayed.
