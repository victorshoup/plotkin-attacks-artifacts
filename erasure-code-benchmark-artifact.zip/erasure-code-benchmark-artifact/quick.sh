#!/bin/sh
# Smoke test: one point per codec at each end of the grid, plus the two shapes
# where k is a power of two (f = 31, 63) -- those reach the FFT encode routes and
# are the shapes v8.1 and earlier never sampled.
set -eu
cd "$(dirname "$0")"
./bootstrap.sh
: "${RAYON_NUM_THREADS:=1}"
export RAYON_NUM_THREADS
# The Rust side is only measured at parity with the C side if it is built for
# this CPU, and the line above sets that ONLY when RUSTFLAGS is unset. A
# RUSTFLAGS exported for any other reason silently drops it to baseline x86-64
# and every rs_simd figure in the run is wrong, with nothing in the output
# saying so. HANDOVER-2026-08-24.md section 3.1.
check_rustflags() {
    case "${RUSTFLAGS:-}" in
        *target-cpu*) ;;
        *) echo "ERROR: RUSTFLAGS is set but does not carry -C target-cpu:" >&2
           echo "         RUSTFLAGS=${RUSTFLAGS:-}" >&2
           echo "       The Rust codecs would be built for baseline x86-64 while" >&2
           echo "       the C driver is built -march=native. Unset RUSTFLAGS, or" >&2
           echo "       add -C target-cpu=native to it." >&2
           exit 1 ;;
    esac
}
if [ -z "${RUSTFLAGS+x}" ]; then
    RUSTFLAGS="-C target-cpu=native"
    export RUSTFLAGS
fi
check_rustflags
cargo build --release --bin erasure-baseline
BIN=./target/release/erasure-baseline
PY=${PYTHON:-python3}
sb() { $PY -c "import grid,sys; print(grid.aligned_shard_bytes(int(sys.argv[1]), int(sys.argv[2])))" "$1" "$2"; }

for f in 31 32 63 85; do
    s=$(sb 1048576 $((f + 1)))
    for codec in r10 rq rs; do
        $BIN --f "$f" --shard-bytes "$s" --codec "$codec" --trials 2 --warmup 1 >/dev/null
        echo "smoke f=$f $codec: OK"
    done
    # No tape smoke: the tape codec is not in this artifact. No isal-point
    # smoke either -- rs_point.c replaced it (report 5.21) and the split
    # binaries are not carried.
    if [ -x ./codec/rs-point ]; then
        ./codec/rs-point --field 8 --f "$f" --shard-bytes "$s" --plan cauchy \
            --trials 2 --warmup 1 >/dev/null
        echo "smoke f=$f rs-point cauchy (gf8): OK"
    fi
done

for f in 129 256; do
    s=$(sb 1048576 $((f + 1)))
    $BIN --f "$f" --shard-bytes "$s" --codec rs --trials 2 --warmup 1 >/dev/null
    echo "smoke f=$f rs: OK"
    # The GF(2^16) smoke was `--codec tape --tape-field gf16`, which this
    # artifact has no codec for. rs-point's own GF(2^16) path is the thing to
    # smoke here instead: it is what carries every T > 256 figure.
    if [ -x ./codec/rs-point ]; then
        ./codec/rs-point --field 16 --f "$f" --shard-bytes "$s" --plan cauchy \
            --trials 2 --warmup 1 >/dev/null
        echo "smoke f=$f rs-point cauchy (gf16): OK"
    fi
done
