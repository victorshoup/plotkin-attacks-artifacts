#!/bin/sh
set -eu
cd "$(dirname "$0")"
./bootstrap.sh
: "${RAYON_NUM_THREADS:=1}"
export RAYON_NUM_THREADS
# The Rust side is only measured at parity with the C side if it is built for
# this CPU, and the line above sets that ONLY when RUSTFLAGS is unset. A
# RUSTFLAGS exported for any other reason silently drops it to baseline x86-64
# and every rs_simd figure in the run is wrong, with nothing in the output
# saying so. HANDOVER-2026-08-24.md section 3.1.
check_rustflags() {
    case "${RUSTFLAGS:-}" in
        *target-cpu*) ;;
        *) echo "ERROR: RUSTFLAGS is set but does not carry -C target-cpu:" >&2
           echo "         RUSTFLAGS=${RUSTFLAGS:-}" >&2
           echo "       The Rust codecs would be built for baseline x86-64 while" >&2
           echo "       the C driver is built -march=native. Unset RUSTFLAGS, or" >&2
           echo "       add -C target-cpu=native to it." >&2
           exit 1 ;;
    esac
}
if [ -z "${RUSTFLAGS+x}" ]; then
    RUSTFLAGS="-C target-cpu=native"
    export RUSTFLAGS
fi
check_rustflags
if ! command -v cargo >/dev/null 2>&1; then echo "ERROR: cargo is not on PATH" >&2; exit 1; fi
if ! command -v python3 >/dev/null 2>&1; then echo "ERROR: python3 is required" >&2; exit 1; fi
cargo build --release --bin erasure-baseline
# BENCH_CPU=N   pin every measurement process to core N (strongly recommended)
# BENCH_LABELS  core (default) or full -- see robust_benchmark.py
exec ./robust_benchmark.py
