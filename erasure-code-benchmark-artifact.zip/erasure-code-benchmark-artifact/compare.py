#!/usr/bin/env python3
"""Compare a run's summary CSV against this artifact's reference.

    python3 compare.py results/robust-summary-<stamp>.csv
    python3 compare.py mine.csv theirs.csv       # any two runs

WHAT THIS IS FOR. The artifact's claim is not a set of absolute milliseconds --
those depend on the machine, and on this one they were taken pinned to a core
with ASLR off, boost off and the clock fixed. The claim is the SHAPE of the
result: which codec wins, by how much, and where the crossovers are. This tool
says whether a run reproduces that shape and flags the rows where it does not.

MATCHING IS BY NAME FROM THE HEADER, NEVER BY COLUMN POSITION. The label set is
not fixed -- BENCH_LABELS=full adds columns, a codec unavailable at a shape
leaves its cells empty, and a future revision may add or drop a label entirely.
Positional matching silently compares `r10` against `rq` the first time any of
that happens. Labels present in one file and not the other are REPORTED AND
SKIPPED, not treated as a failure: a smaller label set is a legitimate run.

Rows are matched on (f, target_MiB), and a point present in only one file is
listed rather than dropped silently.
"""
import csv, statistics, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def default_reference(run_path):
    """Pick the reference matching the RUN'S PHASE, from its filename.

    A phase leg and an interleaved leg have the same shape and nothing inside
    either says which it is, so defaulting to the interleaved reference would
    silently diff an encode leg against a leg that also ran the decoder --
    comparing a cold, once-per-process encode against a warm steady-state one.
    That is not a small error: it is the very contamination the phase split
    exists to measure. The phase is in the filename, so it is read from there.
    """
    name = Path(run_path).name
    for tag in ("-encode-", "-decode-"):
        if tag in name:
            return ROOT / "results" / f"reference-grid{tag.rstrip('-')}.csv"
    return ROOT / "results" / "reference-grid.csv"

# A ratio outside this band is called out. It is deliberately wide: the point is
# to catch a codec that changed rank or a label that is measuring something
# else, not to relitigate a few percent of machine difference. This is a diff,
# NOT a statistical test: no confidence interval is computed and none is
# claimed. docs/LIMITS.md section 2 states what does and does not carry across
# machines.
TOL = 0.25


def load(path):
    with open(path, newline="") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise SystemExit(f"{path}: no data rows")
    return {(r["f"], r["target_MiB"]): r for r in rows}, list(rows[0].keys())


def metrics(cols):
    """Every `<label>_<term>_p50` column, keyed by (label, term)."""
    out = {}
    for c in cols:
        if c.endswith("_p50"):
            stem = c[:-4]
            for term in ("encode", "decode", "plan", "code", "consumed"):
                if stem.endswith("_" + term):
                    out[(stem[: -len(term) - 1], term)] = c
    return out


def num(row, col):
    v = (row.get(col) or "").strip()
    if not v:
        return None
    try:
        return float(v)
    except ValueError:
        return None


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    new_path = args[0]
    ref_path = args[1] if len(args) > 1 else default_reference(new_path)
    if not Path(ref_path).exists():
        raise SystemExit(
            f"reference not found: {ref_path}\n"
            "The reference is chosen to match the run's phase, read from its\n"
            "filename. Generate the set with  BENCH_CPU=N ./phase_campaign_leg.sh\n"
            "and copy each summary to results/reference-grid[-encode|-decode].csv,\n"
            "or pass a reference explicitly as the second argument.")

    new, ncols = load(new_path)
    ref, rcols = load(ref_path)
    nm, rm = metrics(ncols), metrics(rcols)

    shared = sorted(set(nm) & set(rm))
    only_new = sorted(set(nm) - set(rm))
    only_ref = sorted(set(rm) - set(nm))
    print(f"reference: {ref_path}")
    print(f"run:       {new_path}")
    print(f"{len(shared)} shared label/term pairs, "
          f"{len(set(new) & set(ref))} shared points\n")
    for lbl, where in ((only_new, "only in the run"), (only_ref, "only in the reference")):
        if lbl:
            print(f"  {where}, skipped: " +
                  ", ".join(f"{a}:{b}" for a, b in lbl))
    pts_new = set(new) - set(ref)
    pts_ref = set(ref) - set(new)
    for pts, where in ((pts_new, "only in the run"), (pts_ref, "only in the reference")):
        if pts:
            print(f"  {len(pts)} point(s) {where}, skipped: " +
                  ", ".join(f"f={f}@{m}MiB" for f, m in sorted(pts)[:6]) +
                  (" ..." if len(pts) > 6 else ""))
    print()

    print("| label | term | n | min | median | max | outside ±%d%% |"
          % int(TOL * 100))
    print("|---|---|---:|---:|---:|---:|---:|")
    worst = []
    bad = 0
    for label, term in shared:
        rs = []
        for key in sorted(set(new) & set(ref)):
            a, b = num(new[key], nm[(label, term)]), num(ref[key], rm[(label, term)])
            if a is None or b is None or b == 0:
                continue
            rs.append((a / b, key))
        if not rs:
            continue
        vals = [x for x, _ in rs]
        out = [(x, k) for x, k in rs if abs(x - 1) > TOL]
        bad += len(out)
        worst += [(abs(x - 1), x, k, label, term) for x, k in out]
        print("| `%s` | %s | %d | %.3f | **%.3f** | %.3f | %d |"
              % (label, term, len(vals), min(vals), statistics.median(vals),
                 max(vals), len(out)))

    if worst:
        print(f"\n## {bad} cell(s) outside ±{int(TOL*100)}%, worst first\n")
        print("| label | term | f | MiB | run ÷ reference |")
        print("|---|---|---:|---:|---:|")
        for _, x, (f, m), label, term in sorted(worst, reverse=True)[:25]:
            print("| `%s` | %s | %s | %s | **%.3f** |" % (label, term, f, m, x))
        print("\nA cell outside the band is not by itself a failure -- a different")
        print("machine, or one that is not pinned, moves absolute times. What")
        print("matters is whether the RANKING moved; see docs/REPRODUCING.md.")
    else:
        print(f"\nEvery shared cell is within ±{int(TOL*100)}% of the reference.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
