#!/usr/bin/env python3
"""
Robust fixed-source-message erasure-code benchmark -- harness v9.

Primary question this version is built to answer: how do Raptor-family codes
(R10, RaptorQ) compare against Reed-Solomon codes across committee size, at
n = 3f+1 with k = f+1 and T = 3f+1, when the decoder cannot control arrival
order and pays every per-pattern setup cost on every message?

v9 changes over v8.1
--------------------
  * f grid expanded from 6 values to 48. v8.1 sampled 32, 64, 85, 96, 128, 256
    -- four of which are powers of two, and reed-solomon-simd's FFT work buffer
    is at its 1.33xT floor exactly at powers of two. The old grid therefore
    sampled RS at its best case almost everywhere and never once at its worst.
    v9 brackets every work-buffer transition (2^n-1, 2^n, 2^n+1) and sweeps the
    interior.
  * summary CSV gains rs_rate, rs_work_count and rs_work_over_T so the RS
    column can be read; without them a plain f-ordered table looks like a
    committee-size trend when it is a sawtooth.
  * summary CSV gains encode p90 and max. v8.1 carried encode p50 only, so
    encode stability could not be computed without reparsing the detail file.
  * label set is selectable. BENCH_LABELS=core (default) is the paper's set:
    R10, RaptorQ, stock reed-solomon-simd, RS-8 with its decode instrument,
    RS-16, and the firedancer reference. BENCH_LABELS=full adds the nulls --
    the reed-solomon-simd rate variants and the O(k^3) GE decode plan.
    The former `gf16` set is gone: isal_cauchy16 IS RS-16 and a default run
    that omitted it could not reproduce the paper's Table 1.
  * the code-term control is checked against a RELATIVE tolerance. v8.1 and the
    rev 5 report both assert it agrees "within 0.005 ms everywhere"; measured
    spread is up to 0.074 ms, and rev 5's own section 5.1 table implies 0.036 ms.
    The control is sound -- spread is proportional to the code term, about 5% --
    but the absolute threshold was wrong by more than an order of magnitude.

Carried forward from v8.1 (unchanged)
-------------------------------------
  each (f, target, codec, repetition) gets a fresh process; 3 warmups + 20
  measured trials; every trial kept in the detail CSV; BENCH_CPU=N pins every
  measurement process with taskset.

v9 measurement protocol (2026-08-24)
------------------------------------
  * every measured process runs under `setarch -R`, and repetitions go from 3
    to 5, so the headline is the median of 5 same-layout invocations rather
    than of 3 differently-laid-out ones;
  * the summary carries `*_repmin` / `*_repmax` beside `*_p50`, so the spread
    across processes is readable without reparsing the detail file. It was not,
    and a 1.9x across-invocation spread at large f went unnoticed for a day.
  See HANDOVER-2026-08-24.md section 2.

EXTRACTED for the public artifact: tape-reed-solomon is not part of it, so its
labels, its decode-plan decomposition, and the isal-vs-tape kernel comparison
are gone. Relative paths are still the working tree's, so this stays runnable
there. The C driver is in `codec/`; firedancer's is in `references/`.
The code-term control survives, retargeted from four tape plan
variants to isal_cauchy vs isal_ge -- the same control (every plan variant does
r*k MACs, so their code terms must agree within one library), one library over.
"""
import csv
import io
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))

from grid import (FS, TARGETS, ALIGN, RQ_MAX_SYMBOL, gf16_available,
                  aligned_shard_bytes, rq_available, rs_rate_and_work)

# Five, not three. HANDOVER-2026-08-24.md section 2 rule 2: a median *within*
# one invocation is tight and tells you nothing about the spread *across* them,
# and that spread reached 1.9x at large f before the C.1 fix. Five is the
# protocol minimum for a min/median/max to mean anything.
REPETITIONS = 5
TRIALS = 20
WARMUPS = 3
REP_SEEDS = [1, 1000003, 2000003, 3000017, 4000037]
assert len(REP_SEEDS) == REPETITIONS

# Relative tolerance for the code-term control. See the module docstring.
CODE_CONTROL_TOL = 0.08

ROOT = Path(__file__).resolve().parent
BIN = ROOT / "target" / "release" / "erasure-baseline"
# ONE C driver serves both fields. The working tree kept a BENCH_ISAL_SPLIT=1
# fallback to the two separate drivers rs_point.c replaced -- the null for that
# merge, report 5.21 -- and it is dropped here: those binaries are not in this
# artifact, so the switch could only ever have selected a missing file. The
# aliases are kept so the label table below reads as it always did.
RS_BIN = ROOT / "codec" / "rs-point"
# firedancer's reedsol, ported into references/fdrs and regenerated to the whole
# T <= 256 region. references/fdrs/README.md; its nulls are in check.sh.
FD_BIN = ROOT / "references" / "fd-point"
ISAL_BIN = RS_BIN
ISAL16_BIN = RS_BIN
BIN_FOR = {"r10": BIN, "rq": BIN, "rs": BIN, "isal": ISAL_BIN,
           "isal16": ISAL16_BIN, "fd": FD_BIN,
           # X: the GF(2^8) additive-FFT/pivot-base encoder behind the Cauchy
           # matrix decoder. Same BINARY as `isal`; what makes it a different
           # codec is the ISAL8_* block in ENV_FOR below, not the executable.
           "isalx": ISAL_BIN, "isalxd": ISAL_BIN,
           # RS-16: the recommended GF(2^16) codec. ONE encoder (Cantor nodes,
           # additive FFT, interleaved layout, tail 4) and TWO decoders, which
           # are two labels rather than a dispatch -- DEFAULTS.md, "There is no
           # single optimal ISAL16_DECODE". A deployment carries one entry point
           # that picks internally; this benchmark deliberately does not, so
           # both nulls stay reachable and the crossover stays visible.
           "x16i": ISAL16_BIN, "x16t": ISAL16_BIN}
FIELD_FOR = {"isal": "8", "isal16": "16",
                              "isalx": "8", "isalxd": "8",
                              "x16i": "16", "x16t": "16"}

# --- per-codec environment, and why it has to be length-equalised ------------
#
# `isal_cauchy` and X run the SAME binary and differ only in environment, so
# they are the one pair in this harness where section 1.9 rule 3 -- equal-length
# environment blocks -- actually bites: the environment sits on the initial
# stack, and a block of a different length shifts every stack address in the
# measured process. Three-byte differences have fabricated 1.16x results here
# before. So all three isal-family codecs get blocks padded to ONE length, and
# `isal` gets a filler rather than nothing.
#
# X's block is rev22a section A1.1's configuration, spelled out rather than
# named. ISAL8_NODES=eval selects the CODE; the rest select kernels and are
# asserted by check.sh not to move a parity byte.
_X_ENV = {
    "ISAL8_NODES": "eval", "ISAL8_ENCODE": "fft", "ISAL8_INTERP": "auto",
    "ISAL8_FFT_BLOCK3": "1", "ISAL8_FUSE": "1", "ISAL8_PPT_FUSE": "1",
    "ISAL8_COSET_FUSE": "1",
}
# The decode instrument: the SAME code as X -- same nodes, same pivot base, so
# the same plan and the same rows -- but encoded by the matrix encoder. It
# exists because section A5.3 of rev22a measures the transform's chunk*stride
# work buffer evicting the decoder's working set between trials at 4 MiB, by
# 1.12x-1.59x. X's own decode column therefore carries an artefact at the
# largest message size and this one does not. Its ENCODE column is a bonus: it
# is the matrix-encoder null for X's transform encoder, inside the same leg.
_XD_ENV = dict(_X_ENV, ISAL8_ENCODE="matrix")


# RS-16, from DEFAULTS.md's C16 block. One encoder, two decoders.
# ISAL16_DECODE=matrix and =fft differ by three bytes, and three bytes has
# fabricated a 1.16x result in this harness before -- but _pad_env absorbs it,
# so both labels can run inside ONE campaign. run-rev23-legs.sh had to run them
# as two whole campaigns with a hand-set BENCH_ENV_PAD for exactly this reason;
# padding per block removes that hack and the defect its own header records.
_X16_ENV = {"ISAL16_NODES": "cantor", "ISAL16_ENCODE": "fft",
            "ISAL16_ENC_LAYOUT": "inter", "ISAL16_DEC_LAYOUT": "inter",
            "ISAL16_FFT_TAIL": "04"}
_X16_IMAT_ENV = dict(_X16_ENV, ISAL16_DECODE="matrix")
_X16_INTER_ENV = dict(_X16_ENV, ISAL16_DECODE="fft")


def _pad_env(d, width):
    """Pad an environment block to `width` bytes with a filler variable."""
    n = sum(len(k) + 1 + len(v) + 1 for k, v in d.items())
    if n > width:
        raise SystemExit(f"env block {n} > width {width}: {d}")
    fill = width - n - len("ENVPAD=") - 1
    if fill < 0:
        raise SystemExit(f"cannot pad env block to {width}: {d}")
    return dict(d, ENVPAD="x" * fill)


_ENV_WIDTH = max(sum(len(k) + 1 + len(v) + 1 for k, v in d.items())
                 for d in (_X_ENV, _XD_ENV,
                           {"ISAL8_NODES": "cauchy", "ISAL8_ENCODE": "matrix"},
                           {"ISAL16_NODES": "linear", "ISAL16_ENCODE": "matrix",
                            "ISAL16_DECODE": "matrix", "ISAL16_ENC_LAYOUT": "plane",
                            "ISAL16_DEC_LAYOUT": "plane", "ISAL16_FFT_TAIL": "12"},
                           _X16_IMAT_ENV, _X16_INTER_ENV)) + 32
# The GF(2^8) baseline, PINNED rather than inherited.
#
# Until 2026-08-26 this was `_pad_env({})` -- an empty ISAL8_ block -- and it
# worked only because the compiled defaults happened to be `cauchy` and
# `matrix`. Those defaults are now `eval` and `fft` (DEFAULTS.md policy 1), so
# an empty block would silently turn `isal_cauchy` into X. It is pinned here.
#
# THE RULE THIS ENCODES: a label's meaning must never depend on a compiled
# default. Both times this project has reported an inverted ratio -- firedancer
# on 24 Aug, leopard on 26 Aug -- the cause was a comparator that inherited a
# default instead of stating its configuration.
_C8_ENV = {"ISAL8_NODES": "cauchy", "ISAL8_ENCODE": "matrix"}

# The GF(2^16) label, also pinned. `isal_cauchy16` has meant linear nodes and
# the matrix encoder in every revision through 23, and the compiled default no
# longer supplies that, so it is stated. A leg that wants the recommended
# configuration passes it explicitly, as run-rev23-legs.sh's $L16 does.
_C16_ENV = {"ISAL16_NODES": "linear", "ISAL16_ENCODE": "matrix",
            "ISAL16_DECODE": "matrix", "ISAL16_ENC_LAYOUT": "plane",
            "ISAL16_DEC_LAYOUT": "plane", "ISAL16_FFT_TAIL": "12"}


ENV_FOR = {
    "isalx":  _pad_env(_X_ENV, _ENV_WIDTH),
    "isalxd": _pad_env(_XD_ENV, _ENV_WIDTH),
    "isal":   _pad_env(_C8_ENV, _ENV_WIDTH),
    # Padded to the same width as the three GF(2^8) blocks: isal_cauchy16 runs
    # the SAME BINARY as isal_cauchy and X, so section 1.9 rule 3's equal-length
    # requirement covers it too. Before today it carried an empty block, which
    # was a 155-byte difference against the others -- measured harmless on
    # 26 Aug (0.993x-1.015x over 14 points) but not a thing to leave in place.
    "isal16": _pad_env(_C16_ENV, _ENV_WIDTH),
    "x16i":   _pad_env(_X16_IMAT_ENV, _ENV_WIDTH),
    "x16t":   _pad_env(_X16_INTER_ENV, _ENV_WIDTH),
}
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
# BENCH_PHASE: `both` (default) is the interleaved encode+decode loop, and it
# stays the null. `decode` encodes ONCE at setup in every driver and times
# decode alone against a fresh erasure pattern per trial; `encode` is its
# mirror. THE PAPER'S GRID TABLES ARE MEASURED FROM THE ISOLATED LEGS, not from
# `both` -- the interleaved leg contaminates each timer with the other
# operation's cache footprint, and the delta between the modes is what prices
# that. Quote the delta, not the isolated number alone.
#
# APPLIED TO EVERY LABEL OR NONE. Applying it to the MDS labels alone would
# split the label set along MDS vs fountain, which is the comparison's headline
# axis, so the flag goes to every driver -- r10 and rq included -- or to none.
PHASE = os.environ.get("BENCH_PHASE", "both").lower()
if PHASE not in ("both", "encode", "decode"):
    raise SystemExit(
        f"BENCH_PHASE must be 'both', 'encode' or 'decode', got {PHASE!r}")

# THE PHASE IS IN THE FILENAME, and that is not cosmetic. A phase summary has
# the same shape as an interleaved one and nothing inside it says which it is,
# so joining the two silently mixes a warm steady-state encode column with a
# COLD one -- under `decode` the encoder runs once per process at the first
# warmup trial and pays that process's page faults.
_PHASE_TAG = "" if PHASE == "both" else f"-{PHASE}"
STAMP = time.strftime("%Y%m%d-%H%M%S")
DETAIL = RESULTS / f"robust-detail{_PHASE_TAG}-{STAMP}.csv"
SUMMARY = RESULTS / f"robust-summary{_PHASE_TAG}-{STAMP}.csv"

PIN = os.environ.get("BENCH_CPU")
# `setarch -R` disables ASLR for the measured child. Section 2 rule 1: this
# machine runs randomize_va_space = 2, and under it 4 MiB large-f timing was
# bimodal across invocations, spanning 1.9x on encode from memory layout alone,
# while rs_simd was stable to 2%. A deployment does not get to choose its
# layout; a comparison does have to hold one variable at a time. BENCH_ASLR=1
# restores the randomised layout, which is what item 7 of the handover wants
# re-checked -- it is not the grid of record.
NO_ASLR = os.environ.get("BENCH_ASLR") != "1"
if NO_ASLR and not shutil.which("setarch"):
    raise SystemExit("setarch not found; install util-linux or set BENCH_ASLR=1")
PREFIX = (["setarch", "-R"] if NO_ASLR else []) + (
    ["taskset", "-c", PIN] if PIN else [])
# The allocator contract. See PERF-NOTES-ALLOCATOR.md.
#
# glibc's mmap and trim thresholds are dynamic: whether a freed working buffer is
# recycled or handed back to the kernel depends on its size, on what else the
# process has freed, and so on the codec and the grid point. The cost of
# re-faulting it lands in whichever timer touches the pages first. Measured at
# 0.86x-2.78x on decode across three points -- larger than every optimisation in
# section 4, and it reorders codecs.
#
# BENCH_MALLOC defaults to `warm`: both thresholds pinned high, so nothing is
# returned to the kernel and every codec is measured on recycled buffers. The
# per-call allocation of rule 3 still happens; what stops varying is whether the
# kernel has to hand the pages back. Under it ISAL_ALLOC_PER_CALL=1 and =0 agree
# to 0.998x, i.e. the rule becomes the no-op it was always supposed to be.
#
# `default` restores glibc's own behaviour, which is what rev 16 and the three
# legs of 2026-08-22 were measured under. Those figures are not comparable with
# `warm` ones and must not be mixed.
MALLOC_MODE = os.environ.get("BENCH_MALLOC", "warm").lower()
if MALLOC_MODE not in ("warm", "default"):
    raise SystemExit(f"BENCH_MALLOC must be 'warm' or 'default', got {MALLOC_MODE!r}")
if MALLOC_MODE == "warm":
    _TUNE = ("glibc.malloc.mmap_threshold=536870912:"
             "glibc.malloc.trim_threshold=536870912")
    _prev = os.environ.get("GLIBC_TUNABLES")
    os.environ["GLIBC_TUNABLES"] = f"{_prev}:{_TUNE}" if _prev else _TUNE

LABEL_SET = os.environ.get("BENCH_LABELS", "core").lower()
if LABEL_SET not in ("core", "full"):
    raise SystemExit(f"BENCH_LABELS must be 'core' or 'full', got {LABEL_SET!r}")


def pct(values, q):
    """Nearest-rank percentile; q in [0,100]."""
    if not values:
        return None
    s = sorted(values)
    i = min(len(s) - 1, max(0, int(round(q / 100.0 * len(s) + 0.5)) - 1))
    return s[i]


# ---------------------------------------------------------------- labels

# (label, codec, field, gen, plan, rs_rate)
# Order here fixes the summary column order; every label a run can emit must
# appear, and the offsets are computed from the index.
ALL_LABELS = [
    # Raptor family
    "r10", "rq",
    # Reed-Solomon: the live candidates
    "rs", "isal_cauchy",
    # Reed-Solomon: decomposition experiments, BENCH_LABELS=full only
    "rs_high", "rs_low", "isal_ge",
    # RS-16: one encoder, two decoders, two labels. Every f.
    "isal_x16_imat", "isal_x16_inter",
    # The GF(2^16) Cauchy codec in its historical configuration -- a null,
    # BENCH_LABELS=full only. NOT RS-16: its encoder is the matrix one, 5.7x
    # slower at f = 86 / 0.5 MiB.
    "isal_cauchy16",
    # Reed-Solomon: firedancer's additive-FFT/PPT code over GF(2^8)
    "fd_reedsol",
    # X: additive-FFT encode over a cost-chosen pivot base, Cauchy matrix
    # decode, GF(2^8), T <= 256. `isal_x_dec` is the decode instrument, not a
    # deployment configuration -- see ENV_FOR.
    "isal_x", "isal_x_dec",
]


def runs_for(f, T):
    out = [
        ("r10", "r10", None, None, None, None),
        ("rq", "rq", None, None, None, None),
        ("rs", "rs", None, None, None, "auto"),
    ]
    if T <= 256:
        if HAVE_ISAL:
            out.append(("isal_cauchy", "isal", None, None, "cauchy", None))
            # X and its decode instrument. Same binary, same --field/--plan;
            # the codec key selects the ISAL8_* block in ENV_FOR.
            #
            # ORDER MATTERS AND IS NOT COSMETIC. `isal_x_dec` exists to give X a
            # decode measurement, and it must not be preceded by `isal_x`: X's
            # transform work buffer is chunk*stride, up to 6.1 MB at f = 85 /
            # 4 MiB, and a label that runs immediately after it decodes into a
            # cache the previous PROCESS just evicted. Measured, with that
            # ordering: `isal_x_dec` read 1.05x-1.08x `isal_cauchy` at >= 1 MiB,
            # where the same pair run standalone with equal-length environment
            # blocks reads 0.984x-0.996x. Same code, same plan, same rows, same
            # kernel -- so the difference was the schedule, not the codec.
            # Putting the instrument after `isal_cauchy` and X last removes it.
            out.append(("isal_x_dec", "isalxd", None, None, "cauchy", None))
            out.append(("isal_x", "isalx", None, None, "cauchy", None))
        # fd_reedsol is generated to the field's own limit, which at this rate
        # is f <= 85 -- the whole of T <= 256, so the branch condition already
        # implies it. The assert states that rather than assuming it.
        if HAVE_FD:
            assert f + 1 <= 86 and 2 * f <= 170, (f, T)
            out.append(("fd_reedsol", "fd", None, None, None, None))

    # isal_cauchy16 is RS-16, and the only Reed-Solomon label that spans the
    # T = 256 boundary, so it is emitted for every f rather than in either
    # branch. It is APPENDED, after the T <= 256 block: the emission order
    # inside a point is load-bearing (see the isal_x_dec note above), and
    # appending leaves every earlier label's predecessor unchanged.
    if HAVE_ISAL16 and gf16_available(f):
        # The transform decoder goes LAST: its work buffer is the largest thing
        # in the point, and the isal_x_dec note above is what happens when a
        # label decodes into a cache the previous process just evicted.
        out.append(("isal_x16_imat", "x16i", None, None, "cauchy", None))
        out.append(("isal_x16_inter", "x16t", None, None, "cauchy", None))

    if LABEL_SET == "full":
        out.append(("rs_high", "rs", None, None, None, "high"))
        out.append(("rs_low", "rs", None, None, None, "low"))
        if HAVE_ISAL16 and gf16_available(f):
            out.append(("isal_cauchy16", "isal16", None, None, "cauchy", None))
        if T <= 256:
            if HAVE_ISAL:
                out.append(("isal_ge", "isal", None, None, "ge", None))
    return out


if not BIN.exists():
    raise SystemExit(f"missing benchmark binary: {BIN}; run ./benchmark.sh")
HAVE_ISAL = ISAL_BIN.exists()
if not HAVE_ISAL:
    print(f"note: {ISAL_BIN} not built; skipping ISA-L points "
          "(run ./bootstrap-isal.sh)", file=sys.stderr)
HAVE_ISAL16 = ISAL16_BIN.exists()
HAVE_FD = FD_BIN.exists()
if not HAVE_FD:
    print(f"note: {FD_BIN} not built; skipping fd_reedsol points "
          "(run `make -C isal`)", file=sys.stderr)
if not HAVE_ISAL16:
    print(f"note: {ISAL16_BIN} not built; skipping isal_cauchy16 points "
          "(run ./bootstrap-isal.sh)", file=sys.stderr)

emitted = set()
for _f in FS:
    for _lab, *_ in runs_for(_f, 3 * _f + 1):
        emitted.add(_lab)
LABELS = [lab for lab in ALL_LABELS if lab in emitted]
unknown = emitted - set(ALL_LABELS)
if unknown:
    raise SystemExit(f"runs_for emitted labels missing from ALL_LABELS: {sorted(unknown)}")


def cpu_mhz():
    try:
        out = subprocess.run(["lscpu"], text=True, stdout=subprocess.PIPE).stdout
        for line in out.splitlines():
            if "MHz" in line:
                return line.strip()
    except Exception:
        pass
    return "unknown"


def governor():
    p = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
    try:
        return p.read_text().strip()
    except Exception:
        return "unknown"


point_total = len(FS) * len(TARGETS)
print(f"Robust fixed-message benchmark v9: {len(FS)} f values, {point_total} points, "
      f"{REPETITIONS} repetitions, {WARMUPS} warmups + {TRIALS} measured trials per "
      f"fresh process.", file=sys.stderr)
print(f"labels={LABEL_SET} ({len(LABELS)}): {' '.join(LABELS)}", file=sys.stderr)
print(f"governor={governor()}  pinning={'cpu ' + PIN if PIN else 'none (set BENCH_CPU=N)'}"
      f"  aslr={'off (setarch -R)' if NO_ASLR else 'ON (BENCH_ASLR=1)'}",
      file=sys.stderr)
print(f"malloc={MALLOC_MODE}"
      + ("  (mmap/trim thresholds pinned; buffers recycled)" if MALLOC_MODE == "warm"
         else "  (glibc default -- NOT comparable with warm runs)"),
      file=sys.stderr)
print(f"{cpu_mhz()}", file=sys.stderr)
if governor() not in ("performance", "unknown"):
    print("note: governor is not 'performance'. For a fixed userspace pin at a set "
          "frequency this is fine and is what the report's runs used.", file=sys.stderr)

trials_by = {}
runs_by = {}
detail_rows = []
point_count = 0
# BENCH_STRIPES: byte-range striping for the Reed-Solomon variants.
#
#   unset / "1"  no striping (the grid of record)
#   "auto"       one stated rule, applied identically to every RS label:
#                keep the per-stripe source plane at STRIPE_BUDGET bytes, i.e.
#                N = ceil(k * shard_bytes / STRIPE_BUDGET).
#   <integer>    that many stripes everywhere
#
# `auto` is a policy, not an oracle: it is not the best N per point, it is one
# formula both sides get. At 512 KiB it happens to land on the measured optimum
# at f = 86, 128 and 255 / 4 MiB, and on N = 1 below 2 MiB, where striping does
# nothing for anyone.
#
# **R10 and RaptorQ are never striped.** They could be -- a fountain code's
# decodability depends on which ESIs are held, not on the data, so a shared ESI
# set makes every stripe decode together -- but their per-decode schedule solve
# is internal to the crate and cannot be hoisted out of the stripe loop the way
# eval_poly and ec_init_tables can. Their fixed decode terms are comparable to
# rs_simd's (0.2021 and 0.2537 ms against 0.1827 at f = 255), so striping them
# unhoisted would cost them N times that and misreport the baseline. A striped
# leg is therefore an RS-side column, read beside the unstriped one, and is not
# an all-codec comparison. See PERF-NOTES-STRIPING.md.
STRIPE_MODE = os.environ.get("BENCH_STRIPES", "1").lower()
STRIPE_BUDGET = int(os.environ.get("BENCH_STRIPE_BUDGET", 512 * 1024))


def stripes_for(k, shard_bytes):
    if STRIPE_MODE in ("1", ""):
        return 1
    if STRIPE_MODE == "auto":
        return max(1, -(-k * shard_bytes // STRIPE_BUDGET))
    return max(1, int(STRIPE_MODE))


started = time.time()

for f in FS:
    k = f + 1
    T = 3 * f + 1
    for target_label, target_bytes in TARGETS:
        shard = aligned_shard_bytes(target_bytes, k)
        actual_bytes = k * shard
        for label, codec, field, gen, plan, rsrate in runs_for(f, T):
            if codec == "rq" and not rq_available(shard):
                continue
            pooled = {"encode": [], "decode": [], "plan": [], "code": [], "consumed": []}
            rep_medians = []
            for rep, seed in enumerate(REP_SEEDS, start=1):
                cmd = PREFIX + [
                    str(BIN_FOR[codec]),
                    "--f", str(f),
                    "--shard-bytes", str(shard),
                    "--codec", codec,
                    "--trials", str(TRIALS),
                    "--warmup", str(WARMUPS),
                    "--seed", str(seed),
                    "--phase", PHASE,
                ]
                n_str = stripes_for(k, shard)
                # `isalx` is absent by necessity, not by oversight: X's encoder is the
                # additive transform and `rs_point.c` refuses `--stripes` for it
                # outright ("ISAL8_ENCODE=fft does not stripe"). A byte-range
                # split does not decompose a coset walk over a shared work
                # buffer the way it decomposes a matrix apply. `isalxd` uses the
                # MATRIX encoder and is where X's decode column is read from, so
                # X's decode CAN be striped and is.
                if n_str > 1 and codec in ("isal", "isal16", "isalxd", "rs",
                                           "x16i", "x16t"):
                    cmd += ["--stripes", str(n_str)]
                if codec == "fd":
                    # No --plan, no --field, no --stripes: this driver has one
                    # code and one kernel, and striping is not implemented for
                    # it. F7 -- an implementation difference between the things
                    # measured, disclosed rather than corrected.
                    pass
                elif codec in ("isal", "isal16", "isalx", "isalxd", "x16i", "x16t"):
                    cmd += ["--plan", plan]
                    if codec in FIELD_FOR:
                        cmd += ["--field", FIELD_FOR[codec]]
                else:
                    if rsrate and rsrate != "auto":
                        cmd += ["--rs-rate", rsrate]
                penv = os.environ.copy()
                penv.update(ENV_FOR.get(codec, {}))
                cp = subprocess.run(cmd, cwd=ROOT, text=True, env=penv,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if cp.returncode != 0:
                    sys.stderr.write(cp.stderr)
                    raise SystemExit(f"benchmark process failed: {' '.join(cmd)}")
                rows = list(csv.DictReader(io.StringIO(cp.stdout)))
                if len(rows) != TRIALS:
                    raise SystemExit(
                        f"expected {TRIALS} rows, got {len(rows)} for f={f} "
                        f"target={target_label}MiB shard={shard} rep={rep} {label}"
                    )
                # A phase leg reports ONLY its own half. The other half's fields
                # come back EMPTY and stay empty all the way to the summary, so
                # they are absent rather than zero and nothing can read them as
                # a timing. The two asserts below make that structural: a driver
                # that reports the half it was told not to measure fails the run.
                def col(name):
                    return [float(r[name]) for r in rows if r[name] != ""]
                enc, dec = col("encode_ms"), col("decode_ms")
                pln, cod, con = col("plan_ms"), col("code_ms"), col("consumed_per_k")
                if PHASE == "decode" and enc:
                    raise SystemExit("BENCH_PHASE=decode but a driver reported an "
                                     "encode time; the setup encode must not be timed")
                if PHASE == "encode" and dec:
                    raise SystemExit("BENCH_PHASE=encode but a driver reported a "
                                     "decode time; the decoder must not run in a "
                                     "measured trial")
                for key, vals in (("encode", enc), ("decode", dec), ("plan", pln),
                                  ("code", cod), ("consumed", con)):
                    pooled[key] += vals
                rep_medians.append((statistics.median(enc) if enc else None,
                                    statistics.median(dec) if dec else None))
                for i, r in enumerate(rows):
                    detail_rows.append([
                        f, k, T, target_bytes, shard, actual_bytes, actual_bytes - target_bytes,
                        rep, seed, label, r.get("plan_algo", "-"), i,
                        r["encode_ms"], r["decode_ms"], r["plan_ms"], r["code_ms"],
                        r["symbols_consumed"], r["consumed_per_k"],
                    ])
            trials_by[(f, target_bytes, label)] = pooled
            runs_by[(f, target_bytes, label)] = rep_medians
        point_count += 1
        print(f"\rProgress: {point_count}/{point_total} points "
              f"({time.time() - started:.0f}s)", end="", file=sys.stderr, flush=True)
print(file=sys.stderr)

with DETAIL.open("w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow([
        "f", "k", "T", "target_source_bytes", "shard_bytes", "actual_source_bytes",
        "padding_bytes", "repetition", "seed", "label",
        "plan_algo", "trial", "encode_ms", "decode_ms", "plan_ms", "code_ms",
        "symbols_consumed", "consumed_per_k",
    ])
    w.writerows(detail_rows)

# `*_repmin` / `*_repmax` are the min and max of the REPETITIONS per-invocation
# medians, i.e. the spread ACROSS processes; `*_p50` is their median. `*_p90` and
# `*_max` remain pooled over all REPETITIONS x TRIALS trials, i.e. the spread
# WITHIN processes. The two are different questions and rev 20 only carried the
# second. Section 2 rule 2.
PER_LABEL = ["encode_repmin", "encode_p50", "encode_repmax", "encode_p90",
             "encode_max", "decode_repmin", "decode_p50", "decode_repmax",
             "decode_p90", "decode_max", "plan_p50", "code_p50", "consumed_p50",
             "consumed_p90", "consumed_max"]
header = ["f", "k", "T", "target_MiB", "shard_bytes", "shard_KiB", "actual_MiB",
          "rs_rate", "rs_work_count", "rs_work_over_T"]
for lab in LABELS:
    header += [f"{lab}_{s}" for s in PER_LABEL]
NKEYS = 10
NPL = len(PER_LABEL)

summary = []
for f in FS:
    k = f + 1
    T = 3 * f + 1
    rate, work = rs_rate_and_work(f)
    for target_label, target_bytes in TARGETS:
        shard = aligned_shard_bytes(target_bytes, k)
        row = [f, k, T, float(target_label), shard, shard / 1024.0,
               k * shard / (1024 * 1024), rate, work, work / T]
        for lab in LABELS:
            key = (f, target_bytes, lab)
            if key not in trials_by:
                row += [None] * NPL
                continue
            p = trials_by[key]
            reps = runs_by[key]
            # Empty under a phase leg -- the drivers report no time for the
            # half they were told not to measure -- so these five cells come out
            # BLANK rather than holding a cold setup measurement dressed as a
            # timing. `pct` already returns None on an empty list.
            enc_reps = [r[0] for r in reps if r[0] is not None]
            dec_reps = [r[1] for r in reps if r[1] is not None]
            row += [
                min(enc_reps) if enc_reps else None,
                statistics.median(enc_reps) if enc_reps else None,
                max(enc_reps) if enc_reps else None,
                pct(p["encode"], 90), max(p["encode"]) if p["encode"] else None,
                min(dec_reps) if dec_reps else None,
                statistics.median(dec_reps) if dec_reps else None,
                max(dec_reps) if dec_reps else None,
                pct(p["decode"], 90), max(p["decode"]) if p["decode"] else None,
                statistics.median(p["plan"]) if p["plan"] else None,
                statistics.median(p["code"]) if p["code"] else None,
                statistics.median(p["consumed"]) if p["consumed"] else None,
                pct(p["consumed"], 90),
                max(p["consumed"]) if p["consumed"] else None,
            ]
        summary.append(row)

with SUMMARY.open("w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(header)
    for r in summary:
        w.writerow(["" if x is None else (f"{x:.6f}" if isinstance(x, float) else x)
                    for x in r])

IDX = {lab: NKEYS + NPL * i for i, lab in enumerate(LABELS)}
C = {name: off for off, name in enumerate(PER_LABEL)}


def get(row, lab, field):
    if lab not in IDX:
        return None
    return row[IDX[lab] + C[field]]


def fmt(x, w=9, p=3):
    return " " * (w - 2) + "--" if x is None else f"{x:{w}.{p}f}"


def ratio(a, b, w=8):
    if a is None or b in (None, 0):
        return " " * (w - 2) + "--"
    return f"{a / b:{w - 1}.2f}x"


print()
print("=" * 118)
print("RAPTOR vs REED-SOLOMON -- decode, ms. Median of 3 run medians.")
print("RS-best is the fastest of the paper's Reed-Solomon codecs at that point:")
print("RS-8 where T <= 256, RS-16 at every T, and stock reed-solomon-simd as")
print("the external reference. RS-8's DECODE comes from isal_x_dec, its control")
print("leg, not from isal_x. RS-16 is ONE encoder and TWO decoders -- the imat")
print("and inter labels -- and its figure is the per-shape better of the two,")
print("which is where the k ~ 220 crossover shows up.")
print("cons = shards consumed per k; 1.000 is the MDS minimum, which every RS")
print("variant meets by construction. Raptor codes need more.")
print("=" * 118)
print(f"{'f':>4} {'T':>5} {'MiB':>4} {'shKiB':>7} | {'R10':>8} {'cons':>7} | {'RQ':>8} {'cons':>7} | "
      f"{'RS-simd':>8} | {'RS-best':>8} {'which':>12} | {'R10/RSb':>8}")
print("-" * 118)
for r in summary:
    f, T, mib = r[0], r[2], r[3]
    r10d, rqd, rsd = get(r, "r10", "decode_p50"), get(r, "rq", "decode_p50"), get(r, "rs", "decode_p50")
    cands = [(lab, get(r, lab, "decode_p50"))
             for lab in ("rs", "isal_x_dec", "isal_x16_imat", "isal_x16_inter")]
    cands = [c for c in cands if c[1] is not None]
    bl, bv = min(cands, key=lambda x: x[1]) if cands else ("--", None)
    print(f"{f:4d} {T:5d} {mib:4.1f} {r[5]:7.2f} | {fmt(r10d, 8)} {fmt(get(r,'r10','consumed_p50'), 7, 4)} | "
          f"{fmt(rqd, 8)} {fmt(get(r,'rq','consumed_p50'), 7, 4)} | {fmt(rsd, 8)} | "
          f"{fmt(bv, 8)} {bl:>12} | {ratio(r10d, bv)}")

print()
print("=" * 100)
print("SHARD CONSUMPTION -- the structural cost of a non-MDS code. Per k; 1.000 = MDS.")
print("Pooled over all 60 trials. For a consensus timeout the max, not the median, is")
print("the number that matters: it sets how much data a validator must receive.")
print("=" * 100)
print(f"{'f':>4} {'T':>5} {'MiB':>4} | {'R10 p50':>8} {'R10 p90':>8} {'R10 max':>8} | "
      f"{'RQ p50':>8} {'RQ p90':>8} {'RQ max':>8}")
print("-" * 100)
for r in summary:
    print(f"{r[0]:4d} {r[2]:5d} {r[3]:4.1f} | "
          f"{fmt(get(r,'r10','consumed_p50'),8,4)} {fmt(get(r,'r10','consumed_p90'),8,4)} "
          f"{fmt(get(r,'r10','consumed_max'),8,4)} | "
          f"{fmt(get(r,'rq','consumed_p50'),8,4)} {fmt(get(r,'rq','consumed_p90'),8,4)} "
          f"{fmt(get(r,'rq','consumed_max'),8,4)}")

print()
print("=" * 112)
print("REED-SOLOMON-SIMD WORK-BUFFER STAIRCASE. The FFT work buffer is sized from")
print("recovery_count = 2f, not from T, and sits at its 1.33xT floor only when f is a")
print("power of two. Read the RS column against work/T, never against f alone.")
print("norm = decode / (work_count * shard_bytes) * 1e6; flat means the model holds.")
print("=" * 112)
print(f"{'f':>4} {'T':>5} {'MiB':>4} {'shard B':>9} | {'rate':>5} {'work':>6} {'work/T':>7} | "
      f"{'RS dec':>9} {'norm':>8}")
print("-" * 112)
for r in summary:
    d = get(r, "rs", "decode_p50")
    norm = (d / (r[8] * r[4]) * 1e6) if d else None
    print(f"{r[0]:4d} {r[2]:5d} {r[3]:4.1f} {r[4]:9d} | {r[7]:>5} {r[8]:6d} {r[9]:7.2f} | "
          f"{fmt(d)} {fmt(norm, 8)}")

# The code-term control proper: block work is r*k MACs in every plan variant, so
# within one library the code terms must agree. That needs two or more variants
# at the same point, which only the full label set provides. Comparing across
# libraries is NOT this control -- see the note above.
CTL_VARIANTS = [v for v in ("isal_cauchy", "isal_ge") if v in IDX]
if len(CTL_VARIANTS) > 1:
    print()
    print("=" * 104)
    print("CODE-TERM CONTROL, GF(2^8), within ISA-L. Every plan variant does r*k MACs, so")
    print(f"these must agree. Tolerance is RELATIVE ({CODE_CONTROL_TOL:.0%}): the spread scales with the")
    print("code term, so the fixed 0.005 ms threshold used through v8.1 was wrong by more")
    print("than an order of magnitude at large messages.")
    print("=" * 104)
    print(f"{'f':>4} {'T':>5} {'MiB':>4} | " + " ".join(f"{v:>12}" for v in CTL_VARIANTS)
          + f" | {'spread':>8} {'rel':>7} {'ctl':>6}")
    print("-" * 104)
    ctl_fail = 0
    for r in summary:
        vals = [get(r, v, "code_p50") for v in CTL_VARIANTS]
        vals = [v for v in vals if v is not None]
        if len(vals) < 2:
            continue
        spread = max(vals) - min(vals)
        rel = spread / min(vals)
        ok = "ok"
        if rel > CODE_CONTROL_TOL:
            ok = "CHECK"
            ctl_fail += 1
        cells = " ".join(fmt(get(r, v, "code_p50"), 12) for v in CTL_VARIANTS)
        print(f"{r[0]:4d} {r[2]:5d} {r[3]:4.1f} | {cells} | {spread:8.4f} {rel:6.1%} {ok:>6}")
    if ctl_fail:
        print(f"  {ctl_fail} point(s) exceed {CODE_CONTROL_TOL:.0%}: something other than the plan")
        print("  algorithm moved. Do not compare plan columns at those points.")

print()
print("=" * 106)
print("DECODE STABILITY -- max / median over all 60 trials. Above ~1.5 the median is not")
print("a stable statistic and must not be quoted alone. Raptor codes are bimodal.")
print("=" * 106)
print(f"{'f':>4} {'T':>5} {'MiB':>4} | " + " ".join(f"{lab:>13}" for lab in LABELS))
print("-" * 106)
for r in summary:
    cells = []
    for lab in LABELS:
        mx, md = get(r, lab, "decode_max"), get(r, lab, "decode_p50")
        cells.append(("           --" if not (mx and md) else f"{mx / md:12.2f}x"))
    print(f"{r[0]:4d} {r[2]:5d} {r[3]:4.1f} | " + " ".join(cells))

print()
print("=" * 96)
print("ENCODE -- ms, p50, and stability. Encode is on the critical path for the")
print("proposer only, but MDS encoding is materially dearer than Raptor at large k.")
print("=" * 96)
print(f"{'f':>4} {'T':>5} {'MiB':>4} | {'R10':>8} {'stab':>6} | {'RQ':>8} {'stab':>6} | "
      f"{'RS':>8} {'stab':>6} | {'RS-8/16':>9} {'stab':>6}")
print("-" * 96)
for r in summary:
    def cell(lab):
        p50, mx = get(r, lab, "encode_p50"), get(r, lab, "encode_max")
        s = f"{mx / p50:5.2f}x" if (p50 and mx) else "    --"
        return fmt(p50, 8), s
    # ENCODE is isal_x below the boundary -- the transform encoder, which is
    # what the paper reports -- and isal_cauchy16 above it, where GF(2^8)
    # cannot reach. (DECODE is the other leg, isal_x_dec; see RS-best above.)
    cf = "isal_x" if get(r, "isal_x", "encode_p50") is not None else "isal_x16_imat"
    a, b = cell("r10"); c, d = cell("rq"); e, g = cell("rs"); h, i = cell(cf)
    print(f"{r[0]:4d} {r[2]:5d} {r[3]:4.1f} | {a} {b} | {c} {d} | {e} {g} | {h:>9} {i}")

print()
# Relative to the artifact root. These two lines are quoted into logs that
# ship and into reports, so an absolute path leaks the builder's home
# directory and username for no gain -- the files are always under results/.
def _rel(p):
    try:
        return p.relative_to(ROOT)
    except ValueError:
        return p
print(f"detail:  {_rel(DETAIL)}")
print(f"summary: {_rel(SUMMARY)}")
print(f"elapsed: {time.time() - started:.0f}s")
