#!/bin/sh
# Unpack the Python packages fdrs/generators/ needs, without root and
# without pip -- neither pip nor ensurepip is present on the machine of report
# section 1.10, and the project's convention for that is localtools/ (see the
# nasm .deb already there).
#
# Wheels are zip archives with the package directory at the top level, so
# unzipping them onto PYTHONPATH is a complete install for a pure build-time
# tool. Nothing here is linked into a driver or measured; it exists only to run
# firedancer's own code generators. localtools/ is gitignored.
set -eu
cd "$(dirname "$0")"
DEST="$PWD/localtools/pygen"
if [ -d "$DEST/galois" ] && [ -d "$DEST/numpy" ]; then
    echo "fdgen toolchain already present at $DEST"
    exit 0
fi
mkdir -p "$DEST"
python3 - "$DEST" <<'PY'
import io, json, sys, urllib.request, zipfile
dest = sys.argv[1]
# galois pulls numba, which pulls llvmlite; all four plus typing_extensions.
for pkg in ("numpy", "llvmlite", "numba", "galois", "typing_extensions"):
    meta = json.load(urllib.request.urlopen(
        f"https://pypi.org/pypi/{pkg}/json", timeout=60))
    ver = meta["info"]["version"]
    tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
    best = None
    for f in meta["releases"][ver]:
        n = f["filename"]
        if not n.endswith(".whl"):
            continue
        if "py3-none-any" in n:
            best = f
            break
        if tag in n and "manylinux" in n and "x86_64" in n and "musl" not in n:
            best = f
    if best is None:
        raise SystemExit(f"no wheel for {pkg} {ver} on {tag}/linux-x86_64")
    print(f"  {pkg} {ver}: {best['filename']}", flush=True)
    zipfile.ZipFile(io.BytesIO(
        urllib.request.urlopen(best["url"], timeout=600).read())).extractall(dest)
PY
echo "fdgen toolchain unpacked to $DEST"
echo "use it with: PYTHONPATH=$DEST python3 ..."
