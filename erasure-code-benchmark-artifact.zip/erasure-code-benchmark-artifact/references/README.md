# references/ — external comparison

Firedancer's `reedsol`, and nothing else. Three parts:

| | |
|---|---|
| `fd_point.c` | the benchmark adapter: Firedancer's encoder and recovery behind this harness's `K`-of-`n` contract and its 15-column CSV |
| `fdrs/` | Firedancer's own `src/ballet/reedsol` tree, keeping their layout so every relative include resolves as it does upstream |
| `bootstrap-fdgen.sh` | unpacks the Python wheels their code generators need, into `localtools/pygen`, without root |

## What was changed, and why it is a port rather than an optimization

**Only Firedancer's policy size ceilings are raised** — their data and parity
shred maxima — so the same construction covers this paper's shapes. At n = 3f+1
the parity bound binds first, and the shipped values reach only a small corner of
this grid. Upstream's own comment calls them *"limits based on current Solana
needs and performance"*, not mathematical limits.

That is a **port needed to make the comparison possible at all**, which is why it
ships, where an optimization of a baseline's numbers would not — the same
distinction that keeps the locally optimized `reed-solomon-simd` out of this
artifact. `fdrs/generators/PARAMETERS.diff` is the complete difference from the
pinned upstream commit, and `fdrs/regen.sh` refuses to write unless the *unraised*
generators first reproduce upstream's own shipped files byte for byte.

The decode adapter omits parity reconstruction and corruption checking, which are
not charged to any other codec here.

## Build

`../bootstrap-isal.sh` builds this directory's binaries alongside `codec/`'s,
against the one `isa-l.a`. **`Makefile`'s `CFLAGS` are identical to
`../codec/Makefile`'s and must stay identical**, because the two binaries are
compared against each other.

`../check.sh` runs the four nulls that license the port; one of them needs a
pinned upstream clone at `../firedancer/` and reports `SKIPPED` without it, since
that tree is not ours to redistribute.
