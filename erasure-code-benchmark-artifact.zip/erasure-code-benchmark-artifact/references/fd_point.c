/*
 * fd_point.c -- firedancer's `src/ballet/reedsol` encoder, on this benchmark's
 *               encode timer, against ISA-L's Cauchy encoder on the same one.
 *
 * Report section 10 item 25 records firedancer's reedsol as read but not
 * measured. This driver measures it. It is the Lin/Al-Naffouri/Han/Chung
 * additive-FFT construction over GF(2^8), generated and fully unrolled per
 * size, with a hand-written AVX-512 + GFNI assembly kernel for the 32:32 shape
 * Turbine uses. It is a *different code* from `isal_cauchy` -- different
 * generator, different parity bytes -- so there is no cross-library digest
 * between them, only a cross-backend one within firedancer (see --digest).
 *
 * WHAT IS AND IS NOT HERE
 *
 * Encode only. `--codec fd` and `--codec isal` are the two variants and exactly
 * one runs per process, which is rev 11 section 3.6's rule: two variants timed in
 * one process is worth up to 55% from ordering alone. `--codec isal` exists as
 * the harness null -- it must reproduce `rs-point --field 8 --plan ge`'s encode
 * column, since it is the same ec_encode_data on the same pool at the same
 * stride -- and to reach shapes rs-point cannot express, which take (k, m)
 * directly rather than deriving them from f.
 *
 * Decode is timed under HARNESS-FAIRNESS-MATRIX.md's contract, not under
 * firedancer's API. `--decode-contract bench` (default) reconstructs the k data
 * shards and reports the `plan` / `code` split the four MDS labels report;
 * `--decode-contract fd` calls their `fd_reedsol_recover_fini` whole and is the
 * null for it. fdrs/generators/generate_recover_bench.py has the three
 * differences and why each is required -- all three make firedancer faster.
 * Under `fd` there is no split, because gen_pi is inside their kernel, so it
 * reports `plan = 0` and `code = decode`, which is F6's convention.
 *
 * THE ENCODE TIMER
 *
 * Byte for byte the region rs_point.c's run_gf8 times under its default
 * (ISAL_ENC_TIMER=lean): the per-call parity output buffer allocation, at the
 * pool's own stride, and the coding kernel. Outside it: the k*sz scatter of the
 * source into the shard pool, the copy of parity back into the pool, and the
 * free. Shape-only setup is hoisted out of the loop for both codecs -- ISA-L's
 * ec_init_tables, firedancer's encoder object -- which is HARNESS-FAIRNESS-
 * MATRIX.md rule 1.
 *
 * The one asymmetry worth naming: firedancer's API takes its shards as two
 * pointer arrays built by fd_reedsol_encode_add_{data,parity}_shred, and those
 * k + m pointer stores are inside the timer, because a caller cannot avoid
 * them. ISA-L's equivalent -- filling enc_out[] -- is inside its timer too, so
 * the two sides are charged the same thing, and at k + m <= 134 stores against
 * a kernel of milliseconds it is not a term either way.
 *
 * SHAPES firedancer CAN REACH
 *
 * FD_REEDSOL_{DATA,PARITY}_SHREDS_MAX are 67 each. At this report's rate,
 * k = f+1 and m = 2f, so the parity limit binds first and f <= 33. The whole
 * intersection with grid.py's FS is {31, 32, 33}. Report section 10 item 25's
 * "f <= 44" is the T = 134 total-shred bound and is not the binding one.
 *
 *   usage: fd-point --f <f> --shard-bytes <n> [--trials N] [--warmup W]
 *                   [--seed S] [--codec fd|isal] [--k K --m M] [--digest]
 *                   [--no-verify]
 *   env:   ISAL_SHARD_PAD   the pool stride rule, shared with rs-point
 *          FD_ENC_REPEAT=N  N encodes inside one timed region, as
 *                           ISAL_ENC_REPEAT is for rs-point
 */
#include "rs_common.h"
/* private.h, not fd_reedsol.h: it is what selects and reports the arithmetic
 * backend, and which backend ran belongs in every row this driver prints. */
#include "fd_reedsol_private.h"
#include "fd_reedsol_recover_bench.h"

#if   FD_REEDSOL_ARITH_IMPL==0
#define FD_ARITH_NAME "generic"
#elif FD_REEDSOL_ARITH_IMPL==1
#define FD_ARITH_NAME "avx2"
#elif FD_REEDSOL_ARITH_IMPL==2
#define FD_ARITH_NAME "gfni"
#else
#define FD_ARITH_NAME "gfni-avx512"
#endif

/*
 * --phase decode: the setup encode is NOT A MEASUREMENT. It exists only to
 * produce a codeword for the decoder to work on, so it is neither reported nor
 * treated as a timing, and the encode field is emitted EMPTY.
 *
 * Empty rather than zero and rather than the value: a consumer that reaches for
 * it gets nothing instead of a wrong number. Reporting it was a mistake. It is
 * ONE COLD ENCODE PER PROCESS, paying that process's page faults on the shard
 * pool and the transform work buffer, and it read 5.1x the interleaved figure
 * at f = 33 / 0.5 MiB while looking like an ordinary encode_ms.
 */
static const char *enc_field(char *buf, size_t n, int phase_decode, double ms)
{
	if (phase_decode)
		buf[0] = '\0';
	else
		snprintf(buf, n, "%.6f", ms);
	return buf;
}

static void usage(const char *p)
{
	fprintf(stderr,
		"usage: %s --f <f> --shard-bytes <n> [options]\n"
		"  --codec fd|isal   which encoder (default fd); one per process\n"
		"  --k K --m M       explicit shape, instead of k=f+1, m=2f\n"
		"  --trials N        measured trials (default 20)\n"
		"  --warmup W        unmeasured trials first (default 3)\n"
		"  --seed S          harness seed (default 1)\n"
		"  --digest          encode once, print an FNV-1a 64 digest of the\n"
		"                    source and of the parity, and exit\n"
		"  --decode-contract bench|fd   bench (default) is this benchmark's\n"
		"                    decode contract, fd is firedancer's whole API\n"
		"  --no-verify       skip the reconstruction check\n",
		p);
}

int main(int argc, char **argv)
{
	int f = -1, k = -1, m = -1;
	long shard_bytes = -1;
	int trials = 20, warmup = 3, verify = 1, digest_only = 0;
	/* --phase decode: see rs_point.c. Same contract, same default. */
	int phase_decode = 0;
	int phase_encode = 0;
	uint64_t seed = 1;
	int codec_fd = 1, contract_fd = 0, do_decode = 1, arrivals = 0;

	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--f") && i + 1 < argc)
			f = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--k") && i + 1 < argc)
			k = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--m") && i + 1 < argc)
			m = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--shard-bytes") && i + 1 < argc)
			shard_bytes = atol(argv[++i]);
		else if (!strcmp(argv[i], "--trials") && i + 1 < argc)
			trials = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--warmup") && i + 1 < argc)
			warmup = atoi(argv[++i]);
		else if (!strcmp(argv[i], "--seed") && i + 1 < argc)
			seed = strtoull(argv[++i], NULL, 10);
		else if (!strcmp(argv[i], "--digest"))
			digest_only = 1;
		else if (!strcmp(argv[i], "--no-verify"))
			verify = 0;
		else if (!strcmp(argv[i], "--phase") && i + 1 < argc) {
			const char *ph = argv[++i];
			if (!strcmp(ph, "decode"))
				phase_decode = 1;
			else if (!strcmp(ph, "encode"))
				phase_encode = 1;
			else if (strcmp(ph, "both")) {
				fprintf(stderr, "--phase must be both, encode or decode\n");
				return 2;
			}
		}
		/* Diagnostic only, and NOT a measurement configuration: rs-point
		 * encodes and decodes in the same trial, so an encode timed in a
		 * process that never decodes sees a different cache state between
		 * trials and is not comparable with it. This exists to isolate the
		 * encoder when that is the question being asked. */
		else if (!strcmp(argv[i], "--no-decode"))
			do_decode = 0;
		/* Diagnostic, NOT the measurement configuration. The harness contract is
		 * a uniformly random arrival order, which is what `random` does and what
		 * every other label is measured under. `first` delivers shards 0..k-1,
		 * i.e. every data shard present and nothing to reconstruct but the
		 * ordering; `dataheavy` erases only within the data range. They exist to
		 * show what this decoder's cost is actually a function of. */
		else if (!strcmp(argv[i], "--arrivals") && i + 1 < argc) {
			const char *a = argv[++i];
			if (!strcmp(a, "random")) arrivals = 0;
			else if (!strcmp(a, "first")) arrivals = 1;
			else { fprintf(stderr, "unknown --arrivals %s\n", a); return 2; }
		}
		else if (!strcmp(argv[i], "--decode-contract") && i + 1 < argc) {
			const char *d = argv[++i];
			if (!strcmp(d, "bench"))
				contract_fd = 0;
			else if (!strcmp(d, "fd"))
				contract_fd = 1;
			else {
				fprintf(stderr, "unknown --decode-contract %s; use bench or fd\n", d);
				return 2;
			}
		}
		else if (!strcmp(argv[i], "--codec") && i + 1 < argc) {
			const char *c = argv[++i];
			if (!strcmp(c, "fd"))
				codec_fd = 1;
			else if (!strcmp(c, "isal"))
				codec_fd = 0;
			else {
				fprintf(stderr, "unknown --codec %s; use fd or isal\n", c);
				return 2;
			}
		} else {
			usage(argv[0]);
			return 2;
		}
	}

	/* The shape. --f is the report's rate; --k/--m reach the shapes it cannot
	 * name, of which firedancer's own 32:32 is the one that matters. */
	if (k < 0 || m < 0) {
		if (f < 1) {
			usage(argv[0]);
			return 2;
		}
		k = f + 1;
		m = 2 * f;
	} else if (f < 0) {
		f = -1; /* reported as -1: this row is not a point on the f grid */
	}
	if (shard_bytes < 1 || k < 1 || m < 1) {
		usage(argv[0]);
		return 2;
	}
	int t = k + m;
	if (t > 256) {
		fprintf(stderr, "GF(2^8) needs T<=256, but k=%d m=%d gives T=%d\n",
			k, m, t);
		return 2;
	}
	if (codec_fd) {
		if (k > (int)FD_REEDSOL_DATA_SHREDS_MAX ||
		    m > (int)FD_REEDSOL_PARITY_SHREDS_MAX) {
			fprintf(stderr,
				"firedancer reedsol caps data at %lu and parity at %lu "
				"shreds; k=%d m=%d is out of reach (at k=f+1, m=2f that "
				"is f<=%d).\n",
				FD_REEDSOL_DATA_SHREDS_MAX, FD_REEDSOL_PARITY_SHREDS_MAX,
				k, m, (int)FD_REEDSOL_PARITY_SHREDS_MAX / 2);
			return 2;
		}
		if (shard_bytes < 32) {
			fprintf(stderr, "firedancer reedsol needs shred_sz >= 32\n");
			return 2;
		}
	}
	size_t sz = (size_t)shard_bytes;
	size_t stride = shard_stride(sz);
	/* The configuration, named by its knob set rather than by a label. */
	const char *plan_algo = !codec_fd ? "isal-ge"
			      : contract_fd ? FD_ARITH_NAME "/contract-fd"
					    : FD_ARITH_NAME "/contract-bench";

	/* Buffers. Same layout as rs_point.c's: one page-aligned pool of t shards
	 * at `stride`, and a separate contiguous source the trial scatters from. */
	unsigned char *src = malloc((size_t)k * sz);
	unsigned char **shard = malloc((size_t)t * sizeof(*shard));
	size_t pool_bytes = ((size_t)t * stride + 4095) & ~(size_t)4095;
	unsigned char *pool = aligned_alloc(4096, pool_bytes);
	if (!src || !shard || !pool) {
		fprintf(stderr, "allocation failed\n");
		return 1;
	}
	memset(pool, 0, pool_bytes);
	for (int i = 0; i < t; i++)
		shard[i] = pool + (size_t)i * stride;
	unsigned char **enc_out = malloc((size_t)m * sizeof(*enc_out));

	/* ---- shape-only setup, hoisted out of the loop for both codecs ---- */

	/* ISA-L: the generator and its coefficient tables. gf_gen_cauchy1_matrix,
	 * i.e. rs-point's `--plan ge` generator, so `--digest` is comparable with
	 * it directly. The encode kernel does not depend on which plan the decoder
	 * would use, so the encode column is the null for `--plan cauchy` too. */
	unsigned char *gen = NULL, *enc_tab = NULL;
	if (!codec_fd) {
		gen = malloc((size_t)t * k);
		enc_tab = malloc((size_t)k * m * 32);
		gf_gen_cauchy1_matrix(gen, t, k);
		ec_init_tables(k, m, gen + (size_t)k * k, enc_tab);
	}

	/* firedancer: the encoder object. 2304 bytes at 128-byte alignment, of
	 * which 1024 is the scratch the 32:32 assembly kernel uses. It carries no
	 * shape and no tables -- the constants are a .rodata blob linked in -- so
	 * this is bookkeeping storage, the counterpart of enc_tab above. */
	void *fd_mem = NULL, *fd_rec_mem = NULL;
	if (codec_fd) {
		fd_mem = aligned_alloc(FD_REEDSOL_ALIGN, FD_REEDSOL_FOOTPRINT);
		fd_rec_mem = aligned_alloc(FD_REEDSOL_ALIGN, FD_REEDSOL_FOOTPRINT);
		if (!fd_mem || !fd_rec_mem) {
			fprintf(stderr, "fd_reedsol_t allocation failed\n");
			return 1;
		}
	}

	int *order = malloc((size_t)t * sizeof(int));
	char *got = malloc((size_t)t);
	/* --phase decode's codeword, built once at setup and never written
	 * again. NULL under the default interleaved loop, which allocates
	 * nothing new. */
	unsigned char *code = NULL;

	/* Decode scratch that the PLAN writes into.
	 *
	 * Process-lifetime, which is what rs_point.c does with the equivalent --
	 * `rows`, `binv`, `xs`, `ys` are all allocated once and the plan fills them
	 * per call. The per-call allocation rule (rule 3) applies to the buffers the
	 * CODE phase works in, and those are allocated below, inside that phase,
	 * exactly as `pc_dec_tab` and `pc_whole` are.
	 *
	 * `shredp` is 256 entries whatever T is: recover addresses a whole n-wide
	 * block and n can exceed T. The entries past T are never loaded, since
	 * `_erased` is set for them, but they must be readable pointers rather than
	 * garbage, so they point at a scratch shard.
	 */
	unsigned char *dead = malloc(sz);
	unsigned char **shredp = malloc(256 * sizeof(*shredp));
	/* aligned_alloc, not malloc: gen_pi declares its two arrays W_ATTR, i.e.
	 * 32-byte aligned, and reads and writes them with aligned vector ops. A
	 * malloc'd buffer is 16-byte aligned on this ABI and segfaults about half
	 * the time, which is the worst kind of half. */
	unsigned char *erased = aligned_alloc(128, 256);
	unsigned char *ferased = aligned_alloc(128, 256);
	unsigned char *pi = aligned_alloc(128, 256);
	if (!dead || !shredp || !erased || !ferased || !pi) {
		fprintf(stderr, "decode scratch allocation failed\n");
		return 1;
	}
	memset(dead, 0, sz);
	unsigned char *whole = NULL;	/* materialized message; per call, in `code` */
	void *fd_bench_mem = codec_fd ? aligned_alloc(FD_REEDSOL_ALIGN,
						      FD_REEDSOL_FOOTPRINT) : NULL;

	long enc_reps = getenv("FD_ENC_REPEAT") ? atol(getenv("FD_ENC_REPEAT")) : 1;
	if (enc_reps < 1)
		enc_reps = 1;

	if (!digest_only)
		/* rs_point.c's CSV schema exactly, so robust_benchmark.py reads this
		 * driver with the same csv.DictReader it reads that one with and
		 * fd_reedsol is a label rather than a special case. `plan_algo` carries
		 * the arithmetic backend and the decode contract, which is what names
		 * this configuration -- report rule 3, name it by its knob set. */
		printf("f,k,T,symbol_bytes,trial,codec,tape_field,tape_gen,plan_algo,"
		       "encode_ms,decode_ms,plan_ms,code_ms,symbols_consumed,"
		       "consumed_per_k\n");

	char encbuf[32];
	for (int trial = -warmup; trial < trials; trial++) {
		/* rs_point.c's seed derivation, unchanged, so a run of this driver and
		 * a run of rs-point at the same f, shard size and seed encode the same
		 * source bytes and draw the same arrival order. */
		uint64_t s = seed ^ ((uint64_t)f << 48) ^ ((uint64_t)k << 32) ^ (uint64_t)t
			^ (((uint64_t)sz << 17) | ((uint64_t)sz >> 47))
			^ (trial < 0
			   ? (uint64_t)(trial + warmup) * 0x9e3779b97f4a7c15ULL
			   : (uint64_t)(trial + warmup) * 0xd1b54a32d192ed03ULL);

		/* --phase decode: fill and encode ONCE, at the first warmup trial;
		 * every later trial re-decodes that codeword under a fresh erasure
		 * pattern. Verification returns the pool to its encoded state, so it
		 * is required. Same contract as rs_point.c's two mains. */
		int do_encode = !phase_decode || trial == -warmup;
		if (do_encode) {
			sm64 rs = { s ^ 0x535243ULL };
			sm64_fill(&rs, src, (size_t)k * sz);
		}
		for (int i = 0; i < t; i++)
			order[i] = i;
		sm64 ro = { s ^ 0x4f52444552ULL };
		sm64_shuffle(&ro, order, t);

		/* Under --phase decode this is the ONE setup encode, reported in
		 * every row. Not the encode number of record. */
		/* Zero and unused under --phase decode: the setup encode is not a
		 * measurement and no value is carried between trials. enc_field()
		 * emits the column EMPTY there. */
		double encode_ms = 0.0;
		if (do_encode) {
			/* Outside the timer, as run_gf8's lean encode timer has it. */
			for (int i = 0; i < k; i++)
				memcpy(shard[i], src + (size_t)i * sz, sz);

			/* ------------------------------ the encode timer ----------------- */
			double t0 = now_ms();
			/* Parity output buffer, per call, inside the timer: F2 in
			 * HARNESS-FAIRNESS-MATRIX.md, and the same spelling rs_point.c uses.
			 * Same stride as the pool, so section 3.1's non-aliasing layout holds and
			 * the only variable is where the memory came from. No memset -- both
			 * kernels write every byte before reading it. */
			unsigned char *pc_par = aligned_alloc(4096,
				(((size_t)m * stride) + 4095) & ~(size_t)4095);
			if (!pc_par) {
				fprintf(stderr, "per-call parity allocation failed\n");
				return 1;
			}
			for (int i = 0; i < m; i++)
				enc_out[i] = pc_par + (size_t)i * stride;

			if (codec_fd) {
				for (long rep = 0; rep < enc_reps; rep++) {
					fd_reedsol_t *e = fd_reedsol_encode_init(fd_mem, sz);
					for (int i = 0; i < k; i++)
						fd_reedsol_encode_add_data_shred(e, shard[i]);
					for (int i = 0; i < m; i++)
						fd_reedsol_encode_add_parity_shred(e, enc_out[i]);
					fd_reedsol_encode_fini(e);
				}
			} else {
				for (long rep = 0; rep < enc_reps; rep++)
					ec_encode_data((int)sz, k, m, enc_tab, shard, enc_out);
			}
			encode_ms = (now_ms() - t0) / (double)enc_reps;
			/* ----------------------------- end of the timer ------------------ */

			/* Outside the timer: hand the parity to the pool the check reads. */
			for (int i = 0; i < m; i++)
				memcpy(shard[k + i], enc_out[i], sz);
			free(pc_par);
		if (phase_decode) {
			/* The codeword, snapshotted once. Immutable from here on. */
			if (!code) {
				code = malloc((size_t)t * sz);
				if (!code) {
					fprintf(stderr, "codeword allocation failed\n");
					return 1;
				}
			}
			for (int i = 0; i < t; i++)
				memcpy(code + (size_t)i * sz, shard[i], sz);
		}
		}

		if (digest_only) {
			uint64_t hs = 0xcbf29ce484222325ULL, hp = 0xcbf29ce484222325ULL;
			for (int i = 0; i < k; i++)
				hs = fnv1a(shard[i], sz, hs);
			for (int i = k; i < t; i++)
				hp = fnv1a(shard[i], sz, hp);
			printf("digest codec=%s k=%d m=%d T=%d shard_bytes=%zu seed=%llu "
			       "src=%016llx parity=%016llx\n",
			       codec_fd ? "fd" : "isal", k, m, t, sz,
			       (unsigned long long)seed,
			       (unsigned long long)hs, (unsigned long long)hp);
			return 0;
		}

		/* --phase encode: THE DECODER DOES NOT RUN IN A MEASURED TRIAL. It runs
		 * once, at the first warmup trial, purely as the correctness gate; every
		 * measured trial is encode alone, with no decoder working set in cache
		 * when the encode timer starts. Report section 6.8 measured that mirror
		 * effect -- the decoder's buffers moving the ENCODE timer -- and this is
		 * what removes it, symmetrically with what --phase decode does for the
		 * encoder.
		 *
		 * decode_ms, plan_ms, code_ms, symbols_consumed and consumed_per_k are
		 * emitted EMPTY. Absent, not zero: a consumer that reaches for them gets
		 * nothing rather than a wrong number, which is the same rule the encode
		 * column follows under --phase decode. */
		if (phase_encode && trial != -warmup) {
			if (trial >= 0)
				printf("%d,%d,%d,%zu,%d,%s,gf8,%s,%s,%s,,,,,\n",
				       f, k, t, sz, trial,
				       codec_fd ? "fd_reedsol" : "isal",
				       codec_fd ? "fd-ppt-fft" : "isal-cauchy1",
				       plan_algo,
				       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms));
			continue;
		}
		/* ---- decode: exactly the first k arrivals ---- */
		memset(got, 0, (size_t)t);
		for (int i = 0; i < k; i++)
			got[arrivals ? i : order[i]] = 1;
		/* Zero the slots the receiver never got. The pool still holds the
		 * correct bytes from the encode above, and leaving them would let a
		 * decode that writes nothing pass verification. Outside both timers, as
		 * the equivalent loop in rs_point.c's run_gf8 is. */
		/* --phase decode: COPY THE SHARDS THIS TRIAL DECODES FROM into the
		 * pool, out of the codeword built once at setup. The codeword itself is
		 * never written, so there is nothing to restore and no ordering between
		 * trials.
		 *
		 * WHY A COPY AND NOT THE NARROWER RESTORE IT REPLACES: what matters is
		 * not that the out-of-timer work be SMALL, it is that it be THE SAME IN
		 * BOTH MODES. The interleaved loop already does a k*sz copy-in above,
		 * before its timer starts. Matching it here makes `decode` equal `both`
		 * minus exactly the encoder, so the delta measures the encoder and
		 * nothing else. The restore did not match it, and that asymmetry is what
		 * made labels with no contamination read BELOW 1.0 -- leopard 0.947,
		 * tape_gf16 0.894 -- which was an artefact of the instrument, not a
		 * property of the codec. Outside both timers. */
		if (phase_decode)
			for (int j = 0; j < t; j++)
				if (got[j])
					memcpy(shard[j], code + (size_t)j * sz, sz);
		for (int j = 0; j < t; j++)
			if (!got[j])
				memset(shard[j], 0, sz);

		double plan_ms = 0.0, code_ms = 0.0;
		if (!codec_fd || !do_decode) {
			/* ISA-L decode lives in rs-point, which is the label of record and
			 * verifies its own reconstruction every trial. Re-deriving a second
			 * inverse here would be checking this driver against itself. */
			plan_ms = code_ms = 0.0;
		} else if (contract_fd) {
			/* Their whole API, as a deployment would call it: it rebuilds every
			 * erased shred including parity, and it verifies. No plan/code split
			 * is available because gen_pi is inside the kernel, so this reports
			 * plan = 0 and code = decode, which is F6's convention. */
			double t1 = now_ms();
			fd_reedsol_t *d = fd_reedsol_recover_init(fd_rec_mem, sz);
			for (int i = 0; i < t; i++) {
				if (got[i])
					fd_reedsol_recover_add_rcvd_shred(d, i < k, shard[i]);
				else
					fd_reedsol_recover_add_erased_shred(d, i < k, shard[i]);
			}
			int err = fd_reedsol_recover_fini(d);
			whole = malloc((size_t)k * sz);
			if (!whole) {
				fprintf(stderr, "per-call message allocation failed\n");
				return 1;
			}
			for (int i = 0; i < k; i++)
				memcpy(whole + (size_t)i * sz, shard[i], sz);
			code_ms = now_ms() - t1;
			if (err != FD_REEDSOL_SUCCESS) {
				fprintf(stderr, "fd_reedsol_recover failed k=%d m=%d trial=%d: "
					"%s\n", k, m, trial, fd_reedsol_strerror(err));
				return 1;
			}
		} else {
			/* ---- plan ----
			 * Survivor bookkeeping and the pattern-dependent plan, which for
			 * this construction is the erasure locator: the block width, the
			 * decoder's own erasure mask, and gen_pi. Writes into
			 * process-lifetime scratch, as rs_point.c's plan does. */
			double t1 = now_ms();
			for (int i = 0; i < t; i++)
				erased[i] = (unsigned char)!got[i];
			/* fd_reedsol_recover_fini's own rule: find how far in we must look
			 * to see k un-erased shreds, and take the block that covers it. */
			int unerased = 0, last = t - 1;
			for (int i = 0; i < t; i++) {
				unerased += got[i];
				if (unerased == k) { last = i; break; }
			}
			if (unerased != k) {
				fprintf(stderr, "fewer than k survivors k=%d trial=%d\n",
					k, trial);
				return 1;
			}
			unsigned n = last < 16 ? 16 : last < 32 ? 32 : last < 64 ? 64
				   : last < 128 ? 128 : 256;
			int loaded = 0;
			for (unsigned i = 0; i < n; i++) {
				int use = ((int)i < t) && (loaded < k) && !erased[i];
				ferased[i] = (unsigned char)!use;
				loaded += use;
			}
			for (unsigned i = (unsigned)t; i < n; i++)
				erased[i] = 0;	/* past the block: nothing to store */
			switch (n) {
			case 16:  fd_reedsol_private_gen_pi_16 (ferased, pi); break;
			case 32:  fd_reedsol_private_gen_pi_32 (ferased, pi); break;
			case 64:  fd_reedsol_private_gen_pi_64 (ferased, pi); break;
			case 128: fd_reedsol_private_gen_pi_128(ferased, pi); break;
			default:  fd_reedsol_private_gen_pi_256(ferased, pi); break;
			}
			plan_ms = now_ms() - t1;
			if (trial == 0 && getenv("FD_TRACE_N"))
				fprintf(stderr, "f=%d k=%d T=%d last=%d n=%u erased_data=%d\n",
					f, k, t, last, n, k - (int)0);

			/* ---- code ----
			 * Per-call working memory first, inside the timer, exactly where
			 * rs_point.c puts pc_dec_tab and pc_whole. */
			double t2 = now_ms();
			whole = malloc((size_t)k * sz);
			if (!whole) {
				fprintf(stderr, "per-call message allocation failed\n");
				return 1;
			}
			for (int i = 0; i < t; i++)
				shredp[i] = shard[i];
			for (unsigned i = (unsigned)t; i < n; i++)
				shredp[i] = dead;
			switch (n) {
			case 16:  fd_reedsol_private_recover_bench_16 (sz, shredp, (ulong)k, erased, ferased, pi); break;
			case 32:  fd_reedsol_private_recover_bench_32 (sz, shredp, (ulong)k, erased, ferased, pi); break;
			case 64:  fd_reedsol_private_recover_bench_64 (sz, shredp, (ulong)k, erased, ferased, pi); break;
			case 128: fd_reedsol_private_recover_bench_128(sz, shredp, (ulong)k, erased, ferased, pi); break;
			default:  fd_reedsol_private_recover_bench_256(sz, shredp, (ulong)k, erased, ferased, pi); break;
			}
			for (int i = 0; i < k; i++)
				memcpy(whole + (size_t)i * sz, shard[i], sz);
			code_ms = now_ms() - t2;
		}

		if (verify && codec_fd && do_decode) {
			if (memcmp(whole, src, (size_t)k * sz)) {
				fprintf(stderr, "fd materialized source mismatch k=%d m=%d "
					"trial=%d\n", k, m, trial);
				return 1;
			}
			for (int i = 0; i < k; i++)
				if (memcmp(shard[i], src + (size_t)i * sz, sz)) {
					fprintf(stderr, "fd reconstruction mismatch k=%d m=%d "
						"shard=%d trial=%d\n", k, m, i, trial);
					return 1;
				}
		}
		/* Outside the timer, as every other codec's free is. */
		free(whole);
		whole = NULL;

		if (trial >= 0)
			printf("%d,%d,%d,%zu,%d,%s,gf8,%s,%s,"
			       "%s,%.6f,%.6f,%.6f,%d,%.8f\n",
			       f, k, t, sz, trial,
			       codec_fd ? "fd_reedsol" : "isal",
			       codec_fd ? "fd-ppt-fft" : "isal-cauchy1",
			       plan_algo,
			       enc_field(encbuf, sizeof encbuf, phase_decode, encode_ms), plan_ms + code_ms, plan_ms, code_ms, k, 1.0);
	}
	return 0;
}
