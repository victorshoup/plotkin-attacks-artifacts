/* Note: This file is auto generated. */
#include "fd_reedsol_ppt.h"
#include "fd_reedsol_fderiv.h"

FD_FN_UNSANITIZED int
fd_reedsol_private_recover_var_256( ulong           shred_sz,
                                    uchar * const * shred,
                                    ulong           data_shred_cnt,
                                    ulong           parity_shred_cnt,
                                    uchar const *   erased ) {
  uchar _erased[ 256 ] W_ATTR;
  uchar pi[      256 ] W_ATTR;
  ulong shred_cnt = data_shred_cnt + parity_shred_cnt;
  ulong loaded_cnt = 0UL;
  for( ulong i=0UL; i<256UL; i++) {
    int load_shred = ((i<shred_cnt)&(loaded_cnt<data_shred_cnt))&&( erased[ i ]==0 );
    _erased[ i ] = !load_shred;
    loaded_cnt += (ulong)load_shred;
  }
  if( FD_UNLIKELY( loaded_cnt<data_shred_cnt ) ) return FD_REEDSOL_ERR_PARTIAL;

  fd_reedsol_private_gen_pi_256( _erased, pi );

  /* Store the difference for each shred that was regenerated.  This
     must be 0.  Otherwise there's a corrupt shred. */
  gf_t diff = gf_zero();

  for( ulong shred_pos=0UL; shred_pos<shred_sz; /* advanced manually at end of loop */ ) {
    /* Load exactly data_shred_cnt un-erased input shreds into
       their respective vector.  Fill the erased vectors with 0. */
    gf_t in00 = _erased[  0 ] ? gf_zero() : gf_ldu( shred[  0 ] + shred_pos );
    gf_t in01 = _erased[  1 ] ? gf_zero() : gf_ldu( shred[  1 ] + shred_pos );
    gf_t in02 = _erased[  2 ] ? gf_zero() : gf_ldu( shred[  2 ] + shred_pos );
    gf_t in03 = _erased[  3 ] ? gf_zero() : gf_ldu( shred[  3 ] + shred_pos );
    gf_t in04 = _erased[  4 ] ? gf_zero() : gf_ldu( shred[  4 ] + shred_pos );
    gf_t in05 = _erased[  5 ] ? gf_zero() : gf_ldu( shred[  5 ] + shred_pos );
    gf_t in06 = _erased[  6 ] ? gf_zero() : gf_ldu( shred[  6 ] + shred_pos );
    gf_t in07 = _erased[  7 ] ? gf_zero() : gf_ldu( shred[  7 ] + shred_pos );
    gf_t in08 = _erased[  8 ] ? gf_zero() : gf_ldu( shred[  8 ] + shred_pos );
    gf_t in09 = _erased[  9 ] ? gf_zero() : gf_ldu( shred[  9 ] + shred_pos );
    gf_t in10 = _erased[ 10 ] ? gf_zero() : gf_ldu( shred[ 10 ] + shred_pos );
    gf_t in11 = _erased[ 11 ] ? gf_zero() : gf_ldu( shred[ 11 ] + shred_pos );
    gf_t in12 = _erased[ 12 ] ? gf_zero() : gf_ldu( shred[ 12 ] + shred_pos );
    gf_t in13 = _erased[ 13 ] ? gf_zero() : gf_ldu( shred[ 13 ] + shred_pos );
    gf_t in14 = _erased[ 14 ] ? gf_zero() : gf_ldu( shred[ 14 ] + shred_pos );
    gf_t in15 = _erased[ 15 ] ? gf_zero() : gf_ldu( shred[ 15 ] + shred_pos );
    gf_t in16 = _erased[ 16 ] ? gf_zero() : gf_ldu( shred[ 16 ] + shred_pos );
    gf_t in17 = _erased[ 17 ] ? gf_zero() : gf_ldu( shred[ 17 ] + shred_pos );
    gf_t in18 = _erased[ 18 ] ? gf_zero() : gf_ldu( shred[ 18 ] + shred_pos );
    gf_t in19 = _erased[ 19 ] ? gf_zero() : gf_ldu( shred[ 19 ] + shred_pos );
    gf_t in20 = _erased[ 20 ] ? gf_zero() : gf_ldu( shred[ 20 ] + shred_pos );
    gf_t in21 = _erased[ 21 ] ? gf_zero() : gf_ldu( shred[ 21 ] + shred_pos );
    gf_t in22 = _erased[ 22 ] ? gf_zero() : gf_ldu( shred[ 22 ] + shred_pos );
    gf_t in23 = _erased[ 23 ] ? gf_zero() : gf_ldu( shred[ 23 ] + shred_pos );
    gf_t in24 = _erased[ 24 ] ? gf_zero() : gf_ldu( shred[ 24 ] + shred_pos );
    gf_t in25 = _erased[ 25 ] ? gf_zero() : gf_ldu( shred[ 25 ] + shred_pos );
    gf_t in26 = _erased[ 26 ] ? gf_zero() : gf_ldu( shred[ 26 ] + shred_pos );
    gf_t in27 = _erased[ 27 ] ? gf_zero() : gf_ldu( shred[ 27 ] + shred_pos );
    gf_t in28 = _erased[ 28 ] ? gf_zero() : gf_ldu( shred[ 28 ] + shred_pos );
    gf_t in29 = _erased[ 29 ] ? gf_zero() : gf_ldu( shred[ 29 ] + shred_pos );
    gf_t in30 = _erased[ 30 ] ? gf_zero() : gf_ldu( shred[ 30 ] + shred_pos );
    gf_t in31 = _erased[ 31 ] ? gf_zero() : gf_ldu( shred[ 31 ] + shred_pos );
    gf_t in32 = _erased[ 32 ] ? gf_zero() : gf_ldu( shred[ 32 ] + shred_pos );
    gf_t in33 = _erased[ 33 ] ? gf_zero() : gf_ldu( shred[ 33 ] + shred_pos );
    gf_t in34 = _erased[ 34 ] ? gf_zero() : gf_ldu( shred[ 34 ] + shred_pos );
    gf_t in35 = _erased[ 35 ] ? gf_zero() : gf_ldu( shred[ 35 ] + shred_pos );
    gf_t in36 = _erased[ 36 ] ? gf_zero() : gf_ldu( shred[ 36 ] + shred_pos );
    gf_t in37 = _erased[ 37 ] ? gf_zero() : gf_ldu( shred[ 37 ] + shred_pos );
    gf_t in38 = _erased[ 38 ] ? gf_zero() : gf_ldu( shred[ 38 ] + shred_pos );
    gf_t in39 = _erased[ 39 ] ? gf_zero() : gf_ldu( shred[ 39 ] + shred_pos );
    gf_t in40 = _erased[ 40 ] ? gf_zero() : gf_ldu( shred[ 40 ] + shred_pos );
    gf_t in41 = _erased[ 41 ] ? gf_zero() : gf_ldu( shred[ 41 ] + shred_pos );
    gf_t in42 = _erased[ 42 ] ? gf_zero() : gf_ldu( shred[ 42 ] + shred_pos );
    gf_t in43 = _erased[ 43 ] ? gf_zero() : gf_ldu( shred[ 43 ] + shred_pos );
    gf_t in44 = _erased[ 44 ] ? gf_zero() : gf_ldu( shred[ 44 ] + shred_pos );
    gf_t in45 = _erased[ 45 ] ? gf_zero() : gf_ldu( shred[ 45 ] + shred_pos );
    gf_t in46 = _erased[ 46 ] ? gf_zero() : gf_ldu( shred[ 46 ] + shred_pos );
    gf_t in47 = _erased[ 47 ] ? gf_zero() : gf_ldu( shred[ 47 ] + shred_pos );
    gf_t in48 = _erased[ 48 ] ? gf_zero() : gf_ldu( shred[ 48 ] + shred_pos );
    gf_t in49 = _erased[ 49 ] ? gf_zero() : gf_ldu( shred[ 49 ] + shred_pos );
    gf_t in50 = _erased[ 50 ] ? gf_zero() : gf_ldu( shred[ 50 ] + shred_pos );
    gf_t in51 = _erased[ 51 ] ? gf_zero() : gf_ldu( shred[ 51 ] + shred_pos );
    gf_t in52 = _erased[ 52 ] ? gf_zero() : gf_ldu( shred[ 52 ] + shred_pos );
    gf_t in53 = _erased[ 53 ] ? gf_zero() : gf_ldu( shred[ 53 ] + shred_pos );
    gf_t in54 = _erased[ 54 ] ? gf_zero() : gf_ldu( shred[ 54 ] + shred_pos );
    gf_t in55 = _erased[ 55 ] ? gf_zero() : gf_ldu( shred[ 55 ] + shred_pos );
    gf_t in56 = _erased[ 56 ] ? gf_zero() : gf_ldu( shred[ 56 ] + shred_pos );
    gf_t in57 = _erased[ 57 ] ? gf_zero() : gf_ldu( shred[ 57 ] + shred_pos );
    gf_t in58 = _erased[ 58 ] ? gf_zero() : gf_ldu( shred[ 58 ] + shred_pos );
    gf_t in59 = _erased[ 59 ] ? gf_zero() : gf_ldu( shred[ 59 ] + shred_pos );
    gf_t in60 = _erased[ 60 ] ? gf_zero() : gf_ldu( shred[ 60 ] + shred_pos );
    gf_t in61 = _erased[ 61 ] ? gf_zero() : gf_ldu( shred[ 61 ] + shred_pos );
    gf_t in62 = _erased[ 62 ] ? gf_zero() : gf_ldu( shred[ 62 ] + shred_pos );
    gf_t in63 = _erased[ 63 ] ? gf_zero() : gf_ldu( shred[ 63 ] + shred_pos );
    gf_t in64 = _erased[ 64 ] ? gf_zero() : gf_ldu( shred[ 64 ] + shred_pos );
    gf_t in65 = _erased[ 65 ] ? gf_zero() : gf_ldu( shred[ 65 ] + shred_pos );
    gf_t in66 = _erased[ 66 ] ? gf_zero() : gf_ldu( shred[ 66 ] + shred_pos );
    gf_t in67 = _erased[ 67 ] ? gf_zero() : gf_ldu( shred[ 67 ] + shred_pos );
    gf_t in68 = _erased[ 68 ] ? gf_zero() : gf_ldu( shred[ 68 ] + shred_pos );
    gf_t in69 = _erased[ 69 ] ? gf_zero() : gf_ldu( shred[ 69 ] + shred_pos );
    gf_t in70 = _erased[ 70 ] ? gf_zero() : gf_ldu( shred[ 70 ] + shred_pos );
    gf_t in71 = _erased[ 71 ] ? gf_zero() : gf_ldu( shred[ 71 ] + shred_pos );
    gf_t in72 = _erased[ 72 ] ? gf_zero() : gf_ldu( shred[ 72 ] + shred_pos );
    gf_t in73 = _erased[ 73 ] ? gf_zero() : gf_ldu( shred[ 73 ] + shred_pos );
    gf_t in74 = _erased[ 74 ] ? gf_zero() : gf_ldu( shred[ 74 ] + shred_pos );
    gf_t in75 = _erased[ 75 ] ? gf_zero() : gf_ldu( shred[ 75 ] + shred_pos );
    gf_t in76 = _erased[ 76 ] ? gf_zero() : gf_ldu( shred[ 76 ] + shred_pos );
    gf_t in77 = _erased[ 77 ] ? gf_zero() : gf_ldu( shred[ 77 ] + shred_pos );
    gf_t in78 = _erased[ 78 ] ? gf_zero() : gf_ldu( shred[ 78 ] + shred_pos );
    gf_t in79 = _erased[ 79 ] ? gf_zero() : gf_ldu( shred[ 79 ] + shred_pos );
    gf_t in80 = _erased[ 80 ] ? gf_zero() : gf_ldu( shred[ 80 ] + shred_pos );
    gf_t in81 = _erased[ 81 ] ? gf_zero() : gf_ldu( shred[ 81 ] + shred_pos );
    gf_t in82 = _erased[ 82 ] ? gf_zero() : gf_ldu( shred[ 82 ] + shred_pos );
    gf_t in83 = _erased[ 83 ] ? gf_zero() : gf_ldu( shred[ 83 ] + shred_pos );
    gf_t in84 = _erased[ 84 ] ? gf_zero() : gf_ldu( shred[ 84 ] + shred_pos );
    gf_t in85 = _erased[ 85 ] ? gf_zero() : gf_ldu( shred[ 85 ] + shred_pos );
    gf_t in86 = _erased[ 86 ] ? gf_zero() : gf_ldu( shred[ 86 ] + shred_pos );
    gf_t in87 = _erased[ 87 ] ? gf_zero() : gf_ldu( shred[ 87 ] + shred_pos );
    gf_t in88 = _erased[ 88 ] ? gf_zero() : gf_ldu( shred[ 88 ] + shred_pos );
    gf_t in89 = _erased[ 89 ] ? gf_zero() : gf_ldu( shred[ 89 ] + shred_pos );
    gf_t in90 = _erased[ 90 ] ? gf_zero() : gf_ldu( shred[ 90 ] + shred_pos );
    gf_t in91 = _erased[ 91 ] ? gf_zero() : gf_ldu( shred[ 91 ] + shred_pos );
    gf_t in92 = _erased[ 92 ] ? gf_zero() : gf_ldu( shred[ 92 ] + shred_pos );
    gf_t in93 = _erased[ 93 ] ? gf_zero() : gf_ldu( shred[ 93 ] + shred_pos );
    gf_t in94 = _erased[ 94 ] ? gf_zero() : gf_ldu( shred[ 94 ] + shred_pos );
    gf_t in95 = _erased[ 95 ] ? gf_zero() : gf_ldu( shred[ 95 ] + shred_pos );
    gf_t in96 = _erased[ 96 ] ? gf_zero() : gf_ldu( shred[ 96 ] + shred_pos );
    gf_t in97 = _erased[ 97 ] ? gf_zero() : gf_ldu( shred[ 97 ] + shred_pos );
    gf_t in98 = _erased[ 98 ] ? gf_zero() : gf_ldu( shred[ 98 ] + shred_pos );
    gf_t in99 = _erased[ 99 ] ? gf_zero() : gf_ldu( shred[ 99 ] + shred_pos );
    gf_t in100 = _erased[ 100 ] ? gf_zero() : gf_ldu( shred[ 100 ] + shred_pos );
    gf_t in101 = _erased[ 101 ] ? gf_zero() : gf_ldu( shred[ 101 ] + shred_pos );
    gf_t in102 = _erased[ 102 ] ? gf_zero() : gf_ldu( shred[ 102 ] + shred_pos );
    gf_t in103 = _erased[ 103 ] ? gf_zero() : gf_ldu( shred[ 103 ] + shred_pos );
    gf_t in104 = _erased[ 104 ] ? gf_zero() : gf_ldu( shred[ 104 ] + shred_pos );
    gf_t in105 = _erased[ 105 ] ? gf_zero() : gf_ldu( shred[ 105 ] + shred_pos );
    gf_t in106 = _erased[ 106 ] ? gf_zero() : gf_ldu( shred[ 106 ] + shred_pos );
    gf_t in107 = _erased[ 107 ] ? gf_zero() : gf_ldu( shred[ 107 ] + shred_pos );
    gf_t in108 = _erased[ 108 ] ? gf_zero() : gf_ldu( shred[ 108 ] + shred_pos );
    gf_t in109 = _erased[ 109 ] ? gf_zero() : gf_ldu( shred[ 109 ] + shred_pos );
    gf_t in110 = _erased[ 110 ] ? gf_zero() : gf_ldu( shred[ 110 ] + shred_pos );
    gf_t in111 = _erased[ 111 ] ? gf_zero() : gf_ldu( shred[ 111 ] + shred_pos );
    gf_t in112 = _erased[ 112 ] ? gf_zero() : gf_ldu( shred[ 112 ] + shred_pos );
    gf_t in113 = _erased[ 113 ] ? gf_zero() : gf_ldu( shred[ 113 ] + shred_pos );
    gf_t in114 = _erased[ 114 ] ? gf_zero() : gf_ldu( shred[ 114 ] + shred_pos );
    gf_t in115 = _erased[ 115 ] ? gf_zero() : gf_ldu( shred[ 115 ] + shred_pos );
    gf_t in116 = _erased[ 116 ] ? gf_zero() : gf_ldu( shred[ 116 ] + shred_pos );
    gf_t in117 = _erased[ 117 ] ? gf_zero() : gf_ldu( shred[ 117 ] + shred_pos );
    gf_t in118 = _erased[ 118 ] ? gf_zero() : gf_ldu( shred[ 118 ] + shred_pos );
    gf_t in119 = _erased[ 119 ] ? gf_zero() : gf_ldu( shred[ 119 ] + shred_pos );
    gf_t in120 = _erased[ 120 ] ? gf_zero() : gf_ldu( shred[ 120 ] + shred_pos );
    gf_t in121 = _erased[ 121 ] ? gf_zero() : gf_ldu( shred[ 121 ] + shred_pos );
    gf_t in122 = _erased[ 122 ] ? gf_zero() : gf_ldu( shred[ 122 ] + shred_pos );
    gf_t in123 = _erased[ 123 ] ? gf_zero() : gf_ldu( shred[ 123 ] + shred_pos );
    gf_t in124 = _erased[ 124 ] ? gf_zero() : gf_ldu( shred[ 124 ] + shred_pos );
    gf_t in125 = _erased[ 125 ] ? gf_zero() : gf_ldu( shred[ 125 ] + shred_pos );
    gf_t in126 = _erased[ 126 ] ? gf_zero() : gf_ldu( shred[ 126 ] + shred_pos );
    gf_t in127 = _erased[ 127 ] ? gf_zero() : gf_ldu( shred[ 127 ] + shred_pos );
    gf_t in128 = _erased[ 128 ] ? gf_zero() : gf_ldu( shred[ 128 ] + shred_pos );
    gf_t in129 = _erased[ 129 ] ? gf_zero() : gf_ldu( shred[ 129 ] + shred_pos );
    gf_t in130 = _erased[ 130 ] ? gf_zero() : gf_ldu( shred[ 130 ] + shred_pos );
    gf_t in131 = _erased[ 131 ] ? gf_zero() : gf_ldu( shred[ 131 ] + shred_pos );
    gf_t in132 = _erased[ 132 ] ? gf_zero() : gf_ldu( shred[ 132 ] + shred_pos );
    gf_t in133 = _erased[ 133 ] ? gf_zero() : gf_ldu( shred[ 133 ] + shred_pos );
    gf_t in134 = _erased[ 134 ] ? gf_zero() : gf_ldu( shred[ 134 ] + shred_pos );
    gf_t in135 = _erased[ 135 ] ? gf_zero() : gf_ldu( shred[ 135 ] + shred_pos );
    gf_t in136 = _erased[ 136 ] ? gf_zero() : gf_ldu( shred[ 136 ] + shred_pos );
    gf_t in137 = _erased[ 137 ] ? gf_zero() : gf_ldu( shred[ 137 ] + shred_pos );
    gf_t in138 = _erased[ 138 ] ? gf_zero() : gf_ldu( shred[ 138 ] + shred_pos );
    gf_t in139 = _erased[ 139 ] ? gf_zero() : gf_ldu( shred[ 139 ] + shred_pos );
    gf_t in140 = _erased[ 140 ] ? gf_zero() : gf_ldu( shred[ 140 ] + shred_pos );
    gf_t in141 = _erased[ 141 ] ? gf_zero() : gf_ldu( shred[ 141 ] + shred_pos );
    gf_t in142 = _erased[ 142 ] ? gf_zero() : gf_ldu( shred[ 142 ] + shred_pos );
    gf_t in143 = _erased[ 143 ] ? gf_zero() : gf_ldu( shred[ 143 ] + shred_pos );
    gf_t in144 = _erased[ 144 ] ? gf_zero() : gf_ldu( shred[ 144 ] + shred_pos );
    gf_t in145 = _erased[ 145 ] ? gf_zero() : gf_ldu( shred[ 145 ] + shred_pos );
    gf_t in146 = _erased[ 146 ] ? gf_zero() : gf_ldu( shred[ 146 ] + shred_pos );
    gf_t in147 = _erased[ 147 ] ? gf_zero() : gf_ldu( shred[ 147 ] + shred_pos );
    gf_t in148 = _erased[ 148 ] ? gf_zero() : gf_ldu( shred[ 148 ] + shred_pos );
    gf_t in149 = _erased[ 149 ] ? gf_zero() : gf_ldu( shred[ 149 ] + shred_pos );
    gf_t in150 = _erased[ 150 ] ? gf_zero() : gf_ldu( shred[ 150 ] + shred_pos );
    gf_t in151 = _erased[ 151 ] ? gf_zero() : gf_ldu( shred[ 151 ] + shred_pos );
    gf_t in152 = _erased[ 152 ] ? gf_zero() : gf_ldu( shred[ 152 ] + shred_pos );
    gf_t in153 = _erased[ 153 ] ? gf_zero() : gf_ldu( shred[ 153 ] + shred_pos );
    gf_t in154 = _erased[ 154 ] ? gf_zero() : gf_ldu( shred[ 154 ] + shred_pos );
    gf_t in155 = _erased[ 155 ] ? gf_zero() : gf_ldu( shred[ 155 ] + shred_pos );
    gf_t in156 = _erased[ 156 ] ? gf_zero() : gf_ldu( shred[ 156 ] + shred_pos );
    gf_t in157 = _erased[ 157 ] ? gf_zero() : gf_ldu( shred[ 157 ] + shred_pos );
    gf_t in158 = _erased[ 158 ] ? gf_zero() : gf_ldu( shred[ 158 ] + shred_pos );
    gf_t in159 = _erased[ 159 ] ? gf_zero() : gf_ldu( shred[ 159 ] + shred_pos );
    gf_t in160 = _erased[ 160 ] ? gf_zero() : gf_ldu( shred[ 160 ] + shred_pos );
    gf_t in161 = _erased[ 161 ] ? gf_zero() : gf_ldu( shred[ 161 ] + shred_pos );
    gf_t in162 = _erased[ 162 ] ? gf_zero() : gf_ldu( shred[ 162 ] + shred_pos );
    gf_t in163 = _erased[ 163 ] ? gf_zero() : gf_ldu( shred[ 163 ] + shred_pos );
    gf_t in164 = _erased[ 164 ] ? gf_zero() : gf_ldu( shred[ 164 ] + shred_pos );
    gf_t in165 = _erased[ 165 ] ? gf_zero() : gf_ldu( shred[ 165 ] + shred_pos );
    gf_t in166 = _erased[ 166 ] ? gf_zero() : gf_ldu( shred[ 166 ] + shred_pos );
    gf_t in167 = _erased[ 167 ] ? gf_zero() : gf_ldu( shred[ 167 ] + shred_pos );
    gf_t in168 = _erased[ 168 ] ? gf_zero() : gf_ldu( shred[ 168 ] + shred_pos );
    gf_t in169 = _erased[ 169 ] ? gf_zero() : gf_ldu( shred[ 169 ] + shred_pos );
    gf_t in170 = _erased[ 170 ] ? gf_zero() : gf_ldu( shred[ 170 ] + shred_pos );
    gf_t in171 = _erased[ 171 ] ? gf_zero() : gf_ldu( shred[ 171 ] + shred_pos );
    gf_t in172 = _erased[ 172 ] ? gf_zero() : gf_ldu( shred[ 172 ] + shred_pos );
    gf_t in173 = _erased[ 173 ] ? gf_zero() : gf_ldu( shred[ 173 ] + shred_pos );
    gf_t in174 = _erased[ 174 ] ? gf_zero() : gf_ldu( shred[ 174 ] + shred_pos );
    gf_t in175 = _erased[ 175 ] ? gf_zero() : gf_ldu( shred[ 175 ] + shred_pos );
    gf_t in176 = _erased[ 176 ] ? gf_zero() : gf_ldu( shred[ 176 ] + shred_pos );
    gf_t in177 = _erased[ 177 ] ? gf_zero() : gf_ldu( shred[ 177 ] + shred_pos );
    gf_t in178 = _erased[ 178 ] ? gf_zero() : gf_ldu( shred[ 178 ] + shred_pos );
    gf_t in179 = _erased[ 179 ] ? gf_zero() : gf_ldu( shred[ 179 ] + shred_pos );
    gf_t in180 = _erased[ 180 ] ? gf_zero() : gf_ldu( shred[ 180 ] + shred_pos );
    gf_t in181 = _erased[ 181 ] ? gf_zero() : gf_ldu( shred[ 181 ] + shred_pos );
    gf_t in182 = _erased[ 182 ] ? gf_zero() : gf_ldu( shred[ 182 ] + shred_pos );
    gf_t in183 = _erased[ 183 ] ? gf_zero() : gf_ldu( shred[ 183 ] + shred_pos );
    gf_t in184 = _erased[ 184 ] ? gf_zero() : gf_ldu( shred[ 184 ] + shred_pos );
    gf_t in185 = _erased[ 185 ] ? gf_zero() : gf_ldu( shred[ 185 ] + shred_pos );
    gf_t in186 = _erased[ 186 ] ? gf_zero() : gf_ldu( shred[ 186 ] + shred_pos );
    gf_t in187 = _erased[ 187 ] ? gf_zero() : gf_ldu( shred[ 187 ] + shred_pos );
    gf_t in188 = _erased[ 188 ] ? gf_zero() : gf_ldu( shred[ 188 ] + shred_pos );
    gf_t in189 = _erased[ 189 ] ? gf_zero() : gf_ldu( shred[ 189 ] + shred_pos );
    gf_t in190 = _erased[ 190 ] ? gf_zero() : gf_ldu( shred[ 190 ] + shred_pos );
    gf_t in191 = _erased[ 191 ] ? gf_zero() : gf_ldu( shred[ 191 ] + shred_pos );
    gf_t in192 = _erased[ 192 ] ? gf_zero() : gf_ldu( shred[ 192 ] + shred_pos );
    gf_t in193 = _erased[ 193 ] ? gf_zero() : gf_ldu( shred[ 193 ] + shred_pos );
    gf_t in194 = _erased[ 194 ] ? gf_zero() : gf_ldu( shred[ 194 ] + shred_pos );
    gf_t in195 = _erased[ 195 ] ? gf_zero() : gf_ldu( shred[ 195 ] + shred_pos );
    gf_t in196 = _erased[ 196 ] ? gf_zero() : gf_ldu( shred[ 196 ] + shred_pos );
    gf_t in197 = _erased[ 197 ] ? gf_zero() : gf_ldu( shred[ 197 ] + shred_pos );
    gf_t in198 = _erased[ 198 ] ? gf_zero() : gf_ldu( shred[ 198 ] + shred_pos );
    gf_t in199 = _erased[ 199 ] ? gf_zero() : gf_ldu( shred[ 199 ] + shred_pos );
    gf_t in200 = _erased[ 200 ] ? gf_zero() : gf_ldu( shred[ 200 ] + shred_pos );
    gf_t in201 = _erased[ 201 ] ? gf_zero() : gf_ldu( shred[ 201 ] + shred_pos );
    gf_t in202 = _erased[ 202 ] ? gf_zero() : gf_ldu( shred[ 202 ] + shred_pos );
    gf_t in203 = _erased[ 203 ] ? gf_zero() : gf_ldu( shred[ 203 ] + shred_pos );
    gf_t in204 = _erased[ 204 ] ? gf_zero() : gf_ldu( shred[ 204 ] + shred_pos );
    gf_t in205 = _erased[ 205 ] ? gf_zero() : gf_ldu( shred[ 205 ] + shred_pos );
    gf_t in206 = _erased[ 206 ] ? gf_zero() : gf_ldu( shred[ 206 ] + shred_pos );
    gf_t in207 = _erased[ 207 ] ? gf_zero() : gf_ldu( shred[ 207 ] + shred_pos );
    gf_t in208 = _erased[ 208 ] ? gf_zero() : gf_ldu( shred[ 208 ] + shred_pos );
    gf_t in209 = _erased[ 209 ] ? gf_zero() : gf_ldu( shred[ 209 ] + shred_pos );
    gf_t in210 = _erased[ 210 ] ? gf_zero() : gf_ldu( shred[ 210 ] + shred_pos );
    gf_t in211 = _erased[ 211 ] ? gf_zero() : gf_ldu( shred[ 211 ] + shred_pos );
    gf_t in212 = _erased[ 212 ] ? gf_zero() : gf_ldu( shred[ 212 ] + shred_pos );
    gf_t in213 = _erased[ 213 ] ? gf_zero() : gf_ldu( shred[ 213 ] + shred_pos );
    gf_t in214 = _erased[ 214 ] ? gf_zero() : gf_ldu( shred[ 214 ] + shred_pos );
    gf_t in215 = _erased[ 215 ] ? gf_zero() : gf_ldu( shred[ 215 ] + shred_pos );
    gf_t in216 = _erased[ 216 ] ? gf_zero() : gf_ldu( shred[ 216 ] + shred_pos );
    gf_t in217 = _erased[ 217 ] ? gf_zero() : gf_ldu( shred[ 217 ] + shred_pos );
    gf_t in218 = _erased[ 218 ] ? gf_zero() : gf_ldu( shred[ 218 ] + shred_pos );
    gf_t in219 = _erased[ 219 ] ? gf_zero() : gf_ldu( shred[ 219 ] + shred_pos );
    gf_t in220 = _erased[ 220 ] ? gf_zero() : gf_ldu( shred[ 220 ] + shred_pos );
    gf_t in221 = _erased[ 221 ] ? gf_zero() : gf_ldu( shred[ 221 ] + shred_pos );
    gf_t in222 = _erased[ 222 ] ? gf_zero() : gf_ldu( shred[ 222 ] + shred_pos );
    gf_t in223 = _erased[ 223 ] ? gf_zero() : gf_ldu( shred[ 223 ] + shred_pos );
    gf_t in224 = _erased[ 224 ] ? gf_zero() : gf_ldu( shred[ 224 ] + shred_pos );
    gf_t in225 = _erased[ 225 ] ? gf_zero() : gf_ldu( shred[ 225 ] + shred_pos );
    gf_t in226 = _erased[ 226 ] ? gf_zero() : gf_ldu( shred[ 226 ] + shred_pos );
    gf_t in227 = _erased[ 227 ] ? gf_zero() : gf_ldu( shred[ 227 ] + shred_pos );
    gf_t in228 = _erased[ 228 ] ? gf_zero() : gf_ldu( shred[ 228 ] + shred_pos );
    gf_t in229 = _erased[ 229 ] ? gf_zero() : gf_ldu( shred[ 229 ] + shred_pos );
    gf_t in230 = _erased[ 230 ] ? gf_zero() : gf_ldu( shred[ 230 ] + shred_pos );
    gf_t in231 = _erased[ 231 ] ? gf_zero() : gf_ldu( shred[ 231 ] + shred_pos );
    gf_t in232 = _erased[ 232 ] ? gf_zero() : gf_ldu( shred[ 232 ] + shred_pos );
    gf_t in233 = _erased[ 233 ] ? gf_zero() : gf_ldu( shred[ 233 ] + shred_pos );
    gf_t in234 = _erased[ 234 ] ? gf_zero() : gf_ldu( shred[ 234 ] + shred_pos );
    gf_t in235 = _erased[ 235 ] ? gf_zero() : gf_ldu( shred[ 235 ] + shred_pos );
    gf_t in236 = _erased[ 236 ] ? gf_zero() : gf_ldu( shred[ 236 ] + shred_pos );
    gf_t in237 = _erased[ 237 ] ? gf_zero() : gf_ldu( shred[ 237 ] + shred_pos );
    gf_t in238 = _erased[ 238 ] ? gf_zero() : gf_ldu( shred[ 238 ] + shred_pos );
    gf_t in239 = _erased[ 239 ] ? gf_zero() : gf_ldu( shred[ 239 ] + shred_pos );
    gf_t in240 = _erased[ 240 ] ? gf_zero() : gf_ldu( shred[ 240 ] + shred_pos );
    gf_t in241 = _erased[ 241 ] ? gf_zero() : gf_ldu( shred[ 241 ] + shred_pos );
    gf_t in242 = _erased[ 242 ] ? gf_zero() : gf_ldu( shred[ 242 ] + shred_pos );
    gf_t in243 = _erased[ 243 ] ? gf_zero() : gf_ldu( shred[ 243 ] + shred_pos );
    gf_t in244 = _erased[ 244 ] ? gf_zero() : gf_ldu( shred[ 244 ] + shred_pos );
    gf_t in245 = _erased[ 245 ] ? gf_zero() : gf_ldu( shred[ 245 ] + shred_pos );
    gf_t in246 = _erased[ 246 ] ? gf_zero() : gf_ldu( shred[ 246 ] + shred_pos );
    gf_t in247 = _erased[ 247 ] ? gf_zero() : gf_ldu( shred[ 247 ] + shred_pos );
    gf_t in248 = _erased[ 248 ] ? gf_zero() : gf_ldu( shred[ 248 ] + shred_pos );
    gf_t in249 = _erased[ 249 ] ? gf_zero() : gf_ldu( shred[ 249 ] + shred_pos );
    gf_t in250 = _erased[ 250 ] ? gf_zero() : gf_ldu( shred[ 250 ] + shred_pos );
    gf_t in251 = _erased[ 251 ] ? gf_zero() : gf_ldu( shred[ 251 ] + shred_pos );
    gf_t in252 = _erased[ 252 ] ? gf_zero() : gf_ldu( shred[ 252 ] + shred_pos );
    gf_t in253 = _erased[ 253 ] ? gf_zero() : gf_ldu( shred[ 253 ] + shred_pos );
    gf_t in254 = _erased[ 254 ] ? gf_zero() : gf_ldu( shred[ 254 ] + shred_pos );
    gf_t in255 = _erased[ 255 ] ? gf_zero() : gf_ldu( shred[ 255 ] + shred_pos );
    /* Technically, we only need to multiply the non-erased ones, since
       the erased ones are 0, but we know at least half of them are
       non-erased, and the branch is going to be just as costly as the
       multiply. */
    in00 = GF_MUL_VAR( in00, pi[  0 ] );
    in01 = GF_MUL_VAR( in01, pi[  1 ] );
    in02 = GF_MUL_VAR( in02, pi[  2 ] );
    in03 = GF_MUL_VAR( in03, pi[  3 ] );
    in04 = GF_MUL_VAR( in04, pi[  4 ] );
    in05 = GF_MUL_VAR( in05, pi[  5 ] );
    in06 = GF_MUL_VAR( in06, pi[  6 ] );
    in07 = GF_MUL_VAR( in07, pi[  7 ] );
    in08 = GF_MUL_VAR( in08, pi[  8 ] );
    in09 = GF_MUL_VAR( in09, pi[  9 ] );
    in10 = GF_MUL_VAR( in10, pi[ 10 ] );
    in11 = GF_MUL_VAR( in11, pi[ 11 ] );
    in12 = GF_MUL_VAR( in12, pi[ 12 ] );
    in13 = GF_MUL_VAR( in13, pi[ 13 ] );
    in14 = GF_MUL_VAR( in14, pi[ 14 ] );
    in15 = GF_MUL_VAR( in15, pi[ 15 ] );
    in16 = GF_MUL_VAR( in16, pi[ 16 ] );
    in17 = GF_MUL_VAR( in17, pi[ 17 ] );
    in18 = GF_MUL_VAR( in18, pi[ 18 ] );
    in19 = GF_MUL_VAR( in19, pi[ 19 ] );
    in20 = GF_MUL_VAR( in20, pi[ 20 ] );
    in21 = GF_MUL_VAR( in21, pi[ 21 ] );
    in22 = GF_MUL_VAR( in22, pi[ 22 ] );
    in23 = GF_MUL_VAR( in23, pi[ 23 ] );
    in24 = GF_MUL_VAR( in24, pi[ 24 ] );
    in25 = GF_MUL_VAR( in25, pi[ 25 ] );
    in26 = GF_MUL_VAR( in26, pi[ 26 ] );
    in27 = GF_MUL_VAR( in27, pi[ 27 ] );
    in28 = GF_MUL_VAR( in28, pi[ 28 ] );
    in29 = GF_MUL_VAR( in29, pi[ 29 ] );
    in30 = GF_MUL_VAR( in30, pi[ 30 ] );
    in31 = GF_MUL_VAR( in31, pi[ 31 ] );
    in32 = GF_MUL_VAR( in32, pi[ 32 ] );
    in33 = GF_MUL_VAR( in33, pi[ 33 ] );
    in34 = GF_MUL_VAR( in34, pi[ 34 ] );
    in35 = GF_MUL_VAR( in35, pi[ 35 ] );
    in36 = GF_MUL_VAR( in36, pi[ 36 ] );
    in37 = GF_MUL_VAR( in37, pi[ 37 ] );
    in38 = GF_MUL_VAR( in38, pi[ 38 ] );
    in39 = GF_MUL_VAR( in39, pi[ 39 ] );
    in40 = GF_MUL_VAR( in40, pi[ 40 ] );
    in41 = GF_MUL_VAR( in41, pi[ 41 ] );
    in42 = GF_MUL_VAR( in42, pi[ 42 ] );
    in43 = GF_MUL_VAR( in43, pi[ 43 ] );
    in44 = GF_MUL_VAR( in44, pi[ 44 ] );
    in45 = GF_MUL_VAR( in45, pi[ 45 ] );
    in46 = GF_MUL_VAR( in46, pi[ 46 ] );
    in47 = GF_MUL_VAR( in47, pi[ 47 ] );
    in48 = GF_MUL_VAR( in48, pi[ 48 ] );
    in49 = GF_MUL_VAR( in49, pi[ 49 ] );
    in50 = GF_MUL_VAR( in50, pi[ 50 ] );
    in51 = GF_MUL_VAR( in51, pi[ 51 ] );
    in52 = GF_MUL_VAR( in52, pi[ 52 ] );
    in53 = GF_MUL_VAR( in53, pi[ 53 ] );
    in54 = GF_MUL_VAR( in54, pi[ 54 ] );
    in55 = GF_MUL_VAR( in55, pi[ 55 ] );
    in56 = GF_MUL_VAR( in56, pi[ 56 ] );
    in57 = GF_MUL_VAR( in57, pi[ 57 ] );
    in58 = GF_MUL_VAR( in58, pi[ 58 ] );
    in59 = GF_MUL_VAR( in59, pi[ 59 ] );
    in60 = GF_MUL_VAR( in60, pi[ 60 ] );
    in61 = GF_MUL_VAR( in61, pi[ 61 ] );
    in62 = GF_MUL_VAR( in62, pi[ 62 ] );
    in63 = GF_MUL_VAR( in63, pi[ 63 ] );
    in64 = GF_MUL_VAR( in64, pi[ 64 ] );
    in65 = GF_MUL_VAR( in65, pi[ 65 ] );
    in66 = GF_MUL_VAR( in66, pi[ 66 ] );
    in67 = GF_MUL_VAR( in67, pi[ 67 ] );
    in68 = GF_MUL_VAR( in68, pi[ 68 ] );
    in69 = GF_MUL_VAR( in69, pi[ 69 ] );
    in70 = GF_MUL_VAR( in70, pi[ 70 ] );
    in71 = GF_MUL_VAR( in71, pi[ 71 ] );
    in72 = GF_MUL_VAR( in72, pi[ 72 ] );
    in73 = GF_MUL_VAR( in73, pi[ 73 ] );
    in74 = GF_MUL_VAR( in74, pi[ 74 ] );
    in75 = GF_MUL_VAR( in75, pi[ 75 ] );
    in76 = GF_MUL_VAR( in76, pi[ 76 ] );
    in77 = GF_MUL_VAR( in77, pi[ 77 ] );
    in78 = GF_MUL_VAR( in78, pi[ 78 ] );
    in79 = GF_MUL_VAR( in79, pi[ 79 ] );
    in80 = GF_MUL_VAR( in80, pi[ 80 ] );
    in81 = GF_MUL_VAR( in81, pi[ 81 ] );
    in82 = GF_MUL_VAR( in82, pi[ 82 ] );
    in83 = GF_MUL_VAR( in83, pi[ 83 ] );
    in84 = GF_MUL_VAR( in84, pi[ 84 ] );
    in85 = GF_MUL_VAR( in85, pi[ 85 ] );
    in86 = GF_MUL_VAR( in86, pi[ 86 ] );
    in87 = GF_MUL_VAR( in87, pi[ 87 ] );
    in88 = GF_MUL_VAR( in88, pi[ 88 ] );
    in89 = GF_MUL_VAR( in89, pi[ 89 ] );
    in90 = GF_MUL_VAR( in90, pi[ 90 ] );
    in91 = GF_MUL_VAR( in91, pi[ 91 ] );
    in92 = GF_MUL_VAR( in92, pi[ 92 ] );
    in93 = GF_MUL_VAR( in93, pi[ 93 ] );
    in94 = GF_MUL_VAR( in94, pi[ 94 ] );
    in95 = GF_MUL_VAR( in95, pi[ 95 ] );
    in96 = GF_MUL_VAR( in96, pi[ 96 ] );
    in97 = GF_MUL_VAR( in97, pi[ 97 ] );
    in98 = GF_MUL_VAR( in98, pi[ 98 ] );
    in99 = GF_MUL_VAR( in99, pi[ 99 ] );
    in100 = GF_MUL_VAR( in100, pi[ 100 ] );
    in101 = GF_MUL_VAR( in101, pi[ 101 ] );
    in102 = GF_MUL_VAR( in102, pi[ 102 ] );
    in103 = GF_MUL_VAR( in103, pi[ 103 ] );
    in104 = GF_MUL_VAR( in104, pi[ 104 ] );
    in105 = GF_MUL_VAR( in105, pi[ 105 ] );
    in106 = GF_MUL_VAR( in106, pi[ 106 ] );
    in107 = GF_MUL_VAR( in107, pi[ 107 ] );
    in108 = GF_MUL_VAR( in108, pi[ 108 ] );
    in109 = GF_MUL_VAR( in109, pi[ 109 ] );
    in110 = GF_MUL_VAR( in110, pi[ 110 ] );
    in111 = GF_MUL_VAR( in111, pi[ 111 ] );
    in112 = GF_MUL_VAR( in112, pi[ 112 ] );
    in113 = GF_MUL_VAR( in113, pi[ 113 ] );
    in114 = GF_MUL_VAR( in114, pi[ 114 ] );
    in115 = GF_MUL_VAR( in115, pi[ 115 ] );
    in116 = GF_MUL_VAR( in116, pi[ 116 ] );
    in117 = GF_MUL_VAR( in117, pi[ 117 ] );
    in118 = GF_MUL_VAR( in118, pi[ 118 ] );
    in119 = GF_MUL_VAR( in119, pi[ 119 ] );
    in120 = GF_MUL_VAR( in120, pi[ 120 ] );
    in121 = GF_MUL_VAR( in121, pi[ 121 ] );
    in122 = GF_MUL_VAR( in122, pi[ 122 ] );
    in123 = GF_MUL_VAR( in123, pi[ 123 ] );
    in124 = GF_MUL_VAR( in124, pi[ 124 ] );
    in125 = GF_MUL_VAR( in125, pi[ 125 ] );
    in126 = GF_MUL_VAR( in126, pi[ 126 ] );
    in127 = GF_MUL_VAR( in127, pi[ 127 ] );
    in128 = GF_MUL_VAR( in128, pi[ 128 ] );
    in129 = GF_MUL_VAR( in129, pi[ 129 ] );
    in130 = GF_MUL_VAR( in130, pi[ 130 ] );
    in131 = GF_MUL_VAR( in131, pi[ 131 ] );
    in132 = GF_MUL_VAR( in132, pi[ 132 ] );
    in133 = GF_MUL_VAR( in133, pi[ 133 ] );
    in134 = GF_MUL_VAR( in134, pi[ 134 ] );
    in135 = GF_MUL_VAR( in135, pi[ 135 ] );
    in136 = GF_MUL_VAR( in136, pi[ 136 ] );
    in137 = GF_MUL_VAR( in137, pi[ 137 ] );
    in138 = GF_MUL_VAR( in138, pi[ 138 ] );
    in139 = GF_MUL_VAR( in139, pi[ 139 ] );
    in140 = GF_MUL_VAR( in140, pi[ 140 ] );
    in141 = GF_MUL_VAR( in141, pi[ 141 ] );
    in142 = GF_MUL_VAR( in142, pi[ 142 ] );
    in143 = GF_MUL_VAR( in143, pi[ 143 ] );
    in144 = GF_MUL_VAR( in144, pi[ 144 ] );
    in145 = GF_MUL_VAR( in145, pi[ 145 ] );
    in146 = GF_MUL_VAR( in146, pi[ 146 ] );
    in147 = GF_MUL_VAR( in147, pi[ 147 ] );
    in148 = GF_MUL_VAR( in148, pi[ 148 ] );
    in149 = GF_MUL_VAR( in149, pi[ 149 ] );
    in150 = GF_MUL_VAR( in150, pi[ 150 ] );
    in151 = GF_MUL_VAR( in151, pi[ 151 ] );
    in152 = GF_MUL_VAR( in152, pi[ 152 ] );
    in153 = GF_MUL_VAR( in153, pi[ 153 ] );
    in154 = GF_MUL_VAR( in154, pi[ 154 ] );
    in155 = GF_MUL_VAR( in155, pi[ 155 ] );
    in156 = GF_MUL_VAR( in156, pi[ 156 ] );
    in157 = GF_MUL_VAR( in157, pi[ 157 ] );
    in158 = GF_MUL_VAR( in158, pi[ 158 ] );
    in159 = GF_MUL_VAR( in159, pi[ 159 ] );
    in160 = GF_MUL_VAR( in160, pi[ 160 ] );
    in161 = GF_MUL_VAR( in161, pi[ 161 ] );
    in162 = GF_MUL_VAR( in162, pi[ 162 ] );
    in163 = GF_MUL_VAR( in163, pi[ 163 ] );
    in164 = GF_MUL_VAR( in164, pi[ 164 ] );
    in165 = GF_MUL_VAR( in165, pi[ 165 ] );
    in166 = GF_MUL_VAR( in166, pi[ 166 ] );
    in167 = GF_MUL_VAR( in167, pi[ 167 ] );
    in168 = GF_MUL_VAR( in168, pi[ 168 ] );
    in169 = GF_MUL_VAR( in169, pi[ 169 ] );
    in170 = GF_MUL_VAR( in170, pi[ 170 ] );
    in171 = GF_MUL_VAR( in171, pi[ 171 ] );
    in172 = GF_MUL_VAR( in172, pi[ 172 ] );
    in173 = GF_MUL_VAR( in173, pi[ 173 ] );
    in174 = GF_MUL_VAR( in174, pi[ 174 ] );
    in175 = GF_MUL_VAR( in175, pi[ 175 ] );
    in176 = GF_MUL_VAR( in176, pi[ 176 ] );
    in177 = GF_MUL_VAR( in177, pi[ 177 ] );
    in178 = GF_MUL_VAR( in178, pi[ 178 ] );
    in179 = GF_MUL_VAR( in179, pi[ 179 ] );
    in180 = GF_MUL_VAR( in180, pi[ 180 ] );
    in181 = GF_MUL_VAR( in181, pi[ 181 ] );
    in182 = GF_MUL_VAR( in182, pi[ 182 ] );
    in183 = GF_MUL_VAR( in183, pi[ 183 ] );
    in184 = GF_MUL_VAR( in184, pi[ 184 ] );
    in185 = GF_MUL_VAR( in185, pi[ 185 ] );
    in186 = GF_MUL_VAR( in186, pi[ 186 ] );
    in187 = GF_MUL_VAR( in187, pi[ 187 ] );
    in188 = GF_MUL_VAR( in188, pi[ 188 ] );
    in189 = GF_MUL_VAR( in189, pi[ 189 ] );
    in190 = GF_MUL_VAR( in190, pi[ 190 ] );
    in191 = GF_MUL_VAR( in191, pi[ 191 ] );
    in192 = GF_MUL_VAR( in192, pi[ 192 ] );
    in193 = GF_MUL_VAR( in193, pi[ 193 ] );
    in194 = GF_MUL_VAR( in194, pi[ 194 ] );
    in195 = GF_MUL_VAR( in195, pi[ 195 ] );
    in196 = GF_MUL_VAR( in196, pi[ 196 ] );
    in197 = GF_MUL_VAR( in197, pi[ 197 ] );
    in198 = GF_MUL_VAR( in198, pi[ 198 ] );
    in199 = GF_MUL_VAR( in199, pi[ 199 ] );
    in200 = GF_MUL_VAR( in200, pi[ 200 ] );
    in201 = GF_MUL_VAR( in201, pi[ 201 ] );
    in202 = GF_MUL_VAR( in202, pi[ 202 ] );
    in203 = GF_MUL_VAR( in203, pi[ 203 ] );
    in204 = GF_MUL_VAR( in204, pi[ 204 ] );
    in205 = GF_MUL_VAR( in205, pi[ 205 ] );
    in206 = GF_MUL_VAR( in206, pi[ 206 ] );
    in207 = GF_MUL_VAR( in207, pi[ 207 ] );
    in208 = GF_MUL_VAR( in208, pi[ 208 ] );
    in209 = GF_MUL_VAR( in209, pi[ 209 ] );
    in210 = GF_MUL_VAR( in210, pi[ 210 ] );
    in211 = GF_MUL_VAR( in211, pi[ 211 ] );
    in212 = GF_MUL_VAR( in212, pi[ 212 ] );
    in213 = GF_MUL_VAR( in213, pi[ 213 ] );
    in214 = GF_MUL_VAR( in214, pi[ 214 ] );
    in215 = GF_MUL_VAR( in215, pi[ 215 ] );
    in216 = GF_MUL_VAR( in216, pi[ 216 ] );
    in217 = GF_MUL_VAR( in217, pi[ 217 ] );
    in218 = GF_MUL_VAR( in218, pi[ 218 ] );
    in219 = GF_MUL_VAR( in219, pi[ 219 ] );
    in220 = GF_MUL_VAR( in220, pi[ 220 ] );
    in221 = GF_MUL_VAR( in221, pi[ 221 ] );
    in222 = GF_MUL_VAR( in222, pi[ 222 ] );
    in223 = GF_MUL_VAR( in223, pi[ 223 ] );
    in224 = GF_MUL_VAR( in224, pi[ 224 ] );
    in225 = GF_MUL_VAR( in225, pi[ 225 ] );
    in226 = GF_MUL_VAR( in226, pi[ 226 ] );
    in227 = GF_MUL_VAR( in227, pi[ 227 ] );
    in228 = GF_MUL_VAR( in228, pi[ 228 ] );
    in229 = GF_MUL_VAR( in229, pi[ 229 ] );
    in230 = GF_MUL_VAR( in230, pi[ 230 ] );
    in231 = GF_MUL_VAR( in231, pi[ 231 ] );
    in232 = GF_MUL_VAR( in232, pi[ 232 ] );
    in233 = GF_MUL_VAR( in233, pi[ 233 ] );
    in234 = GF_MUL_VAR( in234, pi[ 234 ] );
    in235 = GF_MUL_VAR( in235, pi[ 235 ] );
    in236 = GF_MUL_VAR( in236, pi[ 236 ] );
    in237 = GF_MUL_VAR( in237, pi[ 237 ] );
    in238 = GF_MUL_VAR( in238, pi[ 238 ] );
    in239 = GF_MUL_VAR( in239, pi[ 239 ] );
    in240 = GF_MUL_VAR( in240, pi[ 240 ] );
    in241 = GF_MUL_VAR( in241, pi[ 241 ] );
    in242 = GF_MUL_VAR( in242, pi[ 242 ] );
    in243 = GF_MUL_VAR( in243, pi[ 243 ] );
    in244 = GF_MUL_VAR( in244, pi[ 244 ] );
    in245 = GF_MUL_VAR( in245, pi[ 245 ] );
    in246 = GF_MUL_VAR( in246, pi[ 246 ] );
    in247 = GF_MUL_VAR( in247, pi[ 247 ] );
    in248 = GF_MUL_VAR( in248, pi[ 248 ] );
    in249 = GF_MUL_VAR( in249, pi[ 249 ] );
    in250 = GF_MUL_VAR( in250, pi[ 250 ] );
    in251 = GF_MUL_VAR( in251, pi[ 251 ] );
    in252 = GF_MUL_VAR( in252, pi[ 252 ] );
    in253 = GF_MUL_VAR( in253, pi[ 253 ] );
    in254 = GF_MUL_VAR( in254, pi[ 254 ] );
    in255 = GF_MUL_VAR( in255, pi[ 255 ] );
    #define ALL_VARS in00, in01, in02, in03, in04, in05, in06, in07, in08, in09, in10, in11, in12, in13, in14, in15, in16, in17, in18, in19, in20, in21, in22, in23, in24, in25, in26, in27, in28, in29, in30, in31, in32, in33, in34, in35, in36, in37, in38, in39, in40, in41, in42, in43, in44, in45, in46, in47, in48, in49, in50, in51, in52, in53, in54, in55, in56, in57, in58, in59, in60, in61, in62, in63, in64, in65, in66, in67, in68, in69, in70, in71, in72, in73, in74, in75, in76, in77, in78, in79, in80, in81, in82, in83, in84, in85, in86, in87, in88, in89, in90, in91, in92, in93, in94, in95, in96, in97, in98, in99, in100, in101, in102, in103, in104, in105, in106, in107, in108, in109, in110, in111, in112, in113, in114, in115, in116, in117, in118, in119, in120, in121, in122, in123, in124, in125, in126, in127, in128, in129, in130, in131, in132, in133, in134, in135, in136, in137, in138, in139, in140, in141, in142, in143, in144, in145, in146, in147, in148, in149, in150, in151, in152, in153, in154, in155, in156, in157, in158, in159, in160, in161, in162, in163, in164, in165, in166, in167, in168, in169, in170, in171, in172, in173, in174, in175, in176, in177, in178, in179, in180, in181, in182, in183, in184, in185, in186, in187, in188, in189, in190, in191, in192, in193, in194, in195, in196, in197, in198, in199, in200, in201, in202, in203, in204, in205, in206, in207, in208, in209, in210, in211, in212, in213, in214, in215, in216, in217, in218, in219, in220, in221, in222, in223, in224, in225, in226, in227, in228, in229, in230, in231, in232, in233, in234, in235, in236, in237, in238, in239, in240, in241, in242, in243, in244, in245, in246, in247, in248, in249, in250, in251, in252, in253, in254, in255
    #define ALL_VARS_REF &in00, &in01, &in02, &in03, &in04, &in05, &in06, &in07, &in08, &in09, &in10, &in11, &in12, &in13, &in14, &in15, &in16, &in17, &in18, &in19, &in20, &in21, &in22, &in23, &in24, &in25, &in26, &in27, &in28, &in29, &in30, &in31, &in32, &in33, &in34, &in35, &in36, &in37, &in38, &in39, &in40, &in41, &in42, &in43, &in44, &in45, &in46, &in47, &in48, &in49, &in50, &in51, &in52, &in53, &in54, &in55, &in56, &in57, &in58, &in59, &in60, &in61, &in62, &in63, &in64, &in65, &in66, &in67, &in68, &in69, &in70, &in71, &in72, &in73, &in74, &in75, &in76, &in77, &in78, &in79, &in80, &in81, &in82, &in83, &in84, &in85, &in86, &in87, &in88, &in89, &in90, &in91, &in92, &in93, &in94, &in95, &in96, &in97, &in98, &in99, &in100, &in101, &in102, &in103, &in104, &in105, &in106, &in107, &in108, &in109, &in110, &in111, &in112, &in113, &in114, &in115, &in116, &in117, &in118, &in119, &in120, &in121, &in122, &in123, &in124, &in125, &in126, &in127, &in128, &in129, &in130, &in131, &in132, &in133, &in134, &in135, &in136, &in137, &in138, &in139, &in140, &in141, &in142, &in143, &in144, &in145, &in146, &in147, &in148, &in149, &in150, &in151, &in152, &in153, &in154, &in155, &in156, &in157, &in158, &in159, &in160, &in161, &in162, &in163, &in164, &in165, &in166, &in167, &in168, &in169, &in170, &in171, &in172, &in173, &in174, &in175, &in176, &in177, &in178, &in179, &in180, &in181, &in182, &in183, &in184, &in185, &in186, &in187, &in188, &in189, &in190, &in191, &in192, &in193, &in194, &in195, &in196, &in197, &in198, &in199, &in200, &in201, &in202, &in203, &in204, &in205, &in206, &in207, &in208, &in209, &in210, &in211, &in212, &in213, &in214, &in215, &in216, &in217, &in218, &in219, &in220, &in221, &in222, &in223, &in224, &in225, &in226, &in227, &in228, &in229, &in230, &in231, &in232, &in233, &in234, &in235, &in236, &in237, &in238, &in239, &in240, &in241, &in242, &in243, &in244, &in245, &in246, &in247, &in248, &in249, &in250, &in251, &in252, &in253, &in254, &in255

    fd_reedsol_ifft_256_0( ALL_VARS_REF );

    fd_reedsol_fderiv_256( ALL_VARS_REF );

    fd_reedsol_fft_256_0( ALL_VARS_REF );

    /* Again, we only need to multiply the erased ones, since we don't
       use the value of the non-erased ones anymore, but I'll take
       multiplies over branches most days. */
    in00 = GF_MUL_VAR( in00, pi[  0 ] );
    in01 = GF_MUL_VAR( in01, pi[  1 ] );
    in02 = GF_MUL_VAR( in02, pi[  2 ] );
    in03 = GF_MUL_VAR( in03, pi[  3 ] );
    in04 = GF_MUL_VAR( in04, pi[  4 ] );
    in05 = GF_MUL_VAR( in05, pi[  5 ] );
    in06 = GF_MUL_VAR( in06, pi[  6 ] );
    in07 = GF_MUL_VAR( in07, pi[  7 ] );
    in08 = GF_MUL_VAR( in08, pi[  8 ] );
    in09 = GF_MUL_VAR( in09, pi[  9 ] );
    in10 = GF_MUL_VAR( in10, pi[ 10 ] );
    in11 = GF_MUL_VAR( in11, pi[ 11 ] );
    in12 = GF_MUL_VAR( in12, pi[ 12 ] );
    in13 = GF_MUL_VAR( in13, pi[ 13 ] );
    in14 = GF_MUL_VAR( in14, pi[ 14 ] );
    in15 = GF_MUL_VAR( in15, pi[ 15 ] );
    in16 = GF_MUL_VAR( in16, pi[ 16 ] );
    in17 = GF_MUL_VAR( in17, pi[ 17 ] );
    in18 = GF_MUL_VAR( in18, pi[ 18 ] );
    in19 = GF_MUL_VAR( in19, pi[ 19 ] );
    in20 = GF_MUL_VAR( in20, pi[ 20 ] );
    in21 = GF_MUL_VAR( in21, pi[ 21 ] );
    in22 = GF_MUL_VAR( in22, pi[ 22 ] );
    in23 = GF_MUL_VAR( in23, pi[ 23 ] );
    in24 = GF_MUL_VAR( in24, pi[ 24 ] );
    in25 = GF_MUL_VAR( in25, pi[ 25 ] );
    in26 = GF_MUL_VAR( in26, pi[ 26 ] );
    in27 = GF_MUL_VAR( in27, pi[ 27 ] );
    in28 = GF_MUL_VAR( in28, pi[ 28 ] );
    in29 = GF_MUL_VAR( in29, pi[ 29 ] );
    in30 = GF_MUL_VAR( in30, pi[ 30 ] );
    in31 = GF_MUL_VAR( in31, pi[ 31 ] );
    in32 = GF_MUL_VAR( in32, pi[ 32 ] );
    in33 = GF_MUL_VAR( in33, pi[ 33 ] );
    in34 = GF_MUL_VAR( in34, pi[ 34 ] );
    in35 = GF_MUL_VAR( in35, pi[ 35 ] );
    in36 = GF_MUL_VAR( in36, pi[ 36 ] );
    in37 = GF_MUL_VAR( in37, pi[ 37 ] );
    in38 = GF_MUL_VAR( in38, pi[ 38 ] );
    in39 = GF_MUL_VAR( in39, pi[ 39 ] );
    in40 = GF_MUL_VAR( in40, pi[ 40 ] );
    in41 = GF_MUL_VAR( in41, pi[ 41 ] );
    in42 = GF_MUL_VAR( in42, pi[ 42 ] );
    in43 = GF_MUL_VAR( in43, pi[ 43 ] );
    in44 = GF_MUL_VAR( in44, pi[ 44 ] );
    in45 = GF_MUL_VAR( in45, pi[ 45 ] );
    in46 = GF_MUL_VAR( in46, pi[ 46 ] );
    in47 = GF_MUL_VAR( in47, pi[ 47 ] );
    in48 = GF_MUL_VAR( in48, pi[ 48 ] );
    in49 = GF_MUL_VAR( in49, pi[ 49 ] );
    in50 = GF_MUL_VAR( in50, pi[ 50 ] );
    in51 = GF_MUL_VAR( in51, pi[ 51 ] );
    in52 = GF_MUL_VAR( in52, pi[ 52 ] );
    in53 = GF_MUL_VAR( in53, pi[ 53 ] );
    in54 = GF_MUL_VAR( in54, pi[ 54 ] );
    in55 = GF_MUL_VAR( in55, pi[ 55 ] );
    in56 = GF_MUL_VAR( in56, pi[ 56 ] );
    in57 = GF_MUL_VAR( in57, pi[ 57 ] );
    in58 = GF_MUL_VAR( in58, pi[ 58 ] );
    in59 = GF_MUL_VAR( in59, pi[ 59 ] );
    in60 = GF_MUL_VAR( in60, pi[ 60 ] );
    in61 = GF_MUL_VAR( in61, pi[ 61 ] );
    in62 = GF_MUL_VAR( in62, pi[ 62 ] );
    in63 = GF_MUL_VAR( in63, pi[ 63 ] );
    in64 = GF_MUL_VAR( in64, pi[ 64 ] );
    in65 = GF_MUL_VAR( in65, pi[ 65 ] );
    in66 = GF_MUL_VAR( in66, pi[ 66 ] );
    in67 = GF_MUL_VAR( in67, pi[ 67 ] );
    in68 = GF_MUL_VAR( in68, pi[ 68 ] );
    in69 = GF_MUL_VAR( in69, pi[ 69 ] );
    in70 = GF_MUL_VAR( in70, pi[ 70 ] );
    in71 = GF_MUL_VAR( in71, pi[ 71 ] );
    in72 = GF_MUL_VAR( in72, pi[ 72 ] );
    in73 = GF_MUL_VAR( in73, pi[ 73 ] );
    in74 = GF_MUL_VAR( in74, pi[ 74 ] );
    in75 = GF_MUL_VAR( in75, pi[ 75 ] );
    in76 = GF_MUL_VAR( in76, pi[ 76 ] );
    in77 = GF_MUL_VAR( in77, pi[ 77 ] );
    in78 = GF_MUL_VAR( in78, pi[ 78 ] );
    in79 = GF_MUL_VAR( in79, pi[ 79 ] );
    in80 = GF_MUL_VAR( in80, pi[ 80 ] );
    in81 = GF_MUL_VAR( in81, pi[ 81 ] );
    in82 = GF_MUL_VAR( in82, pi[ 82 ] );
    in83 = GF_MUL_VAR( in83, pi[ 83 ] );
    in84 = GF_MUL_VAR( in84, pi[ 84 ] );
    in85 = GF_MUL_VAR( in85, pi[ 85 ] );
    in86 = GF_MUL_VAR( in86, pi[ 86 ] );
    in87 = GF_MUL_VAR( in87, pi[ 87 ] );
    in88 = GF_MUL_VAR( in88, pi[ 88 ] );
    in89 = GF_MUL_VAR( in89, pi[ 89 ] );
    in90 = GF_MUL_VAR( in90, pi[ 90 ] );
    in91 = GF_MUL_VAR( in91, pi[ 91 ] );
    in92 = GF_MUL_VAR( in92, pi[ 92 ] );
    in93 = GF_MUL_VAR( in93, pi[ 93 ] );
    in94 = GF_MUL_VAR( in94, pi[ 94 ] );
    in95 = GF_MUL_VAR( in95, pi[ 95 ] );
    in96 = GF_MUL_VAR( in96, pi[ 96 ] );
    in97 = GF_MUL_VAR( in97, pi[ 97 ] );
    in98 = GF_MUL_VAR( in98, pi[ 98 ] );
    in99 = GF_MUL_VAR( in99, pi[ 99 ] );
    in100 = GF_MUL_VAR( in100, pi[ 100 ] );
    in101 = GF_MUL_VAR( in101, pi[ 101 ] );
    in102 = GF_MUL_VAR( in102, pi[ 102 ] );
    in103 = GF_MUL_VAR( in103, pi[ 103 ] );
    in104 = GF_MUL_VAR( in104, pi[ 104 ] );
    in105 = GF_MUL_VAR( in105, pi[ 105 ] );
    in106 = GF_MUL_VAR( in106, pi[ 106 ] );
    in107 = GF_MUL_VAR( in107, pi[ 107 ] );
    in108 = GF_MUL_VAR( in108, pi[ 108 ] );
    in109 = GF_MUL_VAR( in109, pi[ 109 ] );
    in110 = GF_MUL_VAR( in110, pi[ 110 ] );
    in111 = GF_MUL_VAR( in111, pi[ 111 ] );
    in112 = GF_MUL_VAR( in112, pi[ 112 ] );
    in113 = GF_MUL_VAR( in113, pi[ 113 ] );
    in114 = GF_MUL_VAR( in114, pi[ 114 ] );
    in115 = GF_MUL_VAR( in115, pi[ 115 ] );
    in116 = GF_MUL_VAR( in116, pi[ 116 ] );
    in117 = GF_MUL_VAR( in117, pi[ 117 ] );
    in118 = GF_MUL_VAR( in118, pi[ 118 ] );
    in119 = GF_MUL_VAR( in119, pi[ 119 ] );
    in120 = GF_MUL_VAR( in120, pi[ 120 ] );
    in121 = GF_MUL_VAR( in121, pi[ 121 ] );
    in122 = GF_MUL_VAR( in122, pi[ 122 ] );
    in123 = GF_MUL_VAR( in123, pi[ 123 ] );
    in124 = GF_MUL_VAR( in124, pi[ 124 ] );
    in125 = GF_MUL_VAR( in125, pi[ 125 ] );
    in126 = GF_MUL_VAR( in126, pi[ 126 ] );
    in127 = GF_MUL_VAR( in127, pi[ 127 ] );
    in128 = GF_MUL_VAR( in128, pi[ 128 ] );
    in129 = GF_MUL_VAR( in129, pi[ 129 ] );
    in130 = GF_MUL_VAR( in130, pi[ 130 ] );
    in131 = GF_MUL_VAR( in131, pi[ 131 ] );
    in132 = GF_MUL_VAR( in132, pi[ 132 ] );
    in133 = GF_MUL_VAR( in133, pi[ 133 ] );
    in134 = GF_MUL_VAR( in134, pi[ 134 ] );
    in135 = GF_MUL_VAR( in135, pi[ 135 ] );
    in136 = GF_MUL_VAR( in136, pi[ 136 ] );
    in137 = GF_MUL_VAR( in137, pi[ 137 ] );
    in138 = GF_MUL_VAR( in138, pi[ 138 ] );
    in139 = GF_MUL_VAR( in139, pi[ 139 ] );
    in140 = GF_MUL_VAR( in140, pi[ 140 ] );
    in141 = GF_MUL_VAR( in141, pi[ 141 ] );
    in142 = GF_MUL_VAR( in142, pi[ 142 ] );
    in143 = GF_MUL_VAR( in143, pi[ 143 ] );
    in144 = GF_MUL_VAR( in144, pi[ 144 ] );
    in145 = GF_MUL_VAR( in145, pi[ 145 ] );
    in146 = GF_MUL_VAR( in146, pi[ 146 ] );
    in147 = GF_MUL_VAR( in147, pi[ 147 ] );
    in148 = GF_MUL_VAR( in148, pi[ 148 ] );
    in149 = GF_MUL_VAR( in149, pi[ 149 ] );
    in150 = GF_MUL_VAR( in150, pi[ 150 ] );
    in151 = GF_MUL_VAR( in151, pi[ 151 ] );
    in152 = GF_MUL_VAR( in152, pi[ 152 ] );
    in153 = GF_MUL_VAR( in153, pi[ 153 ] );
    in154 = GF_MUL_VAR( in154, pi[ 154 ] );
    in155 = GF_MUL_VAR( in155, pi[ 155 ] );
    in156 = GF_MUL_VAR( in156, pi[ 156 ] );
    in157 = GF_MUL_VAR( in157, pi[ 157 ] );
    in158 = GF_MUL_VAR( in158, pi[ 158 ] );
    in159 = GF_MUL_VAR( in159, pi[ 159 ] );
    in160 = GF_MUL_VAR( in160, pi[ 160 ] );
    in161 = GF_MUL_VAR( in161, pi[ 161 ] );
    in162 = GF_MUL_VAR( in162, pi[ 162 ] );
    in163 = GF_MUL_VAR( in163, pi[ 163 ] );
    in164 = GF_MUL_VAR( in164, pi[ 164 ] );
    in165 = GF_MUL_VAR( in165, pi[ 165 ] );
    in166 = GF_MUL_VAR( in166, pi[ 166 ] );
    in167 = GF_MUL_VAR( in167, pi[ 167 ] );
    in168 = GF_MUL_VAR( in168, pi[ 168 ] );
    in169 = GF_MUL_VAR( in169, pi[ 169 ] );
    in170 = GF_MUL_VAR( in170, pi[ 170 ] );
    in171 = GF_MUL_VAR( in171, pi[ 171 ] );
    in172 = GF_MUL_VAR( in172, pi[ 172 ] );
    in173 = GF_MUL_VAR( in173, pi[ 173 ] );
    in174 = GF_MUL_VAR( in174, pi[ 174 ] );
    in175 = GF_MUL_VAR( in175, pi[ 175 ] );
    in176 = GF_MUL_VAR( in176, pi[ 176 ] );
    in177 = GF_MUL_VAR( in177, pi[ 177 ] );
    in178 = GF_MUL_VAR( in178, pi[ 178 ] );
    in179 = GF_MUL_VAR( in179, pi[ 179 ] );
    in180 = GF_MUL_VAR( in180, pi[ 180 ] );
    in181 = GF_MUL_VAR( in181, pi[ 181 ] );
    in182 = GF_MUL_VAR( in182, pi[ 182 ] );
    in183 = GF_MUL_VAR( in183, pi[ 183 ] );
    in184 = GF_MUL_VAR( in184, pi[ 184 ] );
    in185 = GF_MUL_VAR( in185, pi[ 185 ] );
    in186 = GF_MUL_VAR( in186, pi[ 186 ] );
    in187 = GF_MUL_VAR( in187, pi[ 187 ] );
    in188 = GF_MUL_VAR( in188, pi[ 188 ] );
    in189 = GF_MUL_VAR( in189, pi[ 189 ] );
    in190 = GF_MUL_VAR( in190, pi[ 190 ] );
    in191 = GF_MUL_VAR( in191, pi[ 191 ] );
    in192 = GF_MUL_VAR( in192, pi[ 192 ] );
    in193 = GF_MUL_VAR( in193, pi[ 193 ] );
    in194 = GF_MUL_VAR( in194, pi[ 194 ] );
    in195 = GF_MUL_VAR( in195, pi[ 195 ] );
    in196 = GF_MUL_VAR( in196, pi[ 196 ] );
    in197 = GF_MUL_VAR( in197, pi[ 197 ] );
    in198 = GF_MUL_VAR( in198, pi[ 198 ] );
    in199 = GF_MUL_VAR( in199, pi[ 199 ] );
    in200 = GF_MUL_VAR( in200, pi[ 200 ] );
    in201 = GF_MUL_VAR( in201, pi[ 201 ] );
    in202 = GF_MUL_VAR( in202, pi[ 202 ] );
    in203 = GF_MUL_VAR( in203, pi[ 203 ] );
    in204 = GF_MUL_VAR( in204, pi[ 204 ] );
    in205 = GF_MUL_VAR( in205, pi[ 205 ] );
    in206 = GF_MUL_VAR( in206, pi[ 206 ] );
    in207 = GF_MUL_VAR( in207, pi[ 207 ] );
    in208 = GF_MUL_VAR( in208, pi[ 208 ] );
    in209 = GF_MUL_VAR( in209, pi[ 209 ] );
    in210 = GF_MUL_VAR( in210, pi[ 210 ] );
    in211 = GF_MUL_VAR( in211, pi[ 211 ] );
    in212 = GF_MUL_VAR( in212, pi[ 212 ] );
    in213 = GF_MUL_VAR( in213, pi[ 213 ] );
    in214 = GF_MUL_VAR( in214, pi[ 214 ] );
    in215 = GF_MUL_VAR( in215, pi[ 215 ] );
    in216 = GF_MUL_VAR( in216, pi[ 216 ] );
    in217 = GF_MUL_VAR( in217, pi[ 217 ] );
    in218 = GF_MUL_VAR( in218, pi[ 218 ] );
    in219 = GF_MUL_VAR( in219, pi[ 219 ] );
    in220 = GF_MUL_VAR( in220, pi[ 220 ] );
    in221 = GF_MUL_VAR( in221, pi[ 221 ] );
    in222 = GF_MUL_VAR( in222, pi[ 222 ] );
    in223 = GF_MUL_VAR( in223, pi[ 223 ] );
    in224 = GF_MUL_VAR( in224, pi[ 224 ] );
    in225 = GF_MUL_VAR( in225, pi[ 225 ] );
    in226 = GF_MUL_VAR( in226, pi[ 226 ] );
    in227 = GF_MUL_VAR( in227, pi[ 227 ] );
    in228 = GF_MUL_VAR( in228, pi[ 228 ] );
    in229 = GF_MUL_VAR( in229, pi[ 229 ] );
    in230 = GF_MUL_VAR( in230, pi[ 230 ] );
    in231 = GF_MUL_VAR( in231, pi[ 231 ] );
    in232 = GF_MUL_VAR( in232, pi[ 232 ] );
    in233 = GF_MUL_VAR( in233, pi[ 233 ] );
    in234 = GF_MUL_VAR( in234, pi[ 234 ] );
    in235 = GF_MUL_VAR( in235, pi[ 235 ] );
    in236 = GF_MUL_VAR( in236, pi[ 236 ] );
    in237 = GF_MUL_VAR( in237, pi[ 237 ] );
    in238 = GF_MUL_VAR( in238, pi[ 238 ] );
    in239 = GF_MUL_VAR( in239, pi[ 239 ] );
    in240 = GF_MUL_VAR( in240, pi[ 240 ] );
    in241 = GF_MUL_VAR( in241, pi[ 241 ] );
    in242 = GF_MUL_VAR( in242, pi[ 242 ] );
    in243 = GF_MUL_VAR( in243, pi[ 243 ] );
    in244 = GF_MUL_VAR( in244, pi[ 244 ] );
    in245 = GF_MUL_VAR( in245, pi[ 245 ] );
    in246 = GF_MUL_VAR( in246, pi[ 246 ] );
    in247 = GF_MUL_VAR( in247, pi[ 247 ] );
    in248 = GF_MUL_VAR( in248, pi[ 248 ] );
    in249 = GF_MUL_VAR( in249, pi[ 249 ] );
    in250 = GF_MUL_VAR( in250, pi[ 250 ] );
    in251 = GF_MUL_VAR( in251, pi[ 251 ] );
    in252 = GF_MUL_VAR( in252, pi[ 252 ] );
    in253 = GF_MUL_VAR( in253, pi[ 253 ] );
    in254 = GF_MUL_VAR( in254, pi[ 254 ] );
    in255 = GF_MUL_VAR( in255, pi[ 255 ] );
    /* There are a couple of cases we have to handle:
        - If i<shred_cnt and erased[ i ], it's an actual erasure, so we
            need to store the generated value.
        - If i<shred_cnt and _erased[ i ] but not erased[ i ], it was a
            value that we ignored to ensure the data lies on a
            polynomial of the right order, so we need to compare the
            value we generated to the one that was there.
        - If i<shred_cnt and !_erased[ i ], then this is a value we
            actually used in the computation, but we destroyed it, so we
            need to reload the actual value of the shred in order to use the
            IFFT in the next step.
        - If i>=shred_cnt, do nothing, which will keep the value of the
            shred if it existed in the variable. */
  #define STORE_COMPARE_RELOAD( n, var ) do{                                                        \
            if(       erased[ n ] )        gf_stu( shred[ n ] + shred_pos, var );                            \
            else if( _erased[ n ] ) diff = GF_OR( diff, GF_ADD( var, gf_ldu( shred[ n ] + shred_pos ) ) );       \
            else                    var  = gf_ldu( shred[ n ] + shred_pos );                                     \
          } while( 0 )
  #define STORE_COMPARE( n, var ) do{                                                         \
        if(       erased[ n ] )        gf_stu( shred[ n ] + shred_pos, var );                          \
        else                    diff = GF_OR( diff, GF_ADD( var, gf_ldu( shred[ n ] + shred_pos ) ) ); \
      } while( 0 )
    switch( fd_ulong_min( shred_cnt, 256UL ) ) {
      case 256UL: STORE_COMPARE_RELOAD( 255, in255 ); FALLTHRU
      case 255UL: STORE_COMPARE_RELOAD( 254, in254 ); FALLTHRU
      case 254UL: STORE_COMPARE_RELOAD( 253, in253 ); FALLTHRU
      case 253UL: STORE_COMPARE_RELOAD( 252, in252 ); FALLTHRU
      case 252UL: STORE_COMPARE_RELOAD( 251, in251 ); FALLTHRU
      case 251UL: STORE_COMPARE_RELOAD( 250, in250 ); FALLTHRU
      case 250UL: STORE_COMPARE_RELOAD( 249, in249 ); FALLTHRU
      case 249UL: STORE_COMPARE_RELOAD( 248, in248 ); FALLTHRU
      case 248UL: STORE_COMPARE_RELOAD( 247, in247 ); FALLTHRU
      case 247UL: STORE_COMPARE_RELOAD( 246, in246 ); FALLTHRU
      case 246UL: STORE_COMPARE_RELOAD( 245, in245 ); FALLTHRU
      case 245UL: STORE_COMPARE_RELOAD( 244, in244 ); FALLTHRU
      case 244UL: STORE_COMPARE_RELOAD( 243, in243 ); FALLTHRU
      case 243UL: STORE_COMPARE_RELOAD( 242, in242 ); FALLTHRU
      case 242UL: STORE_COMPARE_RELOAD( 241, in241 ); FALLTHRU
      case 241UL: STORE_COMPARE_RELOAD( 240, in240 ); FALLTHRU
      case 240UL: STORE_COMPARE_RELOAD( 239, in239 ); FALLTHRU
      case 239UL: STORE_COMPARE_RELOAD( 238, in238 ); FALLTHRU
      case 238UL: STORE_COMPARE_RELOAD( 237, in237 ); FALLTHRU
      case 237UL: STORE_COMPARE_RELOAD( 236, in236 ); FALLTHRU
      case 236UL: STORE_COMPARE_RELOAD( 235, in235 ); FALLTHRU
      case 235UL: STORE_COMPARE_RELOAD( 234, in234 ); FALLTHRU
      case 234UL: STORE_COMPARE_RELOAD( 233, in233 ); FALLTHRU
      case 233UL: STORE_COMPARE_RELOAD( 232, in232 ); FALLTHRU
      case 232UL: STORE_COMPARE_RELOAD( 231, in231 ); FALLTHRU
      case 231UL: STORE_COMPARE_RELOAD( 230, in230 ); FALLTHRU
      case 230UL: STORE_COMPARE_RELOAD( 229, in229 ); FALLTHRU
      case 229UL: STORE_COMPARE_RELOAD( 228, in228 ); FALLTHRU
      case 228UL: STORE_COMPARE_RELOAD( 227, in227 ); FALLTHRU
      case 227UL: STORE_COMPARE_RELOAD( 226, in226 ); FALLTHRU
      case 226UL: STORE_COMPARE_RELOAD( 225, in225 ); FALLTHRU
      case 225UL: STORE_COMPARE_RELOAD( 224, in224 ); FALLTHRU
      case 224UL: STORE_COMPARE_RELOAD( 223, in223 ); FALLTHRU
      case 223UL: STORE_COMPARE_RELOAD( 222, in222 ); FALLTHRU
      case 222UL: STORE_COMPARE_RELOAD( 221, in221 ); FALLTHRU
      case 221UL: STORE_COMPARE_RELOAD( 220, in220 ); FALLTHRU
      case 220UL: STORE_COMPARE_RELOAD( 219, in219 ); FALLTHRU
      case 219UL: STORE_COMPARE_RELOAD( 218, in218 ); FALLTHRU
      case 218UL: STORE_COMPARE_RELOAD( 217, in217 ); FALLTHRU
      case 217UL: STORE_COMPARE_RELOAD( 216, in216 ); FALLTHRU
      case 216UL: STORE_COMPARE_RELOAD( 215, in215 ); FALLTHRU
      case 215UL: STORE_COMPARE_RELOAD( 214, in214 ); FALLTHRU
      case 214UL: STORE_COMPARE_RELOAD( 213, in213 ); FALLTHRU
      case 213UL: STORE_COMPARE_RELOAD( 212, in212 ); FALLTHRU
      case 212UL: STORE_COMPARE_RELOAD( 211, in211 ); FALLTHRU
      case 211UL: STORE_COMPARE_RELOAD( 210, in210 ); FALLTHRU
      case 210UL: STORE_COMPARE_RELOAD( 209, in209 ); FALLTHRU
      case 209UL: STORE_COMPARE_RELOAD( 208, in208 ); FALLTHRU
      case 208UL: STORE_COMPARE_RELOAD( 207, in207 ); FALLTHRU
      case 207UL: STORE_COMPARE_RELOAD( 206, in206 ); FALLTHRU
      case 206UL: STORE_COMPARE_RELOAD( 205, in205 ); FALLTHRU
      case 205UL: STORE_COMPARE_RELOAD( 204, in204 ); FALLTHRU
      case 204UL: STORE_COMPARE_RELOAD( 203, in203 ); FALLTHRU
      case 203UL: STORE_COMPARE_RELOAD( 202, in202 ); FALLTHRU
      case 202UL: STORE_COMPARE_RELOAD( 201, in201 ); FALLTHRU
      case 201UL: STORE_COMPARE_RELOAD( 200, in200 ); FALLTHRU
      case 200UL: STORE_COMPARE_RELOAD( 199, in199 ); FALLTHRU
      case 199UL: STORE_COMPARE_RELOAD( 198, in198 ); FALLTHRU
      case 198UL: STORE_COMPARE_RELOAD( 197, in197 ); FALLTHRU
      case 197UL: STORE_COMPARE_RELOAD( 196, in196 ); FALLTHRU
      case 196UL: STORE_COMPARE_RELOAD( 195, in195 ); FALLTHRU
      case 195UL: STORE_COMPARE_RELOAD( 194, in194 ); FALLTHRU
      case 194UL: STORE_COMPARE_RELOAD( 193, in193 ); FALLTHRU
      case 193UL: STORE_COMPARE_RELOAD( 192, in192 ); FALLTHRU
      case 192UL: STORE_COMPARE_RELOAD( 191, in191 ); FALLTHRU
      case 191UL: STORE_COMPARE_RELOAD( 190, in190 ); FALLTHRU
      case 190UL: STORE_COMPARE_RELOAD( 189, in189 ); FALLTHRU
      case 189UL: STORE_COMPARE_RELOAD( 188, in188 ); FALLTHRU
      case 188UL: STORE_COMPARE_RELOAD( 187, in187 ); FALLTHRU
      case 187UL: STORE_COMPARE_RELOAD( 186, in186 ); FALLTHRU
      case 186UL: STORE_COMPARE_RELOAD( 185, in185 ); FALLTHRU
      case 185UL: STORE_COMPARE_RELOAD( 184, in184 ); FALLTHRU
      case 184UL: STORE_COMPARE_RELOAD( 183, in183 ); FALLTHRU
      case 183UL: STORE_COMPARE_RELOAD( 182, in182 ); FALLTHRU
      case 182UL: STORE_COMPARE_RELOAD( 181, in181 ); FALLTHRU
      case 181UL: STORE_COMPARE_RELOAD( 180, in180 ); FALLTHRU
      case 180UL: STORE_COMPARE_RELOAD( 179, in179 ); FALLTHRU
      case 179UL: STORE_COMPARE_RELOAD( 178, in178 ); FALLTHRU
      case 178UL: STORE_COMPARE_RELOAD( 177, in177 ); FALLTHRU
      case 177UL: STORE_COMPARE_RELOAD( 176, in176 ); FALLTHRU
      case 176UL: STORE_COMPARE_RELOAD( 175, in175 ); FALLTHRU
      case 175UL: STORE_COMPARE_RELOAD( 174, in174 ); FALLTHRU
      case 174UL: STORE_COMPARE_RELOAD( 173, in173 ); FALLTHRU
      case 173UL: STORE_COMPARE_RELOAD( 172, in172 ); FALLTHRU
      case 172UL: STORE_COMPARE_RELOAD( 171, in171 ); FALLTHRU
      case 171UL: STORE_COMPARE_RELOAD( 170, in170 ); FALLTHRU
      case 170UL: STORE_COMPARE_RELOAD( 169, in169 ); FALLTHRU
      case 169UL: STORE_COMPARE_RELOAD( 168, in168 ); FALLTHRU
      case 168UL: STORE_COMPARE_RELOAD( 167, in167 ); FALLTHRU
      case 167UL: STORE_COMPARE_RELOAD( 166, in166 ); FALLTHRU
      case 166UL: STORE_COMPARE_RELOAD( 165, in165 ); FALLTHRU
      case 165UL: STORE_COMPARE_RELOAD( 164, in164 ); FALLTHRU
      case 164UL: STORE_COMPARE_RELOAD( 163, in163 ); FALLTHRU
      case 163UL: STORE_COMPARE_RELOAD( 162, in162 ); FALLTHRU
      case 162UL: STORE_COMPARE_RELOAD( 161, in161 ); FALLTHRU
      case 161UL: STORE_COMPARE_RELOAD( 160, in160 ); FALLTHRU
      case 160UL: STORE_COMPARE_RELOAD( 159, in159 ); FALLTHRU
      case 159UL: STORE_COMPARE_RELOAD( 158, in158 ); FALLTHRU
      case 158UL: STORE_COMPARE_RELOAD( 157, in157 ); FALLTHRU
      case 157UL: STORE_COMPARE_RELOAD( 156, in156 ); FALLTHRU
      case 156UL: STORE_COMPARE_RELOAD( 155, in155 ); FALLTHRU
      case 155UL: STORE_COMPARE_RELOAD( 154, in154 ); FALLTHRU
      case 154UL: STORE_COMPARE_RELOAD( 153, in153 ); FALLTHRU
      case 153UL: STORE_COMPARE_RELOAD( 152, in152 ); FALLTHRU
      case 152UL: STORE_COMPARE_RELOAD( 151, in151 ); FALLTHRU
      case 151UL: STORE_COMPARE_RELOAD( 150, in150 ); FALLTHRU
      case 150UL: STORE_COMPARE_RELOAD( 149, in149 ); FALLTHRU
      case 149UL: STORE_COMPARE_RELOAD( 148, in148 ); FALLTHRU
      case 148UL: STORE_COMPARE_RELOAD( 147, in147 ); FALLTHRU
      case 147UL: STORE_COMPARE_RELOAD( 146, in146 ); FALLTHRU
      case 146UL: STORE_COMPARE_RELOAD( 145, in145 ); FALLTHRU
      case 145UL: STORE_COMPARE_RELOAD( 144, in144 ); FALLTHRU
      case 144UL: STORE_COMPARE_RELOAD( 143, in143 ); FALLTHRU
      case 143UL: STORE_COMPARE_RELOAD( 142, in142 ); FALLTHRU
      case 142UL: STORE_COMPARE_RELOAD( 141, in141 ); FALLTHRU
      case 141UL: STORE_COMPARE_RELOAD( 140, in140 ); FALLTHRU
      case 140UL: STORE_COMPARE_RELOAD( 139, in139 ); FALLTHRU
      case 139UL: STORE_COMPARE_RELOAD( 138, in138 ); FALLTHRU
      case 138UL: STORE_COMPARE_RELOAD( 137, in137 ); FALLTHRU
      case 137UL: STORE_COMPARE_RELOAD( 136, in136 ); FALLTHRU
      case 136UL: STORE_COMPARE_RELOAD( 135, in135 ); FALLTHRU
      case 135UL: STORE_COMPARE_RELOAD( 134, in134 ); FALLTHRU
      case 134UL: STORE_COMPARE_RELOAD( 133, in133 ); FALLTHRU
      case 133UL: STORE_COMPARE_RELOAD( 132, in132 ); FALLTHRU
      case 132UL: STORE_COMPARE_RELOAD( 131, in131 ); FALLTHRU
      case 131UL: STORE_COMPARE_RELOAD( 130, in130 ); FALLTHRU
      case 130UL: STORE_COMPARE_RELOAD( 129, in129 ); FALLTHRU
      case 129UL: STORE_COMPARE_RELOAD( 128, in128 ); FALLTHRU
      case 128UL: STORE_COMPARE_RELOAD( 127, in127 ); FALLTHRU
      case 127UL: STORE_COMPARE_RELOAD( 126, in126 ); FALLTHRU
      case 126UL: STORE_COMPARE_RELOAD( 125, in125 ); FALLTHRU
      case 125UL: STORE_COMPARE_RELOAD( 124, in124 ); FALLTHRU
      case 124UL: STORE_COMPARE_RELOAD( 123, in123 ); FALLTHRU
      case 123UL: STORE_COMPARE_RELOAD( 122, in122 ); FALLTHRU
      case 122UL: STORE_COMPARE_RELOAD( 121, in121 ); FALLTHRU
      case 121UL: STORE_COMPARE_RELOAD( 120, in120 ); FALLTHRU
      case 120UL: STORE_COMPARE_RELOAD( 119, in119 ); FALLTHRU
      case 119UL: STORE_COMPARE_RELOAD( 118, in118 ); FALLTHRU
      case 118UL: STORE_COMPARE_RELOAD( 117, in117 ); FALLTHRU
      case 117UL: STORE_COMPARE_RELOAD( 116, in116 ); FALLTHRU
      case 116UL: STORE_COMPARE_RELOAD( 115, in115 ); FALLTHRU
      case 115UL: STORE_COMPARE_RELOAD( 114, in114 ); FALLTHRU
      case 114UL: STORE_COMPARE_RELOAD( 113, in113 ); FALLTHRU
      case 113UL: STORE_COMPARE_RELOAD( 112, in112 ); FALLTHRU
      case 112UL: STORE_COMPARE_RELOAD( 111, in111 ); FALLTHRU
      case 111UL: STORE_COMPARE_RELOAD( 110, in110 ); FALLTHRU
      case 110UL: STORE_COMPARE_RELOAD( 109, in109 ); FALLTHRU
      case 109UL: STORE_COMPARE_RELOAD( 108, in108 ); FALLTHRU
      case 108UL: STORE_COMPARE_RELOAD( 107, in107 ); FALLTHRU
      case 107UL: STORE_COMPARE_RELOAD( 106, in106 ); FALLTHRU
      case 106UL: STORE_COMPARE_RELOAD( 105, in105 ); FALLTHRU
      case 105UL: STORE_COMPARE_RELOAD( 104, in104 ); FALLTHRU
      case 104UL: STORE_COMPARE_RELOAD( 103, in103 ); FALLTHRU
      case 103UL: STORE_COMPARE_RELOAD( 102, in102 ); FALLTHRU
      case 102UL: STORE_COMPARE_RELOAD( 101, in101 ); FALLTHRU
      case 101UL: STORE_COMPARE_RELOAD( 100, in100 ); FALLTHRU
      case 100UL: STORE_COMPARE_RELOAD( 99, in99 ); FALLTHRU
      case 99UL: STORE_COMPARE_RELOAD( 98, in98 ); FALLTHRU
      case 98UL: STORE_COMPARE_RELOAD( 97, in97 ); FALLTHRU
      case 97UL: STORE_COMPARE_RELOAD( 96, in96 ); FALLTHRU
      case 96UL: STORE_COMPARE_RELOAD( 95, in95 ); FALLTHRU
      case 95UL: STORE_COMPARE_RELOAD( 94, in94 ); FALLTHRU
      case 94UL: STORE_COMPARE_RELOAD( 93, in93 ); FALLTHRU
      case 93UL: STORE_COMPARE_RELOAD( 92, in92 ); FALLTHRU
      case 92UL: STORE_COMPARE_RELOAD( 91, in91 ); FALLTHRU
      case 91UL: STORE_COMPARE_RELOAD( 90, in90 ); FALLTHRU
      case 90UL: STORE_COMPARE_RELOAD( 89, in89 ); FALLTHRU
      case 89UL: STORE_COMPARE_RELOAD( 88, in88 ); FALLTHRU
      case 88UL: STORE_COMPARE_RELOAD( 87, in87 ); FALLTHRU
      case 87UL: STORE_COMPARE_RELOAD( 86, in86 ); FALLTHRU
      case 86UL: STORE_COMPARE_RELOAD( 85, in85 ); FALLTHRU
      case 85UL: STORE_COMPARE_RELOAD( 84, in84 ); FALLTHRU
      case 84UL: STORE_COMPARE_RELOAD( 83, in83 ); FALLTHRU
      case 83UL: STORE_COMPARE_RELOAD( 82, in82 ); FALLTHRU
      case 82UL: STORE_COMPARE_RELOAD( 81, in81 ); FALLTHRU
      case 81UL: STORE_COMPARE_RELOAD( 80, in80 ); FALLTHRU
      case 80UL: STORE_COMPARE_RELOAD( 79, in79 ); FALLTHRU
      case 79UL: STORE_COMPARE_RELOAD( 78, in78 ); FALLTHRU
      case 78UL: STORE_COMPARE_RELOAD( 77, in77 ); FALLTHRU
      case 77UL: STORE_COMPARE_RELOAD( 76, in76 ); FALLTHRU
      case 76UL: STORE_COMPARE_RELOAD( 75, in75 ); FALLTHRU
      case 75UL: STORE_COMPARE_RELOAD( 74, in74 ); FALLTHRU
      case 74UL: STORE_COMPARE_RELOAD( 73, in73 ); FALLTHRU
      case 73UL: STORE_COMPARE_RELOAD( 72, in72 ); FALLTHRU
      case 72UL: STORE_COMPARE_RELOAD( 71, in71 ); FALLTHRU
      case 71UL: STORE_COMPARE_RELOAD( 70, in70 ); FALLTHRU
      case 70UL: STORE_COMPARE_RELOAD( 69, in69 ); FALLTHRU
      case 69UL: STORE_COMPARE_RELOAD( 68, in68 ); FALLTHRU
      case 68UL: STORE_COMPARE_RELOAD( 67, in67 ); FALLTHRU
      case 67UL: STORE_COMPARE_RELOAD( 66, in66 ); FALLTHRU
      case 66UL: STORE_COMPARE_RELOAD( 65, in65 ); FALLTHRU
      case 65UL: STORE_COMPARE_RELOAD( 64, in64 ); FALLTHRU
      case 64UL: STORE_COMPARE_RELOAD( 63, in63 ); FALLTHRU
      case 63UL: STORE_COMPARE_RELOAD( 62, in62 ); FALLTHRU
      case 62UL: STORE_COMPARE_RELOAD( 61, in61 ); FALLTHRU
      case 61UL: STORE_COMPARE_RELOAD( 60, in60 ); FALLTHRU
      case 60UL: STORE_COMPARE_RELOAD( 59, in59 ); FALLTHRU
      case 59UL: STORE_COMPARE_RELOAD( 58, in58 ); FALLTHRU
      case 58UL: STORE_COMPARE_RELOAD( 57, in57 ); FALLTHRU
      case 57UL: STORE_COMPARE_RELOAD( 56, in56 ); FALLTHRU
      case 56UL: STORE_COMPARE_RELOAD( 55, in55 ); FALLTHRU
      case 55UL: STORE_COMPARE_RELOAD( 54, in54 ); FALLTHRU
      case 54UL: STORE_COMPARE_RELOAD( 53, in53 ); FALLTHRU
      case 53UL: STORE_COMPARE_RELOAD( 52, in52 ); FALLTHRU
      case 52UL: STORE_COMPARE_RELOAD( 51, in51 ); FALLTHRU
      case 51UL: STORE_COMPARE_RELOAD( 50, in50 ); FALLTHRU
      case 50UL: STORE_COMPARE_RELOAD( 49, in49 ); FALLTHRU
      case 49UL: STORE_COMPARE_RELOAD( 48, in48 ); FALLTHRU
      case 48UL: STORE_COMPARE_RELOAD( 47, in47 ); FALLTHRU
      case 47UL: STORE_COMPARE_RELOAD( 46, in46 ); FALLTHRU
      case 46UL: STORE_COMPARE_RELOAD( 45, in45 ); FALLTHRU
      case 45UL: STORE_COMPARE_RELOAD( 44, in44 ); FALLTHRU
      case 44UL: STORE_COMPARE_RELOAD( 43, in43 ); FALLTHRU
      case 43UL: STORE_COMPARE_RELOAD( 42, in42 ); FALLTHRU
      case 42UL: STORE_COMPARE_RELOAD( 41, in41 ); FALLTHRU
      case 41UL: STORE_COMPARE_RELOAD( 40, in40 ); FALLTHRU
      case 40UL: STORE_COMPARE_RELOAD( 39, in39 ); FALLTHRU
      case 39UL: STORE_COMPARE_RELOAD( 38, in38 ); FALLTHRU
      case 38UL: STORE_COMPARE_RELOAD( 37, in37 ); FALLTHRU
      case 37UL: STORE_COMPARE_RELOAD( 36, in36 ); FALLTHRU
      case 36UL: STORE_COMPARE_RELOAD( 35, in35 ); FALLTHRU
      case 35UL: STORE_COMPARE_RELOAD( 34, in34 ); FALLTHRU
      case 34UL: STORE_COMPARE_RELOAD( 33, in33 ); FALLTHRU
      case 33UL: STORE_COMPARE_RELOAD( 32, in32 ); FALLTHRU
      case 32UL: STORE_COMPARE_RELOAD( 31, in31 ); FALLTHRU
      case 31UL: STORE_COMPARE_RELOAD( 30, in30 ); FALLTHRU
      case 30UL: STORE_COMPARE_RELOAD( 29, in29 ); FALLTHRU
      case 29UL: STORE_COMPARE_RELOAD( 28, in28 ); FALLTHRU
      case 28UL: STORE_COMPARE_RELOAD( 27, in27 ); FALLTHRU
      case 27UL: STORE_COMPARE_RELOAD( 26, in26 ); FALLTHRU
      case 26UL: STORE_COMPARE_RELOAD( 25, in25 ); FALLTHRU
      case 25UL: STORE_COMPARE_RELOAD( 24, in24 ); FALLTHRU
      case 24UL: STORE_COMPARE_RELOAD( 23, in23 ); FALLTHRU
      case 23UL: STORE_COMPARE_RELOAD( 22, in22 ); FALLTHRU
      case 22UL: STORE_COMPARE_RELOAD( 21, in21 ); FALLTHRU
      case 21UL: STORE_COMPARE_RELOAD( 20, in20 ); FALLTHRU
      case 20UL: STORE_COMPARE_RELOAD( 19, in19 ); FALLTHRU
      case 19UL: STORE_COMPARE_RELOAD( 18, in18 ); FALLTHRU
      case 18UL: STORE_COMPARE_RELOAD( 17, in17 ); FALLTHRU
      case 17UL: STORE_COMPARE_RELOAD( 16, in16 ); FALLTHRU
      case 16UL: STORE_COMPARE_RELOAD( 15, in15 ); FALLTHRU
      case 15UL: STORE_COMPARE_RELOAD( 14, in14 ); FALLTHRU
      case 14UL: STORE_COMPARE_RELOAD( 13, in13 ); FALLTHRU
      case 13UL: STORE_COMPARE_RELOAD( 12, in12 ); FALLTHRU
      case 12UL: STORE_COMPARE_RELOAD( 11, in11 ); FALLTHRU
      case 11UL: STORE_COMPARE_RELOAD( 10, in10 ); FALLTHRU
      case 10UL: STORE_COMPARE_RELOAD(  9, in09 ); FALLTHRU
      case  9UL: STORE_COMPARE_RELOAD(  8, in08 ); FALLTHRU
      case  8UL: STORE_COMPARE_RELOAD(  7, in07 ); FALLTHRU
      case  7UL: STORE_COMPARE_RELOAD(  6, in06 ); FALLTHRU
      case  6UL: STORE_COMPARE_RELOAD(  5, in05 ); FALLTHRU
      case  5UL: STORE_COMPARE_RELOAD(  4, in04 ); FALLTHRU
      case  4UL: STORE_COMPARE_RELOAD(  3, in03 ); FALLTHRU
      case  3UL: STORE_COMPARE_RELOAD(  2, in02 ); FALLTHRU
      case  2UL: STORE_COMPARE_RELOAD(  1, in01 ); FALLTHRU
      case  1UL: STORE_COMPARE_RELOAD(  0, in00 );
    }

    if( FD_UNLIKELY( GF_ANY( diff ) ) ) return FD_REEDSOL_ERR_CORRUPT;
    shred_pos += GF_WIDTH;
    shred_pos = fd_ulong_if( ((shred_sz-GF_WIDTH)<shred_pos) & (shred_pos<shred_sz), shred_sz-GF_WIDTH, shred_pos );
    #undef STORE_COMPARE_RELOAD
    #undef STORE_COMPARE
    #undef ALL_VARS
    #undef ALL_VARS_REF
  }
  return FD_REEDSOL_SUCCESS;
}
