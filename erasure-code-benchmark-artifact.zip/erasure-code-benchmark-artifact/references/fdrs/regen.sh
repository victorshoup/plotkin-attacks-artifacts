#!/bin/sh
# Re-run firedancer's code generators at this tree's raised ceilings.
#
# The generators in generators/ are firedancer's, differing from the pinned tree
# at ../../firedancer only in parameter values -- generators/PARAMETERS.diff is
# that diff and is regenerated here so it cannot go stale.
#
# NULL FIRST, ALWAYS. Before writing anything, the pinned tree's OWN generators
# are run unmodified in a scratch directory and their output is compared against
# the sources firedancer ships. If those 35 files are not byte-for-byte
# identical, the toolchain is not reproducing upstream and this script refuses
# to touch src/ -- because at that point a difference in the regenerated code
# could be the ceiling change or could be the toolchain, and nothing downstream
# could tell which.
set -eu
cd "$(dirname "$0")"
FDRS="$PWD"
UP="$FDRS/../../firedancer/src/ballet/reedsol"
PYGEN="$FDRS/../../localtools/pygen"
[ -d "$UP" ]    || { echo "missing pinned clone $UP; see SOURCES.txt" >&2; exit 1; }
[ -d "$PYGEN" ] || { echo "missing $PYGEN; run ../bootstrap-fdgen.sh" >&2; exit 1; }
export PYTHONPATH="$PYGEN"

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "null: upstream generators must reproduce upstream sources"
mkdir -p "$TMP/up/wrapped_impl"
cp "$UP"/generate_*.py "$TMP/up/"
( cd "$TMP/up" && for g in generate_fft.py generate_fderiv.py generate_ppt.py \
                           generate_encode.py generate_recover.py; do
      python3 "$g"; done )
n=0; bad=0
for f in $(cd "$TMP/up" && ls *.c *.h wrapped_impl/*.c); do
    n=$((n+1))
    cmp -s "$TMP/up/$f" "$UP/$f" || { bad=$((bad+1)); echo "  DIFFERS: $f" >&2; }
done
[ "$bad" -eq 0 ] || { echo "toolchain does not reproduce upstream ($bad of $n); refusing to regenerate" >&2; exit 1; }
echo "  $n files, all identical"

echo "regenerating at this tree's ceilings"
mkdir -p "$TMP/new/wrapped_impl"
cp "$FDRS"/generators/generate_*.py "$TMP/new/"
( cd "$TMP/new" && for g in generate_fft.py generate_fderiv.py generate_ppt.py \
                            generate_encode.py generate_recover.py \
                            generate_recover_bench.py; do
      python3 "$g"; done )

R="$FDRS/src/ballet/reedsol"
cp "$TMP/new"/fd_reedsol_encode_*.c "$TMP/new"/fd_reedsol_recover_*.c \
   "$TMP/new"/fd_reedsol_fft.h "$TMP/new"/fd_reedsol_ppt.h \
   "$TMP/new"/fd_reedsol_fderiv.h "$R/"
rm -f "$R"/wrapped_impl/*.c
cp "$TMP/new"/wrapped_impl/*.c "$R"/wrapped_impl/
# ours, and deliberately not under src/ -- bench/README.md says why
cp "$TMP/new"/fd_reedsol_recover_bench*.c "$TMP/new"/fd_reedsol_recover_bench.h \
   "$FDRS/bench/"

# generate_recover_bench.py is ours, not firedancer's, so it has no upstream
# counterpart to diff against and is deliberately absent from this list.
for g in generate_fft.py generate_ppt.py generate_encode.py generate_recover.py \
         generate_fderiv.py; do
    diff -u "$UP/$g" "$FDRS/generators/$g" || true
done > "$FDRS/generators/PARAMETERS.diff"

echo "done; rebuild with: make -C $FDRS/../.."
