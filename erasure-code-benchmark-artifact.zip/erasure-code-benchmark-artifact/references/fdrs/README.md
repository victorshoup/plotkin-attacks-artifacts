# `fdrs` — firedancer's `reedsol`, ported into this tree and regenerated

This is firedancer's `src/ballet/reedsol`, brought into this repository so it can
be measured as a first-class codec rather than read as reference material. It
keeps firedancer's own `src/` layout, so every relative include in their sources
resolves exactly as it does upstream and nothing about the code drifts.

Upstream is pinned at `813cebdb1a029f95609c7a8f275fc1ae2a58323a`; `SOURCES.txt`
carries the provenance. The pinned clone is still fetched to `../firedancer`,
and it is not decoration — it is what `references/fd-point-upstream` builds against,
which is the null for everything below.

## Why it was regenerated

`FD_REEDSOL_{DATA,PARITY}_SHREDS_MAX` are 67 each upstream. Their own comment
says these are *"limits based on current Solana needs and performance"*, not
mathematical limits. At this report's `n = 3f+1` rate the parity bound binds
first — `m = 2f ≤ 67` — so the shipped code reaches **f ≤ 33**, three of
`grid.py`'s 42 f values.

The construction reaches much further. Over GF(2⁸) the code has 256 evaluation
points, and under the principal pivot transform parity starts at `k` rather than
at `next_pow2(k)`, so the reachable region is

    ceil( (k+m) / next_pow2(k) ) * next_pow2(k) ≤ 256

which at `n = 3f+1` tops out at **k = 86, m = 170, f = 85** — exactly the
T ≤ 256 region, first failure f = 86. `PERF-NOTES-PPT.md` §1 has the algebra.

So the generators in `generators/` were re-run with the ceilings raised. **The
generators themselves are firedancer's, unmodified except for the parameter
values**; `generators/PARAMETERS.diff` is the exact diff from the pinned tree
and is the whole of what changed.

## What was changed, exhaustively

| file | change |
|---|---|
| `generators/generate_fft.py` | coset shifts `range(0, 67*2, N)` → `range(0, 256, N)`, five sites. 134 was the shipped parity ceiling; 256 is the field's. |
| `generators/generate_ppt.py` | PPT wrappers `(65,69,128)` → `(65,87,128)`; the `batches` tuple extended past 68 to 87 so the new wrappers get translation units |
| `generators/generate_encode.py` | per-class coset-parity ceiling 68 → `256 - n`; data ceiling for the 128-wide class 68 → 87 |
| `generators/generate_recover.py` | total shred ceiling `67*2` → `256` |
| `src/ballet/reedsol/fd_reedsol.h` | `DATA_SHREDS_MAX` 67 → 86, `PARITY_SHREDS_MAX` 67 → 170, `FOOTPRINT` 2304 → 3456 |

Everything else — `fd_reedsol.c`, `fd_reedsol_pi.c`, the three arithmetic
headers, `fd_reedsol_gfni_32.S`, the three `constants/*.bin`, and the util
headers — is byte-identical to the pinned tree. **No firedancer source file was
edited except `fd_reedsol.h`**, and that edit is three constants.

`src/util/` carries the 47 headers the preprocessor actually opens, of
firedancer's 98, determined with `cc -MM` over every translation unit rather
than by judgement. `fd_ballet_base.h` and the reedsol sources reach them by the
same relative paths they use upstream, which is why the layout is preserved.

**Two traps in those parameters, both of which bit and are recorded so they
don't bite again.**

*`max_parity_shreds` in `generate_encode.py` counts only the parity produced by
the extra FFT cosets.* The `n - data_shred_cnt` shreds the PPT block already
yields are separate and are not included. A coset lives at shift `n*rep + n`, so
the largest value that stays inside the field is `256 - n`, not 256 and not the
total parity wanted. Asking for 170 at `n = 128` emitted a coset at shift 256 and
failed to compile.

*`max_data_shreds` is EXCLUSIVE in that file's PPT switch,* which runs
`range(max_data_shreds-1, min_data_shreds-1, -1)`. Upstream's `(65,68,68)`
supports k = 65..67, matching their ceiling of 67. Passing 86 therefore generated
PPT cases only to k = 85, and k = 86 encoded garbage that compiled, linked, and
failed only at the round-trip. The other three size classes are immune because
`n ≤ max_data_shreds` holds for them, so their top k is the IFFT case rather than
a PPT one.

## Reach

Generated to the field's limit per size class, not to this grid's needs, so
shapes off the `n = 3f+1` rate work too:

| k | `next_pow2(k)` | coset parity generated | so m up to |
|---:|---:|---:|---:|
| 1–15 | 16 | 240 | `(16-k) + 240` |
| 16 | 16 | 240 | 240 |
| 17–31 | 32 | 224 | `(32-k) + 224` |
| 32 | 32 | 224 | 224 |
| 33–63 | 64 | 192 | `(64-k) + 192` |
| 64 | 64 | 192 | 192 |
| 65–86 | 128 | 128 | `(128-k) + 128` |

bounded in every case by the field condition at the top of this file. **k > 86 is
not generated** — those are rates above 1/2 with large k, which this report does
not price, and the 128-wide PPT bodies are the expensive ones to emit.

At `n = 3f+1` that is `FS_LOW` exactly: f ∈ {31, 32, 33, 40, 48, 56, 63, 64, 65,
72, 80, 85}, 12 of the grid's 42 f values, 48 grid points. **Nothing at f ≥ 86,
ever** — that is the alphabet, not the implementation, and it is the region the
report exists to answer.

## The nulls

Run by `../../check.sh`; these are what license the port.

1. **The generators reproduce their own shipped output.** Run unmodified in a
   scratch directory against the pinned tree, all **35** generated files —
   `fd_reedsol_{fft,ppt,fderiv}.h`, four `encode_*.c`, five `recover_*.c`, 23
   `wrapped_impl/*.c` — come out **byte for byte identical**. This is what makes
   the toolchain trustworthy at parameters upstream never used.
2. **The regenerated code computes upstream's code.** `fd-point` against
   `fd-point-upstream`, `--digest`, at every shape upstream can also express:
   18 shapes, 0 differing.
3. **Both arithmetic backends agree.** `fd-point` (`gfni-avx512`) against
   `fd-point-generic` (`FD_REEDSOL_ARITH_IMPL=0`, table lookup, 32:32 assembly
   kernel not linked): 24 shapes across the whole region, 0 differing.
4. **Every grid shape round-trips.** `fd_reedsol_recover` with exactly the first
   k arrivals, 20 trials each, 12 f values × 4 message sizes: 48 shapes,
   0 failing.

## Regenerating

`generators/` needs `numpy` and `galois`, which this machine has no `pip` for;
`../bootstrap-fdgen.sh` unpacks wheels into `localtools/pygen` without root.

From the artifact root:

```sh
./references/bootstrap-fdgen.sh      # once
(cd references/fdrs && ./regen.sh)   # ~10 s
make -C references                   # rebuild fd-point
```

`regen.sh` refuses to write unless null 1 above passes first, so a broken
toolchain cannot silently replace the generated sources.
