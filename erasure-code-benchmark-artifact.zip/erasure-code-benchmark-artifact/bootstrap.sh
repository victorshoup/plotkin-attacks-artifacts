#!/bin/sh
set -eu
cd "$(dirname "$0")"

MONAD_COMMIT="fcafa0d7cb96c18588530c992f25c3d4a73b13dd"
ARCHIVE_URL="https://codeload.github.com/category-labs/monad-bft/tar.gz/${MONAD_COMMIT}"

# monad-raptor IS VENDORED in this artifact (monad-raptor/VENDORED.md), so this
# script exits here every time and downloads nothing. It is kept as the
# PROVENANCE RECORD -- it names the exact upstream commit the vendored tree came
# from, and re-running it against an emptied monad-raptor/ is how a reader
# checks that the vendored copy is what it claims to be. ARTIFACT-PLAN 9.4.
if [ -f monad-raptor/src/lib.rs ]; then
    exit 0
fi

if ! command -v curl >/dev/null 2>&1; then
    echo "ERROR: curl is required for the one-time Monad source download." >&2
    exit 1
fi

tmp=$(mktemp -d "${TMPDIR:-/tmp}/raptor-bench.XXXXXX")
trap 'rm -rf "$tmp"' EXIT HUP INT TERM

echo "Downloading pinned Monad source snapshot (no git, no submodules)..." >&2
# GitHub source archives do not recursively fetch Git submodules.
curl -fL --retry 3 --retry-delay 2 \
    -o "$tmp/monad-bft.tar.gz" \
    "$ARCHIVE_URL"

mkdir "$tmp/unpack"
tar xzf "$tmp/monad-bft.tar.gz" -C "$tmp/unpack"
root=$(find "$tmp/unpack" -mindepth 1 -maxdepth 1 -type d | head -1)
if [ -z "$root" ] || [ ! -f "$root/monad-raptor/src/lib.rs" ]; then
    echo "ERROR: downloaded archive does not contain monad-raptor/src/lib.rs" >&2
    exit 1
fi

rm -rf monad-raptor
cp -R "$root/monad-raptor" ./monad-raptor

# The upstream crate inherits rand/rayon from the monad-bft workspace.
# Make exactly those two dependencies standalone; Rust sources are untouched.
cat > monad-raptor/Cargo.toml <<'TOML'
[package]
name = "monad-raptor"
version = "0.1.0"
edition = "2021"

[lib]
bench = false

[dependencies]
rand = "0.8"
rayon = "1.7"
TOML

printf '%s\n' "$MONAD_COMMIT" > monad-raptor/UPSTREAM_COMMIT

echo "Prepared local monad-raptor from commit $MONAD_COMMIT" >&2
