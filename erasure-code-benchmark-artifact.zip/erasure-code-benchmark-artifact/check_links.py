#!/usr/bin/env python3
"""Every path reference in this tree must resolve, and must stay inside it.

WHY THIS EXISTS. The artifact is an extract, and extraction moves files. When
`isal/` became `codec/` and `references/`, thirteen references inside comments
and Markdown kept naming the old layout, and two more ended up a directory level
off because `bootstrap-fdgen.sh` changed parent. Separately, files written while
`artifact/` was a subdirectory of a larger repository could reach outward with
`../..` -- which resolves on the machine it was written on and dangles the moment
the extract is published on its own.

None of that was caught by anything. `check.sh` verifies arithmetic; a compiler
verifies `#include`; NOTHING looks at a path inside a comment or a Markdown link.
This does.

THE THREE RULES

  R1  a Markdown link must resolve, relative to the file that contains it
  R2  a path that names a file this tree HAS, but at a location it does not,
      is a stale path -- this is what a rename leaves behind
  R3  a relative reference that escapes this directory is a link that works
      here and dangles once published

WHAT IT DELIBERATELY DOES NOT FLAG. Source comments and `codec/KNOBS.md` cite
the project's internal working notes by bare filename -- `PERF-NOTES-*.md` and
the internal status report. Those are provenance, not links: each records which
measurement licensed a line of code, and `docs/MAPPING.md` section 8 decodes
them. A bare filename with no directory component is never a path here.

R2's limit, stated so nobody trusts it further than it goes: it can only catch a
path whose basename this tree still has SOMEWHERE. A reference to a file that was
dropped entirely -- a development probe that was never extracted -- looks exactly
like prose, and no checker can tell. Those need a reader.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

# Third-party or generated trees. Their internal references are not ours, and
# upstream firedancer's `src/` carries hundreds of includes into parts of their
# repository this artifact deliberately does not extract.
SKIP_DIRS = {
    "isa-l-2.31.1", "target", "__pycache__", ".git", "localtools", "firedancer",
    "node_modules",
}
SKIP_SUBTREES = (
    os.path.join("references", "fdrs", "src"),
    os.path.join("references", "fdrs", "generators"),
    os.path.join("references", "fdrs", "bench", "wrapped_impl"),
)

SCAN_EXT = {".md", ".py", ".sh", ".c", ".h", ".rs", ".S", ".toml", ".txt", ""}
SCAN_NAMES = {"Makefile", "LICENSE", "VENDORED.md", "UPSTREAM_COMMIT"}

# Paths that are legitimately absent until something builds or fetches them.
# `.gitignore` is the authority on what is generated; this mirrors it.
OPTIONAL = {
    "codec/rs-point", "references/fd-point", "references/fd-point-generic",
    "references/fd-point-upstream", "isa-l-2.31.1", "isa-l.tar.gz",
    "localtools", "localtools/pygen", "firedancer", "target",
    "results/reference-largef.csv",
}

PATH_EXT = (".md", ".py", ".sh", ".c", ".h", ".rs", ".S", ".csv", ".txt",
            ".toml", ".patch", ".lock", ".log", ".diff", ".json")

MD_LINK = re.compile(r"\[[^\]^]*\]\(([^)\s]+)\)")
# A path-shaped token: at least one slash, no whitespace, no shell expansion,
# no field-arithmetic punctuation. A BACKTICK MUST NOT BE IN THE LOOKBEHIND --
# most Markdown path references are backticked, and excluding them made the
# first version of this checker silently blind to its own motivating case.
# The trailing group is `*`, not `+`, with a "must contain a slash" test at the
# use site. With `+` a purely upward reference -- two dot-dot hops followed by a
# bare filename, with no subdirectory after it -- never matched at all, which is
# how R3 stayed dead through two rounds of fixing it. The slash test is what
# keeps a bare `PERF-NOTES-LARGE-F.md` citation from being read as a path.
TOKEN = re.compile(r"(?<![\w/.$-])((?:\.\.?/)*[A-Za-z0-9_][A-Za-z0-9_.-]*"
                   r"(?:/[A-Za-z0-9_.+-]+)*)")


# Recorded measurement output, shipped byte-identical to what the campaign
# wrote. The sweeps' printed summaries name their CSVs by the path they had in
# the development tree ("results/largef-..."), which is a record, not a link, and
# must not be edited to satisfy R2. Only these sidecars are exempt; the README
# and script beside them are scanned like everything else.
RECORDED = (os.path.join("results", "paper-data"), (".txt",))


def walk():
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in sorted(dirnames) if d not in SKIP_DIRS]
        rel = os.path.relpath(dirpath, ROOT)
        if rel != "." and any(rel == s or rel.startswith(s + os.sep)
                              for s in SKIP_SUBTREES):
            dirnames[:] = []
            continue
        for fn in sorted(filenames):
            if rel == RECORDED[0] and fn.endswith(RECORDED[1]):
                continue
            yield os.path.join(dirpath, fn)


def main():
    files = list(walk())
    # Every basename this tree actually has, mapped to where. R2 uses it.
    have = {}
    for f in files:
        have.setdefault(os.path.basename(f), []).append(
            os.path.relpath(f, ROOT))
    existing = {os.path.relpath(f, ROOT) for f in files}
    for d, _, _ in os.walk(ROOT):
        existing.add(os.path.relpath(d, ROOT))

    def resolves(ref, from_dir):
        """Does `ref` name something IN THIS TREE, from this file's dir or root?

        A candidate that lands outside ROOT does not count as resolving, even
        when it exists on this machine -- that is the whole of R3. The first
        version of this function called os.path.exists() without the containment
        test, so a dot-dot reference to the plan file in the parent repository
        resolved happily here, and the checker never reported the one defect it
        had been written to catch.
        """
        for base in (from_dir, ROOT):
            p = os.path.normpath(os.path.join(base, ref))
            r = os.path.relpath(p, ROOT)
            if r.startswith(".."):
                continue
            if r in existing or r in OPTIONAL or os.path.exists(p):
                return True
        return False

    def escapes(ref, from_dir):
        p = os.path.normpath(os.path.join(from_dir, ref))
        return os.path.relpath(p, ROOT).startswith("..")

    problems = []
    scanned = 0
    for path in files:
        name, ext = os.path.basename(path), os.path.splitext(path)[1]
        if name not in SCAN_NAMES and ext not in SCAN_EXT:
            continue
        try:
            text = open(path, encoding="utf-8").read()
        except (UnicodeDecodeError, OSError):
            continue
        scanned += 1
        rel = os.path.relpath(path, ROOT)
        here = os.path.dirname(path)

        for lineno, line in enumerate(text.splitlines(), 1):
            stripped = line.lstrip()
            # A compiler already checks these, and upstream's resolve against a
            # tree this artifact does not carry.
            if stripped.startswith(("#include", "use ", "from ", "import ")):
                continue

            # R1 -- Markdown links
            for ref in MD_LINK.findall(line):
                if ref.startswith(("http://", "https://", "mailto:", "#")):
                    continue
                ref = ref.split("#", 1)[0]
                if not ref:
                    continue
                if escapes(ref, here):
                    problems.append((rel, lineno, ref, "link escapes the tree"))
                elif not resolves(ref, here):
                    problems.append((rel, lineno, ref, "link does not resolve"))

            # R2 / R3 -- path-shaped tokens anywhere, comments included
            for ref in TOKEN.findall(line):
                if "/" not in ref or "$" in ref or ref.startswith(("http", "//")):
                    continue
                if resolves(ref, here):
                    continue
                if ref.startswith("..") and escapes(ref, here):
                    problems.append((rel, lineno, ref,
                                     "reference escapes the tree"))
                    continue
                base = os.path.basename(ref)
                if base in have and (base.endswith(PATH_EXT) or "." not in base):
                    problems.append((rel, lineno, ref,
                                     "stale path -- this tree has %s at %s"
                                     % (base, ", ".join(have[base]))))

    seen, uniq = set(), []
    for p in problems:
        if p not in seen:
            seen.add(p)
            uniq.append(p)

    print("  scanned:                %d files" % scanned)
    if not uniq:
        print("  path references:        all resolve, none escape the tree")
        return 0
    print("  path references:        %d PROBLEM(S)" % len(uniq),
          file=sys.stderr)
    for rel, lineno, ref, why in uniq:
        print("    %s:%d  %s  -- %s" % (rel, lineno, ref, why), file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
