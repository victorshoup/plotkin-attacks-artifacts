"""Single source of truth for the benchmark grid.

Imported by robust_benchmark.py and read by check.sh (via -c one-liners), so the
two cannot drift. In v8.1 the f list was written out three times -- once in
robust_benchmark.py and twice in check.sh -- and the ISA-L loop encoded the
T <= 256 boundary by hand.
"""

# Powers of two are the floor of reed-solomon-simd's work-buffer staircase, so
# each 2^n-1 / 2^n / 2^n+1 triple is sampled: the first pair flips the rate at a
# constant buffer, the second doubles the buffer for a one-unit change in f.
FS_LOW = [31, 32, 33, 40, 48, 56, 63, 64, 65, 72, 80, 85]          # T <= 256
FS_HIGH = sorted(set(range(86, 255, 6)) | {96, 127, 128, 129, 160, 192, 224, 255, 256})
FS = FS_LOW + FS_HIGH

TARGETS = [
    ("0.5", 512 * 1024),
    ("1", 1024 * 1024),
    ("2", 2 * 1024 * 1024),
    ("4", 4 * 1024 * 1024),
]

# Tape GF(2^16) is O(k^3) in the plan and would cost more than every other label
# combined across the full high-f sweep. Run it where it answers something: at
# the boundary, at a work-buffer peak (129), and at the top.
TAPE_GF16_ANCHORS = {86, 96, 129, 160, 192, 255}

ALIGN = 64
RQ_MAX_SYMBOL = 65535          # RaptorQ transfer-symbol-size field is 16 bits
GF8_MAX_T = 256                # one GF(2^8) code admits at most 256 shards
GF16_MAX_T = 65536             # ditto for GF(2^16); the isal_cauchy16 ceiling


def k_of(f):
    return f + 1


def t_of(f):
    return 3 * f + 1


def in_l1_bad_class(shard_bytes):
    """Is this shard size one that costs `reed-solomon-simd` an L1 stall?

    Measured: a shard of `2**j * 31` or `2**j * 33` -- a size within one
    thirty-second of a power of two -- raises `rs_simd`'s L1 data-cache load-miss
    rate from about 19% to about 35% and costs 1.2x-1.7x on both encode and
    decode, at every magnitude tested (2**13, 2**14, 2**15). Instruction, branch
    and load counts are unchanged, so it is the same work stalling.

    The condition is on the *ratio* to a power of two, not on the magnitude, and
    it is not avoided by choosing a non-power-of-two message size: the shard is
    `ceil(message / k)` and lands on this class about as often either way.
    """
    n = shard_bytes
    while n % 2 == 0:
        n //= 2
    return n in (31, 33)


def aligned_shard_bytes(target_bytes, k):
    """Shard size: `ceil(target / k)` rounded up to ALIGN.

    **The shard size is a protocol quantity and is deliberately NOT adjusted to
    avoid `in_l1_bad_class`.** Changing it would change the workload -- it is the
    number of bytes actually transmitted, and `k * shard` is the message -- which
    at f = 254 / 0.5 MiB would inflate the message by 5.83%.

    The L1 effect is fixed where it belongs, inside the library that owns the
    buffer: `RS_STRIDE_PAD` pads `reed-solomon-simd`'s internal work-buffer
    stride, exactly as section 3.1's rule pads the ISA-L and tape shard pools.
    The shard stays the size it was; the shards simply sit further apart.
    """
    raw = (target_bytes + k - 1) // k
    return ((raw + ALIGN - 1) // ALIGN) * ALIGN


def rq_available(shard_bytes):
    return shard_bytes <= RQ_MAX_SYMBOL


def gf8_available(f):
    return t_of(f) <= GF8_MAX_T


def gf16_available(f):
    """isal_cauchy16 reach. Its Cauchy nodes are y_j = j for j < k and x_i = k+i,
    which stay distinct for any T <= 65536, so the field bound is the only one.
    Every f in this grid satisfies it; the helper exists so check.sh and
    robust_benchmark.py state the bound rather than assume it."""
    return t_of(f) <= GF16_MAX_T


def _npo2(n):
    p = 1
    while p < n:
        p *= 2
    return p


def rs_rate_and_work(f):
    """reed-solomon-simd 3.1.0 DefaultRate selection and decoder work buffer.

    Mirrors rate_default.rs::use_high_rate plus {High,Low}RateDecoder::work_count,
    with original_count = k = f+1 and recovery_count = T-k = 2f. The buffer, not
    the committee size, governs RS decode cost; it reaches its 1.33xT floor only
    when f is a power of two.
    """
    o, r = k_of(f), 2 * f
    op, rp = _npo2(o), _npo2(r)
    if op < rp:
        high = False
    elif op > rp:
        high = True
    else:
        high = o <= r
    work = _npo2(rp + o) if high else _npo2(op + r)
    return ("High" if high else "Low"), work


# Testing / bisecting override: BENCH_FS="32 85 129" restricts the grid without
# editing this file. Not used for production runs -- the stamped CSVs record
# whatever grid actually ran, so a restricted run is self-describing.
import os as _os

_override = _os.environ.get("BENCH_FS")
if _override:
    FS = [int(x) for x in _override.replace(",", " ").split()]
    FS_LOW = [f for f in FS if gf8_available(f)]
    FS_HIGH = [f for f in FS if not gf8_available(f)]
