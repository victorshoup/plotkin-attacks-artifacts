#!/usr/bin/env python3
"""Large-f sweep: the region the fixed grid in `grid.py` does not reach.

`FS` stops at f = 256, so T stops at 769 and k at 257. Every figure in the
report through rev 20 lives inside that box. But the GF(2^16) transform decoder
does not overtake the matrix decoder until f is around 384, so inside the box it
never wins and the report could only say "it does not pay off here". The whole
point of a k log k decoder is what happens when k gets large, and the grid was
built for BFT shapes where it does not.

This sweep is deliberately NOT part of `grid.py`. Folding large f into `FS`
would renumber every table and force every label to be re-run, and most labels
cannot go there anyway: R10 caps K at 8192 and RaptorQ at 56403, and both would
dominate the wall clock long before that. So this is a separate, narrower
instrument -- only the labels that reach the region, only the quantities the
crossover question needs.

THE MEASUREMENT PROTOCOL (HANDOVER-2026-08-24.md section 2)
-----------------------------------------------------------
Through 2026-08-23 this script took ONE process invocation per label, with no
`setarch -R`, and handed the two binaries environment blocks of different
lengths. Under that treatment 4 MiB large-f timing was bimodal ACROSS
invocations, spanning 1.9x on encode from memory layout alone, while `rs_simd`
was stable to 2%. Every number it printed was one lottery ticket. The four
rules it now implements:

  1. `setarch -R` in front of every measured binary. `randomize_va_space` is 2
     on this machine and a deployment does not get to choose its layout, but a
     comparison does have to hold one variable at a time.
  2. N invocations per label, N >= 5, reported as min/median/max. A median
     *within* one invocation is tight and says nothing about the spread across
     them -- that spread was the entire defect.
  3. Equal-length environment blocks. `ISAL_SHARD_PAD=auto` against `=0` differ
     by three bytes of environment, which shifts the initial stack and is on its
     own enough to fabricate a 1.16x result. The two values a leg is most often
     A/B-ed against are equal-length by construction (`auto`/`0000`,
     `plane`/`inter`), and every remaining difference between legs -- including
     `matrix` against `fft` -- is absorbed by a filler variable, so all legs
     serialise to the same number of environment bytes.
  4. Every invocation is kept, in `--csv`, not just the summary.

Legs (`--legs`, default `mat,fft,inter,rs`):

    mat     Cantor nodes, transform encode, MATRIX decode, plane layouts
    fft     Cantor nodes, transform encode, TRANSFORM decode, plane layouts
    inter   as `fft` but with the interleaved decode buffer and shard pool
    rs      reed-solomon-simd, the full optimised knob set

`mat` and `fft` encode the same way and emit byte-identical parity, so their
encode columns are a control: they should agree, and any difference is
measurement. `inter` emits a different byte ordering -- same code, same decoded
source, different parity bytes -- so it is NOT digest-comparable with the other
two. The decode column is the measurement.

Contracts are the report's: core `BENCH_CPU` (default 4), the section 4.8 warm
allocator, shard sizes rounded to 64 as the grid rounds.

    ./largef_sweep.py                          # 1 MiB, 5 invocations per label
    ./largef_sweep.py --mib 4 --trials 25
    ./largef_sweep.py --mib 4 --pad both --csv results/largef-4mib.csv
"""
import argparse
import os
import statistics
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ISAL = os.path.join(HERE, "codec", "rs-point")
RUST = os.path.join(HERE, "target", "release", "erasure-baseline")

# The rev-18 optimised reed-solomon-simd knob set, all five, always. Omitting
# RS_ENGINE and GFNI_BLOCK3 handicaps it by 1.8x encode / 1.45x decode.
# RS_PLAN_CACHE stays out: it only pays at --stripes > 1 and this sweep runs one.
RS_KNOBS = dict(RS_ENGINE="gfni", GFNI_BLOCK3="1", RS_EVAL_TRUNC="1",
                RS_XOR_SIMD="1", RS_STRIDE_PAD="1")
# Section 4.8's warm allocator contract.
WARM = ("glibc.malloc.mmap_threshold=536870912:"
        "glibc.malloc.trim_threshold=536870912")

# Straddles the crossover: 255 and 341 sit below it, 511 and up above.
DEFAULT_FS = [255, 341, 511, 767, 1023, 1535, 2047]

# `equalise()` below holds every one of these to the same serialised length, so
# no leg is compared against another across a shifted stack. Per rule 3.
ISAL_BASE = dict(ISAL16_NODES="cantor", ISAL16_ENCODE="fft")
LEG_ENV = {
    "mat":   dict(ISAL_BASE, ISAL16_DECODE="matrix",
                  ISAL16_DEC_LAYOUT="plane", ISAL16_ENC_LAYOUT="plane",
                  ISAL16_DEC_PACK="0"),
    # Single-variable control for `imat`: the PLANE decoder given the same
    # densely-packed survivor buffer, by memcpy instead of inter_to_plane. Moves
    # packing without moving layout. `0`/`1` are equal-length, so rule 3 is free
    # on the mat/matpack pair.
    "matpack": dict(ISAL_BASE, ISAL16_DECODE="matrix",
                    ISAL16_DEC_LAYOUT="plane", ISAL16_ENC_LAYOUT="plane",
                    ISAL16_DEC_PACK="1"),
    "fft":   dict(ISAL_BASE, ISAL16_DECODE="fft",
                  ISAL16_DEC_LAYOUT="plane", ISAL16_ENC_LAYOUT="plane"),
    "inter": dict(ISAL_BASE, ISAL16_DECODE="fft",
                  ISAL16_DEC_LAYOUT="inter", ISAL16_ENC_LAYOUT="inter"),
    # The GF(2^8) matrix/Cauchy decoder reading an interleaved pool. `mat` is
    # its control: same decoder, same encoder, plane layout, and the two env
    # blocks are the same length by construction (`matrix`/`matrix`,
    # `plane`/`inter`), so rule 3 costs nothing on this pair.
    "imat":  dict(ISAL_BASE, ISAL16_DECODE="matrix",
                  ISAL16_DEC_LAYOUT="inter", ISAL16_ENC_LAYOUT="inter",
                  ISAL16_DEC_PACK="0"),
    "rs":    dict(RS_KNOBS),
}
LEG_BIN = {"mat": ISAL, "fft": ISAL, "inter": ISAL, "imat": ISAL,
           "matpack": ISAL, "rs": RUST}
ISAL_LEGS = ("mat", "fft", "inter", "imat", "matpack")

PAD_KEY = "BENCH_ENV_PAD"


def env_bytes(d):
    """Length of the environment block contributed by `d`, as execve sees it."""
    return sum(len(k) + len(v) + 2 for k, v in d.items())


def equalise(envs):
    """Pad every env dict with a filler so all serialise to the same length.

    Rule 3. The inherited environment is identical for every invocation, so
    equalising the per-leg deltas equalises the totals.
    """
    target = max(env_bytes(d) for d in envs) + len(PAD_KEY) + 2 + 8
    out = []
    for d in envs:
        n = target - env_bytes(d) - len(PAD_KEY) - 2
        out.append(dict(d, **{PAD_KEY: "x" * n}))
        assert env_bytes(out[-1]) == target
    return out


def invoke(binary, args, env, cpu):
    """One measured process: ASLR off, pinned, warm allocator.

    Returns (median encode_ms, median decode_ms) over the trials in this one
    process, or None if it produced no usable rows.
    """
    e = dict(os.environ, GLIBC_TUNABLES=WARM, **env)
    cp = subprocess.run(["setarch", "-R", "taskset", "-c", str(cpu), binary] + args,
                        capture_output=True, text=True, env=e)
    rows = [l.split(",") for l in cp.stdout.splitlines() if l[:1].isdigit()]
    if not rows:
        sys.stderr.write(cp.stderr)
        return None
    # A phase leg reports only its own half; the other half's field is EMPTY.
    # None here rather than 0.0, so a caller cannot average in a number that was
    # never measured.
    enc = [float(r[9]) for r in rows if r[9] != ""]
    dec = [float(r[10]) for r in rows if r[10] != ""]
    return (statistics.median(enc) if enc else None,
            statistics.median(dec) if dec else None)


def mmm(values):
    """min / median / max, the three numbers rule 2 asks for."""
    return (min(values), statistics.median(values), max(values))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--mib", type=float, default=1,
                   help="message size in MiB, fractional allowed (default 1)")
    p.add_argument("--trials", type=int, default=15, help="trials per invocation")
    p.add_argument("--phase", choices=("both", "encode", "decode"), default="both",
                   help="both (default, the interleaved null), or encode/decode "
                        "measured with the other half out of the timed loop. The "
                        "unmeasured half comes back empty and is dropped, not "
                        "zeroed. The paper's large-f decode table wants `decode`.")
    p.add_argument("--reps", type=int, default=5,
                   help="process invocations per label (protocol minimum 5)")
    p.add_argument("--cpu", type=int, default=int(os.environ.get("BENCH_CPU", 4)))
    p.add_argument("--fs", type=int, nargs="+", default=DEFAULT_FS)
    p.add_argument("--legs", default="mat,fft,inter,rs",  # imat is opt-in
                   help="comma-separated subset of mat,fft,inter,imat,rs")
    p.add_argument("--pad", choices=("auto", "0000", "both"), default="auto",
                   help="ISAL_SHARD_PAD for the isal legs; 'both' runs each twice")
    p.add_argument("--csv", help="write every invocation's medians here")
    a = p.parse_args()

    if a.reps < 5:
        print(f"warning: --reps {a.reps} is below the protocol minimum of 5",
              file=sys.stderr)
    legs = [s.strip() for s in a.legs.split(",") if s.strip()]
    bad = [s for s in legs if s not in LEG_ENV]
    if bad:
        sys.exit(f"unknown leg(s): {', '.join(bad)}")
    pads = ["auto", "0000"] if a.pad == "both" else [a.pad]

    for b in {LEG_BIN[s] for s in legs}:
        if not os.path.exists(b):
            sys.exit(f"missing {b}; run check.sh first")

    # Build the full leg list, then equalise every environment block at once so
    # the padding is comparable across pad variants as well as across legs.
    plan = []
    for leg in legs:
        if leg in ISAL_LEGS:
            for pad in pads:
                plan.append((f"{leg}/{pad}", leg, dict(LEG_ENV[leg],
                                                       ISAL_SHARD_PAD=pad)))
        else:
            plan.append((leg, leg, dict(LEG_ENV[leg])))
    envs = equalise([e for _, _, e in plan])
    plan = [(name, leg, env) for (name, leg, _), env in zip(plan, envs)]

    msg = int(a.mib * (1 << 20))
    print(f"# large-f sweep, {a.mib} MiB message, core {a.cpu}, ASLR off "
          f"(setarch -R), {a.reps} invocations x median of {a.trials} trials, "
          f"warm allocator")
    print(f"# legs: {' '.join(n for n, _, _ in plan)}"
          f"   (env block equalised at {env_bytes(plan[0][2])} bytes)")
    print(f"# {'f':>5} {'k':>6} {'T':>6} {'shard':>6} {'leg':<10} "
          f"{'enc min':>9} {'enc med':>9} {'enc max':>9} {'e spr':>6}  "
          f"{'dec min':>9} {'dec med':>9} {'dec max':>9} {'d spr':>6}")

    csv_rows = []
    medians = {}
    for f in a.fs:
        k, t = f + 1, 3 * f + 1
        sz = ((msg + k - 1) // k + 63) // 64 * 64
        for name, leg, env in plan:
            binary = LEG_BIN[leg]
            if leg == "rs":
                args = ["--f", str(f), "--shard-bytes", str(sz), "--codec", "rs",
                        "--trials", str(a.trials)]
            else:
                args = ["--field", "16", "--f", str(f), "--shard-bytes", str(sz),
                        "--trials", str(a.trials)]
            if a.phase != "both":
                args += ["--phase", a.phase]
            enc, dec = [], []
            for rep in range(a.reps):
                r = invoke(binary, args, env, a.cpu)
                if r is None:
                    continue
                if r[0] is not None:
                    enc.append(r[0])
                if r[1] is not None:
                    dec.append(r[1])
                csv_rows.append([f, k, t, sz, name, rep,
                                 "" if r[0] is None else f"{r[0]:.6f}",
                                 "" if r[1] is None else f"{r[1]:.6f}"])
            if not enc and not dec:
                print(f"  {f:>5} {k:>6} {t:>6} {sz:>6} {name:<10} "
                      f"(no invocation produced rows)")
                continue
            e0, e1, e2 = mmm(enc) if enc else (None, None, None)
            d0, d1, d2 = mmm(dec) if dec else (None, None, None)
            medians[(f, name)] = (e1, d1)
            def _t(v):
                # Blank, not zero, for the half this phase did not measure.
                return f"{v:>9.4f}" if v is not None else f"{'':>9}"

            def _s(hi, lo):
                return f"{hi / lo:>5.2f}x" if hi is not None and lo else f"{'':>6}"

            print(f"  {f:>5} {k:>6} {t:>6} {sz:>6} {name:<10} "
                  f"{_t(e0)} {_t(e1)} {_t(e2)} {_s(e2, e0)}  "
                  f"{_t(d0)} {_t(d1)} {_t(d2)} {_s(d2, d0)}", flush=True)

    # Ratios, medians only, against rs_simd. Below 1.00 means isal_cauchy16 leads.
    isal_names = [n for n, leg, _ in plan if leg in ISAL_LEGS]
    if "rs" in legs and isal_names:
        print()
        print("# isal_cauchy/rs, medians across invocations. below 1.00 means "
              "isal_cauchy16 leads.")
        print(f"# {'f':>5} " + " ".join(f"{n + ' enc':>16}" + f"{n + ' dec':>16}"
                                        for n in isal_names))
        for f in a.fs:
            if (f, "rs") not in medians:
                continue
            re_, rd = medians[(f, "rs")]
            cells = []
            for n in isal_names:
                if (f, n) not in medians:
                    cells.append(f"{'-':>16}{'-':>16}")
                    continue
                ie, idc = medians[(f, n)]
                # A PHASE LEG MEASURES ONE HALF AND LEAVES THE OTHER None.
                # This ratio line used to divide unconditionally and died with a
                # TypeError under `--phase decode` -- which is the mode this
                # script's own --help recommends for the paper's large-f decode
                # table, so the recommended invocation could not finish. The
                # unmeasured half prints as '-', the same convention the missing
                # -leg case above already uses.
                def _r(num, den):
                    if num is None or den is None or den == 0:
                        return f"{'-':>16}"
                    return f"{num/den:>15.2f}x"
                cells.append(_r(ie, re_) + _r(idc, rd))
            print(f"  {f:>5} " + " ".join(cells))

    if a.csv:
        import csv as _csv
        with open(a.csv, "w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["f", "k", "T", "shard_bytes", "leg", "invocation",
                        "encode_ms", "decode_ms"])
            w.writerows(csv_rows)
        print(f"\n# {len(csv_rows)} invocations written to {a.csv}")


if __name__ == "__main__":
    main()
