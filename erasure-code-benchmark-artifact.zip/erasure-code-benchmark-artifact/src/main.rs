use monad_raptor::{Encoder as R10Encoder, ManagedDecoder, SOURCE_SYMBOLS_MAX, SOURCE_SYMBOLS_MIN};
use raptorq::{
    Decoder as RaptorQDecoder, EncodingPacket as RaptorQPacket, ObjectTransmissionInformation,
    SourceBlockEncoder as RaptorQBlockEncoder, SourceBlockEncodingPlan,
};
use reed_solomon_simd::engine::DefaultEngine;
use reed_solomon_simd::rate::{
    HighRateDecoder, HighRateEncoder, LowRateDecoder, LowRateEncoder, RateDecoder, RateEncoder,
};
use reed_solomon_simd::{
    decode as rs_decode, encode as rs_encode, ReedSolomonDecoder, ReedSolomonEncoder,
};
use std::collections::HashMap;
use std::env;
use std::hint::black_box;
use std::time::{Duration, Instant};

#[derive(Clone, Copy, Debug)]
enum Codec {
    R10,
    RaptorQ,
    Rs,
}

impl Codec {
    fn parse(s: &str) -> Result<Self, String> {
        match s {
            "r10" => Ok(Self::R10),
            "rq" | "raptorq" => Ok(Self::RaptorQ),
            "rs" => Ok(Self::Rs),
            _ => Err(format!("unknown codec {s:?}; use r10, rq, or rs")),
        }
    }

    fn name(self) -> &'static str {
        match self {
            Self::R10 => "r10",
            Self::RaptorQ => "rq",
            Self::Rs => "rs",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum RsRate {
    Auto,
    High,
    Low,
}

impl RsRate {
    fn parse(s: &str) -> Result<Self, String> {
        match s {
            "auto" => Ok(Self::Auto),
            "high" => Ok(Self::High),
            "low" => Ok(Self::Low),
            _ => Err(format!("unknown --rs-rate {s:?}; use auto, high, or low")),
        }
    }
    fn name(self) -> &'static str {
        match self {
            Self::Auto => "auto",
            Self::High => "high",
            Self::Low => "low",
        }
    }
}

/// `--phase decode`: encode ONCE at setup, then time decode alone.
///
/// The same contract as rs_point.c's, and it must be the same or the two
/// harnesses stop being comparable: `Both` is the interleaved loop, unchanged
/// and the null, and nothing published moves. `Decode` runs the encoder once
/// before warmup and every later trial re-decodes that codeword under a fresh
/// erasure pattern -- which is what decode time actually depends on.
///
/// HARNESS-SPECULATIVE-decode-isolation.md section 3.5: this is applied to
/// EVERY label including r10 and rq, deliberately. Applying it to the MDS
/// labels alone would split the label set along MDS vs fountain, which is the
/// report's headline axis and the one comparison the benchmark exists to make.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    Both,
    /// Encode alone: the DECODER never runs in a measured trial. It runs once,
    /// at the first invocation, purely as the correctness gate.
    Encode,
    Decode,
}

#[derive(Clone, Debug)]
struct Config {
    f: usize,
    symbol_size: usize,
    codec: Codec,
    trials: usize,
    warmup: usize,
    seed: u64,
    rs_rate: RsRate,
    /// Byte-range stripes per shard for `--codec rs`. 1 is a single decode.
    stripes: usize,
    phase: Phase,
    arrivals: Arrivals,
}

fn usage() {
    eprintln!(
        "Usage: erasure-baseline --f N --shard-bytes N --codec r10|rq|rs [options]\n\
         Options:\n\
           --trials N       measured trials (default: 20)\n\
           --warmup N       unreported warmup trials (default: 3)\n\
           --seed N         deterministic base seed (default: 1)\n\
           --phase P        both (default) | decode. `decode` encodes once at\n\
                            setup and times decode alone; `both` is the\n\
                            interleaved loop and is the null.\n\
           --rs-rate R      auto|high|low  (reed-solomon-simd rate selection)\n\
           --stripes N      --codec rs: decode each shard as N byte-ranges,\n\
                            reusing one decoder and one erasure plan (default 1)\n\
           --arrivals A     random (default) | parity. `parity` hands the\n\
                            receiver only repair symbols -- the arrival set a\n\
                            Byzantine disperser may choose. Systematic codecs\n\
                            only; --codec r10 is non-systematic and refuses it.\n\
           -h, --help       show this help\n\n\
         Uses exactly k=f+1 and T=3f+1. Raw per-trial CSV is written to stdout."
    );
}

fn parse_args() -> Result<Config, String> {
    let mut f: Option<usize> = None;
    let mut symbol_size: Option<usize> = None;
    let mut codec: Option<Codec> = None;
    let mut trials = 20usize;
    let mut warmup = 3usize;
    let mut seed = 1u64;
    let mut rs_rate = RsRate::Auto;
    let mut stripes: usize = 1;
    let mut phase = Phase::Both;
    let mut arrivals = Arrivals::Random;
    let mut args = env::args().skip(1);

    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                usage();
                std::process::exit(0);
            }
            "--f" => {
                f = Some(
                    args.next()
                        .ok_or("--f needs a value")?
                        .parse()
                        .map_err(|e| format!("bad --f: {e}"))?,
                )
            }
            "--shard-bytes" => {
                symbol_size = Some(
                    args.next()
                        .ok_or("--shard-bytes needs a value")?
                        .parse()
                        .map_err(|e| format!("bad --shard-bytes: {e}"))?,
                )
            }
            "--codec" => codec = Some(Codec::parse(&args.next().ok_or("--codec needs a value")?)?),
            "--arrivals" => {
                arrivals = match args.next().ok_or("--arrivals needs a value")?.as_str() {
                    "random" => Arrivals::Random,
                    "parity" => Arrivals::Parity,
                    other => return Err(format!("unknown --arrivals {other}")),
                }
            }
            "--trials" => {
                trials = args
                    .next()
                    .ok_or("--trials needs a value")?
                    .parse()
                    .map_err(|e| format!("bad --trials: {e}"))?
            }
            "--warmup" => {
                warmup = args
                    .next()
                    .ok_or("--warmup needs a value")?
                    .parse()
                    .map_err(|e| format!("bad --warmup: {e}"))?
            }
            "--phase" => {
                phase = match args.next().as_deref() {
                    Some("both") => Phase::Both,
                    Some("encode") => Phase::Encode,
                    Some("decode") => Phase::Decode,
                    other => return Err(format!("bad --phase: {other:?}; use both, encode or decode")),
                }
            }
            "--seed" => {
                seed = args
                    .next()
                    .ok_or("--seed needs a value")?
                    .parse()
                    .map_err(|e| format!("bad --seed: {e}"))?
            }
            "--stripes" => {
                stripes = args
                    .next()
                    .ok_or("--stripes needs a value")?
                    .parse()
                    .map_err(|e| format!("bad --stripes: {e}"))?
            }
            "--rs-rate" => {
                rs_rate = RsRate::parse(&args.next().ok_or("--rs-rate needs a value")?)?
            }
            _ => return Err(format!("unknown argument: {arg}")),
        }
    }

    let f = f.ok_or("--f is required")?;
    let symbol_size = symbol_size.ok_or("--shard-bytes is required")?;
    let codec = codec.ok_or("--codec is required")?;
    let k = f.checked_add(1).ok_or("f overflows k=f+1")?;
    let _t = f
        .checked_mul(3)
        .and_then(|x| x.checked_add(1))
        .ok_or("f overflows T=3f+1")?;

    if !(SOURCE_SYMBOLS_MIN..=SOURCE_SYMBOLS_MAX).contains(&k) {
        return Err(format!(
            "f={f} gives k={k}, outside Monad R10 supported range {SOURCE_SYMBOLS_MIN}..={SOURCE_SYMBOLS_MAX}"
        ));
    }
    if symbol_size == 0 || symbol_size % 64 != 0 {
        return Err(format!(
            "shard size {symbol_size} must be positive and a multiple of 64 bytes"
        ));
    }
    if matches!(codec, Codec::RaptorQ) && symbol_size > u16::MAX as usize {
        return Err(format!(
            "RaptorQ unavailable: shard size {symbol_size} exceeds its u16 transfer-symbol-size field"
        ));
    }
    if trials == 0 {
        return Err("--trials must be positive".into());
    }
    Ok(Config {
        f,
        symbol_size,
        codec,
        trials,
        warmup,
        seed,
        rs_rate,
        stripes,
        phase,
        arrivals,
    })
}

#[derive(Clone)]
struct SplitMix64(u64);
impl SplitMix64 {
    fn next_u64(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9e3779b97f4a7c15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        z ^ (z >> 31)
    }

    fn fill_bytes(&mut self, dst: &mut [u8]) {
        for chunk in dst.chunks_mut(8) {
            let x = self.next_u64().to_le_bytes();
            chunk.copy_from_slice(&x[..chunk.len()]);
        }
    }

    fn shuffle<T>(&mut self, a: &mut [T]) {
        for i in (1..a.len()).rev() {
            let j = (self.next_u64() as usize) % (i + 1);
            a.swap(i, j);
        }
    }
}

/// A source block whose first byte is page-aligned.
///
/// Shard size is always a multiple of 64, so shard `i` starts on a cache-line
/// boundary exactly when the block does. A `Vec` this large is served by `mmap`
/// and the allocator's header puts its data at page + 16, which starts every
/// shard 16 bytes into a line and makes every 64-byte access straddle two --
/// worth up to 1.29x on encode (section 3.4 of the report). Both Cauchy drivers
/// align their shard pools; this gives the same footing to every codec that
/// reads its source from one contiguous block.
///
/// The recovery shards `rs_simd`, RaptorQ and R10 allocate internally are theirs
/// and are not reachable from here.
struct AlignedSource {
    buf: Vec<u8>,
    off: usize,
    len: usize,
}

impl std::ops::Deref for AlignedSource {
    type Target = [u8];
    fn deref(&self) -> &[u8] {
        &self.buf[self.off..self.off + self.len]
    }
}

/// `SOURCE_SKEW=N`: start the source block N bytes past the page boundary, the
/// same diagnostic as `TAPE_POOL_SKEW` and `ISAL_POOL_SKEW`. `SOURCE_SKEW=16`
/// reproduces what a plain `Vec` of this size gets from the allocator.
fn make_source(k: usize, symbol_size: usize, seed: u64) -> AlignedSource {
    let skew = env_usize("SOURCE_SKEW");
    let len = k * symbol_size;
    let mut buf = vec![0u8; len + POOL_SLACK + skew];
    let off = shard_offset(&buf, skew);
    SplitMix64(seed).fill_bytes(&mut buf[off..off + len]);
    AlignedSource { buf, off, len }
}

fn make_order(t: usize, seed: u64) -> Vec<usize> {
    let mut order: Vec<usize> = (0..t).collect();
    SplitMix64(seed).shuffle(&mut order);
    order
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Arrivals {
    Random,
    Parity,
}

/// Stable partition of an arrival order so PARITY/repair symbols (index >= k)
/// come first, leaving the receiver with none of the systematic symbols.
///
/// THE TWIN OF `arrivals_parity_first` IN codec/rs_point.c, AND IT MUST STAY SO.
/// `SplitMix64::shuffle` is the bit-exact contract that makes these codecs
/// comparable at one seed (MANIFEST.md); this partition is now part of that
/// contract, so both drivers must select the same arrivals from the same seed.
/// Stable, and over the same shuffle, for the same reason as there: the shuffle
/// still decides WHICH repair symbols arrive and in what order, so only the
/// class of the arriving symbol differs between the modes.
///
/// ONLY MEANINGFUL FOR A SYSTEMATIC CODE. `run_rq` and `run_rs` are systematic
/// -- RaptorQ's packet vector is `source ++ repair` and reed-solomon-simd's is
/// originals then recovery -- so `pos >= k` names a repair symbol in both. R10
/// here is the NON-systematic variant (`monad-raptor/src/r10/nonsystematic/`):
/// every transmitted symbol is already a repair symbol, there is no class to
/// partition by, and applying this would silently substitute a different random
/// draw for a worst case. `run_r10` therefore refuses the mode rather than
/// accepting it and reporting a number that means nothing.
fn arrivals_parity_first(order: &mut [usize], k: usize) {
    let mut out: Vec<usize> = Vec::with_capacity(order.len());
    out.extend(order.iter().copied().filter(|&x| x >= k));
    out.extend(order.iter().copied().filter(|&x| x < k));
    order.copy_from_slice(&out);
}

/// How many of the k symbols the receiver actually gets are repair symbols.
///
/// `BENCH_ARRIVALS_REPORT=1` prints it once per process to stderr. This exists
/// because a selection mode that silently does nothing looks exactly like a
/// codec that is insensitive to it, and the two must never be confused: under
/// `--arrivals parity` this must read k of k, and under `random` it should read
/// about 2k/3 at this rate. It is a check on the instrument, not a measurement,
/// so it is off by default and writes to stderr, which the CSV consumers ignore.
fn report_arrivals(order: &[usize], k: usize, tag: &str) {
    if env::var("BENCH_ARRIVALS_REPORT").as_deref() != Ok("1") {
        return;
    }
    let repair = order[..k].iter().filter(|&&x| x >= k).count();
    eprintln!("arrivals[{tag}]: {repair} of {k} received symbols are repair");
}

fn rq_config(k: usize, symbol_size: usize) -> ObjectTransmissionInformation {
    ObjectTransmissionInformation::new((k * symbol_size) as u64, symbol_size as u16, 1, 1, 8)
}

/// What `--phase decode` carries across trials, so the encoder runs once.
///
/// One struct rather than a per-codec enum: the fields a given codec does not
/// use stay empty, which costs nothing and keeps `run_one`'s five arms the same
/// shape. `ready` is set only under `Phase::Decode`; under `Phase::Both` it
/// stays false and every trial re-encodes exactly as before, so the null is the
/// same code path and not a parallel one.
///
/// `prev_present` is the restore, and it is needed for the same
/// reason it is needed in fd_point.c and leo_point.c: these decoders do not all
/// write their reconstruction back into the pool, and the zeroing that makes an
/// erased slot well-defined would otherwise leave it zero for the NEXT trial,
/// whose arrival set may include it. Only the slots erased last trial are
/// rewritten -- r*sz, not t*sz -- because a blanket restore would put back the
/// footprint this whole change exists to remove.
#[derive(Default)]
struct Prep {
    /// True only under `Phase::Decode`. Gates the snapshot and the
    /// prev_present bookkeeping, so `Phase::Both` does no extra work at all
    /// and stays the same code path it always was.
    active: bool,
    ready: bool,
    /// R10 / RaptorQ / reed-solomon-simd keep their encoded artefacts as owned
    /// values rather than in a shard pool, so they are held here instead.
    /// `AlignedSource` has no `Default`, hence the `Option`.
    src: Option<AlignedSource>,
    r10_symbols: Vec<Vec<u8>>,
    r10_pool: Vec<u8>,
    rs_recovery: Vec<Vec<u8>>,
    /// RaptorQ is the ONE decode here that consumes its input: it `take()`s
    /// packets by value. So it needs both a pristine set and a working set, and
    /// only the slots the previous trial actually consumed are refilled --
    /// `consumed` of t, typically about k rather than all t.
    ///
    /// This is the fountain-side residual section 3 names: an r10/rq decode
    /// carries a setup its RS counterparts do not. It is second-order next to
    /// the encoder being removed, and the delta between the two phases prices
    /// it directly rather than assuming it away.
    rq_pristine: Vec<RaptorQPacket>,
    rq_packets: Vec<Option<RaptorQPacket>>,
}

struct ResultRow {
    encode: Duration,
    /// False under `Phase::Encode` for every measured trial: no decode ran,
    /// so decode/plan/code/consumed are emitted EMPTY rather than as zeros.
    decoded: bool,
    decode: Duration,
    consumed: usize,
    /// Decode-plan construction, non-zero only for Tape. `decode` includes it.
    plan: Duration,
    /// Coding work plus source materialization: `decode` minus `plan`.
    code: Duration,
}

/// `R10_BUFS`: where the `t` encoded symbols are written.
///
/// `sep` (default) is the published behaviour -- `t` separate `Vec`s, one
/// allocation per symbol. `monad-bft` writes into caller-provided packet
/// storage instead, so the harness is charging R10 for an allocation the
/// deployment does not make; that is F2 in `HARNESS-FAIRNESS-MATRIX.md`.
///
/// A previous attempt to fix it wrote into one contiguous buffer at stride
/// `symbol_size` and made encode **5x slower** (1.48 -> 7.35 ms at 4 MiB), which
/// the handover files as unexplained. `contig` reproduces that spelling and
/// `pool` is the same thing at `pool_stride`, so the two can be measured
/// against each other. §3.1's rule says why they should differ: `symbol_size`
/// is a multiple of 4096 whenever the message is a power of two and `k` divides
/// it, and then all `t` destinations start in the same L1 set.
#[derive(Clone, Copy, PartialEq)]
enum R10Bufs {
    Sep,
    Contig,
    Pool,
}

impl R10Bufs {
    fn from_env() -> Self {
        match env::var("R10_BUFS").as_deref() {
            Ok("contig") => R10Bufs::Contig,
            Ok("pool") => R10Bufs::Pool,
            _ => R10Bufs::Sep,
        }
    }
}

fn run_r10(
    k: usize,
    t: usize,
    symbol_size: usize,
    seed: u64,
    verify: bool,
    reuse: bool,
    skip_decode: bool,
    prep: &mut Prep,
) -> Result<ResultRow, String> {
    // NO RESTORE. `received_encoded_symbol` takes the symbol BY REFERENCE and
    // the decoder is rebuilt every trial, so nothing the decode touches is
    // consumed or mutated -- the same property run_rs has, and unlike run_rq
    // below, which takes packets by value.
    if !reuse {
        prep.src = Some(make_source(k, symbol_size, seed ^ 0x535243));
    }
    let order = make_order(t, seed ^ 0x4f52444552);
    let bufs = R10Bufs::from_env();
    let stride = match bufs {
        R10Bufs::Pool => pool_stride(symbol_size),
        _ => symbol_size,
    };

    let encode = if reuse {
        Duration::ZERO
    } else {
    let src = prep.src.as_ref().unwrap();
    let start = Instant::now();
    let mut ph = Phases::new();
    let encoder = R10Encoder::new(black_box(&src), symbol_size)
        .map_err(|e| format!("R10 Encoder::new failed: {e}"))?;
    ph.mark("encoder_new");
    if encoder.num_source_symbols() != k {
        return Err(format!(
            "R10 chose {} source symbols, expected {k}",
            encoder.num_source_symbols()
        ));
    }
    let mut symbols: Vec<Vec<u8>> = Vec::new();
    let mut pool: Vec<u8> = Vec::new();
    match bufs {
        R10Bufs::Sep => {
            symbols.reserve(t);
            for esi in 0..t {
                let mut buf = vec![0u8; symbol_size];
                encoder.encode_symbol(black_box(&mut buf), esi);
                symbols.push(buf);
            }
            black_box(&symbols);
        }
        // One allocation for all t symbols, inside the timer as the separate
        // ones are, so the only variable is the layout. `encode_symbol` needs
        // its destination zeroed on entry, which `vec![0u8; ..]` gives.
        _ => {
            pool = vec![0u8; t * stride];
            ph.mark("pool_alloc");
            for esi in 0..t {
                let off = esi * stride;
                encoder.encode_symbol(black_box(&mut pool[off..off + symbol_size]), esi);
            }
            black_box(&pool);
        }
    }
    ph.mark("symbols_alloc+encode");
    let d = start.elapsed();
    ph.report("r10_encode", k - 1, symbol_size);
        prep.r10_symbols = symbols;
        prep.r10_pool = pool;
        d
    };
    // --phase encode: the decoder does not run in a measured trial. Every
    // decode-side column is emitted empty; see `ResultRow::decoded`.
    if skip_decode {
        return Ok(ResultRow {
            encode,
            decoded: false,
            decode: Duration::ZERO,
            consumed: 0,
            plan: Duration::ZERO,
            code: Duration::ZERO,
        });
    }

    let src = prep.src.as_ref().unwrap();
    let symbols = &prep.r10_symbols;
    let pool = &prep.r10_pool;

    let start = Instant::now();
    let mut ph = Phases::new();
    let mut decoder = ManagedDecoder::new(k, t, symbol_size)
        .map_err(|e| format!("ManagedDecoder::new failed: {e}"))?;
    ph.mark("decoder_new");
    let mut consumed = None;
    for (n, &esi) in order.iter().enumerate() {
        let sym: &[u8] = match bufs {
            R10Bufs::Sep => &symbols[esi],
            _ => &pool[esi * stride..esi * stride + symbol_size],
        };
        decoder.received_encoded_symbol(black_box(sym), esi);
        if decoder.try_decode() {
            consumed = Some(n + 1);
            break;
        }
    }
    let consumed = consumed.ok_or_else(|| format!("R10 did not decode for k={k},T={t}"))?;
    ph.mark("ingest+decode");
    let reconstructed = decoder
        .reconstruct_source_data()
        .ok_or("R10 reported success but reconstruction returned None")?;
    black_box(&reconstructed);
    ph.mark("reconstruct_alloc");
    let decode = start.elapsed();
    ph.report("r10_decode", k - 1, symbol_size);

    if verify && reconstructed[..] != src[..] {
        return Err("R10 reconstruction mismatch".into());
    }
    Ok(ResultRow {
        encode,
        decoded: true,
        decode,
        consumed,
        plan: Duration::ZERO,
        code: decode,
    })
}

fn run_rq(
    k: usize,
    t: usize,
    symbol_size: usize,
    seed: u64,
    arrivals: Arrivals,
    plan: &SourceBlockEncodingPlan,
    verify: bool,
    reuse: bool,
    skip_decode: bool,
    prep: &mut Prep,
) -> Result<ResultRow, String> {
    if symbol_size > u16::MAX as usize {
        return Err(format!(
            "RaptorQ unavailable: shard size {symbol_size} exceeds u16::MAX"
        ));
    }
    let recovery_count = t - k;
    if !reuse {
        prep.src = Some(make_source(k, symbol_size, seed ^ 0x535243));
    }
    let order = make_order(t, seed ^ 0x4f52444552);
    // Random reaches everything below byte-identically to before this mode
    // existed; only Parity rewrites the order, and it does so here at the point
    // of construction so there is exactly one place arrivals are decided.
    let mut order = order;
    if arrivals == Arrivals::Parity {
        arrivals_parity_first(&mut order, k);
    }
    report_arrivals(&order, k, "rq");
    let cfg = rq_config(k, symbol_size);

    let encode = if reuse {
        // Same rule as the shard copy-in: match what the other mode does out
        // of the timer. `both` builds all t packets from the encoder every
        // trial, so this clones all t, not just the ones the previous trial
        // consumed. Outside the timer.
        prep.rq_packets.clear();
        prep.rq_packets
            .extend(prep.rq_pristine.iter().map(|p| Some(p.clone())));
        Duration::ZERO
    } else {
    let src = prep.src.as_ref().unwrap();
    let start = Instant::now();
    let mut ph = Phases::new();
    let encoder = RaptorQBlockEncoder::with_encoding_plan(0, &cfg, black_box(&src), plan);
    ph.mark("encoder_new");
    let repair = encoder.repair_packets(0, recovery_count as u32);
    black_box(&repair);
    ph.mark("repair_alloc+encode");
    let d = start.elapsed();
    ph.report("rq_encode", k - 1, symbol_size);

    let source = encoder.source_packets();
    if source.len() != k || repair.len() != recovery_count {
        return Err("RaptorQ packet count mismatch".into());
    }
    let all: Vec<RaptorQPacket> = source.into_iter().chain(repair.into_iter()).collect();
    if prep.active {
        prep.rq_pristine = all.clone();
    }
    prep.rq_packets = all.into_iter().map(Some).collect();
    d
    };
    // --phase encode: the decoder does not run in a measured trial. Every
    // decode-side column is emitted empty; see `ResultRow::decoded`.
    if skip_decode {
        return Ok(ResultRow {
            encode,
            decoded: false,
            decode: Duration::ZERO,
            consumed: 0,
            plan: Duration::ZERO,
            code: Duration::ZERO,
        });
    }

    let src = prep.src.as_ref().unwrap();

    let start = Instant::now();
    let mut ph = Phases::new();
    let mut decoder = RaptorQDecoder::new(cfg);
    ph.mark("decoder_new");
    let mut result = None;
    let mut consumed = None;
    for (n, &pos) in order.iter().enumerate() {
        let packet = prep.rq_packets[pos]
            .take()
            .ok_or("RaptorQ packet consumed twice")?;
        if let Some(decoded) = decoder.decode(black_box(packet)) {
            result = Some(decoded);
            consumed = Some(n + 1);
            break;
        }
    }
    let reconstructed = result.ok_or_else(|| format!("RaptorQ did not decode for k={k},T={t}"))?;
    black_box(&reconstructed);
    ph.mark("ingest+decode+result");
    let decode = start.elapsed();
    ph.report("rq_decode", k - 1, symbol_size);

    if verify && reconstructed[..] != src[..] {
        return Err("RaptorQ reconstruction mismatch".into());
    }
    Ok(ResultRow {
        encode,
        decoded: true,
        decode,
        consumed: consumed.unwrap(),
        plan: Duration::ZERO,
        code: decode,
    })
}

/// reed-solomon-simd with the rate explicitly forced.
///
/// `DefaultRate` picks High or Low by comparing `original_count` and
/// `recovery_count` rounded up to powers of two. At `T = 3f+1` that selects
/// LowRate at some f, and those points underperform HighRate at an identical
/// FFT domain. Forcing the rate isolates that choice from padding.
///
/// Encode and decode are separate macros so each stays inside its own timer.
macro_rules! rs_forced_encode {
    ($enc:ident, $k:expr, $rec:expr, $sz:expr, $orig:expr) => {{
        let mut e = $enc::new($k, $rec, $sz, DefaultEngine::new(), None)
            .map_err(|err| format!("RS forced encoder new: {err}"))?;
        for shard in $orig.iter() {
            e.add_original_shard(shard)
                .map_err(|err| format!("RS forced add_original_shard: {err}"))?;
        }
        let res = e
            .encode()
            .map_err(|err| format!("RS forced encode: {err}"))?;
        let recovery: Vec<Vec<u8>> = res.recovery_iter().map(|s| s.to_vec()).collect();
        recovery
    }};
}

macro_rules! rs_forced_decode {
    ($dec:ident, $k:expr, $rec:expr, $sz:expr, $recv_o:expr, $recv_r:expr) => {{
        let mut d = $dec::new($k, $rec, $sz, DefaultEngine::new(), None)
            .map_err(|err| format!("RS forced decoder new: {err}"))?;
        for &(idx, shard) in $recv_o.iter() {
            d.add_original_shard(idx, shard)
                .map_err(|err| format!("RS forced add_original_shard: {err}"))?;
        }
        for &(idx, shard) in $recv_r.iter() {
            d.add_recovery_shard(idx, shard)
                .map_err(|err| format!("RS forced add_recovery_shard: {err}"))?;
        }
        let out = d
            .decode()
            .map_err(|err| format!("RS forced decode: {err}"))?;
        let restored: HashMap<usize, Vec<u8>> = out
            .restored_original_iter()
            .map(|(i, s)| (i, s.to_vec()))
            .collect();
        restored
    }};
}

/// Sizing hints for `reed-solomon-simd`, **not** held buffers.
///
/// The harness rule, adopted after the R10 and RaptorQ timers were decomposed:
/// **hoist out of the stripes, never out of the encode or decode.** R10 builds
/// its precode and allocates its output buffers inside its own timers, and
/// RaptorQ constructs its encoder inside its; those two are the baseline the
/// report prices the MDS requirement against, so any codec that hoists
/// allocation across calls is being measured on a different contract. A striped
/// decode may build one decoder and use it for every stripe of *that message* --
/// that is one decode's working memory, not a cache — but the next message
/// starts from nothing, exactly as R10's does.
///
/// What survives here is the *size* to ask for, from `(f, n, max_shard_bytes)`,
/// because a deployment knows its worst case up front and would not resize per
/// message. `RS_MAX_SHARD_BYTES` sets it; unset means this run's shard size.
struct RsScratch {
    /// Worst-case shard size this process will be asked for.
    max_bytes: usize,
}

impl RsScratch {
    fn new(_k: usize, _t: usize, symbol_size: usize) -> Self {
        let max_bytes = match env::var("RS_MAX_SHARD_BYTES") {
            Ok(v) => v.parse::<usize>().unwrap_or(symbol_size).max(symbol_size),
            Err(_) => symbol_size,
        };
        RsScratch { max_bytes }
    }
}

/// Sub-phase breakdown of a decode timer.
///
/// `BENCH_DECODE_BREAKDOWN=1` prints one stderr line per decode naming where
/// the time inside the `decode` timer went. **The timer's contents do not
/// change**: the total still holds everything an application would pay --
/// buffer allocation, shard ingest, the codec, and materializing the message.
/// The breakdown only says how that total divides.
///
/// Two cautions, both learned the hard way in this project.
///
/// 1. §3.6: whichever phase first touches freshly mapped memory is charged for
///    the faults. `reed-solomon-simd` allocates its work buffer inside `new`
///    and the harness allocates `reconstructed` fresh per trial, so `new` and
///    `materialize` each carry fault cost that belongs to no phase in
///    particular. Take medians over many trials and read the split as
///    indicative, not exact. The **total** is exact.
/// 2. §3.7: the same knob drives `isal_point16.c`, so the two drivers can be
///    compared phase by phase. A breakdown in one driver only is how four
///    earlier fixes came to be asymmetric.
fn decode_breakdown() -> bool {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ON.get_or_init(|| env::var("BENCH_DECODE_BREAKDOWN").as_deref() == Ok("1"))
}

struct Phases {
    on: bool,
    last: Instant,
    out: Vec<(&'static str, f64)>,
}

impl Phases {
    fn new() -> Self {
        Self { on: decode_breakdown(), last: Instant::now(), out: Vec::new() }
    }
    #[inline]
    fn mark(&mut self, name: &'static str) {
        if !self.on {
            return;
        }
        let now = Instant::now();
        let prev = std::mem::replace(&mut self.last, now);
        self.out.push((name, now.duration_since(prev).as_secs_f64() * 1e3));
    }
    fn report(&self, codec: &str, f: usize, shard_bytes: usize) {
        if !self.on {
            return;
        }
        let parts: Vec<String> =
            self.out.iter().map(|(n, ms)| format!("{n}={ms:.6}")).collect();
        eprintln!(
            "decode_breakdown impl={codec} f={f} shard_bytes={shard_bytes} | {}",
            parts.join(" ")
        );
    }
}

fn run_rs(
    k: usize,
    t: usize,
    symbol_size: usize,
    seed: u64,
    arrivals: Arrivals,
    verify: bool,
    rate: RsRate,
    stripes: usize,
    scratch: &mut RsScratch,
    reuse: bool,
    skip_decode: bool,
    prep: &mut Prep,
) -> Result<ResultRow, String> {
    let recovery_count = t - k;
    // NO RESTORE HERE, and unlike the tape and ISA-L paths that is not an
    // oversight: this decode reads `src` and `recovery` immutably and writes its
    // output into a freshly allocated `reconstructed`, so nothing it touches
    // needs putting back. `--phase decode` costs this label only the encode it
    // skips.
    if !reuse {
        prep.src = Some(make_source(k, symbol_size, seed ^ 0x535243));
    }
    let order = make_order(t, seed ^ 0x4f52444552);
    // Random reaches everything below byte-identically to before this mode
    // existed; only Parity rewrites the order, and it does so here at the point
    // of construction so there is exactly one place arrivals are decided.
    let mut order = order;
    if arrivals == Arrivals::Parity {
        arrivals_parity_first(&mut order, k);
    }
    report_arrivals(&order, k, "rs");

    // `RS_ENC_BORROW=0` restores the copy; the default is to borrow.
    //
    // `reed_solomon_simd::encode` is a convenience wrapper whose last line is
    // `recovery_iter().map(to_vec).collect()` -- an 8.36 MB copy at
    // f = 255 / 4 MiB, out of a buffer the encoder already owns. The crate also
    // exposes `ReedSolomonEncoder` with `recovery_iter()` yielding borrowed
    // slices, so a caller who does not need owned shards need not pay it.
    //
    // `isal_point.c` writes parity into the shard pool and its decode reads it
    // from there, copying nothing; F2 in HARNESS-FAIRNESS-MATRIX.md is that
    // `rs_simd` was charged for a copy the Cauchy labels never make. The copy
    // still happens here -- the decode phase below needs owned shards -- but
    // outside the timer, which is where the equivalent bookkeeping sits for
    // every other label.
    let encode: Duration = if reuse {
        Duration::ZERO
    } else {
        let src_ref = prep.src.as_ref().unwrap();
        let original_shards: Vec<&[u8]> = src_ref.chunks_exact(symbol_size).collect();
        let (d, recovery): (Duration, Vec<Vec<u8>>) =
        if matches!(rate, RsRate::Auto) && env::var("RS_ENC_BORROW").as_deref() != Ok("0") {
            let start = Instant::now();
            let mut e = ReedSolomonEncoder::new(k, recovery_count, symbol_size)
                .map_err(|err| format!("RS encoder new: {err}"))?;
            for shard in original_shards.iter() {
                e.add_original_shard(shard)
                    .map_err(|err| format!("RS add_original_shard: {err}"))?;
            }
            let res = e.encode().map_err(|err| format!("RS encode failed: {err}"))?;
            black_box(&res);
            let d = start.elapsed();
            (d, res.recovery_iter().map(<[u8]>::to_vec).collect())
        } else {
            let start = Instant::now();
            let recovery: Vec<Vec<u8>> = match rate {
                RsRate::Auto => rs_encode(k, recovery_count, black_box(&original_shards))
                    .map_err(|e| format!("RS encode failed: {e}"))?,
                RsRate::High => {
                    rs_forced_encode!(HighRateEncoder, k, recovery_count, symbol_size, original_shards)
                }
                RsRate::Low => {
                    rs_forced_encode!(LowRateEncoder, k, recovery_count, symbol_size, original_shards)
                }
            };
            black_box(&recovery);
            (start.elapsed(), recovery)
        };
        drop(original_shards);
        prep.rs_recovery = recovery;
        d
    };
    // --phase encode: the decoder does not run in a measured trial. Every
    // decode-side column is emitted empty; see `ResultRow::decoded`.
    if skip_decode {
        return Ok(ResultRow {
            encode,
            decoded: false,
            decode: Duration::ZERO,
            consumed: 0,
            plan: Duration::ZERO,
            code: Duration::ZERO,
        });
    }

    let src = prep.src.as_ref().unwrap();
    let original_shards: Vec<&[u8]> = src.chunks_exact(symbol_size).collect();
    let recovery = &prep.rs_recovery;

    let received = &order[..k];
    let start = Instant::now();
    let mut ph = Phases::new();
    let mut originals = Vec::<(usize, &[u8])>::new();
    let mut recovery_in = Vec::<(usize, &[u8])>::new();
    let mut present = vec![false; k];
    for &pos in received {
        if pos < k {
            originals.push((pos, original_shards[pos]));
            present[pos] = true;
        } else {
            recovery_in.push((pos - k, &recovery[pos - k]));
        }
    }
    ph.mark("index");

    // STRIPED PATH: one decoder for *this* decode, used for every stripe of it,
    // and allocated inside the timer like R10's and RaptorQ's are. Hoisted out
    // of the stripes, not out of the decode. See `RsScratch`.
    if matches!(rate, RsRate::Auto) {
        let mut d = ReedSolomonDecoder::new(k, recovery_count, scratch.max_bytes)
            .map_err(|e| format!("RS decoder new: {e}"))?;
        let mut reconstructed = vec![0u8; k * symbol_size];
        ph.mark("alloc");

        // Stripe length, rounded up to 64. `symbol_size` is already a multiple
        // of 64 (grid.py's ALIGN), so every stripe including the last is too,
        // which keeps `shard_bytes % 2 == 0` for the decoder.
        let stripe = if stripes <= 1 {
            symbol_size
        } else {
            ((symbol_size.div_ceil(stripes) + 63) & !63).min(symbol_size)
        };

        // THE WORKING TREE CALLED `engine::utils::plan_invalidate()` HERE, and
        // this artifact cannot and must not. That function does not exist in
        // reed-solomon-simd 3.1.0 as published; it belongs to the vendored
        // tree's `RS_PLAN_CACHE` addition, which caches a decode plan across the
        // stripes of one message. Its purpose was to stop that cache outliving a
        // decode and crediting striping with a reuse no caller gets -- the
        // stripes of *this* message share an erasure pattern, successive
        // messages do not.
        //
        // Stock 3.1.0 HAS NO SUCH CACHE, so there is nothing to invalidate and
        // no reuse to guard against; removing the call is behaviour-identical
        // against this dependency rather than a simplification of it. It was
        // also a no-op in the working tree unless `RS_PLAN_CACHE=1`, which no
        // campaign sets. docs/LIMITS.md records the whole delta.

        let mut off = 0;
        while off < symbol_size {
            let l = stripe.min(symbol_size - off);
            d.reset(k, recovery_count, l)
                .map_err(|e| format!("RS decoder reset: {e}"))?;
            for &(idx, shard) in originals.iter() {
                d.add_original_shard(idx, &shard[off..off + l])
                    .map_err(|e| format!("RS add_original_shard: {e}"))?;
            }
            for &(idx, shard) in recovery_in.iter() {
                d.add_recovery_shard(idx, &shard[off..off + l])
                    .map_err(|e| format!("RS add_recovery_shard: {e}"))?;
            }
            ph.mark("ingest");
            let out = d.decode().map_err(|e| format!("RS decode failed: {e}"))?;
            ph.mark("algebra+kernel");
            for i in 0..k {
                let dst = &mut reconstructed[i * symbol_size + off..i * symbol_size + off + l];
                match out.restored_original(i) {
                    Some(sh) => dst.copy_from_slice(sh),
                    None => dst.copy_from_slice(&original_shards[i][off..off + l]),
                }
            }
            drop(out);
            off += l;
        }
        black_box(&reconstructed);
        ph.mark("materialize");
        let decode = start.elapsed();
        ph.report("rs_simd", k - 1, symbol_size);
        if verify && reconstructed[..] != src[..] {
            return Err("RS reconstruction mismatch".into());
        }
        return Ok(ResultRow {
            encode,
            decoded: true,
            decode,
            consumed: k,
            plan: Duration::ZERO,
            code: decode,
        });
    }

    let restored: HashMap<usize, Vec<u8>> = match rate {
        // Instrumented spelling of the `RsRate::Auto` arm below. Same calls, in
        // the same order, producing the same value -- including the `BTreeMap`
        // that `reed_solomon_simd::decode` allocates and the second copy this
        // harness then makes of it. Only taken when the knob is on, so the
        // default measured path is untouched, and the totals of the two
        // spellings are compared before any split is quoted.
        RsRate::Auto if ph.on => {
            let mut d = ReedSolomonDecoder::new(k, recovery_count, symbol_size)
                .map_err(|e| format!("RS decoder new: {e}"))?;
            ph.mark("alloc");
            for &(idx, shard) in originals.iter() {
                d.add_original_shard(idx, shard)
                    .map_err(|e| format!("RS add_original_shard: {e}"))?;
            }
            for &(idx, shard) in recovery_in.iter() {
                d.add_recovery_shard(idx, shard)
                    .map_err(|e| format!("RS add_recovery_shard: {e}"))?;
            }
            ph.mark("ingest");
            let out = d.decode().map_err(|e| format!("RS decode failed: {e}"))?;
            ph.mark("algebra+kernel");
            let mut tree = std::collections::BTreeMap::new();
            for (index, original) in out.restored_original_iter() {
                tree.insert(index, original.to_vec());
            }
            ph.mark("collect");
            let m: HashMap<usize, Vec<u8>> =
                tree.into_iter().map(|(i, s)| (i, s.to_vec())).collect();
            ph.mark("rehash");
            m
        }
        RsRate::Auto => rs_decode(k, recovery_count, black_box(originals), black_box(recovery_in))
            .map_err(|e| format!("RS decode failed: {e}"))?
            .into_iter()
            .map(|(i, s)| (i, s.to_vec()))
            .collect(),
        RsRate::High => rs_forced_decode!(
            HighRateDecoder,
            k,
            recovery_count,
            symbol_size,
            originals,
            recovery_in
        ),
        RsRate::Low => rs_forced_decode!(
            LowRateDecoder,
            k,
            recovery_count,
            symbol_size,
            originals,
            recovery_in
        ),
    };
    let mut reconstructed = Vec::with_capacity(k * symbol_size);
    for i in 0..k {
        if present[i] {
            reconstructed.extend_from_slice(original_shards[i]);
        } else {
            reconstructed.extend_from_slice(
                restored
                    .get(&i)
                    .ok_or_else(|| format!("missing restored shard {i}"))?,
            );
        }
    }
    black_box(&reconstructed);
    ph.mark("materialize");
    let decode = start.elapsed();
    ph.report("rs_simd", k - 1, symbol_size);

    if verify && reconstructed[..] != src[..] {
        return Err("RS reconstruction mismatch".into());
    }
    Ok(ResultRow {
        encode,
        decoded: true,
        decode,
        consumed: k,
        plan: Duration::ZERO,
        code: decode,
    })
}

/// Shard stride for the harness's pooled shard storage.
///
/// Two conflict classes have to be dodged, and dodging one is what used to walk
/// into the other:
///
///   * a stride whose 64-byte chunk count shares factors of 2 with 64 confines
///     the shards to few L1 sets -- Zen 4's L1d indexes on address bits 6-11 --
///     so the k source streams contend for 8 ways. At the limit, a multiple of
///     4096 starts every shard in one set;
///   * a stride whose 64-byte chunk count has odd part 31 or 33 -- within one
///     thirty-second of a power of two -- is `stride_64_for`'s class in section
///     5.13, worth 1.2x-1.7x on this crate's work buffer.
///
/// Through rev 19 this returned the next *odd* multiple of 64, which handles the
/// first class and ignores the second -- and forcing `stride / 64` odd means it
/// lands *on* the second whenever that quotient comes out 31 or 33, i.e. stride
/// 1984 or 2112. `pool_stride(2048)` is 2112 = 64 * 33, precisely the f = 2048
/// outlier: the rule meant to avoid conflicts was steering into one.
///
/// So keep the odd requirement -- the stronger form of the first condition,
/// coprimality with 64 rather than merely not 4096 -- and add the second,
/// stepping up by 64 until both hold. Six of the grid's 96 shapes change, all
/// of them 33 * 64 -> 35 * 64. Measured at f = 2048, 2048-byte
/// shards, encode 5.45 -> 2.85 ms and decode 15.53 -> 10.12 ms.
///
/// This matches `rs_point.c`'s `ISAL_SHARD_PAD=auto`. It does **not** match
/// `stride_64_for` inside the crate, though this comment claimed it did in
/// rev 20: that function excludes only the second class and does not force the
/// quotient odd, so at a power-of-two shard size it leaves the stride alone
/// where these two pad it. Measured at a few percent and in the crate's favour
/// outside the grid -- `PERF-NOTES-LARGE-F.md` 1.2. `POOL_STRIDE_ODD=1`
/// restores the rev-19 rule.
fn pool_stride(sz: usize) -> usize {
    let mut stride = ((sz + 63) & !63).max(64);
    if env::var("POOL_STRIDE_ODD").as_deref() == Ok("1") {
        if (stride / 64) % 2 == 0 {
            stride += 64;
        }
        return stride;
    }
    while !stride_ok(stride) {
        stride += 64;
    }
    stride
}

/// `stride / 64` odd -- hence coprime with 64, so consecutive shards walk all 64
/// L1 sets -- and not 31 or 33, section 5.13's class.
fn stride_ok(stride: usize) -> bool {
    let n = stride / 64;
    n % 2 == 1 && n != 31 && n != 33
}

// Shared helpers. `SOURCE_SKEW` is read by `make_source`, so these are NOT
// tape-only and survive the tape removal.
fn env_usize(name: &str) -> usize {
    env::var(name).ok().and_then(|v| v.parse().ok()).unwrap_or(0)
}

/// Slack at the head of the pool, so the shards can start on a page boundary
/// whatever address the allocator returns.
const POOL_SLACK: usize = 4096;

/// Where the shards start inside the pool: the first page boundary at or after
/// its base, plus `TAPE_POOL_SKEW`.
///
/// A `Vec` of this size is served by mmap and the allocator's header puts its
/// data at page + 16, so shards would start 16 bytes into a cache line and every
/// 64-byte access would straddle two. Measured at f = 80 / 4 MiB that is worth
/// 1.29x on encode and 1.18x on decode, and both harnesses respond to it
/// identically -- see the report, section 3.4. `isal_point.c` page-aligns its
/// pool the same way.
fn shard_offset(pool: &[u8], skew: usize) -> usize {
    let base = pool.as_ptr() as usize;
    (4096 - base % 4096) % 4096 + skew
}

/// This process's minor fault count: field 10 of `/proc/self/stat`, which is the

fn ms(d: Duration) -> f64 {
    d.as_secs_f64() * 1e3
}

fn main() {
    let cfg = match parse_args() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}\n");
            usage();
            std::process::exit(2);
        }
    };

    // `--arrivals parity` names a class of transmitted symbol, and only a
    // SYSTEMATIC code has two classes. R10 here is monad-raptor's
    // non-systematic variant and the retired tape codecs are not measured, so
    // for those the flag would quietly become "a different random draw"
    // reported as a worst case. Refuse instead.
    if cfg.arrivals == Arrivals::Parity && !matches!(cfg.codec, Codec::RaptorQ | Codec::Rs) {
        eprintln!(
            "--arrivals parity needs a systematic code: rq or rs. \
             r10 here is monad-raptor's NON-systematic variant, so every \
             transmitted symbol is already a repair symbol and there is no \
             source/repair split to select on."
        );
        std::process::exit(2);
    }    let k = cfg.f + 1;
    let t = 3 * cfg.f + 1;

    let rq_plan = if matches!(cfg.codec, Codec::RaptorQ) {
        Some(SourceBlockEncodingPlan::generate(k as u16))
    } else {
        None
    };

    println!("f,k,T,symbol_bytes,trial,codec,tape_field,tape_gen,plan_algo,encode_ms,decode_ms,plan_ms,code_ms,symbols_consumed,consumed_per_k");

    let mut rs_scratch = if matches!(cfg.codec, Codec::Rs) {
        Some(RsScratch::new(k, t, cfg.symbol_size))
    } else {
        None
    };

    // Built once. Under `--phase decode` the first call encodes and fills it;
    // every later call reuses it, so the encoder never runs inside the measured
    // loop. Under `--phase both` `active` is false, `reuse` is always false, and
    // this costs one bool per trial.
    let mut prep = Prep {
        active: cfg.phase == Phase::Decode,
        ..Default::default()
    };
    let mut run_one = |seed: u64, verify: bool| -> Result<ResultRow, String> {
        let reuse = prep.active && prep.ready;
        // Under Phase::Encode the decoder runs ONCE, on the first invocation,
        // as the correctness gate; every later trial is encode alone.
        let skip_decode = cfg.phase == Phase::Encode && prep.ready;
        let row = match cfg.codec {
            Codec::R10 => run_r10(k, t, cfg.symbol_size, seed, verify, reuse, skip_decode, &mut prep),
            Codec::RaptorQ => run_rq(
                k,
                t,
                cfg.symbol_size,
                seed,
                cfg.arrivals,
                rq_plan.as_ref().unwrap(),
                verify,
                reuse,
                skip_decode,
                &mut prep,
            ),
            Codec::Rs => run_rs(
                k,
                t,
                cfg.symbol_size,
                seed,
                cfg.arrivals,
                verify,
                cfg.rs_rate,
                cfg.stripes,
                rs_scratch.as_mut().unwrap(),
                reuse,
                skip_decode,
                &mut prep,
            ),
        };
        prep.ready = true;
        row
    };

    for w in 0..cfg.warmup {
        let seed = cfg.seed
            ^ ((cfg.f as u64) << 48)
            ^ ((k as u64) << 32)
            ^ (t as u64)
            ^ (cfg.symbol_size as u64).rotate_left(17)
            ^ (w as u64).wrapping_mul(0x9e3779b97f4a7c15);
        if let Err(e) = run_one(seed, true) {
            eprintln!("warmup failed: {e}");
            std::process::exit(1);
        }
    }

    for trial in 0..cfg.trials {
        let seed = cfg.seed
            ^ ((cfg.f as u64) << 48)
            ^ ((k as u64) << 32)
            ^ (t as u64)
            ^ (cfg.symbol_size as u64).rotate_left(17)
            ^ ((trial + cfg.warmup) as u64).wrapping_mul(0xd1b54a32d192ed03);
        let r = run_one(seed, true).unwrap_or_else(|e| {
            eprintln!("trial failed: {e}");
            std::process::exit(1);
        });
        // Columns 7 and 8 (`tape_field`, `tape_gen`) are inert for every codec
        // in this artifact and always emit "-". THE NAMES ARE KEPT because
        // codec/rs_point.c and references/fd_point.c emit the SAME 15-column
        // header, and one CSV format across all three drivers is worth more than
        // two tidier column names in one of them. docs/LIMITS.md records it.
        let field_label = "-";
        let gen_label = "-";
        let plan_label = if matches!(cfg.codec, Codec::Rs) {
            cfg.rs_rate.name()
        } else {
            "-"
        };
        println!(
            "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}",
            cfg.f,
            k,
            t,
            cfg.symbol_size,
            trial,
            cfg.codec.name(),
            field_label,
            gen_label,
            plan_label,
            // --phase decode: the setup encode is NOT A MEASUREMENT -- it exists
            // only to give the decoder a codeword -- so the column is emitted
            // EMPTY. Empty rather than zero or the value: a consumer that
            // reaches for it gets nothing instead of a wrong number.
            match cfg.phase {
                Phase::Both | Phase::Encode => format!("{:.6}", ms(r.encode)),
                Phase::Decode => String::new(),
            },
            if r.decoded { format!("{:.6}", ms(r.decode)) } else { String::new() },
            if r.decoded { format!("{:.6}", ms(r.plan)) } else { String::new() },
            if r.decoded { format!("{:.6}", ms(r.code)) } else { String::new() },
            if r.decoded { r.consumed.to_string() } else { String::new() },
            if r.decoded { format!("{:.8}", r.consumed as f64 / k as f64) } else { String::new() }
        );
    }
}
