#!/usr/bin/env python3
"""The pivot base kp: what code it makes, that the code is MDS, and that the
decoder's diagonals are right at every kp.  Companion to
PERF-NOTES-FFT-GF8-PPT.md section 12.  Shares no code with rs_point.c.

ISAL8_INTERP=kp interpolates the degree-<kp polynomial through the data at
0..k-1 and ZEROS at k..kp-1, and evaluates at kp..kp+m-1.  Writing
Z(x) = prod_{l=k}^{kp-1} (x ^ l), the encoded polynomial is Q = Z*g with
deg g < k, so

    data_j   = Q(j)      = Z(j) g(j)
    parity_i = Q(kp+i)   = Z(kp+i) g(kp+i)

and eliminating g gives a GENERALIZED Reed-Solomon code on the node set
{0..k-1} u {kp..kp+m-1}:

    G[i][j] = ( Z(kp+i) / Z(j) ) * L_j(kp+i),   L over the k DATA nodes only.

kp = k gives Z == 1, i.e. firedancer's plain evaluation code.  Every kp is MDS,
and every one has the diag(A) C diag(1/W) shape the closed-form plan inverts --
which is why the decode does not change by a line.  Sections 1-3 are the three
claims in that order.  About twenty seconds, no dependencies.
"""
import functools, random, sys

# ------------------------------------------------ GF(2^8) mod 0x11d, ISA-L's
E = [0] * 512; LOG = [0] * 256; _x = 1
for _i in range(255):
    E[_i] = _x; LOG[_x] = _i; _x <<= 1
    if _x & 0x100: _x ^= 0x11d
for _i in range(255, 512): E[_i] = E[_i - 255]
def mul(a, b): return 0 if (a == 0 or b == 0) else E[LOG[a] + LOG[b]]
def inv(a):
    assert a, "inverse of zero"
    return E[(255 - LOG[a]) % 255]
def div(a, b): return mul(a, inv(b))

def Z(y, k, kp): return functools.reduce(mul, [(y ^ l) for l in range(k, kp)], 1)

def eval_entry(k, kp, i, j):
    """rs_point.c's eval_entry with ev_D = kp: A_i / ( ((kp+i)^j) * W_j )."""
    A = functools.reduce(mul, [((kp + i) ^ l) for l in range(kp)], 1)
    W = functools.reduce(mul, [(j ^ l) for l in range(kp) if l != j], 1)
    return div(div(A, W), (kp + i) ^ j)

def grs_entry(k, kp, i, j):
    """The GRS form: ( Z(kp+i) / Z(j) ) * L_j(kp+i), L over 0..k-1."""
    num = functools.reduce(mul, [((kp + i) ^ l) for l in range(k) if l != j], 1)
    den = functools.reduce(mul, [(j ^ l) for l in range(k) if l != j], 1)
    return mul(div(Z(kp + i, k, kp), Z(j, k, kp)), div(num, den))

def bases(k, m):
    ch = 1
    while ch < k: ch *= 2
    hi = min(ch, 256 - m)
    return sorted({v for v in (k, (k + hi) // 2, hi) if k <= v <= hi})

SHAPES = [(5, 7), (6, 10), (20, 12), (33, 64), (34, 66), (66, 130), (73, 144), (86, 170)]

# ------------------------- 1. the code the pivot base makes is the GRS code
print("=== 1. eval_entry(kp) == ( Z(kp+i)/Z(j) ) * L_j(kp+i) ===")
n = bad = 0
for k, m in SHAPES:
    for kp in bases(k, m):
        for i in range(m):
            for j in range(k):
                n += 1
                if eval_entry(k, kp, i, j) != grs_entry(k, kp, i, j):
                    bad += 1
                    if bad < 4: print("  MISMATCH k=%d m=%d kp=%d i=%d j=%d" % (k, m, kp, i, j))
    print("  k=%3d m=%3d  kp in %-18s ok" % (k, m, bases(k, m)))
print("  %d generator entries, %d mismatches" % (n, bad))
assert bad == 0

# --------------------------------------------------- 2. every one is MDS
print()
print("=== 2. MDS: every k x k survivor submatrix inverts ===")
def invert(M, nn):
    A = [row[:] + [1 if r == c else 0 for c in range(nn)] for r, row in enumerate(M)]
    for c in range(nn):
        p = next((r for r in range(c, nn) if A[r][c]), None)
        if p is None: return None
        A[c], A[p] = A[p], A[c]
        iv = inv(A[c][c]); A[c] = [mul(v, iv) for v in A[c]]
        for r in range(nn):
            if r != c and A[r][c]:
                f = A[r][c]; A[r] = [a ^ mul(f, b) for a, b in zip(A[r], A[c])]
    return [row[nn:] for row in A]

random.seed(20260825)
for k, m in SHAPES[:6]:
    for kp in bases(k, m):
        G = [[1 if r == j else 0 for j in range(k)] for r in range(k)] + \
            [[eval_entry(k, kp, i, j) for j in range(k)] for i in range(m)]
        tries = 0
        for _ in range(12):
            sel = random.sample(range(k + m), k)
            assert invert([G[s] for s in sel], k) is not None, (k, m, kp, sel)
            tries += 1
        print("  k=%3d m=%3d kp=%3d  %2d random survivor sets, all invertible" % (k, m, kp, tries))

# ------------------- 3. the decoder's diagonals, against Gaussian elimination
print()
print("=== 3. the closed-form plan's two diagonals, at every kp ===")
print("    B = diag(A) C_B diag(1/W)  =>  B^-1 E = diag(W_y)(C_B^-1 C_E)diag(1/W_u)")
print("    -- A cancels, because B and E share their rows.  Checked against a")
print("    Gaussian-elimination inverse of the true B.")
for k, m in SHAPES[:6]:
    for kp in bases(k, m):
        W  = [functools.reduce(mul, [(j ^ l) for l in range(kp) if l != j], 1) for j in range(k)]
        A  = [functools.reduce(mul, [((kp + i) ^ l) for l in range(kp)], 1) for i in range(m)]
        for trial in range(3):
            got = sorted(random.sample(range(k + m), k))
            miss = [j for j in range(k) if j not in got]
            r = len(miss)
            if r == 0 or r > m: continue
            par = [g - k for g in got if g >= k][:r]
            if len(par) < r: continue
            src = [g for g in got if g < k]
            # true B (parity rows x missing cols) and E (parity rows x received src)
            B = [[eval_entry(k, kp, i, j) for j in miss] for i in par]
            Ee = [[eval_entry(k, kp, i, j) for j in src] for i in par]
            Bi = invert(B, r)
            assert Bi is not None, (k, m, kp, "singular B")
            ref = [[functools.reduce(lambda a, t: a ^ mul(Bi[b][t], Ee[t][c]), range(r), 0)
                    for c in range(len(src))] for b in range(r)]
            # closed form: pure Cauchy on the NODES, then the two diagonals
            xs = [kp + i for i in par]; ys = miss; us = src
            C = [[inv(xs[a] ^ ys[b]) for b in range(r)] for a in range(r)]
            Ci = invert(C, r)
            CE = [[functools.reduce(lambda acc, t: acc ^ mul(Ci[b][t], inv(xs[t] ^ us[c])),
                                    range(r), 0) for c in range(len(us))] for b in range(r)]
            cf = [[mul(mul(W[ys[b]], CE[b][c]), inv(W[us[c]])) for c in range(len(us))]
                  for b in range(r)]
            assert cf == ref, (k, m, kp, trial)
        print("  k=%3d m=%3d kp=%3d  3 random erasure patterns, closed form == GE" % (k, m, kp))

print()
print("ALL PIVOT-BASE CLAIMS VERIFY.")
