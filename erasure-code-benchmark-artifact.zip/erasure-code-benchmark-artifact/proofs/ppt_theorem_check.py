#!/usr/bin/env python3
"""Is X's pivot set inside Lin-Alloum-Al-Naffouri's Corollary 1, or outside it?

The attribution question for `ISAL8_INTERP`.  Lin, Alloum and Al-Naffouri,
"Principal pivot transforms on radix-2 DFT-type matrices" (ISIT 2017,
pp. 2358-2362) define the PPT for an ARBITRARY pivot set Theta and then give a
sufficient condition on Theta under which the transform still divides and
conquers in O(N lg N).  Their Proposition 1 uses exactly one instance of it,
Theta = [k], and remarks that it "fits Corollary 1".

X interpolates the degree-<kp polynomial through the data at 0..k-1 and zeros at
k..kp-1, i.e. it knows y[1..kp] and x[kp+1..N] and solves for the rest.  That is
the PPT with Theta = [kp] -- still a PREFIX, just a longer one.  So the question
is whether every prefix fits their condition, or only [k].

Their Theorem 1, at one node of the recursion over a block of size n:

    Theta_1 = Theta n [n/2],   Theta_2 = {a - n/2 : a in Theta, a > n/2}

and the transform splits in O(n) if EITHER

    (i)  Theta_2 subset-of Theta_1   and B[i][1,1] != 0 for all i, OR
    (ii) Theta_1 subset-of Theta_2   and B[i][2,2] != 0 for all i.

Corollary 1 is that condition applied at every node of the recursion.  This
script implements it literally and asks it about prefixes.  No dependencies,
about a second.  It is a statement about the ALGORITHM's applicability, not
about any field: the B[i] nonsingularity side condition is checked separately by
pivot_check.py, which inverts the actual matrices.
"""
import sys

def split(theta, n):
    """Theta_1 and Theta_2 of Theorem 1, as sets of 1-based indices."""
    half = n // 2
    t1 = {a for a in theta if a <= half}
    t2 = {a - half for a in theta if a > half}
    return t1, t2

def fits(theta, n, trace=None):
    """Corollary 1: Theorem 1's condition at every node of the recursion."""
    if n == 1:
        return True
    t1, t2 = split(theta, n)
    branch = None
    if t2 <= t1:
        branch = "(i)  Theta_2 subset Theta_1"
    elif t1 <= t2:
        branch = "(ii) Theta_1 subset Theta_2"
    else:
        if trace is not None:
            trace.append((n, sorted(theta), sorted(t1), sorted(t2), "NEITHER"))
        return False
    if trace is not None:
        trace.append((n, sorted(theta), sorted(t1), sorted(t2), branch))
    return fits(t1, n // 2, trace) and fits(t2, n // 2, trace)

fail = 0

# --- 1. every prefix, every power-of-two block size up to the field ---------
print("1. Theta = [P] for every P, every N -- the claim X rests on")
worst = None
for lg in range(1, 9):
    N = 1 << lg
    bad = [P for P in range(N + 1) if not fits(set(range(1, P + 1)), N)]
    print(f"   N = {N:3d}:  prefixes tested {N+1:4d}   failing {len(bad)}")
    if bad:
        worst = (N, bad); fail += 1
print("   -> every prefix of every block size satisfies Corollary 1"
      if not worst else f"   -> FAILURES at {worst}")

# --- 2. and the condition is not vacuous -----------------------------------
# If every set passed, the check above would say nothing.  Enumerate ALL subsets
# at N = 8 and N = 16 and count how many fit.
print("\n2. the condition is not vacuous -- all subsets, N = 8 and N = 16")
for N in (8, 16):
    tot = 1 << N
    ok = sum(1 for mask in range(tot)
             if fits({i + 1 for i in range(N) if mask >> i & 1}, N))
    print(f"   N = {N:2d}:  {ok} of {tot} subsets fit  ({100.0*ok/tot:.2f}%)")
    if ok == tot:
        print("   -> VACUOUS, which would invalidate section 1"); fail += 1

# an explicit witness, so the failure mode is legible
tr = []
witness = {1, 6}           # Theta_1 = {1}, Theta_2 = {2}: neither contains the other
print(f"\n   witness that fails at N = 8: Theta = {sorted(witness)}")
fits(witness, 8, tr)
for n, th, t1, t2, why in tr:
    print(f"     n={n:2d}  Theta={th}  ->  Theta_1={t1}  Theta_2={t2}   {why}")

# --- 3. the paper's own instance, and X's --------------------------------
print("\n3. the paper's Proposition 1 uses Theta = [k]; X uses Theta = [kp]")
print("   at this report's twelve GF(2^8) shapes, chunk = next_pow2(k):")
print("   f    k   chunk  kp range      all kp in range fit?")
for f in (25, 31, 32, 33, 40, 48, 50, 56, 63, 64, 65, 72, 75, 80, 85):
    k, m = f + 1, 2 * f
    chunk = 1
    while chunk < k:
        chunk <<= 1
    hi = min(chunk, 256 - m)
    if hi < k:
        print(f"   {f:<4} {k:<3} {chunk:<6} -- infeasible")
        continue
    allfit = all(fits(set(range(1, kp + 1)), chunk) for kp in range(k, hi + 1))
    print(f"   {f:<4} {k:<3} {chunk:<6} [{k}, {hi}]".ljust(32)
          + ("yes" if allfit else "NO"))
    if not allfit:
        fail += 1

print("\nRESULT:", "all checks pass" if not fail else f"{fail} FAILURES")
print("""
So X's pivot set is inside their Corollary 1, not outside it: the O(N lg N)
PPT algorithm X runs is theirs at every kp, and Proposition 1 is the kp = k
case of it.  What X adds is not the transform but the CODE-THEORETIC reading of
the parameter -- that each kp yields a different generalized Reed-Solomon code
(pivot_check.py section 1), that all of them are MDS (section 2), that the same
Cauchy plan decodes all of them (section 3), that the node budget kp <= 256 - m
is what makes the whole T <= 256 region reachable, and what the optimum is
worth.  The paper fixes Theta = [k] and does not vary it.""")
sys.exit(1 if fail else 0)
