// Fusion decode-plan generator prototype.
//
// Replaces Tape's O(k^3) Gaussian elimination over a systematic *Vandermonde*
// survivor submatrix with an O(r^2) closed-form inverse of a systematic
// *Cauchy* one, where r = number of missing data shards.
//
// Field matches tape-reed-solomon: GF(2^8), x^8+x^4+x^3+x^2+1 (0x11d).

const POLY: usize = 0x1d;
const FIELD_SIZE: usize = 256;

struct Gf {
    exp: [u8; 512],
    log: [u8; 256],
}

impl Gf {
    fn new() -> Gf {
        let mut exp = [0u8; 512];
        let mut log = [0u8; 256];
        let mut b: usize = 1;
        for i in 0..255 {
            exp[i] = b as u8;
            log[b] = i as u8;
            b <<= 1;
            if b >= FIELD_SIZE {
                b = (b - FIELD_SIZE) ^ POLY;
            }
        }
        for i in 255..512 {
            exp[i] = exp[i - 255];
        }
        Gf { exp, log }
    }
    #[inline]
    fn mul(&self, a: u8, b: u8) -> u8 {
        if a == 0 || b == 0 {
            0
        } else {
            self.exp[self.log[a as usize] as usize + self.log[b as usize] as usize]
        }
    }
    #[inline]
    fn inv(&self, a: u8) -> u8 {
        assert!(a != 0, "inverse of zero");
        self.exp[255 - self.log[a as usize] as usize]
    }
    #[inline]
    fn div(&self, a: u8, b: u8) -> u8 {
        if a == 0 { 0 } else { self.mul(a, self.inv(b)) }
    }
}

// ---------------------------------------------------------------------------
// Systematic Cauchy generator.
//
// y_j = j              for j in 0..k        (data columns)
// x_i = k + i          for i in 0..(T-k)    (parity rows)
// Disjoint by construction, so x_i ^ y_j != 0. Needs T <= 256.
//
// Row layout: rows 0..k are identity, rows k..T are P[i][j] = 1/(x_i ^ y_j).
// ---------------------------------------------------------------------------

fn parity_entry(gf: &Gf, k: usize, i: usize, j: usize) -> u8 {
    let x = (k + i) as u8;
    let y = j as u8;
    gf.inv(x ^ y)
}

// ---------------------------------------------------------------------------
// Closed-form inverse of a Cauchy matrix C[a][b] = 1/(x_a ^ y_b), O(n^2).
//
// (C^-1)[b][a] = [ prod_l (x_a ^ y_l) * prod_l (x_l ^ y_b) ]
//                / [ (x_a ^ y_b) * prod_{l!=a}(x_a ^ x_l) * prod_{l!=b}(y_b ^ y_l) ]
// ---------------------------------------------------------------------------

fn cauchy_inverse(gf: &Gf, xs: &[u8], ys: &[u8], ops: &mut usize) -> Vec<Vec<u8>> {
    let n = xs.len();
    assert_eq!(n, ys.len());

    let mut num_x = vec![1u8; n]; // prod_l (x_a ^ y_l)
    let mut den_x = vec![1u8; n]; // prod_{l!=a} (x_a ^ x_l)
    let mut num_y = vec![1u8; n]; // prod_l (x_l ^ y_b)
    let mut den_y = vec![1u8; n]; // prod_{l!=b} (y_b ^ y_l)

    for a in 0..n {
        for l in 0..n {
            num_x[a] = gf.mul(num_x[a], xs[a] ^ ys[l]);
            if l != a {
                den_x[a] = gf.mul(den_x[a], xs[a] ^ xs[l]);
            }
            *ops += 2;
        }
    }
    for b in 0..n {
        for l in 0..n {
            num_y[b] = gf.mul(num_y[b], xs[l] ^ ys[b]);
            if l != b {
                den_y[b] = gf.mul(den_y[b], ys[b] ^ ys[l]);
            }
            *ops += 2;
        }
    }

    let mut inv = vec![vec![0u8; n]; n];
    for b in 0..n {
        for a in 0..n {
            let num = gf.mul(num_x[a], num_y[b]);
            let den = gf.mul(gf.mul(xs[a] ^ ys[b], den_x[a]), den_y[b]);
            inv[b][a] = gf.div(num, den);
            *ops += 5;
        }
    }
    inv
}

// ---------------------------------------------------------------------------
// Reference: generic Gaussian elimination inverse, O(n^3). What Tape does now.
// ---------------------------------------------------------------------------

fn gauss_inverse(gf: &Gf, m: &[Vec<u8>], ops: &mut usize) -> Option<Vec<Vec<u8>>> {
    let n = m.len();
    let mut a: Vec<Vec<u8>> = m.iter().cloned().collect();
    let mut b = vec![vec![0u8; n]; n];
    for i in 0..n {
        b[i][i] = 1;
    }
    for col in 0..n {
        let mut piv = None;
        for row in col..n {
            if a[row][col] != 0 {
                piv = Some(row);
                break;
            }
        }
        let piv = piv?;
        a.swap(col, piv);
        b.swap(col, piv);
        let s = gf.inv(a[col][col]);
        for c in 0..n {
            a[col][c] = gf.mul(a[col][c], s);
            b[col][c] = gf.mul(b[col][c], s);
            *ops += 2;
        }
        for row in 0..n {
            if row == col || a[row][col] == 0 {
                continue;
            }
            let f = a[row][col];
            for c in 0..n {
                a[row][c] ^= gf.mul(a[col][c], f);
                b[row][c] ^= gf.mul(b[col][c], f);
                *ops += 2;
            }
        }
    }
    Some(b)
}

// ---------------------------------------------------------------------------
// The fusion plan.
//
// received: exactly k indices in 0..T.
// Partition into originals (< k) and parities (>= k).
// r = #missing data = #received parities.
// Stage A coefficients: r x (k-r), applied to received originals.
// Stage B coefficients: r x r  = inverse of the r x r Cauchy block.
// ---------------------------------------------------------------------------

struct Plan {
    missing: Vec<usize>,
    recv_orig: Vec<usize>,
    recv_par: Vec<usize>,
    stage_a: Vec<Vec<u8>>,
    stage_b: Vec<Vec<u8>>,
    ops: usize,
}

fn build_plan_cauchy(gf: &Gf, k: usize, t: usize, received: &[usize]) -> Plan {
    assert_eq!(received.len(), k);
    let mut is_recv = vec![false; t];
    for &i in received {
        is_recv[i] = true;
    }
    let recv_orig: Vec<usize> = (0..k).filter(|&i| is_recv[i]).collect();
    let recv_par: Vec<usize> = (k..t).filter(|&i| is_recv[i]).collect();
    let missing: Vec<usize> = (0..k).filter(|&i| !is_recv[i]).collect();
    assert_eq!(missing.len(), recv_par.len());
    let r = missing.len();

    let mut ops = 0usize;

    // B[a][b] = 1/(x_a ^ y_b), rows = received parities, cols = missing data.
    let xs: Vec<u8> = recv_par.iter().map(|&i| i as u8).collect();
    let ys: Vec<u8> = missing.iter().map(|&j| j as u8).collect();
    let binv = cauchy_inverse(gf, &xs, &ys, &mut ops);

    // A[a][c] = 1/(x_a ^ y_c), cols = received originals.
    let mut stage_a = vec![vec![0u8; recv_orig.len()]; r];
    for a in 0..r {
        for (c, &oc) in recv_orig.iter().enumerate() {
            stage_a[a][c] = parity_entry(gf, k, recv_par[a] - k, oc);
            ops += 1;
        }
    }

    Plan { missing, recv_orig, recv_par, stage_a, stage_b: binv, ops }
}

// Reference plan: what Tape does today. Full k x k survivor submatrix, GE.
fn build_plan_gauss(gf: &Gf, k: usize, t: usize, received: &[usize]) -> (Vec<Vec<u8>>, usize) {
    let mut sub = vec![vec![0u8; k]; k];
    for (row, &idx) in received.iter().enumerate() {
        for c in 0..k {
            sub[row][c] = if idx < k {
                if idx == c { 1 } else { 0 }
            } else {
                parity_entry(gf, k, idx - k, c)
            };
        }
    }
    let _ = t;
    let mut ops = 0usize;
    let inv = gauss_inverse(gf, &sub, &mut ops).expect("survivor submatrix singular");
    (inv, ops)
}

// ---------------------------------------------------------------------------
// End-to-end check: encode k data symbols, erase, decode both ways.
// ---------------------------------------------------------------------------

fn encode(gf: &Gf, k: usize, t: usize, data: &[u8]) -> Vec<u8> {
    let mut all = vec![0u8; t];
    all[..k].copy_from_slice(data);
    for i in 0..(t - k) {
        let mut acc = 0u8;
        for j in 0..k {
            acc ^= gf.mul(parity_entry(gf, k, i, j), data[j]);
        }
        all[k + i] = acc;
    }
    all
}

fn decode_fusion(gf: &Gf, plan: &Plan, coded: &[u8]) -> Vec<u8> {
    let r = plan.missing.len();
    // t_a = p_a ^ sum_c A[a][c] * d_orig[c]
    let mut tvec = vec![0u8; r];
    for a in 0..r {
        let mut acc = coded[plan.recv_par[a]];
        for (c, &oc) in plan.recv_orig.iter().enumerate() {
            acc ^= gf.mul(plan.stage_a[a][c], coded[oc]);
        }
        tvec[a] = acc;
    }
    // d_missing[b] = sum_a Binv[b][a] * t_a
    let mut out = vec![0u8; r];
    for b in 0..r {
        let mut acc = 0u8;
        for a in 0..r {
            acc ^= gf.mul(plan.stage_b[b][a], tvec[a]);
        }
        out[b] = acc;
    }
    out
}

fn lcg(state: &mut u64) -> u64 {
    *state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    *state >> 11
}

fn random_received(k: usize, t: usize, state: &mut u64) -> Vec<usize> {
    let mut order: Vec<usize> = (0..t).collect();
    for i in (1..t).rev() {
        let j = (lcg(state) as usize) % (i + 1);
        order.swap(i, j);
    }
    let mut r: Vec<usize> = order[..k].to_vec();
    r.sort();
    r
}

fn main() {
    let gf = Gf::new();

    // Sanity: field axioms, checked rather than recalled.
    for a in 1..=255u8 {
        assert_eq!(gf.mul(a, gf.inv(a)), 1, "a * a^-1 != 1 for a={}", a);
        assert_eq!(gf.mul(a, 1), a, "a * 1 != a for a={}", a);
    }
    for a in 1..=255u8 {
        for b in 1..=255u8 {
            assert_eq!(gf.mul(a, b), gf.mul(b, a));
            assert!(gf.mul(a, b) != 0, "no zero divisors");
        }
    }

    println!("{:>4} {:>4} {:>4} {:>6} {:>12} {:>12} {:>12} {:>9} {:>9}",
             "f", "k", "T", "r_avg", "V1_2stage", "V2_fused", "GE_today", "V1_gain", "V2_gain");

    for &f in &[32usize, 64, 85] {
        let k = f + 1;
        let t = 3 * f + 1;
        if t > 256 {
            println!("f={} skipped, T={} > 256", f, t);
            continue;
        }
        let trials = 200;
        let mut state = 0x243f6a8885a308d3u64 ^ (f as u64);
        let (mut sum_c, mut sum_g, mut sum_r, mut sum_f) = (0usize, 0usize, 0usize, 0usize);

        for _ in 0..trials {
            let received = random_received(k, t, &mut state);

            // Random data, encode.
            let data: Vec<u8> = (0..k).map(|_| (lcg(&mut state) & 0xff) as u8).collect();
            let coded = encode(&gf, k, t, &data);

            // Fusion path.
            let plan = build_plan_cauchy(&gf, k, t, &received);
            let recovered = decode_fusion(&gf, &plan, &coded);
            for (b, &mi) in plan.missing.iter().enumerate() {
                assert_eq!(recovered[b], data[mi],
                           "fusion decode mismatch f={} missing={}", f, mi);
            }

            // Reference path: full k x k GE inverse, then apply.
            let (ginv, gops) = build_plan_gauss(&gf, k, t, &received);
            for &mi in plan.missing.iter() {
                let mut acc = 0u8;
                for (row, &idx) in received.iter().enumerate() {
                    acc ^= gf.mul(ginv[mi][row], coded[idx]);
                }
                assert_eq!(acc, data[mi], "gauss decode mismatch f={}", f);
            }

            // Variant 2: collapse the two stages into one r x k coefficient
            // matrix over the received shards, so Tape's existing RowTables /
            // fused-tile kernels apply unchanged in a single pass.
            let r = plan.missing.len();
            let mut fused = vec![vec![0u8; k]; r];
            let mut fops = plan.ops;
            for b in 0..r {
                for (a_i, &pi) in plan.recv_par.iter().enumerate() {
                    let col = received.iter().position(|&x| x == pi).unwrap();
                    fused[b][col] = plan.stage_b[b][a_i];
                }
                for (c, &oc) in plan.recv_orig.iter().enumerate() {
                    let col = received.iter().position(|&x| x == oc).unwrap();
                    let mut acc = 0u8;
                    for a_i in 0..r {
                        acc ^= gf.mul(plan.stage_b[b][a_i], plan.stage_a[a_i][c]);
                        fops += 1;
                    }
                    fused[b][col] = acc;
                }
            }
            // Verify the fused rows decode identically.
            for (b, &mi) in plan.missing.iter().enumerate() {
                let mut acc = 0u8;
                for (col, &idx) in received.iter().enumerate() {
                    acc ^= gf.mul(fused[b][col], coded[idx]);
                }
                assert_eq!(acc, data[mi], "fused-variant mismatch f={}", f);
            }
            sum_f += fops;

            sum_c += plan.ops;
            sum_g += gops;
            sum_r += plan.missing.len();
        }

        println!("{:>4} {:>4} {:>4} {:>6.1} {:>12} {:>12} {:>12} {:>8.1}x {:>8.1}x",
                 f, k, t,
                 sum_r as f64 / trials as f64,
                 sum_c / trials, sum_f / trials, sum_g / trials,
                 sum_g as f64 / sum_c as f64,
                 sum_g as f64 / sum_f as f64);
    }

    // MDS spot check: every survivor submatrix invertible over many patterns.
    let (k, t) = (33usize, 97usize);
    let mut state = 0xdeadbeefu64;
    for _ in 0..500 {
        let received = random_received(k, t, &mut state);
        let (_inv, _) = build_plan_gauss(&gf, k, t, &received);
    }
    println!("\nMDS spot check passed: 500 random survivor sets at (k=33,T=97) all invertible.");
    println!("All decode assertions passed.");
}
