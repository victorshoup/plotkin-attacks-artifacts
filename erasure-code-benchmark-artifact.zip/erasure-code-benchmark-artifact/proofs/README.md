# proofs/ — independent re-derivations of the Reed–Solomon appendix

Four checks: `pivot_check.py`, `ppt_theorem_check.py`,
`fft_cauchy_check.py`, `standalone_cauchy_check.rs`. `check.sh` runs all four.

These share no code with the driver, which is the point of them. They are
verifications of the appendix's algebra (`app:rs-algebra`), not claims of
novelty — the appendix makes none, and neither should anything here.
