#!/usr/bin/env python3
"""Structural check: is an additive-FFT Reed-Solomon code a Cauchy code?

    cargo build --release --bin gen_probe
    ./fft_cauchy_check.py

Two claims, each checked rather than asserted:

  1. `reed-solomon-simd`'s FFT encoder produces a generator matrix
     `G[j][i] = c_t / (y_j ^ x_i)` with `x_i = beta(i)`, `y_j = beta(chunk+j)`,
     `beta(z)` the Cantor-basis expansion of the index `z`, `chunk =
     k.next_power_of_two()`, and `c_t` one scalar per recovery coset.
  2. The same law holds in `isal_cauchy16`'s composite tower field, which
     therefore admits an additive FFT over its own Cantor basis.

Claim 1 is measured from the encoder. Claim 2 is computed from the field.
The point of both is that the FFT-encoded code is, once the encoder divides
out the per-coset scalar c_t, exactly the code the closed-form decode plan
inverts: that is what codec/rs_point.c's fft16_encode emits (docs/ALGORITHMS.md
4.3). Neither claim runs rs_point.c's encoder; check.sh's matrix-vs-FFT parity
oracle is what ties the shipped encoder to this law. Claim 1 also shows that
reed-solomon-simd emits the unnormalized code (c_2 = beta_1 != 1).

EXTRACTED for the public artifact: the working tree carried a third claim --
that `tape_red`'s FFT encoder is generalized Cauchy too, but over different
nodes, so tape's FFT and `reed-solomon-simd`'s are not the same code. That
claim is about `tape-reed-solomon`, which is not part of this artifact
(Cargo.toml), and it is the only thing the node-recovery machinery served, so
both are gone rather than left unreachable. Claims 1 and 2 are what the
Reed-Solomon appendix rests on, and neither mentions tape.

A generalized Cauchy matrix `a_j b_i / (y_j ^ x_i)` is detected without knowing
any of a, b, x or y: its entrywise inverse is `y_j/(a_j b_i) ^ x_i/(a_j b_i)`,
a sum of two rank-1 terms, so it has rank exactly 2.
"""
import subprocess
import sys

PROBE = "./target/release/gen_probe"

# ---------------------------------------------------------------- fields

RS_POLY = 0x1002D               # reed-solomon-simd's direct degree-16 extension
RS_CANTOR = [0x0001, 0xACCA, 0x3C0E, 0x163E, 0xC582, 0xED2E, 0x914C, 0x4012,
             0x6C98, 0x10D8, 0x6A72, 0xB900, 0xFDB8, 0xFB34, 0xFF38, 0x991E]
TOWER_BETA8 = 0x20              # isal_cauchy16: GF(2^8)[z]/(z^2 + z + 0x20)


def rs_mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a & 0x10000:
            a ^= RS_POLY
    return r


def _m8(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a & 0x100:
            a ^= 0x11D
    return r


def tw_mul(a, b):
    """(hi<<8)|lo == hi*z + lo, z^2 = z + 0x20."""
    a1, a0, b1, b0 = a >> 8, a & 0xFF, b >> 8, b & 0xFF
    hh = _m8(a1, b1)
    return ((_m8(a1, b0) ^ _m8(a0, b1) ^ hh) << 8) | (_m8(a0, b0) ^ _m8(TOWER_BETA8, hh))


def make_inv(mul):
    def inv(a):
        r, e, base = 1, 65534, a
        while e:
            if e & 1:
                r = mul(r, base)
            base = mul(base, base)
            e >>= 1
        return r
    return inv


rs_inv, tw_inv = make_inv(rs_mul), make_inv(tw_mul)


def span(z, basis):
    v = 0
    for b in range(16):
        if z >> b & 1:
            v ^= basis[b]
    return v


def rank(rows, mul, inv):
    rows = [list(r) for r in rows]
    n, nc, rk = len(rows), len(rows[0]), 0
    for c in range(nc):
        p = next((i for i in range(rk, n) if rows[i][c]), None)
        if p is None:
            continue
        rows[rk], rows[p] = rows[p], rows[rk]
        pv = inv(rows[rk][c])
        rows[rk] = [mul(x, pv) for x in rows[rk]]
        for i in range(n):
            if i != rk and rows[i][c]:
                f = rows[i][c]
                rows[i] = [x ^ mul(f, y) for x, y in zip(rows[i], rows[rk])]
        rk += 1
    return rk


def tower_cantor_basis():
    """beta_0 = 1, beta_i^2 + beta_i = beta_{i-1}, solved as a GF(2) system."""
    cols = [tw_mul(1 << b, 1 << b) ^ (1 << b) for b in range(16)]
    basis = [1]
    for _ in range(15):
        c = basis[-1]
        rows = [[(cols[b] >> i) & 1 for b in range(16)] + [(c >> i) & 1]
                for i in range(16)]
        piv, where = 0, [-1] * 16
        for col in range(16):
            p = next((r for r in range(piv, 16) if rows[r][col]), None)
            if p is None:
                continue
            rows[piv], rows[p] = rows[p], rows[piv]
            for r in range(16):
                if r != piv and rows[r][col]:
                    rows[r] = [a ^ b for a, b in zip(rows[r], rows[piv])]
            where[col] = piv
            piv += 1
        if any(rows[r][16] for r in range(piv, 16)):
            raise RuntimeError("no Cantor step: trace obstruction")
        u = 0
        for col in range(16):
            if where[col] >= 0 and rows[where[col]][16]:
                u |= 1 << col
        basis.append(min(u, u ^ 1))
    return basis


# ---------------------------------------------------------------- checks

def generator(k, m):
    out = subprocess.run([PROBE, str(k), str(m)],
                         capture_output=True, text=True, check=True).stdout
    return [[int(v, 16) for v in l.split()] for l in out.strip().split("\n")[1:]]


def chunk_of(k):
    c = 1
    while c < k:
        c *= 2
    return c


def coset_constants(G, x, y, chunk, mul):
    """c_t := G[j][i] * (y_j ^ x_i); None if it depends on i."""
    out = {}
    for j in range(len(G)):
        vals = {mul(G[j][i], y[j] ^ x[i]) for i in range(len(G[0]))}
        if len(vals) != 1:
            return None
        out.setdefault((chunk + j) // chunk, set()).add(vals.pop())
    return None if any(len(s) != 1 for s in out.values()) else \
        {t: s.pop() for t, s in out.items()}


SHAPES = [(4, 6), (6, 12), (8, 14), (9, 16), (13, 24), (20, 38),
          (33, 64), (87, 172), (129, 256)]


def subspace_collapse(basis, n, mul, inv):
    r"""The two steps of the report's section 2.2, checked rather than asserted.

    W_i = prod_{l!=i}(x_i ^ x_l) is independent of i, because u = x_i ^ v runs
    over V\{0} as v runs over V\{x_i}; and s_V(z) = prod_{v in V}(z ^ v) is
    GF(2)-linear, hence constant on each coset of V.
    """
    V = [span(i, basis) for i in range(1 << n)]
    Ws = set()
    for xi in V:
        w = 1
        for xl in V:
            if xl != xi:
                w = mul(w, xi ^ xl)
        Ws.add(w)
    prod_nonzero = 1
    for u in V:
        if u:
            prod_nonzero = mul(prod_nonzero, u)

    def s_V(z):
        p = 1
        for v in V:
            p = mul(p, z ^ v)
        return p

    additive = all(s_V(a ^ b) == s_V(a) ^ s_V(b)
                   for a in (V[1], V[2], span((1 << n) + 3, basis))
                   for b in (V[1], span((1 << n) + 5, basis)))
    cosets = {t: {s_V(span(t * (1 << n) + j, basis)) for j in range(1 << n)}
              for t in (1, 2)}
    per_coset = all(len(v) == 1 for v in cosets.values())
    W = next(iter(Ws))
    c = {t: mul(next(iter(v)), inv(W)) for t, v in cosets.items()}
    return len(Ws) == 1, W == prod_nonzero, additive, per_coset, c


def main():
    fail = 0

    print("1. reed-solomon-simd's FFT generator, in its own field "
          "(poly 0x1002D, Cantor coordinates)\n")
    print(f"   {'k':>4} {'m':>4} {'chunk':>6}  {'ent-inv rank':>12}  coset constants c_t")
    for k, m in SHAPES:
        G = [[span(v, RS_CANTOR) for v in row] for row in generator(k, m)]
        ch = chunk_of(k)
        x = [span(i, RS_CANTOR) for i in range(k)]
        y = [span(ch + j, RS_CANTOR) for j in range(m)]
        rk = rank([[rs_inv(v) for v in r] for r in G], rs_mul, rs_inv)
        c = coset_constants(G, x, y, ch, rs_mul)
        ok = rk == 2 and c is not None
        fail += not ok
        shown = " ".join(f"c{t}={v:#06x}" for t, v in sorted(c.items())) if c else "NOT CAUCHY"
        print(f"   {k:>4} {m:>4} {ch:>6}  {rk:>12}  {shown}")
    print(f"\n   beta_1 of this field = {RS_CANTOR[1]:#06x}  "
          "-- the second coset constant\n")

    print("2. the same law in isal_cauchy16's composite tower "
          "GF(2^8)[z]/(z^2+z+0x20)\n")
    B = tower_cantor_basis()
    print("   Cantor basis: " + " ".join(f"{v:04x}" for v in B))
    assert all(tw_mul(B[i], B[i]) ^ B[i] == B[i - 1] for i in range(1, 16))
    assert len({span(i, B) for i in range(65536)}) == 65536
    print("   beta_i^2 + beta_i == beta_{i-1}: True     spans the field: True")
    print(f"\n   {'chunk':>6} {'k':>4} {'m':>4}  coset constants of the "
          "Lagrange generator over beta(0..chunk-1)")
    for k, m in SHAPES[:8]:
        ch = chunk_of(k)
        x = [span(i, B) for i in range(ch)]
        y = [span(ch + j, B) for j in range(m)]
        # L_i(y_j) over the full chunk; padding columns i >= k carry zeros.
        G = []
        for j in range(m):
            row = []
            for i in range(k):
                num, den = 1, 1
                for l in range(ch):
                    if l != i:
                        num = tw_mul(num, y[j] ^ x[l])
                        den = tw_mul(den, x[i] ^ x[l])
                row.append(tw_mul(num, tw_inv(den)))
            G.append(row)
        c = coset_constants(G, x[:k], y, ch, tw_mul)
        fail += c is None
        shown = " ".join(f"c{t}={v:#06x}" for t, v in sorted(c.items())) if c else "NOT CAUCHY"
        print(f"   {ch:>6} {k:>4} {m:>4}  {shown}")
    print(f"\n   beta_1 of this field = {B[1]:#06x}  -- the second coset constant\n")

    print("2b. the two steps that collapse the diagonals (report section 2.2)\n")
    STD = [1 << i for i in range(16)]
    print(f"   {'basis':>16} {'n':>2} | {'W_i same for all i':>19} {'W = prod V\\0':>13} "
          f"{'s_V additive':>13} {'s_V per coset':>14} | coset scalars")
    for basis, name in ((B, "Cantor"), (STD, "plain bit")):
        for n in (3, 4, 5):
            a, b_, c_, d_, cs = subspace_collapse(basis, n, tw_mul, tw_inv)
            fail += not (a and b_ and c_ and d_)
            print(f"   {name:>16} {n:>2} | {str(a):>19} {str(b_):>13} {str(c_):>13} "
                  f"{str(d_):>14} | " + "  ".join(f"c{t}={v:#06x}" for t, v in sorted(cs.items())))
    print("\n   Any basis gives per-coset constants -- that is section 2.2, which uses\n"
          "   only that V is a subspace. The Cantor basis additionally makes c_1 = 1.\n")

    print("\nRESULT:", "all checks pass" if not fail else f"{fail} CHECK(S) FAILED")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
