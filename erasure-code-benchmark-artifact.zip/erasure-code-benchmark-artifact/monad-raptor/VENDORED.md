# `monad-raptor` — vendored, GPL-3.0-or-later

**This subtree is NOT covered by the artifact's MIT LICENSE.** It is third-party
code under the GNU General Public License v3.0 **or any later version**, and it
carries its own `LICENSE` (the full GPLv3 text) alongside this file.

| | |
|---|---|
| upstream | `monad-raptor`, Category Labs, Inc. |
| commit | `fcafa0d7cb96c18588530c992f25c3d4a73b13dd` (see `UPSTREAM_COMMIT`) |
| copyright | Copyright (C) 2025 Category Labs, Inc. |
| licence | **GPL-3.0-or-later** (SPDX: `GPL-3.0-or-later`) |
| modifications | **none.** Vendored verbatim |

Every source file carries the upstream GPLv3 header, which states version 3
"or (at your option) any later version" — hence `-or-later` rather than a bare
`GPL-3.0`. Upstream ships no top-level `LICENSE` file and no `license` field in
its `Cargo.toml`; the licence is established by those per-file headers, and this
directory's `LICENSE` is the canonical GPLv3 text supplied to satisfy §4's
requirement that a copy accompany the source.

## Why it is vendored rather than fetched

R10 carries three of the four appendix tables. A build-time fetch of a company
repository would be a single point of failure for most of the benchmark appendix, and it
would make the artifact's numbers depend on a branch that can move. It is
recorded as a settled decision in `../MANIFEST.md`.

## What links it, and what does not

`monad-raptor` is a dependency of the **Rust baseline binary only** — the
`r10` label in `src/main.rs`. The C codec in `codec/` is a separate program: it
neither links nor is linked by this crate, and the two never share an address
space. The artifact's own code is MIT (`../LICENSE`).

> **This directory's licensing is stated, not adjudicated.** The interaction
> between a GPL-3.0-or-later dependency of one binary and an MIT licence on a
> separate program in the same distribution is a question for someone
> qualified to answer it. It is flagged as worth confirming professionally
> rather than settled on a non-lawyer's reading. Nothing here should be read as
> legal advice or as a settled conclusion.
