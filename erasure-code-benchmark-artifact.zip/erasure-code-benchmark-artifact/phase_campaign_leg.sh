#!/bin/sh
# THE campaign behind the paper's grid tables: the same grid three times,
# differing in ONE variable.
#
# THREE legs, and the third is not optional. There is no world in which it makes
# sense to isolate the decode timer and leave the encode timer interleaved: the
# encoder's footprint contaminates decode and the DECODER'S footprint
# contaminates encode. Isolating one and not the other fixes half a symmetric
# problem and quietly reports the other half.
#
#   both     the interleaved encode+decode loop. The NULL, and the only leg
#            comparable with figures published before the split.
#   encode   encode alone. The decoder runs ONCE, at the first warmup trial, as
#            the correctness gate, and never in a measured trial.
#   decode   decode alone against a fresh erasure pattern per trial. The encoder
#            runs once at setup.
#
# THE PAPER'S GRID TABLES ARE READ FROM THE ISOLATED LEGS -- encode figures from
# the encode leg, decode figures from the decode leg. The interleaved leg is the
# null and appears only as a delta. Reading a paper number off a `both` run will
# not reproduce it: the deltas are real and do not point one way. The transform
# encoder evicts the decoder's working set, so `both` reads SLOW for RS--8;
# labels whose decoder allocates inside its own timer get the encoder's
# just-freed block warm, so `both` reads FAST for them.
#
# EACH LEG REPORTS ONLY ITS OWN HALF. The other half's columns come out EMPTY,
# not zero, all the way to the summary -- so no consumer can read a number that
# was not measured -- and the harness REFUSES a leg whose driver reports the
# half it was told not to measure.
#
# READ THE RESULT AGAINST [repmin, repmax], NOT AS p50 RATIOS. A p50 ratio
# inside the repetition spread is not a result.
#
# BENCH_LABELS=core is the paper's label set and is the default; it is stated
# here rather than inherited. No RS_* knobs: unset means `rs` is
# reed-solomon-simd 3.1.0 exactly as published on crates.io, which is what the
# paper compares against. Their absence is the stated configuration.
set -eu
cd "$(dirname "$0")"
echo "### THREE-PHASE CAMPAIGN START $(date -u +%FT%TZ)"
for ph in both encode decode; do
    echo "### LEG phase=$ph"
    env BENCH_LABELS=core BENCH_CPU="${BENCH_CPU:-4}" BENCH_PHASE=$ph \
        ./benchmark.sh > "phase-campaign-$ph.log" 2>&1
    echo "###   -> $(grep -o 'results/robust-summary[a-z-]*-[0-9]\{8\}-[0-9]\{6\}\.csv' "phase-campaign-$ph.log" | tail -1)"
done
echo "### THREE-PHASE CAMPAIGN DONE $(date -u +%FT%TZ)"
