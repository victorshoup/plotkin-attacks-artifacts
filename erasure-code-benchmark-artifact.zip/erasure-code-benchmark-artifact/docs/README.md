# docs/

Six documents. Two are for running the artifact, two are for reading the code,
and two state the boundaries.

| | |
|---|---|
| **[`REPRODUCING.md`](REPRODUCING.md)** | how to run it, and the six things that silently invalidate a run. **Read this before `./benchmark.sh`.** |
| **[`MAPPING.md`](MAPPING.md)** | paper claim → file, function, knob. The label table, the table-to-script map, `codec/rs_point.c`'s section map, and §8's key to the internal documents the source comments cite but this artifact does not ship |
| **[`ALGORITHMS.md`](ALGORITHMS.md)** | how RS–8 and RS–16 actually work. The field, the node sets, the additive FFT, the pivot base, why one encoder pairs with two decoders. **Read this before `codec/rs_point.c`** |
| **[`HARNESS.md`](HARNESS.md)** | why the harness is shaped this way. The measurement model, the timer contract, why nulls are not configuration, why emission order is load-bearing, what each oracle is for |
| **[`DEFAULTS.md`](DEFAULTS.md)** | every default, what it changes, and the null it is measured against |
| **[`LIMITS.md`](LIMITS.md)** | what is **not** claimed |

## A note on what is deliberately absent

**These documents state no measured codec figures.** Every number lives in the
paper's `app:benchmarks` or in `results/`. That is not brevity for its own sake:
it is what lets these files be checked against the code rather than believed, and
it keeps them from becoming a second, drifting copy of the results.

The exception is `HARNESS.md`, which quotes magnitudes for *harness artifacts* —
how wrong a run goes when a rule is broken — because that is the content of the
warning rather than a result.

Where a document describes a mechanism, it names the function that implements it
and the check that asserts it. Where it describes a choice, it names the null.
