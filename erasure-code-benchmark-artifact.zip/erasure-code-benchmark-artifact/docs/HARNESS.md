# Why the harness is built this way

Rationale, for someone auditing or modifying the harness. `REPRODUCING.md` is
the companion for someone running it.

Almost every rule below exists because it was violated first. Where that is so,
the incident is recorded rather than the rule alone — a rule with its scar
attached is much harder to optimise away by someone who does not know what it
cost.

**This file states no measured codec figures.** Those live in the paper and in
`results/`. The magnitudes that do appear here are characterisations of harness
artifacts — how wrong a run goes when a rule is broken — because that is the
content of the warning.

---

## 1. The measurement model, and what follows from it

Erasure coding for a BFT / data-availability workload at n = 3f+1:

* `k = f + 1` source shards, `T = 3f + 1` total coded shards
* the decoder receives shards in an arrival order it does not control
* it must reconstruct from **any** k of them

**The critical modelling choice is a fresh random erasure pattern per trial.**
In a BFT setting the set of first-k-to-arrive differs every block, so any
per-pattern setup cost — matrix inversion, coefficient-table expansion, plan
construction — is paid on **every message**, and no cache ever hits.

This is why published benchmarks for these libraries do not answer this
question. A storage benchmark amortizes that setup across many decodes and
reports a number that is irrelevant here. And it is why the harness times **one**
decode per trial: a validator decodes one block per block, cold. That measures
cold entry rather than throughput, and the two genuinely differ.

**The consequence, and it is first-order.** Setup is not a rounding error at
these shapes — it is a large fraction of decode, rising with f and rising with
the field width. Moving the decode plan from O(k³) to O(r²) is therefore a
first-order change, not a micro-optimisation, and `ALGORITHMS.md` §1.6 is the
algebra of doing so.

**And it is why setup defects hide here and nowhere else.** Two traps found this
way, both worth knowing before writing a probe:

* **Setup cost can land in a different timer than the code that causes it.**
  Building coefficient tables is charged to `plan`; the cache lines it evicts are
  paid for by the *kernel*, in `code`. A large share of one table-building cost
  appeared in a term containing none of the offending code — which is why a long
  series of hypotheses aimed at `code` all came back null.
* **Sub-timer splits inside `code` do not attribute.** The same reconstruct call
  measures very differently depending on which side of a timer boundary first
  touches freshly mapped memory, with the sum unchanged. Only `plan`, `code` and
  their sum mean anything.

The cheapest way to tell a one-time per-plan cost from a per-call one is to time
N decodes in one region and watch whether the per-decode cost decays as 1/N.

## 2. The process model

**Every codec, every repetition, every grid point runs in its own fresh
process.** One codec per process, always.

Two variants timed in one process is worth up to tens of percent from ordering
alone. So the harness never does it: `robust_benchmark.py` dispatches by
subprocess, and every probe takes the variant as an argument rather than looping
over variants.

**The CSV is the integration boundary.** A new codec is a new binary emitting the
same 15-column detail header — added to `BIN_FOR` and `runs_for`, never by FFI
into the Rust binary. That keeps fresh-process-per-trial for free, keeps the
build of one codec from perturbing another, and means the three drivers in this
tree (`src/main.rs`, `codec/rs_point.c`, `references/fd_point.c`) are
interchangeable from the harness's point of view.

Porting SplitMix64 and the shard permutation **bit-exactly** across those three
is what makes the comparison trial-for-trial: at one seed, every codec sees the
same message bytes and the same arrival order, including across the C/Rust
boundary. `codec/rs_common.h` carries the C copy, and it is a contract, not a
convenience — it is the only reason R10 and RS–8 are comparable at one seed.

**The statistic.** Five independent fresh-process invocations per point, three
discarded warmups then 20 measured trials each, headline = **the median of the
five per-invocation medians**; p90 and max are pooled over all 100 trials. A
median *within* one invocation is tight and says nothing about the spread across
them — and that spread was, once, the entire defect: under randomised layout,
large-f 4 MiB timing was bimodal across invocations, spanning 1.9× on encode
from memory layout alone, while a well-behaved label was stable to 2%. Every
number a single-invocation instrument printed was one lottery ticket.

**Grid numbers and isolated numbers are different measurements**, systematically,
by something like ten percent. Isolation is for "does this move by 1.3×", never
for "is this 10% high".

## 3. The timer contract

Three rules, applied to every codec:

1. **Shape-only work is hoisted, for every codec.** Anything a function of
   (k, m) alone — not of the data, not of which shards are missing — is built
   once per process.
2. **Pattern-dependent work is hoisted for nobody, across calls.** Every message
   arrives with its own survivor set. Within one decode it may be shared, which
   is what striping exploits: hoist out of the stripes, never out of the encode
   or decode.
3. **Buffers are allocated per call.** R10 allocates a decoder and a fresh
   message inside its decode timer, and `reed-solomon-simd` allocates its work
   buffer; those are the baseline the MDS premium is priced against, so every
   codec does the same. Sizing still comes from (f, n, max shard bytes) — a
   deployment knows its worst case. What is not allowed is carrying a buffer to
   the next call.

**Everything is inside the timer**, including decoder construction, for every
codec. `decode = plan + code` exactly, per trial.

### The allocator contract, which governs rule 3

Rule 3 is true at the source level and **that does not make the codecs equally
cold.** glibc's `mmap` and `trim` thresholds are dynamic, so whether a freed
buffer is recycled or handed back to the kernel depends on its size and on the
process's whole allocation mix — per codec, per grid point. The re-fault cost
then lands in whichever timer touches the pages first, and it is large enough to
reorder codecs.

**`BENCH_MALLOC=warm` is the default**: both thresholds pinned high, so nothing
is returned to the kernel and every label is measured on recycled buffers.
Per-call allocation still happens; what stops varying is whether the kernel has
to hand the pages back.

The reason for preferring this to a genuinely cold contract is that cold
behaviour is unpredictable and highly system-dependent, so **it is not a property
of the codecs the paper is about.** `BENCH_MALLOC=default` restores glibc's own
behaviour and its figures may not be mixed with `warm` ones.

The shard pool is **page-aligned, not malloc-aligned**, for a related reason: a
multi-megabyte malloc is served by mmap and the chunk header puts the payload
16 bytes into a cache line, so every 64-byte vector access straddles two. Both
harnesses align the pool, so neither codec is measured on a misaligned buffer
and neither is at the mercy of what the allocator happened to return.

### The asymmetries that remain

They are properties of the libraries, not of the harness, and the rule is that
**the harness never adds an allocation the library does not force, and never
removes one it does.** `LIMITS.md` §7 lists them: decode ingest, the encode
source scatter, R10's n outputs against everyone else's n − K, the plan/code
split existing only for the MDS labels, and output-buffer allocation on encode.

Each is disclosed rather than corrected. Correcting one means changing a
library's call pattern to something its API does not offer, which measures a
codec that does not exist.

### Memory this harness allocates and never uses

**`fft8_w`: about 6.1 MB at f = 85 / 4 MiB, allocated, zeroed, and never read
or written.** The GF(2⁸) transform encoder's setup builds a pool whose first
`chunk` shards are `fft8_w`, and the encoder reads `fft8_w` only when
`fft8_ncos == 0` — when no coset is needed. The moment a coset exists it rebinds
to the coset scratch instead.

**`ncos == 0` cannot happen at any shape this artifact runs.** It requires
`chunk − ev_kp ≥ m`, and `ev_kp` is `min(chunk, 256 − m)` clamped up to *k*, so
that difference is either 0 — needing *m* = 0 — or `chunk − 256 + m`, needing
`chunk ≥ 256`. With *T* = 3*f*+1 ≤ 256 we have *f* ≤ 85, *k* ≤ 86 and
`chunk` ≤ 128, so neither holds. Checked over every *f* and every explicit pivot
base in [*k*, min(chunk, 256−*m*)]: zero hits. It is a proof, not an absence of
sightings.

**In theory it cannot affect a measurement.** `fft8_init` runs once per process,
before the trial loop, and nothing touches the region afterwards.

> **It is left in place anyway, and disclosed rather than removed.** A spare
> 6 MB of zeroed pages is not free of consequence — page-table and TLB
> footprint, allocator state, what the kernel does with pages nobody faults
> again — and this project has been wrong before about work "outside the timer"
> being outside the measurement. Removing it edits the encode setup path that
> every published GF(2⁸) encode figure was measured through, so it would cost a
> re-take of that leg.
>
> **A `FIXME` on the allocation in `codec/rs_point.c` carries the repair**: size
> the region conditionally on `ncos` and bind `fft8_w` only when `ncos == 0`,
> which keeps the dead branch correct for any shape that could reach it instead
> of deleting a code path on the strength of an argument. Re-take the GF(2⁸)
> encode leg afterwards rather than mixing vintages.

### One asymmetry is the harness's own, and it is UNFIXED

Everything above concerns asymmetries between codecs. This one is between
**arrival modes**, and unlike the others it is the harness's fault rather than a
library's.

Before the timer, the decoder zeroes the original slots the receiver did not
get, so a decode that writes nothing cannot pass verification on bytes the
encode left behind. **That loop runs r times, where r is the number of missing
originals — and r is exactly the quantity `--arrivals` varies.** Under
`--arrivals random` it is about 2k/3; under `--arrivals parity` it is k. So the
out-of-timer work is *not matched* between the two modes.

Outside the timer is not outside the measurement: r shard-sized buffers are
touched immediately before the timed region, and the cache does not forget.

**Its magnitude is UNMEASURED.** An earlier version of this section said ~6%,
on the strength of RS--8 reading 1.60× where r·k arithmetic predicts 1.51×.
**That attribution was wrong twice over and is withdrawn.** `decode = plan +
code` exactly and the two stages do not move together — plan runs at ~1.6×–1.7×
and code at ~1.44×, because `cauchy_inverse`'s O(r²) block and
`fold_closed_form8`'s O(r·d) block do not cancel: the inverse costs more per
entry. The aggregate is their weighted mean, so there was no residual to explain.

**And the 1.60× was itself an artefact of measuring at a fixed 1 KiB shard**,
which is not a size this grid uses. `plan` is scalar and identical at every shard
size; `code` scales with shard bytes. So the plan share was 54–58% at 1 KiB
against 0.9–19.1% on the grid, and the aggregate is **1.45× there, not 1.60×** —
with RS--8 and RS--16 landing in the same place rather than RS--8 being steeper.
**This loop's effect remains unmeasured**; it is real, and nothing has isolated
it.

> **It is not corrected, and the reason is the same one that governs the
> asymmetries above: correcting it would change a path that has already been
> measured.** Zeroing all k slots unconditionally before the copy-in would make
> the work constant in r — and would also change the `random` path, so every
> decode figure in the report and the appendix would have to be re-taken to stay
> comparable. The confound is one-directional, an order smaller than the 1.5×
> effect it sits inside, and disclosed wherever that ratio is quoted.
>
> **`FIXME` comments sit on both loops in `codec/rs_point.c`**, GF(2⁸) and
> GF(2¹⁶), with the repair and its cost written out. Anyone who fixes it should
> re-take the full decode leg rather than mixing vintages, and should expect the
> parity ratios to fall a few percent toward 1.5×. **The transform decoder is
> the null for that check:** it is arrival-oblivious, so nothing about it should
> move.

## 4. Emission order inside a point is load-bearing

`runs_for` returns labels in a fixed order and **that order is not cosmetic.**

`isal_x_dec` exists to give RS–8 a decode measurement, and it must not be
preceded by `isal_x`. RS–8's transform work buffer is `chunk × stride` — several
megabytes at the top of the grid — and a label that runs immediately after it
decodes into a cache the previous *process* just evicted. Measured with that
ordering, the instrument read 1.05×–1.08× high at ≥ 1 MiB, where the same pair
run standalone with equal-length environment blocks read slightly *below* one.
Same code, same plan, same rows, same kernel — the difference was the schedule.

Two consequences the code encodes:

* **`isal_cauchy` stays in the default label set** even though the paper never
  reports it. It is what sits in front of the instrument.
* **The RS–16 labels are appended** after the n ≤ 256 block rather than
  interleaved, so that every earlier label's predecessor is unchanged, and the
  transform decoder — whose work buffer is the largest thing in the point —
  goes **last**.

There is no assertion that can catch a reordering. It produces wrong numbers
with nothing saying so, which is why it is written down in three places.

## 5. A label pins its whole configuration and inherits nothing

**Nulls are not configuration.** `codec/KNOBS.md` splits the knobs into two
classes and the distinction is the point: some select what the codec *does*, and
some exist only so that a claim about a change can be measured against the
configuration it replaced. **The second kind should never be set to get a
number.** They are there so the number can be checked.

**And a label's meaning must never depend on a compiled default.** Every label in
`ENV_FOR` states its own knobs — including the labels whose knobs happen to
match the compiled defaults, and including the label that passes none at all,
which gets a filler variable rather than an empty block.

### The incident record: three times, one cause

Each time, the driver did exactly what it was told. Each time, the caller assumed
the default was the recommendation.

1. **The Firedancer comparison.** An encode ratio was published showing the
   external reference well ahead. Re-read with the comparator explicitly
   configured, it **inverted** — our side was ahead. The comparator had been run
   bare and reported under a label whose meaning had moved.
2. **A second external comparison, weeks later, repeated it exactly.** The driver
   run bare, reported under a configured label's name, and the encode ratio
   inverted again once the comparator was configured.
3. **After the defaults were flipped**, two legs of a decomposition script became
   something else entirely: one leg silently became a second copy of RS–8, and
   another became RS–8 decoded behind its own transform encoder — the artifact
   §4 exists to avoid. **Caught by diffing against a re-run, not by any test.**

The rules that came out of it are all in force here: a configuration is named by
its knob set and never by a label; every leg pins every knob; and `check.sh`'s
`COMPILED DEFAULTS` section asserts that the bare driver *is* the recommended
codec rather than trusting that it is.

### Equal-length environment blocks

The environment sits on the initial process stack, so a block of a different byte
length shifts every stack address in the measured process. Three bytes has
fabricated a 1.16× result here.

`_pad_env` pads every isal-family block to one width. It is the least obvious
line in the protocol, and it was itself wrong once — one label carried an empty
block, a 155-byte difference against its neighbours, measured harmless but not a
thing to leave in place. It matters most for the labels that **share a binary**:
RS–8, its decode instrument, RS–16's two decoders and the GF(2⁸) null all run
`codec/rs-point` and differ only in environment.

## 6. Striping is an implementation technique, not a harness setting

The Reed–Solomon labels can be byte-range striped; R10 and RaptorQ are not
striped. **That is not a harness asymmetry.** The harness's obligation is an
identical *timer contract*, not an identical set of implementation techniques.
The comparison the paper makes is well-optimised Reed–Solomon implementations
against the Raptor codes **as shipped**.

What has to hold for that to be fair is that unstriped is the baseline's *best*
available configuration — and it is. Striping only pays if the per-decode plan
solve is hoisted out of the stripes; both fountain crates keep their solve inside
`decode`, so striping at N would multiply their fixed decode term by N. Striping
the baseline without a hoist makes it **worse**; striping it with a hoist means
rewriting its crates, which is out of scope. Neither is done.

**The grid of record is unstriped and no label sets `BENCH_STRIPES`.**

This differs in kind from §3's remaining asymmetries. Those are timer-contract
differences — the same step charged to some labels and not others — and would be
defects if uncorrected and undisclosed. Striping is an implementation difference
between the things being measured, which is the point of the measurement.

## 7. What each oracle is for

`check.sh` is not a smoke test. It is the reason a timing run can be believed.

| check | what it establishes |
|---|---|
| **GF(2⁸) against Firedancer**, byte for byte | an **independent implementation** agrees on the code. Available because both index node *i* as field element *i*, so the node conventions coincide — `ALGORITHMS.md` §2.10 |
| **transform parity == matrix parity**, at 32 shapes × 3 pivot bases × 11 kernel variants | the encoders compute the same code, and no kernel knob moves a parity byte |
| **`auto` invariant under six kernel knobs** | catches a performance knob changing the *code* — which has happened |
| **`auto` is `ppt` exactly when the budget forces it, `pad` exactly when it does not** | the chooser has not collapsed to an endpoint |
| **round-trip decode** at 9 shapes × 3 pivot bases × 2 folds × 2 encoders | `--fold naive` recomputes the same rows from the generator, sharing no code with the closed form |
| **`COMPILED DEFAULTS`** | rule 1 of `DEFAULTS.md`, asserted rather than trusted |
| **Firedancer nulls** | the port's raised ceilings reproduce upstream's own shipped generators byte for byte at the unraised parameters |
| **`consumed/k` exactly 1.000** for every MDS label, at every point | the code is MDS at that shape *and* the harness is feeding it exactly k shards |
| **every path reference resolves and none escapes the tree** (`check_links.py`) | this tree describes itself correctly. A compiler checks an `#include`; nothing checked a path inside a comment, and the extraction's `isal/` → `codec/` rename left fifteen behind |

**GF(2¹⁶) has no external oracle and cannot have one** — no other library
implements this node set over this composite field. Its standing checks are
internal differentials: matrix against transform encoder, and both decoders
against the same emitted shards. That is a real check and it is not independence;
`LIMITS.md` §6.

Three defects in the GF(2⁸) construction were caught by this apparatus and by
nothing else: a table read before initialisation on an *unrelated* code path, an
offset correct at both endpoints and wrong at every interior pivot, and a kernel
knob leaking into the code choice. **All three passed every targeted test written
for them.** That is the argument for differential oracles over unit tests here.

## 8. Controls to check before believing a result

* **`consumed_per_k` exactly 1.000** for every MDS label. Any other value means
  the code is not MDS at that shape, or the harness is not feeding it exactly k
  shards. Runs at every point, in every label set.
* **The `code` term across plan variants must agree** to within a few percent
  *relative*. It is r·k multiply-accumulates by construction in every variant, so
  if it differs, something other than the plan moved and the comparison is void.
  The tolerance is **relative**, proportional to the term — an absolute
  millisecond threshold was asserted for a long time and is wrong by more than an
  order of magnitude at the top of the grid.
* **`rs`'s f-curve is a sawtooth, not a trend**, and it is the easiest way to
  draw a wrong conclusion from this harness. Its work buffer is sized from
  `next_pow2(2f)` and reaches its floor only when f is a power of two; decode
  roughly doubles from `f = 2ⁿ` to `f = 2ⁿ+1`, then improves within the octave,
  which reads as "RS gets faster with bigger committees" if you ignore
  `rs_work_over_T`. **Always normalise by `rs_work_count × shard_bytes` before
  reading across f.** The grid samples `2ʲ−1, 2ʲ, 2ʲ+1` triples for exactly this
  reason.
* **R10 and RaptorQ are bimodal** on decode. Never quote their medians without
  the stability ratio (`decode_max / decode_p50`).
* **RaptorQ is unavailable at large shards** — its transfer-symbol-size field is
  16 bits. Those points are an empty cell, not a failure.
* **Nulls before ratios.** A knob's effect is licensed by the labels it *cannot*
  reach reproducing across the pair. One null is not enough when the two sides
  live in different binaries.

## 9. Extending it

**A new codec:** write a binary emitting the 15-column detail header, add it to
`BIN_FOR` and `runs_for`, and port SplitMix64 and the shard permutation
bit-exactly. Do not FFI into the Rust binary. Then decide where in `runs_for`'s
order it goes, and read §4 before deciding.

**A new configuration of an existing codec:** add it to `runs_for` and give it
its own entry in `ENV_FOR` stating **every** knob. `_pad_env` will equalise the
block. Add the label to `ALL_LABELS`, which fixes column order — a label emitted
but absent from it is a hard error at startup rather than a silent column shift.

**A new grid:** `grid.py` and nothing else. It is imported by
`robust_benchmark.py` and read by `check.sh` through `-c` one-liners, so the two
cannot drift. An earlier version of this harness wrote the f list out three times
and hard-coded the field boundary by hand.

**Reading the summary CSV:** never by column position. The count is
`10 + 11·len(LABELS)` and `LABELS` depends on the active set and on which codecs
are available at a shape. `compare.py` matches by name from the header, and
reports-and-skips what is present in only one file.
