# Every default, its evidence, and its null

**The compiled defaults of `codec/rs-point` are the recommended configuration.**
This file states them, says which of them change the *code* and which change only
a *kernel*, and names the null each one is measured against.

Two things this file deliberately does not do. It does not restate measured
numbers — the figures live in the paper's `app:benchmarks` and in
`results/`. And it does not name a configuration by a label: a configuration is
named by its knob set, always.

`codec/KNOBS.md` is the full per-knob reference, including the knobs that exist
only as probes. This file is the shorter statement of what runs by default.

---

## The policy

1. **The default is the best measured configuration.** A default is a
   recommendation, and a recommendation with no evidence is noise. There is no
   virtue in a timid default.
2. **A default changes only when a measurement supports it**, and the change
   names that measurement.
3. **Every default keeps a reachable null**, because the per-optimisation
   decomposition is measured against it. That is what the knobs are for.
4. **Defaults are flipped in a batch, before the legs that produce figures.**
   Flipping afterwards invalidates them. An ordering constraint, not a reason to
   leave a default off.
5. **A default that changes the CODE is different in kind** from one that
   changes only the kernel, and is called out as such. Kernel knobs must never
   change a parity byte, and `check.sh` asserts it.

**Rule 1 is asserted, not trusted.** `check.sh`'s `COMPILED DEFAULTS` section
runs the bare driver and the driver told to use the recommended block, and
requires byte-identical parity at four shapes in both fields. Nothing checked
this until a run of the harness found four GF(2¹⁶) knobs still at an older
codec's behaviour — which had by then inverted two published ratios, in both
cases because a comparator inherited a default instead of stating its
configuration. `HARNESS.md` §5 carries that incident record.

---

## RS–8 — GF(2⁸), n ≤ 256

```sh
ISAL8_NODES=eval ISAL8_ENCODE=fft ISAL8_INTERP=auto ISAL8_FFT_BLOCK3=1 \
ISAL8_FUSE=1 ISAL8_PPT_FUSE=1 ISAL8_COSET_FUSE=1 \
  ./codec/rs-point --field 8 --plan cauchy --f <f> --shard-bytes <n>
```

| knob | default | changes | null | evidence |
|---|---|---|---|---|
| `ISAL8_NODES` | **`eval`** | **the CODE** | `cauchy` | the evaluation code on nodes 0…n−1 is the one an additive FFT can encode, and it is Firedancer's node convention, which is what makes `references/fd-point --digest` an oracle. `app:subspace-shortening` |
| `ISAL8_ENCODE` | **`fft`** | encoder only | `matrix` | the additive transform against `ec_encode_data` over the same nodes. Same code, so the two must agree byte for byte — `check.sh` asserts it at 32 shapes × 3 pivot bases × 11 kernel variants |
| `ISAL8_INTERP` | `auto` | **the CODE** | `ppt`, `pad`, or an explicit `<kp>` | the pivot base, by the rule `kp = min(chunk, 256 − m)`. See `ALGORITHMS.md` §5.4 — including the regime where no constant-free rule can be optimal |
| `ISAL8_FFT_BLOCK` | on | kernel only | `=0` | two transform layers per memory pass |
| `ISAL8_FFT_BLOCK3` | on | kernel only | `=0` | three layers, over eight shards. Gated on AVX-512VL; without it this falls back to two layers, which is correct |
| `ISAL8_FUSE` | on | kernel only | `=0` | the copy-in fused with the interpolation's first butterfly layer. Only on the plain-IFFT path |
| `ISAL8_PPT_FUSE` | on | kernel only | `=0` | the pivot glue's adjacent one-shard ops fused into one pass each |
| `ISAL8_COSET_FUSE` | on | kernel only | `=0` | each later coset's coefficient copy fused with its own first forward pass |
| `ISAL8_FFT_W` | 256 | kernel only | `=512` | 512-bit lanes measured as a wash, which is itself the evidence that this kernel is memory-bound rather than issue-bound |
| decoder | the Cauchy matrix plan, `--plan cauchy` | — | `--plan ge` | **RS–8 has no transform decoder.** GF(2⁸)'s whole reach lies below the decoder crossover — `ALGORITHMS.md` §1.8 |

### Why `auto`'s rule reads no kernel knob, and must not

`ISAL8_INTERP` selects a *code*, so its value may depend on `(k, m)` and nothing
else. An early chooser weighted transform passes using `ISAL8_FFT_BLOCK3` — which
made the encoder emit different parity under a knob whose contract forbids
exactly that. The matrix oracle caught it within one run.

The rule removes that hazard class at the root rather than guarding against it.
`check.sh` keeps the invariant anyway — **`auto` must not move under any of six
kernel knobs** — because what it now guards against is the chooser regrowing one.

## RS–16 — GF(2¹⁶), all n

```sh
ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_ENC_LAYOUT=inter \
ISAL16_DEC_LAYOUT=inter ISAL16_FFT_TAIL=4 \
ISAL16_DECODE=<matrix below f ~ 220, fft above> \
  ./codec/rs-point --field 16 --f <f> --shard-bytes <n>
```

| knob | default | changes | null | evidence |
|---|---|---|---|---|
| `ISAL16_NODES` | **`cantor`** | **the CODE** | `linear` | the Cantor basis is what makes the normalized vanishing polynomials a fixed iterate, so the whole skew table comes from one short recurrence. `ISAL16_ENCODE=fft` requires it. `ALGORITHMS.md` §2.9 |
| `ISAL16_ENCODE` | **`fft`** | encoder only | `matrix` | both compute the *same code*, so their parity must agree byte for byte — which is the standing oracle above n = 256, where no cross-library digest exists |
| `ISAL16_ENC_LAYOUT` | **`inter`** when the transform encoder runs, else `plane` | **the emitted BYTES** | `plane` | the layout of the shard pool itself. Same code over a different element ordering, not a different code; decode still returns the source exactly. Not defaulted unconditionally, because the matrix encoder writes parity through ISA-L, which addresses the pool as planes |
| `ISAL16_DEC_LAYOUT` | **`inter`** | kernel only | `plane` | the transform decoder's work-buffer layout: each 64-byte chunk is lo32\|hi32, so a butterfly touches one memory stream per shard instead of two. Decode only — the encoder writes the pool the matrix decoder reads, so it cannot move |
| `ISAL16_FFT_TAIL` | **4** | kernel only | any `<n>` | encode the last recovery coset by matrix when its live count is ≤ n. **The one genuine tuning threshold in either codec, and the only knob that would want recalibrating on another machine** |
| `ISAL16_DECODE` | `matrix` | decoder only | `fft` | **no single value is optimal — see below** |
| `ISAL16_FFT_BLOCK` | on | kernel only | `=0` | two transform layers per pass |
| `ISAL16_FFT_BLOCK3` | **off** | kernel only | `=1` | three layers is eight shards, which under plane-split planes is sixteen memory streams where upstream's interleave makes it eight. Measured a wash at best, and slower at three of four shapes off-grid. **Off here against upstream's choice**, and on by default in GF(2⁸), where a shard is one stream |
| `ISAL16_FFT_ASM` | **off** | kernel only | `=1` | the hand-written butterfly in `codec/fft_kernels.S`. It was written at `-O2`, where the C form spilled; at `-O3` the intrinsics form spills nothing and the assembly is the slower of the two. Unreachable anyway unless `ISAL16_FFT_BLOCK3=1` |
| `ISAL16_KARATSUBA` | on | kernel only | `=0` | three products instead of four in the composite tower, and a byte-identity oracle against the dense expansion |
| `ISAL16_LOGTAB` | on | kernel only | `=0` | log tables in the plan arithmetic |
| `ISAL16_FWHT` | vectorised | kernel only | `=scalar` | the Walsh–Hadamard locator. The two must decode identically — the locator feeds every recovered shard's scaling, so a wrong transform fails verification at once |
| `ISAL16_APPLY` | `isal` | kernel only | `=fused` | the r × k decode apply. `fused` exists as evidence that fusing loses here, not as an option |
| `ISAL16_DEC_PACK` | off | kernel only | `=1` | — |

### `ISAL16_DECODE` has no single optimal value, and that is a property of the codec

Every other knob above has one best value that holds across the whole grid.
This one does not.

**The mechanism, not a gap in the measurement.** The matrix decoder's work is
O(k·r) in the number of shards actually rebuilt; the transform decoder's is
O(n log n) in a width that does not depend on r at all. Two different functions
of the shape must cross — and here they cross twice, once near f ≈ 220 and again
inside the `f = 2ʲ+1` class, where the transform's work buffer takes a
radix-two step. `ALGORITHMS.md` §1.8 and §2.8(c).

**How it is handled here, and how a deployment would differ:**

| | |
|---|---|
| **in this benchmark** | **two labels**, `isal_x16_imat` and `isal_x16_inter`, measured separately. Keeping them apart keeps both nulls reachable and makes the crossover visible rather than buried in a dispatch |
| **in a production implementation** | **one decoder with a tuned crossover built in.** A deployment does not carry two decoders and a knob. That tuning is a different exercise from this measurement |

**No dispatch logic is compiled into `rs_point.c`, deliberately.** The paper
states the choice as a receiver-local dispatch, on the code shape and the
realized erasure pattern, and reports the crossover intervals;
`app:full-grid-comparison`. Fixing the decoder either way, rather than
dispatching, costs a substantial factor on the worst-case decode floor —
`app:absolute-throughput`.

## Harness-level

| knob | default | null | note |
|---|---|---|---|
| `BENCH_MALLOC` | `warm` | `default` | freed working buffers stay resident. **`default` figures are not comparable with `warm` ones.** `HARNESS.md` §3 |
| `BENCH_STRIPES` | 1 — unstriped | `auto`, or an integer | no label sets it. The grid of record is unstriped |
| `BENCH_LABELS` | `core` | `full` | `full` adds the decomposition nulls |
| `BENCH_ASLR` | unset — `setarch -R` applied | `=1` | the randomised layout is **not** the grid of record |
| `ISAL_ALLOC_PER_CALL` | on | `=0` | per-call working buffers. Under the `warm` contract the two agree |
| `ISAL_ENC_TIMER` | the parity-only encode region | `=full` | — |
| `ISAL_SHARD_PAD` | `auto` | `=0` | the shard-pool stride |

## What is deliberately *not* a default

* **No `ISAL16_DECODE` dispatch**, for the reason above.
* **No adjustment of the shard size to avoid the `reed-solomon-simd` L1 stall
  class.** The shard size is a protocol quantity — it is the number of bytes
  actually transmitted. Changing it would change the workload. `grid.py`'s
  `in_l1_bad_class` documents the effect and deliberately does not act on it.
* **No striping of R10 or RaptorQ.** `HARNESS.md` §6 explains why that is a
  disclosure rather than a defect.
