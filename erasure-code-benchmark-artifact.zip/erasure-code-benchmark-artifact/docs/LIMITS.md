# What is not claimed

This artifact reproduces two appendices of one paper on one class of machine.
This file is the boundary of that.

---

## 1. Hardware: a refusal, not a degradation story

**AVX-512 and GFNI are required.** Every GF(2⁸) and GF(2¹⁶) kernel measured here
is written against `vgf2p8affineqb` and 512-bit lanes. Without them the driver
takes fallback paths that no figure describes, so `check.sh` **exits** rather
than running. A reader is better served by being told the machine cannot
reproduce the paper than by a full run of quietly different numbers.

Nothing is claimed about ARM, about pre-GFNI x86, or about Intel client parts
from Alder Lake on, where AVX-512 is fused off.

## 2. One machine, one core, one clock

The reference figures are single-threaded, on one pinned core of one AMD desktop
part at a fixed frequency with boost disabled and address-space layout fixed.

**What reproduces is the shape of the result, not the milliseconds** — which
codec wins, by how much, and where the crossovers are. Absolute times will
differ. `compare.py`'s tolerance band is wide on purpose: it is there to catch a
codec that changed rank, not to relitigate a few percent of machine difference.
It is a diff, **not a statistical test** — it does not compute confidence
intervals and does not claim any.

**The decoder crossover is expected to move.** The paper places the RS–16
matrix/transform crossover between f = 206 and f = 212 at 0.5 and 1 MiB, between 200 and 206 at 2 MiB,
and between 224 and 230 at 4 MiB, and treats the choice as a receiver-local
dispatch rather than a monotone threshold. It is cache-dependent. Where it lands on other hardware is an open
question this artifact would like answered — `REPRODUCING.md` §5.

Nothing is claimed about multi-threaded throughput, about sustained load, or
about behaviour under a competing workload. Every measurement is single-threaded
and cold-per-message by design; `HARNESS.md` §1 says why that model was chosen
and what it deliberately does not measure.

## 3. What is not in this artifact

* **The attack results of the main paper**, and their implementation. Out of
  scope; not in this repository.
* **Any locally optimized `reed-solomon-simd`.** Only the **published crate**,
  stock 3.1.0 from crates.io, is shipped and benchmarked here, which is also
  what the paper's reference paragraph describes.
* **`tape-reed-solomon` and `leopard`.** Neither appears in the paper.
* **Per-trial detail CSVs**, for any run: neither the reference runs' nor the
  paper campaign's. They are large, and every figure is computed from the
  summaries. `results/paper-data/README.md` records the paper campaign's detail
  files by SHA-256.
* **The project's internal status report.** It is the source these documents
  were written from; it ships nowhere and is linked nowhere.

## 4. What is not claimed about the codecs

**RS–8 is not claimed to be a better encoder than Firedancer's in general.** The
grid ratios are at this paper's rate (n = 3f+1, so m ≈ 2k) and message sizes. At
Firedancer's own operating shape — k = m = 32 with roughly 1 KiB shreds —
their generated straight-line encoder is faster, for two reasons that are
understood and stated in `ALGORITHMS.md` §5.1: it never materialises a work
buffer, and its per-layer kernel has its constants immediate. RS–8's advantage
on this grid comes partly from the pivot base, which is algorithmic, and partly
from amortising a fixed per-call cost over the larger m this rate implies.

**The pivot construction may be prior art.** The additive FFT is Lin–Chung–Han's;
the principal pivot transform for an arbitrary pivot set is stated by
Lin–Alloum–Al-Naffouri. What this project claims is leaving the pivot length
*free*, the node budget `kp ≤ 256 − m` that bounds it, and the measured optimum.
The literature was not exhaustively searched.

**The pivot rule is not optimal everywhere, and says so.** Where the node budget
binds rather than the transform width, no constant-free rule can be optimal —
`ALGORITHMS.md` §5.4. This artifact does not attempt a machine-tied chooser, and
the honest statement is that a measured floor exists there and the shipped rule
sits at it.

**R10 and RaptorQ are measured as shipped.** Optimising them is out of scope.
The Reed–Solomon implementations here are well-optimised and the fountain codes
are not, and that asymmetry is the comparison the paper makes — stated, not
corrected. `HARNESS.md` §6 gives the striping case in full, including why
striping the baseline would make it *worse* rather than better.

## 5. What the R10 numbers do and do not say

The artifact reports R10's **received-symbol consumption** and its timings. It
does **not** instrument which decoding path R10 takes: `monad-raptor/` is
vendored verbatim, modifications none, and carries no counter.

One inference is specifically unavailable, and is worth spelling out because it
looks available. R10 escalates to inactivation decoding on the condition in
`monad-raptor/src/r10/nonsystematic/decoder/decode.rs`:

```
buffer_state.len() − num_redundant_buffers  ≥  inactivation_symbol_threshold
```

**The left side counts decoder buffers, not received symbols.** `buffer_state`
is pre-seeded at construction with the S LDPC and H Half constraint rows
(`.../decoder/init.rs`) and then grows by one per received symbol. The crate's own
comment above that line describes it in received-symbol terms and is wrong about
its own code. So **comparing a measured `consumed/k` against the threshold's
1.5 constant proves nothing about which path ran** — in received terms the
escalation point is `floor(1.5k) − (S+H) + redundant`, which as a multiple of k
*rises* with k and is below 1.0 at small committees.

Nothing in this artifact's figures depends on that distinction. It is recorded
so that the consumption column is not over-read.

## 6. Oracles: what is checked against what

`check.sh` cross-validates GF(2⁸) against Firedancer's independent
implementation, byte for byte, at the one pivot base where the two compute the
same code. **GF(2¹⁶) has no external oracle and cannot have one** — no other
library implements this node set over this composite field. Its standing checks
are internal differentials: the matrix and transform encoders must produce
byte-identical parity, and both decoders must recover the source from the same
emitted shards. Those are strong checks, but they are not independence.

Firedancer's own reach is raised, not stock: `references/` regenerates it with
its policy size ceilings lifted so the same construction covers this paper's
shapes. Upstream's comment calls those ceilings *"limits based on current Solana
needs and performance"*, not mathematical limits, and `regen.sh` refuses to write
unless the unraised generators reproduce the shipped files byte for byte.

## 7. Timer asymmetries that are disclosed rather than corrected

The rule is that **the harness never adds an allocation the library does not
force**, and never removes one it does. What follows from that is not symmetric,
and the differences are properties of the libraries:

* Decode **ingest** is charged to `rs`, `r10` and `rq` and not to the Cauchy
  labels, because the former own their work buffers and must copy received
  shards in, while the latter can receive straight into the pool.
* The encode **source scatter** is charged to `rs` for the same reason one step
  earlier.
* **R10 is charged for n outputs, everyone else for n − K.** R10 here is
  non-systematic: it runs the LT sequence for every ESI including the source
  range, so there is no free source packet. RaptorQ is systematic and its source
  packets are produced outside its encode timer.
* The **plan / code split** exists only for the MDS labels. `r10`, `rq` and `rs`
  report `plan = 0` and `code = decode`; their pattern-dependent work is inside
  `decode`, undifferentiated. The `code` column is comparable within the MDS
  family and not across families. The `decode` column is comparable everywhere.
* **Output-buffer allocation on encode** is inside the timer for `rs`, `r10` and
  `rq` and absent for the Cauchy labels, which write parity into a pool. The
  direction of that bias is stated in `HARNESS.md` §3.

**RaptorQ's encode time is bimodal, and stack layout picks the mode.** At a
given shape it lands on one of two values ~22% apart — at *f* = 33 / 0.5 MiB,
sixteen seeds give seven results near 0.37 ms and nine near 0.45 ms with nothing
between. The selection is deterministic per (binary, seed) under `setarch -R`,
and it moves when **only the length of `argv[0]`** changes: copying the binary
to a longer filename shifts one seed's result by 18%. `argv[0]` sits on the
initial stack, so its length shifts everything above it — the same hazard the
harness pads environment blocks to control, which was never extended to the
binary's own name.

The consequence for a reader: the grid median of RS--8 ÷ RaptorQ encode is
**stable to ~0.5% for a fixed binary and moves ~9% between binaries that differ
only in name and dependency set.** Every other label reproduces at the median
across both (isal_x 1.000, r10 1.000, rs 0.991, rq 0.998 over 192 points); it is
RaptorQ's per-point scatter, 0.79–1.29, that moves a median taken over 40 of
them. **If your RaptorQ encode figures differ from the shipped reference by
around 10% while everything else matches, this is why, and neither number is
wrong.** No mechanism is claimed: which two paths, and what selects between
them, has not been probed.

**Memory allocated and never used.** `fft8_w` — about 6.1 MB at *f* = 85 /
4 MiB — is allocated and zeroed by the GF(2⁸) transform encoder's setup and then
never read or written, because the only path that reads it needs `ncos == 0`,
which is unreachable at every shape this artifact runs. `fft8_init` runs once
before the trial loop, so in theory no measurement can see it; it is disclosed
rather than removed because the removal edits a setup path every published
GF(2⁸) encode figure was measured through. `FIXME` in `codec/rs_point.c`,
full statement in `HARNESS.md` §3.

**And one that is the harness's own rather than a library's.** The pre-timer
zeroing of un-received original slots runs r times, where r is the number of
missing originals — **the very quantity `--arrivals` varies**, about 2k/3 under
`random` and k under `parity`. So a random-vs-parity decode ratio carries a term
that is not the decoder, **of unmeasured size** — an earlier version said ~6%
and that is withdrawn twice over: decomposing `decode = plan + code` leaves no
residual for it, and the figure it was fitted to was itself measured at a fixed
1 KiB shard, which is not a size this grid uses (`HARNESS.md` §3). Unfixed on purpose: the repair
changes the `random` path and would invalidate every decode figure already
measured. `FIXME` comments sit on both loops in `codec/rs_point.c`, and
`HARNESS.md` §3 gives the full statement including how to check a fix.

## 8. Two cosmetic things that are not defects

* The detail CSV's `tape_field` and `tape_gen` columns are **inert** and always
  emit `-`. They name a codec this artifact does not ship, and are kept so that
  all three drivers emit one identical header. `MAPPING.md` §7.
* `codec/rs_point.c` is one ~6 200-line translation unit and is **not split**,
  deliberately. `codec/README.md` gives the dependency analysis.

## 9. This is research code

The implementations here are experimental research implementations, as the paper
says. They are not production-hardened, they have no API, and no interface
stability is offered or implied.
