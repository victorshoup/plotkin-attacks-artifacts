# Running it, and the contract you must not break

Operation. `HARNESS.md` is the companion for *why* the harness is shaped this
way; this file is *how to run it* and what silently invalidates a run.

---

## 1. Requirements

**AVX-512 and GFNI are required** — exactly `CPUID.7.0:ECX.GFNI` and
`CPUID.7.0:EBX.AVX512VL`. `check.sh` reads them from `/proc/cpuinfo` and
**refuses** rather than degrading. In practice: AMD Zen 4 or Zen 5, Intel server
from Ice Lake-SP on, or Intel client through Rocket Lake — not Intel client from
Alder Lake on. `LIMITS.md` says why this is a refusal.

Also needed: a C toolchain, `nasm` (for ISA-L; `bootstrap-isal.sh` will fetch it
into `./localtools` without root if it is absent), `python3`, `cargo` with
rustc ≥ 1.89, and `curl` only if you re-fetch Firedancer's generator sources.

## 2. Build and run

```sh
./check.sh        # environment report, hardware refusal, correctness, oracles
./benchmark.sh    # the full 192-point grid, about 8 minutes
```

Always `check.sh` first. It is not a smoke test: it cross-validates the GF(2⁸)
codec against Firedancer's independent implementation byte for byte, checks
every pivot base against the matrix encoder, asserts that the compiled defaults
*are* the recommended configuration, and exercises the nulls. A green
`check.sh` and a red benchmark means a measurement problem; a red `check.sh`
means the build is wrong.

`./quick.sh` is a smoke subset. `./largef_sweep.py` is the beyond-grid
instrument and is **a different protocol** — see §3.5.

Pin the core:

```sh
BENCH_CPU=4 ./check.sh && BENCH_CPU=4 ./benchmark.sh
```

## 3. The landmines

Each of these silently invalidates numbers. None of them produces an error.

### 3.1 `RUSTFLAGS="-C target-cpu=native"` is not optional

A bare `cargo build --release` produces an R10 that is **about 20% slow**, and
R10 carries three of the four appendix tables. `benchmark.sh` and `check.sh` set
the flag when `RUSTFLAGS` is unset, and refuse to run if `RUSTFLAGS` is set
without `-C target-cpu` — but nothing protects a build you do by hand. If you
build the Rust side yourself, set it. The C side carries `-O3 -march=native` in
`codec/Makefile` and `references/Makefile`, which must stay identical to each
other because the two binaries are compared against one another.

This was first mistaken for a real regression. What settled it was not a
statistic: rebuilding the same source with the flag reproduces the committed
binary byte for byte, where every build without it gives a different hash.

### 3.2 `isal-patches/` is part of the codec, not an optimization

`bootstrap-isal.sh` applies a 991-line patch to stock ISA-L v2.31.1 — the
`vpternlogd` shard-pairing, 128-byte-block and integer-broadcast rewrite of the
GFNI kernels. **These kernels are the measured configuration.** A build without
them is not a slower version of this artifact; it is a different one, and
`check.sh` still passes, because correctness does not depend on which kernel
does the arithmetic.

A missing `isal-patches/` directory is **fatal** in `bootstrap-isal.sh`. It used
to be a silent skip, and that cost a full assembly cycle: the grid came out
1.75× slow on matrix encode and 1.58× slow on GF(2⁸) decode against the
reference, with nothing in the output saying why.

### 3.3 Fixed layout, fixed clock, pinned core

`setarch -R` for every measured child, `taskset` to one core, a clock that does
not chase load, boost disabled. Without a fixed address-space layout, wall clock
carries a large ASLR lottery — measured here as a spread up to 1.9× on large-f
encode at 4 MiB, while a well-behaved label was stable to 2% across the same
draws. `robust_benchmark.py` applies `setarch -R` itself; `BENCH_CPU` and the
governor are yours to set.

`check.sh` **warns** on each of the four it can detect but not fix: `BENCH_CPU`
unset, `setarch` missing, a clock-varying governor, boost enabled. Each warning
states that correctness is unaffected and only timing is at stake. `performance`
and `userspace` both pass — `userspace` means the operator has pinned the
frequency, which is how the reference figures were taken.

### 3.4 Equal-length environment blocks

**The least obvious rule in the protocol.** The environment sits on the initial
process stack, so a configuration block of a different byte length shifts every
stack address in the measured process. A three-byte difference has fabricated a
1.16× result in this harness.

`_pad_env` in `robust_benchmark.py` pads every isal-family block to one width
with a filler variable — including the labels that pass no knobs at all. If you
add a label or change a knob string, it is padded automatically; if you drive
`codec/rs-point` **by hand** for an A/B, you must equalise the blocks yourself.

### 3.5 The other rules that come as a set

* **Label order inside a point is load-bearing.** `isal_x_dec` must not be
  preceded by `isal_x`, or it reads 1.05×–1.08× high at ≥ 1 MiB — it decodes
  into a cache the previous process's transform work buffer just evicted.
  Reordering `runs_for` produces wrong numbers with nothing saying so.
  `HARNESS.md` §4.
* **The allocator contract.** `BENCH_MALLOC=warm` (the default) pins
  `glibc.malloc.mmap_threshold` and `trim_threshold` high, so freed working
  buffers stay resident and every label is measured on recycled memory.
  `BENCH_MALLOC=default` restores glibc's dynamic behaviour and **its figures
  are not comparable with `warm` ones.**
* **The grid is `grid.py` and nothing else.** `BENCH_FS` restricts it for
  bisecting; a restricted run is self-describing, because the stamped CSV
  records whatever grid actually ran.
* **`largef_sweep.py` is a different protocol** — 15 trials per invocation
  against the grid's 20. Its numbers and the grid's must not be merged into one
  table. The paper keeps them in separate tables for this reason.
* **Ad-hoc runs of `codec/rs-point` need the allocator contract too.** Run by
  hand without it, a point can read several times slow. Use:

  ```sh
  GLIBC_TUNABLES=glibc.malloc.mmap_threshold=536870912:glibc.malloc.trim_threshold=536870912 \
    setarch -R taskset -c 4 ./codec/rs-point --field 8 --f 85 --shard-bytes 12224
  ```

## 4. Comparing your run against the reference

```sh
python3 compare.py results/robust-summary-<stamp>.csv
```

`compare.py` diffs a local summary against the reference that matches its
phase, read from its filename: `results/reference-grid-encode.csv`,
`results/reference-grid-decode.csv`, or `results/reference-grid.csv` for an
interleaved run. It prints per-point ratios. Those references are a run of this
artifact's code, not the data the paper was computed from. The latter ship in
`results/paper-data/`, see `results/README.md`. It matches labels **by name from the header**, never by
column position, and reports-and-skips labels or points present in only one
file — a smaller label set is a legitimate run, not a failure.

**What is being reproduced is the shape of the result, not the milliseconds.**
Absolute times depend on the machine. The claim is which codec wins, by how
much, and where the crossovers are. `compare.py`'s tolerance band is
deliberately wide for that reason: it is there to catch a codec that changed
rank or a label that is measuring something else, not to relitigate a few
percent of machine difference.

## 5. What is worth reporting back

**Where the RS–16 matrix/transform decoder crossover lands on your machine.**
The paper places it between f = 206 and f = 212 at 0.5 and 1 MiB, between 200 and 206 at 2 MiB,
and between 224 and 230 at 4 MiB, and treats the choice as a receiver-local
dispatch rather than a monotone threshold. It is
cache-dependent and will move on a different memory hierarchy. It is the single
most useful thing a third party can measure here.

Run the grid, then read `isal_x16_imat` against `isal_x16_inter` on decode. Both
labels consume the same emitted codewords, so the comparison is internal to one
run and does not depend on reproducing our absolute times at all.
