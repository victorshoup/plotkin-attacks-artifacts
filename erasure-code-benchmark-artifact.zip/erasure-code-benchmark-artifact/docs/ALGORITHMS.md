# How RS–8 and RS–16 actually work

**Read this before `codec/rs_point.c`.** The paper's Reed–Solomon appendix
(`app:rs-algebra`) justifies the
mathematics, organized by result, for a reader of the paper. This file explains
the *implementation*: what the codecs compute, why those choices, and where each
piece lives in the source. The central idea of RS–8 — *a transform encoder
behind a matrix decoder, because the two halves have opposite preferences* —
appears nowhere in the code, and cannot be recovered from it.

No ingredient here is new; Part 6 says whose each one is. The combination is
specific to this project and is not recoverable from the source, which is the
only reason this file exists.

**Who this is for.** A reader comfortable with linear algebra who knows
Reed–Solomon as polynomial evaluation and interpolation, and knows the usual
radix-2 multiplicative FFT. It assumes nothing about finite-field
implementation, additive FFTs, Cauchy matrices, or this codebase.

**It states no measured numbers.** Every figure lives in the paper's
`app:benchmarks` or in `results/`. What is here is shapes, mechanisms and
contracts — which is what lets it be checked rather than believed.

**Notation, fixed throughout.**

```
F          the field, GF(2^8) or GF(2^16)
⊕          field addition = XOR.  Subtraction is the same operation; there are
           no signs anywhere in this subject, and a ⊕ a = 0
k, m, T    k source shards, m parity shards, T = k + m total
           (the paper writes K and n for k and T)
f          the committee parameter; this project's rate is k = f+1, T = 3f+1
u_0..u_{k-1}   the source nodes            x_0..x_{m-1}   the parity nodes
r          the number of source shards actually missing at decode time
chunk      next_pow2(k), the transform width
φ          the index-to-field-element map of §2.2
β_j        the j-th GF(2)-basis vector; β_j = φ(2^j)
V_j        span(β_0..β_{j-1});  s_j, ŝ_j its vanishing polynomial, normalized
```

**The four codecs this artifact measures:**

| | field | encode | decode | where |
|---|---|---|---|---|
| **RS–8** | GF(2⁸) | additive FFT, *partial* pivot | **Cauchy matrix** | `codec/rs_point.c --field 8` |
| **RS–16** | GF(2¹⁶) | additive FFT, Cantor basis | **Cauchy matrix**, or FFT above f ≈ 220 | `codec/rs_point.c --field 16` |
| **Firedancer** `reedsol` | GF(2⁸) | additive FFT, full pivot | their own | `references/fdrs/` |
| **`reed-solomon-simd`** | GF(2¹⁶) | additive FFT | additive FFT + Walsh locator | crates.io 3.1.0, stock |

Two bodies of algebra explain all four: **generalized Reed–Solomon codes written
as Cauchy matrices** (Part 1), and the **additive FFT** (Part 2).

---

# Part 1 — Generalized Reed–Solomon and Cauchy matrices

## 1.1 The shape of the problem

`k = f+1` source shards, `T = 3f+1` total coded shards. The code must be
**systematic** — source shards go out verbatim — and **MDS**: any k of the T
shards reconstruct the source.

A shard is a long vector of field elements, but every element position is
treated identically and independently. So all the algebra is on a single
"column": one field element per shard, with the work multiplied by the shard
length at the end. This is why every kernel in this project is some version of
*"multiply a shard by a scalar and XOR it into another shard"* — the arithmetic
is one element wide, the memory traffic is one shard wide, and those two facts
pull in different directions for the whole of Parts 3–5.

The object is therefore a `T × k` generator matrix `G` over `F`, whose top
`k × k` block is the identity, and **every** `k × k` submatrix of which is
invertible. That is MDS, and it is the entire reason this is not just XOR.

## 1.2 Reed–Solomon as evaluation and interpolation

Pick T distinct nodes, split by role from the start:

```
u_0, …, u_{k-1}     the k source nodes
x_0, …, x_{m-1}     the m parity nodes
```

disjoint, and together all T. Map the data `d = (d_0,…,d_{k-1})` to the unique
polynomial `g` of degree `< k` with `g(u_j) = d_j`, then emit

```
g(u_0), …, g(u_{k-1}),   g(x_0), …, g(x_{m-1})
```

The first k outputs are the data by construction, so this is **systematic with
all multipliers equal to 1**. Any k outputs are k evaluations of a degree-`<k`
polynomial, hence determine `g`. MDS, and that is the whole proof.

Note what this forces: **the code is determined by the node set and its
ordering.** Two implementations "both doing Reed–Solomon" emit different bytes
unless they agree on both. This is not pedantry — it is why `DEFAULTS.md`
classifies `ISAL8_NODES` and `ISAL16_NODES` as knobs that *change the code*
rather than a kernel, and why byte-identity between two encoders can be used as
an assertion at all.

## 1.3 The same code as a matrix

Lagrange over the source nodes:

```
g(z) = Σ_j d_j · L_j(z),      L_j(z) = Π_{l≠j} (z ⊕ u_l) / Π_{l≠j} (u_j ⊕ u_l)
```

Write `W_j = Π_{l≠j} (u_j ⊕ u_l)`. Then

```
p_i = g(x_i) = Σ_j d_j · Π_{l≠j}(x_i ⊕ u_l) / W_j
```

Now the move that makes everything work. Let `A_i = Π_l (x_i ⊕ u_l)` — the
product over **all** l, including `l = j`. The node sets are disjoint, so
`x_i ≠ u_j` and we may divide:

```
Π_{l≠j} (x_i ⊕ u_l)  =  A_i / (x_i ⊕ u_j)
```

Substituting,

```
G  =  diag(A) · C · diag(1/W)          where     C[i][j] = 1 / (x_i ⊕ u_j)
```

`W` depends on the source nodes alone; `A` mixes the two sets and is indexed by
parity node. **Hold on to that asymmetry** — §1.7 turns on it.

This identity appears verbatim as a comment above `cauchy_entry` in
`codec/rs_point.c`, and `proofs/pivot_check.py` re-derives it from scratch,
sharing no code with the driver.

## 1.4 `C` is a Cauchy matrix

`C[i][j] = 1/(x_i ⊕ u_j)` for disjoint `{x_i}`, `{u_j}` is a **Cauchy matrix** —
the characteristic-2 form of `1/(x_i − y_j)`. Three properties, increasing in
usefulness.

**(a) Every square submatrix of a Cauchy matrix is a Cauchy matrix.** Obvious:
delete rows and columns and you have shrunk the two node sets.

This is **not** true of a Vandermonde matrix, and it is a practical trap rather
than a theoretical one. ISA-L's `gf_gen_rs_matrix` is Vandermonde-derived, its
own header admits it does not guarantee an invertible submatrix, and at these
shapes it yields a singular survivor set for a small but nonzero fraction of
random arrival orders — an undecodable block every few hundred. A Cauchy
generator has no such failure mode, at any shape.

**(b) Cauchy matrices are nonsingular**, by the classical determinant

```
det C  =  Π_{a<b}(x_a ⊕ x_b) · Π_{a<b}(u_a ⊕ u_b)  /  Π_{a,b}(x_a ⊕ u_b)
```

nonzero exactly because the nodes are distinct and the sets disjoint. With (a):
**every** square submatrix is nonsingular. MDS, without mentioning polynomials —
which is why library authors reach for Cauchy generators.

**(c) The inverse has a closed form**, in O(n²):

```
(C⁻¹)[b][a]  =   Π_l (x_a ⊕ u_l) · Π_l (x_l ⊕ u_b)
                 ────────────────────────────────────────────────
                 (x_a ⊕ u_b) · Π_{l≠a}(x_a ⊕ x_l) · Π_{l≠b}(u_b ⊕ u_l)
```

That is `cauchy_inverse`: two O(n²) passes computing one scalar per row and one
per column, then one multiply and one divide per entry — against Gaussian
elimination at O(n³).

## 1.5 Where generalized RS genuinely enters

Systematic form did **not** force multipliers; §1.2 has them all equal to 1. Two
other things do.

**(i) The Cauchy generator is a different code.** ISA-L's
`gf_gen_cauchy1_matrix`, and this driver's `cauchy_entry`, use

```
G[i][j] = 1 / ((k+i) ⊕ j)
```

— the bare Cauchy matrix, **no diagonals**. By §1.3, the *evaluation* code on the
same nodes is `diag(A)·C·diag(1/W)`. Same `C`, different diagonals, different
parity bytes, both MDS. Once both live in one program you need the family
containing both; `gen_entry` is literally a switch over the two.

**(ii) A transform encoder does not interpolate over k nodes.** This is the
unavoidable one, and it is the bridge to Part 2. An additive FFT of size `2^j`
evaluates over a `2^j`-element subspace; it cannot interpolate through exactly k
points when k is not a power of two. So every transform encoder interpolates
over some node set of size `D ≥ k` and fills the extra `D − k` slots with
something.

Take zero-padding, which is what `reed-solomon-simd` does. Let `D = chunk`, and
let `Q` be the degree-`<D` polynomial with

```
Q(j) = d_j    for j < k
Q(j) = 0      for k ≤ j < D
```

with parity `Q(D+i)`. What code is that? Lagrange over the D nodes gives
`G[i][j] = L_j(D+i)`, so by §1.3

```
G[i][j] = A_i / ((D+i ⊕ j)·W_j),   A_i = Π_{l<D}((D+i) ⊕ l),   W_j = Π_{l<D, l≠j}(j ⊕ l)
```

Those products run to D, not k. The plain evaluation code on the *actual* node
set `{0…k−1} ∪ {D…D+m−1}` has products running to k. The ratio is one
polynomial:

```
Z(z) = Π_{l=k}^{D-1} (z ⊕ l)     ⟹    G_padded = diag(Z(D+i)) · G_plain · diag(1/Z(j))
```

**Nontrivial multipliers, no way around them.** Structurally: the padded code is
the `[D+m, D]` evaluation code *shortened* on coordinates `k…D−1`, and shortening
preserves MDS.

The same `Z` covers the other choice. RS–8 picks a **pivot base** `kp ∈ [k, chunk]`,
interpolating the degree-`<kp` polynomial through the data and zeros at
`k…kp−1`, with parity at `kp…kp+m−1`. Every `kp` gives a different GRS code with
`Z(z) = Π_{l=k}^{kp-1}(z ⊕ l)`; `kp = k` gives `Z ≡ 1`, which is Firedancer's
construction; `kp = chunk` is the padded code. Part 5 develops this.

So the codes in play are: pure Cauchy, plain evaluation, padded, and one per
pivot base — **all of them `diag(·)·C·diag(·)` with the same `C`.**

## 1.6 Why the closed form is the point

Here is where the measurement model (`HARNESS.md` §1) enters the algebra: **a
fresh random erasure pattern on every trial.** In a BFT setting the set of
first-k-to-arrive differs every block, so the decode matrix is built from
scratch every time and no cache ever hits. Storage benchmarks amortize that
setup across thousands of decodes and report a number that does not apply.

Decode therefore splits into a **plan** (build the inverse) and a **code** (apply
it to the shard bytes), and the plan is not a rounding error — it is a large
fraction of decode at these shapes, rising with f and with the field width.
Moving the plan from O(k³) to O(r²) is a first-order effect.

And it gets better than O(r²). With `y_0…y_{r-1}` the missing source nodes, the
rows needed are

```
R  =  [ B⁻¹ | B⁻¹E ]
```

`B` (r × r) the Cauchy matrix on received-parity × missing-source, `E`
(r × (k−r)) on received-parity × received-source. `B⁻¹` is §1.4(c). The product
`B⁻¹E` looks like `r²(k−r)` multiplies — cubic in k at these shapes, and
dominant over the inverse — but **collapses by partial fractions**:

```
(B⁻¹E)[b][c]  =  ny_b · P(u_c) / (u_c ⊕ y_b),      P(w) = Π_l (w ⊕ y_l) / Π_l (w ⊕ x_l)
```

`P(u_c)` costs 2r multiplies and one inversion per column, computed once for all
b; every entry is then one multiply and one divide. That is `fold_closed_form8`
and `fold_closed_form16`. **Plan cost: O(r²) + O(k).**

Both products are nonzero for the reason you would want: `u_c` is a received
source index, so it differs from every missing `y_l`, and being `< k` it differs
from every parity node `≥ k`.

At this rate r is not small — see §1.8 — so this is the difference between a
cubic term and a quadratic one on every message.

## 1.7 The diagonals are free

Combine §1.5 with §1.6. **This is the hinge of the whole design.** The real
generator is `diag(A)·C·diag(1/W)`. Does the closed form survive?

```
B     =  diag(A) · C_B · diag(1/W_y)
B⁻¹   =  diag(W_y) · C_B⁻¹ · diag(1/A)
E     =  diag(A) · C_E · diag(1/W_u)
B⁻¹E  =  diag(W_y) · (C_B⁻¹ C_E) · diag(1/W_u)          ← diag(A) cancels
```

`diag(A)` cancels in the second product **because `B` and `E` share their rows** —
the same received parity shards, hence the same `A_i`. That is the asymmetry
flagged in §1.3. What survives folds into three scalar vectors the closed form
already materializes — one multiply each — and `W`, `A` and their inverses depend
only on (k, m), so they are built once per process, never per decode.

Cost of moving from the pure Cauchy code to any transform-generated code:
**O(k) per decode against an O(r²) plan.** Measured across the GF(2⁸) grid as a
wash on decode, which is the premise the whole construction rests on.

> **This is the load-bearing fact for both RS–8 and RS–16: the encoder may
> choose whatever code an FFT computes cheaply, and the fast matrix decoder
> still applies, for free.**

## 1.8 The tension the four codecs resolve differently

Two descriptions of one family:

* **as a matrix** — good for *decoding*: an arbitrary k-subset of surviving rows
  is just a submatrix, MDS by inspection, cheap to invert;
* **as evaluation** — good for *encoding*: multipoint evaluation at T structured
  points is a transform, O(T log T) against the matrix's O(k·m).

The asymmetry that decides everything: a **transform decoder runs at the
transform's full width regardless of how few shards are missing**, while a
**matrix decoder does O(k·r) work in the number of shards actually rebuilt**.

At this rate r is not small. The decoder receives exactly k shards from T, so
the received source count is hypergeometric with mean `k²/T ≈ f/3`, giving

```
r  ≈  (2/3)·k        hence     matrix Θ(f²)   vs   transform Θ(f log f)
```

**The transform wins asymptotically, decisively** — and the plan side points the
same way, harder: the matrix plan is Θ(f²) scalar operations with a division
each, while the transform's plan (Part 3) is a fixed full-field cost independent
of f. There is no regime beyond the crossover where the matrix returns.

Measured in GF(2¹⁶), the transform leads from around f ≈ 220, with the exact
point depending on message size; the paper reports the interval in
`app:full-grid-comparison`. Two notes on that number:

* It is further out than op-counting predicts. The gap is constant factor: the
  matrix apply is r output shards each accumulating k scaled inputs — pure
  streaming, near-zero write traffic — while a butterfly reads two shards and
  writes two.
* It is shard-size dependent, because shrinking the shards shrinks the
  shard-wide term for both and exposes the plan-side asymmetry, where the
  transform is already far ahead.

**GF(2⁸) caps T ≤ 256, hence f ≤ 85, hence lies entirely below the crossover.**
So "matrix decode wins in GF(2⁸)" is a statement about the field's reach, not
about the algorithm. RS–8 is "transform encode, matrix decode" because its
field's whole range is in the matrix regime; RS–16 carries two decoders because
GF(2¹⁶)'s is not — `DEFAULTS.md`, "`ISAL16_DECODE` has no single optimal value".

---

# Part 2 — The additive FFT

## 2.1 The FFT you know does not exist here

A radix-2 FFT of length `N` needs an element of multiplicative order `N = 2^n`.
In `F = GF(2^m)` the multiplicative group has order `2^m − 1`, which is **odd**.
The only element of 2-power order is 1. **There is no radix-2 FFT of any length
greater than 1 in characteristic 2** — not "it is awkward", it does not exist.

Factor and see what is available. `65535 = 3 · 5 · 17 · 257`, so multiplicative
transforms of length 3, 5, 15, 17, 51, 85, 255, 257, … exist: all odd, all
rigidly fixed by the factorization. Useless for a codec that must accept
arbitrary k.

The alternative is to leave characteristic 2 — `Z/p` with `p = 2¹⁶+1` has
`p−1 = 2¹⁶` and luxurious radix-2 FFTs. But then addition is not XOR, elements do
not pack into machine words, `vgf2p8affineqb` does not apply, and every kernel in
this project evaporates. **Characteristic 2 buys free addition and byte-packing;
the price is the multiplicative FFT.**

## 2.2 What structure does exist

The additive group is as nice as it gets:

```
(F, ⊕)  ≅  (Z/2)^m
```

an m-dimensional GF(2)-vector space, whose subgroups are its subspaces, in every
size `2^j`. So: evaluate on a **subspace** and its **cosets** instead of on a
cyclic group.

And it costs nothing to arrange. Fix a GF(2)-basis `β_0,…,β_{m−1}` and define

```
φ(i)  =  ⊕_{b : bit b of i set}  β_b
```

**`φ` turns integer XOR into field addition**: bit b of `i XOR i'` is set exactly
when it is set in one of them but not both, and on the right-hand side `β_b`
appears twice and cancels precisely when both have it. So `φ` is a group
isomorphism. **Index arithmetic under XOR is field arithmetic under addition.**

Consequences, both immediate:

```
S_j = {0,…,2^j − 1}   is closed under XOR      ⟹   φ(S_j) = V_j := span(β_0..β_{j-1})
```

with the flag `V_0 ⊂ V_1 ⊂ ⋯ ⊂ V_n` free, and

```
B_t = [t·2^j, (t+1)·2^j)  =  { t·2^j + s : s ∈ S_j }
```

where — the crux — `t·2^j` has all its low j bits zero and `s < 2^j` lives
entirely in them, so **the addition carries nothing**:

```
t·2^j + s  =  t·2^j XOR s          ⟹      φ(B_t) = φ(t·2^j) ⊕ V_j
```

an honest coset. **Alignment is doing real work**: the block `[1,3) = {1,2}` is
not a coset, because `1 XOR 2 = 3 ∉ {1,2}` — equivalently `1 + 1 = 2` carries.
That is why every width in these codecs is a power of two and every parity block
starts at a multiple of `chunk`: an algebraic requirement, not a memory-layout
convenience.

Note also that `β_j = φ(2^j)`: choosing the basis and choosing "which field
element sits at index i" are **the same act**, not two.

## 2.3 The one miracle: subspace vanishing polynomials are linear maps

Define

```
s_j(x)  =  Π_{a ∈ V_j} (x ⊕ a)
```

monic, degree `2^j`, roots exactly `V_j`, all simple.

> **Claim.** `s_j` is GF(2)-linear: `s_j(x ⊕ y) = s_j(x) ⊕ s_j(y)`.

*Proof.* Induction. `s_0(x) = x`. For the step, `V_{j+1} = V_j ⊔ (β_j ⊕ V_j)`, so

```
s_{j+1}(x) = s_j(x) · s_j(x ⊕ β_j) = s_j(x)·( s_j(x) ⊕ s_j(β_j) )
           = s_j(x)² ⊕ s_j(β_j)·s_j(x)
```

using the hypothesis. Squaring is the Frobenius, additive in characteristic 2;
scaling is additive; sums of additive maps are additive. ∎

Expanding, `s_j(x) = Σ_i c_i x^{2^i}` — only Frobenius powers, which is what
"linearized polynomial" means.

**Stop and appreciate this.** In characteristic 0 nothing like it holds. In
characteristic 2 the polynomial vanishing on a subspace *is a homomorphism of the
additive group*. Every structural fact below is a consequence.

**The recursion is a composition.** With `L_j(y) = y² ⊕ s_j(β_j)·y`,

```
s_{j+1} = L_j ∘ s_j        ⟹        s_n = L_{n-1} ∘ ⋯ ∘ L_0
```

The vanishing polynomial of an n-dimensional subspace factors as a composition of
n additive quadratics. **That decomposition is the additive FFT** — one butterfly
layer per `L_j`. It is the analogue of `x^N − 1 = Π(…)`, with composition in
place of factorization.

**The corollary everything uses.** Additive with kernel `V_j` means

```
s_j(x ⊕ a) = s_j(x)      for a ∈ V_j
```

so `s_j` is **constant on each coset of `V_j` and injective on the set of
cosets**: it realizes the quotient map `F → F/V_j` *as a polynomial*.

> **The additive FFT works because the quotient by a subspace is implementable as
> a degree-`2^j` polynomial map.**

## 2.4 Normalizing, and the Artin–Schreier tower

Set `ŝ_j(x) = s_j(x)/s_j(β_j)`, legal since `β_j ∉ V_j`. Then

| | |
|---|---|
| **(L)** | `ŝ_j` is GF(2)-linear |
| **(V)** | `ker ŝ_j = V_j` exactly |
| **(N)** | `ŝ_j(β_j) = 1` |

**Why normalize.** With the unnormalized `s_j`, the pair `{x, x ⊕ β_j}` gives
`f(x ⊕ β_j) = f(x) ⊕ s_j(β_j)·g_1(x)` — an **extra multiply**, `(N/2)·log₂N` of
them across the transform, roughly doubling the multiply count. Normalizing makes
that coefficient 1, and costs nothing at runtime because the division is folded
into the *definition of the basis polynomials* (§2.5). This is why the inner loop
of every engine in the tree is `x ^= y·S; y ^= x` with a bare `^` on the second
line.

Two relations, used constantly:

```
ŝ_j(x ⊕ β_j) = ŝ_j(x) ⊕ 1                the crossing relation
ŝ_j(x ⊕ a)   = ŝ_j(x)   for a ∈ V_j      the sharing relation
```

Dividing §2.3's recursion by `s_j(β_j)²` gives, with `℘(y) = y² ⊕ y` the
Artin–Schreier map,

```
ŝ_{j+1}  ∝  ℘ ∘ ŝ_j
```

and the kernel check re-proves §2.3 structurally:
`ker(℘ ∘ ŝ_j) = ŝ_j⁻¹({0,1}) = ŝ_j⁻¹({0, ŝ_j(β_j)}) = V_j ⊕ span(β_j) = V_{j+1}`.
**The flag and the composition chain are the same object.** §2.9 removes the
proportionality constant.

## 2.5 The novel polynomial basis

For `0 ≤ i < 2^n` with binary digits `i_j`:

```
X_i(x)  =  Π_{j=0}^{n-1} ŝ_j(x)^{i_j}
```

Each `ŝ_j` appears **at most once** — the exponents are bits — so

```
deg X_i  =  Σ_j i_j · 2^j  =  i        exactly
```

`n = 3`, written out: `X_0 = 1`, `X_1 = ŝ_0`, `X_2 = ŝ_1`, `X_3 = ŝ_0ŝ_1`,
`X_4 = ŝ_2`, `X_5 = ŝ_0ŝ_2`, `X_6 = ŝ_1ŝ_2`, `X_7 = ŝ_0ŝ_1ŝ_2` — degrees
0,1,…,7, no repeats, no gaps.

Distinct degrees ⟹ linearly independent ⟹ a basis of `F[x]_{<2^n}`, and it is
**degree-graded**:

```
span(X_0, …, X_{d−1})  =  { polynomials of degree < d }        for every d
```

(`⊆` by degree; `⊇` because the change of basis against `1, x, …, x^{d−1}` is
triangular with nonzero diagonal.)

> **This property is the whole ballgame.** Reed–Solomon is "degree `< k`". In the
> novel basis that reads `a_k = ⋯ = a_{N−1} = 0` — a coordinate condition, i.e.
> zero-padding. The monomial basis is degree-graded too but has no fast
> evaluation here; a basis of `ŝ_j`-products with arbitrary exponents would have
> fast evaluation but jumbled degrees. **The contribution is a basis that is
> degree-graded *and* transforms in O(N log N).**

Two smaller facts. The basis is **nested** — `X_i` is the same polynomial
whatever the ambient n — which is what makes truncation and the coset
decomposition coherent. And products are **carry-free**: `X_i·X_{i'} = X_{i⊕i'}`
when `i AND i' = 0`, but colliding bits produce `ŝ_j²`, which is not in the
basis. **So this basis is bad for polynomial multiplication** — and that is
exactly why the decoder of Part 3, at the one point where it needs a product of
many linear factors, does not compute it as a polynomial at all.

## 2.6 The butterfly

**Input** novel-basis coefficients `a_0..a_{N−1}` of `f = Σ a_i X_i`.
**Output** the values of `f` on a coset `ω ⊕ V_n`, index t ↦ point `ω ⊕ φ(t)`.

Split on the **low** bit. For even i, `X_i` has no `ŝ_0` factor and
`X_{i+1} = ŝ_0·X_i`, so

```
f(x)  =  g_0(x)  ⊕  ŝ_0(x)·g_1(x),   g_0 = Σ_{i even} a_i X_i,  g_1 = Σ_{i even} a_{i+1} X_i
```

> **Lemma.** `g_0, g_1` are invariant under `x ↦ x ⊕ β_0`.

*Proof.* They involve only `ŝ_j` with `j ≥ 1`, and `β_0 ∈ V_1 ⊆ V_j`, so
`ŝ_j(β_0) = 0` and by additivity `ŝ_j(x ⊕ β_0) = ŝ_j(x)`. ∎

Everything is `β_0`-invariant except one `ŝ_0`, which flips by exactly 1. Writing
`X = g_0(x)`, `Y = g_1(x)`, `S = ŝ_0(x)` — legitimate because X, Y are the same at
both points:

```
f(x)        =  X ⊕ S·Y
f(x ⊕ β_0)  =  X ⊕ (S ⊕ 1)·Y  =  f(x) ⊕ Y
```

```
forward   (evaluate):     x ^= y·S ;  y ^= x
inverse   (interpolate):  y ^= x   ;  x ^= y·S
```

**As a matrix, and why the determinant matters:**

```
⎡ 1   S   ⎤                                    ⎡ S⊕1   S ⎤
⎢         ⎥   det = (S ⊕ 1) ⊕ S = 1     inv =  ⎢         ⎥
⎣ 1  S⊕1  ⎦                                    ⎣  1    1 ⎦
```

**Determinant 1, for every S, at every layer.** This is not decorative. The
classical inverse FFT ends with a division by N; here `N = 2^n = 0` in
characteristic 2, so a `1/N` normalization would be *impossible*. The additive
FFT is viable only because its butterflies are unimodular: the IFFT is the FFT's
layer walk reversed, same constants, same cost, no scaling pass anywhere.

**Why it must be the low bit.** Try the high bit at n = 2: `f = h_0 ⊕ ŝ_1·h_1`
with `h_0 = a_0 ⊕ a_1ŝ_0`. The crossing relation is fine, but

```
h_0(x ⊕ β_1) = h_0(x) ⊕ a_1·ŝ_0(β_1),      ŝ_0(β_1) = β_1/β_0 ≠ 0
```

so the subproblem is not shared and there is no butterfly. The asymmetry is
structural: `V_j` is spanned by the **low** basis vectors, so `ŝ_j` annihilates
the low ones and not the high ones. Peeling starts at the bottom of the flag —
which is why the inverse walk runs `dist = 1, 2, 4, …` and the forward walk runs
`…, 4, 2, 1`.

**No bit-reversal.** `g_0`'s coefficients live at even positions and its outputs
land at even positions, so the stride-2 sublattice is self-consistent. Natural
order in, natural order out, fully in place; there is no permutation pass
anywhere in this driver's transforms.

**Cost.** `(N/2)·log₂N` butterflies, each ≤1 multiply and 2 XORs. But the
operative currency is **shard passes**: a butterfly reads two shards and writes
two, so one layer streams the whole working set once — `log₂N` passes. That is
the memory picture behind `ISAL8_FFT_BLOCK` / `ISAL16_FFT_BLOCK` (two layers per
pass) and `ISAL8_FFT_BLOCK3` (three, over eight shards, needing AVX-512VL),
which cut `log₂N` passes to `/2` or `/3` **without changing a parity byte**.

## 2.7 The recursion, and one constant per block

> **Factorization lemma.** For `j ≥ 1`, `ŝ_j = ŝ'_{j−1} ∘ ŝ_1`, where `ŝ'` are the
> normalized vanishing polynomials for the basis `β'_i := ŝ_1(β_{i+1})`.

*Proof.* `ŝ_j` is additive and vanishes on `V_j ⊇ V_1 = ker ŝ_1`, so it factors
through the image; extend GF(2)-linearly. Additive maps are linearized
polynomials, and degrees multiply under composition, so the cofactor has degree
`2^{j−1}`. Its kernel contains `ŝ_1(V_j)`, of dimension `j−1`, matching that
degree, so it is that subspace's vanishing polynomial up to a scalar;
`ŝ_j(β_j) = 1` fixes it. ∎

Hence `X_{2i'}(x) = X'_{i'}(ŝ_1(x))`, so `g_0 = g'_0 ∘ ŝ_1` and `g_1 = g'_1 ∘ ŝ_1`
with `g'` novel-basis polynomials one dimension down, and

```
x ∈ ω ⊕ V_n   ⟹   ŝ_1(x) ∈ ŝ_1(ω) ⊕ ŝ_1(V_n)
```

a coset of an (n−1)-dimensional subspace. **Identical problem, dimension n−1**,
with `ŝ_1` performing the quotient. `T(n) = 2T(n−1) + 2^{n−1}` gives
`(N/2)·log₂N`.

**The constant at layer j is `ŝ_j(x)`.** The composite of the first j reduction
maps is `ŝ_j`, and at depth j the reduced problem's own "`ŝ_0`" is `y/ŝ_j(β_j) = y`
by (N). No normalization drift.

**One constant per block.** At layer j the pairs are `(i, i+2^j)`; a block is
`2^{j+1}` consecutive indices, whose x values differ by elements of `V_j`, on
which `ŝ_j` vanishes. One lookup, `2^j` butterflies. Layer 0 degenerates
correctly: `V_0 = {0}` kills nothing, so each butterfly gets its own constant.

**The table packing is elegant and worth seeing.** One entry per (layer, block):

```
layer j, block starting at r  →  skew[ r + 2^j − 1 ]
```

r contributes only bits `≥ j+1`, and `2^j − 1` sets bits `0…j−1`, so **the index
has exactly j trailing ones**. Every integer has a unique trailing-ones count, so
this is a perfect packing of all layers into one flat array of size `2^n − 1`.
`fft_skew_init` (GF(2¹⁶)) and `fft8_skew_init` (GF(2⁸)) build it; the base case is
visible as the `skew[(1 << m) - 1] = 0` line, i.e. `ŝ_m(0) = 0`.

## 2.8 Three consequences that surface as knobs and cliffs

**(a) Skew zero ⇒ no multiply.** `ŝ_j(φ(r)) = 0 ⟺ φ(r) ∈ V_j ⟺ r < 2^j`. But r is
a multiple of `2^{j+1}`, so **exactly one block per layer** qualifies — and the
free blocks are the big ones. Layer `n−1` is one block and it is entirely free;
layer `n−2` is half free; layer j is `2^{j+1}/N` free.

```
free butterflies = Σ_{j<n} 2^j = N − 1   of   (N/2)·log₂N       ⟹   ≈ 2/log₂N
```

In the code this is a "log of zero" sentinel dropping the butterfly to a bare
XOR. **Coset transforms get none of it**: if `ω ∉ V_n` then `ŝ_j(ω ⊕ φ(r)) = 0`
would need `ω ∈ V_n`.

**(b) Cosets, and one table for all of them.** Evaluating on `ω ⊕ V_n` changes
only the constants. And the §2.7 packing is exactly self-consistent under the
shift: with `ω = φ(pos)` and `pos` a multiple of `chunk`, no carry means
`pos + r = pos XOR r`, so `skew[r + 2^j − 1 + pos]` decodes as "layer j, block
pos+r" — precisely `ŝ_j(ω ⊕ φ(r))`. **One flat table serves every layer of every
coset**, with one additive offset. Hence the encode shape: IFFT the data block,
then FFT onto coset after coset, `ncos = ⌈m/chunk⌉` of them.

**(c) Truncation, and the `f = 2ⁿ+1` cliff.** The truncation bound skips whole
subtrees when top coefficients are known zero or top outputs unwanted. Its
sharpest visible consequence is not the truncation but the **width** a decoder is
sized to. `grid.py`'s `rs_rate_and_work` mirrors `reed-solomon-simd`'s own
sizing, with `o = k`, `r = 2f`:

```
work = npo2( npo2(2f) + k )        (high rate)
```

| | `f = 2^n` | `f = 2^n + 1` |
|---|---|---|
| `npo2(2f)` | `2^{n+1}` | **`2^{n+2}`** ← doubles |
| `work` | `2^{n+2}` | `2^{n+3}` |
| `work / T` | ≈ 1.33 | ≈ 2.67 |

A doubling of transform width shows up as a doubling of decode time for a
one-unit change in f. **This is why the grid samples `2ʲ−1, 2ʲ, 2ʲ+1` triples**,
and why any conclusion about `reed-solomon-simd` drawn from a power-of-two-only
grid overstates it — powers of two are the *floor* of the staircase.

> Two things that both look like "padding" should be kept apart. §1.5(ii)'s
> zero-padding to `chunk` decides **which code** is encoded and changes parity
> bytes. This cliff is **which width** a work buffer is sized to and changes only
> time. Same cause, `next_power_of_two`; different consequences.

## 2.9 The Cantor basis

Everything above holds for **any** GF(2)-basis. Cantor's is the one that makes
§2.4's recursion exact:

```
β_0 = 1,        β_i² ⊕ β_i = β_{i−1}
```

> **Claim.** With this basis `ŝ_{j+1} = ŝ_j² ⊕ ŝ_j`, so `ŝ_j = ℘^{∘j}`, the
> j-fold composite of `y ↦ y² ⊕ y`.

*Proof.* `ŝ_0(x) = x/β_0 = x`. Let `p = ŝ_j² ⊕ ŝ_j`. It is additive; vanishes on
`V_j` because `ŝ_j` does; and vanishes on `β_j ⊕ V_j`, where `ŝ_j = 1` and
`1² ⊕ 1 = 0`. So it vanishes on `V_{j+1}`, and `deg p = 2^{j+1} = |V_{j+1}|`, so
`p = s_{j+1}` up to a scalar. For normalization: `℘` sends `β_i ↦ β_{i−1}`, so
`ŝ_j(β_{j+1}) = ℘^{∘j}(β_{j+1}) = β_1`, and `β_1² ⊕ β_1 = β_0 = 1`. ∎

So the tower is Artin–Schreier with every constant equal to 1, and Cantor's
condition reads *"`β_i` is an `℘`-preimage of `β_{i−1}`"*.

**Existence.** `u² ⊕ u = c` is solvable iff `Tr(c) = 0`. `cantor_basis16` solves
the recursion as a 16×16 GF(2) system rather than hardcoding it, checks the
recursion before use, and errors out with *"no Cantor basis: trace obstruction"*
if the system is inconsistent. Cantor bases exist in `GF(2^{2^t})`; GF(2¹⁶)
qualifies.

**The practical payoff** is the skew table: with `ŝ_j` a fixed iterate, all 65535
constants come from one short recurrence, and a large share collapse to 0 or 1.

## 2.10 GF(2⁸) uses no Cantor basis, on purpose

In GF(2⁸) this driver identifies node i with field element i in the **standard**
basis. By §2.2 the subspace/coset structure is automatic, so the additive FFT
works verbatim and the skew table is 255 entries.

Here Cantor's recursion would be an *unwanted* convenience, for a Part 1 reason:
**relabelling the nodes would change the code.** Node i = element i is exactly the
convention of `gf_gen_cauchy1_matrix` — so §1.4's Cauchy decoder applies
unchanged — *and* of Firedancer's generator, which writes `svals[0,x] = GF(x)`.
Because both agree, `references/fd-point --digest` is an independent-implementation
oracle for RS–8's encoder. Give the convention up and you lose both.

**In GF(2⁸) the convenient indexing and the required structure coincide.** In
GF(2¹⁶) they do not, which is why `ISAL16_NODES=cantor` selects a *different node
set* and is classified as a knob that changes the code.

## 2.11 What the transform buys

For a block of `N = 2^n` nodes:

```
IFFT :  values on a coset        →  novel-basis coefficients    O(N log N)
FFT  :  novel-basis coefficients →  values on a coset           O(N log N)
```

and "degree `< d`" is "coefficients `d…N−1` are zero". A systematic encoder is
then **IFFT the data block, FFT the coefficients onto each parity coset** —
`O((k+m)·log)` against the matrix encoder's `O(k·m)`. That is why all four codecs
encode with a transform, **including the two that decode with a matrix**.

Worth saying plainly: **monomial coefficients never appear anywhere.** There is
no fast route between the monomial basis and values here, and none is needed. A
message is either values or novel coefficients.

---

# Part 3 — `reed-solomon-simd`, in brief

A reference section, not a subject. The Leopard lineage: `catid/leopard` in C++,
`AndersTrier/reed-solomon-simd` in Rust, both implementing Lin–Chung–Han's
construction with Didier's locator. **This artifact ships the published crate,
stock 3.1.0**, and benchmarks it as an external reference. It is here because
three things about it explain features of the grid and of RS–16.

**Coordinates.** GF(2¹⁶) mod `0x1002D`, with the Cantor basis of §2.9. The `u16`
values in its shards are **φ-coordinates, not field elements**: its log table is
the discrete log of `φ(i)`, so the whole engine works in index space with φ baked
into the tables.

**Rate and chunking.** `chunk = next_pow2(recovery_count)`, with a high/low rate
chosen by comparing `npo2(k)` against `npo2(m)`; `grid.py`'s `rs_rate_and_work`
mirrors this so the harness can report the shape's work-buffer width as a key
column. §2.8(c) is the staircase that sizing produces, and **the RS decode column
is close to meaningless without `rs_work_over_T` beside it.**

**Decode: not matrix inversion in disguise.** The Lin–Chung–Han erasure decoder,
in three moves.

1. **Locator.** With `E` the erased positions and `ω_i = φ(i)`,
   `Λ(x) = Π_{i ∈ E}(x ⊕ ω_i)`.
2. **The trick that makes it linear.** Set `g = f·Λ`. At received positions
   `g(ω_i) = r_i·Λ(ω_i)` — computable; at erased positions `g(ω_i) = 0`, because
   Λ vanishes there. So g is known at **all** n points and
   `deg g ≤ (k−1) + |E| ≤ n−1`, hence determined. That is one IFFT.
3. **Recover where both vanish.** From `g = f·Λ`, `g′ = f′Λ + fΛ′`, and at an
   erased node Λ vanishes, so `f(ω_i) = g′(ω_i) / Λ′(ω_i)`. L'Hôpital by formal
   derivative, in characteristic 2 — a formal derivative, an FFT, and a scaling.

**The Walsh–Hadamard locator, and where the floor comes from.** Steps 2 and 3
need `Λ(ω_j)` at every j and `Λ′(ω_j)` at every erased j — products of `|E|`
terms over n positions. Take logarithms: `log Λ(ω_j) = Σ_{i∈E} log(ω_j ⊕ ω_i)`.
The index set is `(Z/2)^16` under XOR (§2.2), so this is an **XOR-convolution**,
which the Walsh–Hadamard transform diagonalizes. One transform computes both Λ
and Λ′ at once — the self-term is killed by forcing the transform's zero entry to
`log 1`, and `Λ′` at an erased node is exactly the product over the *other*
erased nodes.

That locator runs over the **whole field** regardless of f. Didier states the
property outright: the complexity does not depend on k or n, so one had better
use codes of length close to q. This project does the opposite — T is on the
order of 1% of the field — so the technique contributes a **fixed per-decode
floor** that no shard size and no code shape reduces. It is the published
behaviour of the technique, not an implementation defect, and it is also the
mechanism behind §1.8's crossover: a fixed cost amortizes to nothing as f grows,
while a matrix plan grows quadratically.

**A small pretty consequence of §2.9**, visible in `formal_derivative` here:
in the novel basis with the Cantor normalization, `℘′ = 1` gives `ŝ_j′ = 1` for
every j, so the formal derivative is **pure XOR, no multiplies**. You would never
guess it from the loop.

---

# Part 4 — RS–16

## 4.1 What it is

`codec/rs_point.c --field 16`: GF(2¹⁶), **additive-FFT encode** on the Cantor
node set, **Cauchy matrix decode** — with a transform decoder also available and
better above f ≈ 220. It exists because §1.8's two halves have opposite
preferences, and §1.7 says taking the fast half of each costs O(k) per decode.

Its recommended configuration is the compiled default; `DEFAULTS.md` states it
knob by knob.

**Where this came from, and how far it moved.** It **began** as a port of
`reed-solomon-simd`'s low-rate encoder and `LowRateDecoder`: the layer walk, the
skew recurrence and the leftover-layer peeling follow upstream's organisation,
and the attribution in `LICENSE` reflects that lineage. **It did not stay a
translation of it.** What differs is not incidental:

* **The field is a tower** (§4.2), `GF(2⁸)[z]/(z² + z + 0x20)`, where upstream
  works over GF(2¹⁶) through exp/log tables. That changes the arithmetic at
  every level and is the whole reason GFNI applies.
* **The kernels are this project's.** `reed-solomon-simd` 3.1.0 ships
  `engine_avx2`, `engine_ssse3`, `engine_neon`, `engine_nosimd` and
  `engine_naive` — no assembly, and no occurrence of `gfni`, `avx512`, `_mm512`
  or `vgf2p8` anywhere. `codec/fft_kernels.S` and the GFNI paths are ours.
* **The default decoder is a Cauchy matrix decoder**, which upstream has no
  counterpart to; the transform decoder is the secondary path, better only
  above *f* ≈ 220.
* **The shard layout** (§4.5) is ours.

> Upstream has attempted AVX-512 twice — `AndersTrier/reed-solomon-simd` PRs #32
> (Apr 2024) and #42 (Aug 2024), both open, both draft, neither merged, **neither
> using GFNI**. The author's note on #32 is worth recording because it is an
> independent measurement of something this project also sees: *"Throughput with
> AVX512 on AMD Ryzen 7 PRO 7840U is about the same as the AVX2 engine. I'll have
> a look at GFNI instead."* A 7840U is Zen 4, the same microarchitecture measured
> here. So the GFNI approach is **not** something upstream evaluated and
> rejected. `reed-solomon-simd` 3.1.0 ships
`engine_avx2`, `engine_ssse3`, `engine_neon`, `engine_nosimd` and
`engine_naive`, no assembly at all, and contains no occurrence of `gfni`,
`avx512`, `_mm512` or `vgf2p8`. `codec/fft_kernels.S` and the GFNI paths in
`codec/rs_point.c` are this project's, and the tower construction of §4.2 — which
is what makes GF(2¹⁶) multiplication a `vgf2p8affineqb` sequence — is the reason
they exist.

## 4.2 The field is a tower

```
GF(2¹⁶) = GF(2⁸)[z]/(z² + z + 0x20)       over GF(2⁸) mod 0x11d
```

rather than a degree-16 polynomial basis. Multiplication by `g = g₀ + g₁z` is
then a 2×2 block of GF(2⁸) operations, which on GFNI is four 8×8 GF(2) affine
matrices — **exactly what `vgf2p8affineqb` consumes**. That is the whole reason
for the tower: it makes GF(2¹⁶) multiplication a GF(2⁸) instruction sequence.

`z² + z + 0x20` is irreducible precisely because no `x ∈ GF(2⁸)` has
`x² + x = 0x20`, and `field_selftest` asserts it at every run.

Karatsuba applies to the 2×2 block — three products instead of four — and
`ISAL16_KARATSUBA=0` restores the dense expansion as a byte-identity oracle.

## 4.3 Why the transform encoder emits the *pure Cauchy* code

This is the prettiest identity in the codebase, and a direct consequence of
§2.3's corollary.

**Notation in this section only:** `x_i = φ(i)` are the source nodes and
`y_j = φ(chunk + j)` the parity nodes. That is the paper's convention, and the
reverse of the letters in §1. `c_t` is the per-coset scalar, which the paper
writes γ_t; the paper's own `c_t` is a coset *representative*.

The transform computes the *evaluation* code on nodes `φ(0…chunk−1)` and the
cosets above. By §1.3 that is `G[j][i] = A_j / ((y_j ⊕ x_i)·W_i)`. Now:

* **`W` collapses.** `W_i = Π_{l≠i}(x_i ⊕ x_l)` where `{x_l} = φ(0…chunk−1)` is a
  **subspace**. As l varies, `x_i ⊕ x_l` runs over every nonzero element of that
  subspace — so `W_i = Π_{v ≠ 0} v`, **the same for every i**.
* **`A` is constant on cosets.** `A_j = Π_{l<chunk}(y_j ⊕ x_l) = s_chunk(y_j)` is
  a **subspace vanishing polynomial**, hence by §2.3 constant on each coset of
  the subspace.

So the evaluation code equals the pure Cauchy code scaled by **one scalar per
coset**, `c_t = A_t / W`. The encoder divides `c_t` out as it copies, and what
leaves the function is **the code the matrix encoder produces**,
`1/(y_j ⊕ x_i)`. It is byte-for-byte identical under `ISAL16_ENC_LAYOUT=plane`,
the only layout the matrix encoder writes. Under the default `inter` layout it
is the same code, with its bytes in a different order.

Under the Cantor basis `W = 1`, `c_1 = 1` and `c_2 = β_1`. So the first
recovery coset leaves the transform unscaled and only the second is divided.

Three consequences, all load-bearing:

* The decode plan is untouched and **cannot tell which encoder ran**.
* `check.sh` uses that byte-identity, under the plane layout, as a standing
  assertion. It is the only strong check available above T = 256, where no
  cross-library digest exists (`LIMITS.md` §6).
* **The transform decoder is the one consumer that wants the raw evaluations**,
  because the decoder it was ported from reads received symbols as values of
  the interpolation polynomial. So `fft16_decode` multiplies each received
  parity shard of coset t by `c_t`, folded into the same multiply as its
  locator value, and that costs nothing extra. Leaving the factor out still
  decodes correctly whenever no second-coset parity shard is received, which
  is why it needs saying rather than a single-shape test.

`fft_coset_init` **computes** `c_t` rather than hardcoding it, and checks it
against what the normalization predicts.

## 4.4 Two decoders, and a crossover that is a property of the codec

`DEFAULTS.md` states flatly that `ISAL16_DECODE` has no single optimal value, and
that this is a property of the codec rather than a gap in the measurement. §1.8
is the reason: the matrix decoder's work is O(k·r) in the number of shards
actually rebuilt, the transform decoder's is O(n log n) in a width independent of
r, and two different functions of the shape must cross. Here they cross twice —
once near f ≈ 220, and again inside the `f = 2ʲ+1` class where §2.8(c)'s width
staircase steps.

The benchmark keeps **two labels** so both nulls stay reachable and the crossover
stays visible. A production implementation would carry one entry point with a
tuned crossover inside; that is a different exercise, and `rs_point.c`
deliberately implements no dispatch.

**Both decoders consume the same emitted codewords**, so the choice is private to
the receiver — unlike `ISAL16_ENC_LAYOUT`, which changes the emitted bytes and
must be agreed in advance.

## 4.5 Layout

`ISAL16_ENC_LAYOUT` and `ISAL16_DEC_LAYOUT` choose between `plane` — a shard's
low bytes, then its high bytes — and `inter`, where each 64-byte chunk is
lo32|hi32.

**This is not algebra.** It is which of two equivalent memory arrangements the
kernels see. Two things make it worth knowing anyway:

* Upstream splits lo/hi *inside each 64-byte chunk* while a plane layout keeps
  whole planes, because the ISA-L matrix decode needs contiguous planes. Under
  `inter` a butterfly touches one memory stream per shard instead of two.
* **`ENC_LAYOUT` changes the parity bytes** — same code over a different element
  ordering, not a different code, and decode still returns the source exactly.
  `DEC_LAYOUT` changes nothing but the decoder's own work buffer.

The reason the tower ships `ISAL16_FFT_BLOCK3` **off** while GF(2⁸) ships it on
is exactly this: three layers is eight shards, and in a two-stream layout that is
sixteen memory streams, past the optimum. In GF(2⁸) a shard is one stream, so
eight shards is eight.

---

# Part 5 — Firedancer and RS–8

## 5.1 Firedancer's `reedsol`

`firedancer-io/firedancer`, `src/ballet/reedsol`, pinned. An independent
additive-FFT Reed–Solomon over GF(2⁸) — the same construction — generated and
fully unrolled per size, with SSSE3, AVX2 and GFNI arithmetic backends selected
by `FD_REEDSOL_ARITH_IMPL`.

> **Their GFNI path is 256-bit.** `FD_HAS_AVX512` gates it (`#if FD_HAS_GFNI &&
> FD_HAS_AVX512` selects impl 3) but the code operates on `ymm`: `zmm` does not
> occur anywhere in their reedsol tree. This project's GF(2⁸) GFNI kernels are
> 512-bit — `fft8_b2_z` is built `target("avx512f,avx512bw,avx512vl,gfni")` —
> and are a hand-written two-layer butterfly block over four shards rather than
> generated per-size code. **Same field, same instruction family, independently
> arrived at**, and the register width is the cheapest way to see that they are
> not derivations of each other. (Which is wider is not the same as which is
> faster: `ISAL8_FFT_W=512` measures as a wash here, `KNOBS.md`.)

Three things matter here:

* **It reaches only f ≤ 33 as shipped**, at this rate: its data and parity shred
  ceilings are 67 each, and `m = 2f` binds first. Upstream's own comment calls
  these *"limits based on current Solana needs and performance"*, not
  mathematical limits, so `references/bootstrap-fdgen.sh` regenerates them for
  the whole T ≤ 256 region. `regen.sh` refuses to write unless the generators
  reproduce upstream's shipped files byte for byte at the unraised parameters.
* **Its erasure locator is a Walsh–Hadamard transform one field down** —
  Didier's technique over `Z/255`, arrived at independently of the GF(2¹⁶) side.
* **Its interpolation strategy is the principal pivot transform** with every
  coordinate above k pivoted: `kp = k` in the notation below.

**Where Firedancer is faster, stated plainly.** At their own operating shape —
k = m = 32, roughly 1 KiB shreds — their encoder is ahead of RS–8. Two causes, in
order. It **never materialises a work buffer**: its generated code streams bytes
of every shred through registers, where RS–8 copies k shards into a work buffer,
and at m = 32 there is only one coset to amortize that copy over. And its
**per-layer kernel quality** is higher: straight-line code with constants
immediate against generic skew-table loops with runtime dispatch. Matching that
means a code generator, which is a project rather than a patch, and is not
attempted here. `LIMITS.md` §4.

**Why their decoder is not adopted.** §1.8, applied: a transform decoder's cost
is Θ(N log N) in `next_pow2` of the **span** of the survivor set; a matrix
decoder's is Θ(r·k) in the **count** of erased data shards, and is position-blind.
The transform wins only when r is large **and** the span is small — and that
crossover sits far beyond anything GF(2⁸) can express. Within RS–8's whole
reachable region the matrix decoder wins.

That is not a defect in their design. Their recovery path fires as soon as half
the shreds arrive and, because parity cannot exist before the data it is computed
from, the common case has **every data shred present** — so their hot path is not
a reconstruction at all but a re-encode of the missing parity plus a consistency
check. A transform is the right tool for that. It is a different job.

## 5.2 RS–8: the pivot base as a free parameter

Let `chunk = next_pow2(k)`. Choose a **pivot base** `kp` with `k ≤ kp ≤ chunk`.
Interpolate the degree-`<kp` polynomial through

* the k data values at nodes `0 … k−1`, and
* **zeros** at nodes `k … kp−1`,

then evaluate at `kp … kp+m−1`. Data shard j sits at node j; parity shard i at
node `kp + i`.

**It is a GRS code, with an explicit multiplier.** With
`Z(x) = Π_{l=k}^{kp−1}(x ⊕ l)`, the interpolant vanishes at `k…kp−1`, so it
factors as `Q = Z·g` with `deg g < k`. Then `data_j = Z(j)·g(j)` and
`parity_i = Z(kp+i)·g(kp+i)`, and eliminating g gives

> **G[i][j] = ( Z(kp+i) / Z(j) ) · L_j(kp+i)**,  `L` the Lagrange basis over the
> ***k* data nodes only**.

Equivalently, in the form the decoder wants, with `A_i = Π_{l<kp}((kp+i) ⊕ l)`
and `W_j = Π_{l<kp, l≠j}(j ⊕ l)`:

> **G = diag(A) · C · diag(1/W)**,  `C[i][j] = 1 / ((kp+i) ⊕ j)`

— a Cauchy matrix between two known diagonals, which is §1.7 and the whole reason
the existing decoder applies.

**Every `kp` gives an MDS GRS code** on `{0…k−1} ∪ {kp…kp+m−1}`; all have
identical decode cost; **they produce different parity bytes**. `kp = k` gives
`Z ≡ 1`.

`proofs/pivot_check.py` re-derives all three claims from scratch, sharing no code
with the driver: the GRS identity, MDS by inverting random survivor submatrices,
and the decoder's diagonals against a Gaussian-elimination inverse.

## 5.3 The two endpoints, and why neither is best

| `kp` | name | parity nodes | glue | node cost |
|---|---|---|---|---|
| `k` | principal pivot transform (PPT) | start at k | most | none |
| `chunk` | zero-padded / shortened | start at `chunk` | **none** | burns `chunk − k` nodes on zeros |

Padding is free of glue but spends `chunk − k` evaluation points on zeros, so it
needs `chunk + m ≤ 256` and cannot express the upper half of this grid's GF(2⁸)
range. PPT spends no points but pivots every coordinate above k, and its glue
dominates at high f. **A partial pivot trades the two continuously.**

**Reach.** Parity occupies `kp … kp+m−1`, so the budget is exactly
`kp ≤ 256 − m`. With `kp ≥ k` that is feasible **iff T = k + m ≤ 256** — the
entire region GF(2⁸) can host, with no further relation between k and T. Padding
alone carries a stronger condition.

**The two existing implementations sit at opposite endpoints of this parameter,
and neither exposes it:**

| codec | strategy when k is not a power of two | in these terms |
|---|---|---|
| `reed-solomon-simd` | zero-pad to the next power of two | `kp = chunk` |
| Firedancer `reedsol` | principal pivot transform | `kp = k` |
| **RS–8** | **the maximum the node budget allows** | **`kp = min(chunk, 256 − m)`** |

Neither is leaving anything obvious on the table from its own vantage: GF(2¹⁶) is
wide enough that padding rarely costs reach, and Firedancer's shapes are small
enough that the glue rarely dominates.

## 5.4 `auto`: the maximum feasible base, by rule

`fft8_pick_kp` takes

> **`kp = min(chunk, 256 − m)`**

— the most padding the node budget allows. Pure arithmetic: no constants, no
kernel knowledge, no search. §5.3's budget is the only constraint, and there is
nothing above `chunk` to pivot, so this is simply its top.

**This replaced a cost model, and the replacement was measured rather than
preferred.** The model scored every feasible `kp` in shard touches and took the
cheapest, on the argument that maximising `kp` minimises glue but can force an
extra coset. Scored against the best base at each of 82 shapes, the rule beat the
model where the padding fits and was level with it where the node budget binds.
`fft8_plan_cost` is deleted.

**The parameter has two regimes and they have different answers.**

*Regime 1 — the padding fits, `min(chunk, 256−m) == chunk`.* The maximum base is
optimal, and that was confirmed on **every kernel class measured**: three-layer
AVX-512VL, two-layer, unblocked, and pure scalar. No architecture dependence
remains in it. This is where the cost model was losing, by declining a free win.

*Regime 2 — the node budget binds, `min(chunk, 256−m) < chunk`.* **No
constant-free rule can settle this one**, and the reason is a work count rather
than a timing: lowering `kp` genuinely removes transform butterflies and
genuinely adds glue passes. Which you prefer is the machine's
compute-to-bandwidth ratio. A floor was measured for *any* such rule, and the
shipped rule sits at it — the two rules are level here. **The honest statement is
that this artifact does not attempt to beat that floor**, because doing so means
a machine-tied choice, and that would forfeit the argument below.

> **A chooser that reads no constants cannot be made to read a kernel knob.**
> `ISAL8_INTERP` selects a *code*, so its value may depend on (k, m) and nothing
> else — least of all on a kernel knob, which by contract cannot change parity
> bytes. An early cost model weighted transform passes using `ISAL8_FFT_BLOCK3`,
> which made the encoder emit different parity under it; the matrix oracle caught
> it within one run. **The rule removes that hazard class at the root rather than
> guarding against it.** `check.sh` keeps the invariant anyway — `auto` must not
> move under any of six kernel knobs — because what it now guards against is the
> chooser regrowing one. It also restores two stronger assertions the cost model
> had made untestable: `auto` is `ppt` exactly when `min(chunk, 256−m) == k`, and
> `pad` exactly when it equals `chunk`.

**What a matrix tail cannot do.** A tail changes how a parity shard is
*computed*, not which node it sits at, so it does not move the node budget. It is
not a substitute for trading pivots against nodes.

## 5.5 Why the decoder does not change

§1.7, applied. Write `xs` for the received parity nodes, `ys` for the missing data
nodes, `us` for the received data nodes. `diag(A)` cancels in the received-source
block because `B` and `E` share their rows; what remains folds into three scalar
vectors the closed form already materialises — one multiply each — and `W`, `A`
and their inverses are functions of (k, m) alone and are hoisted to process
setup.

**The r × k apply is unchanged in shape, in coefficient count and in kernel.**
The only per-decode difference is that a shard index becomes a field element
through one function (`node_of`), because parity shard `k+i` sits at node `kp+i`.

Measured across the GF(2⁸) grid, RS–8's decode against the pure-Cauchy codec's is
a wash. **The node relabelling is free, which is the premise the whole
construction rests on.**

## 5.6 The encoder pipeline

For a chosen `kp`, with `direct = chunk − kp` and `ncos = ⌈(m − direct)/chunk⌉`
(`fft8_encode`):

1. **Copy in, fused.** The k source shards are read straight into the first
   butterfly layer, which writes the work buffer; slots `k … kp−1` read a
   permanently-zero shard. The work buffer **is** the first coset's destination,
   so its outputs are never moved. (`ISAL8_FUSE`; only on the plain-IFFT path —
   under a partial pivot the first thing to touch the buffer is a pivot op, not a
   butterfly.)
2. **Interpolate.** A plain truncated inverse walk when `kp = chunk`; otherwise
   the pivot op list from `ppt_build`, whose sub-blocks and 2×2 pivots are
   emitted **once per process**, not per message.
3. **Extract** the `direct` parity shards the interpolation block yields, and
   **fuse** each later coset's coefficient copy with its own first forward pass.
   Both must happen before the first coset's walk destroys the coefficients.
   (`ISAL8_COSET_FUSE`.)
4. **Evaluate** one forward walk per coset, at skew offset `t·chunk`, truncated
   to the parity that coset owes.

Each fusion in that list removes a pass over the message that the following pass
immediately re-read, and each has a reachable null — `DEFAULTS.md`. None changes
a parity byte, and `check.sh` asserts that at 32 shapes × 3 pivot bases × 11
kernel variants.

## 5.7 What makes it checkable

The oracle is **the matrix encoder over the same node set** — `gen_entry` plus
ISA-L's `ec_encode_data`, an independent implementation *inside* this tree — and
it applies at every pivot base. `references/fd-point --digest` is a second,
cross-library oracle, but only at `kp = k`, since no other pivot base computes
Firedancer's code.

`HARNESS.md` §7 lists what `check.sh` carries. The argument for this apparatus is
empirical: three defects in this construction were caught by it and by nothing
else — a table read before initialisation on an *unrelated* code path, an offset
correct at both endpoints and wrong at every interior pivot, and the
kernel-dependent code choice of §5.4. **All three passed every targeted test
written for them.**

## 5.8 An open question this algebra raises

The pivot trade of §5.4 is **pure index arithmetic**: with `ρ = m mod chunk`, a
pivot removes one coset iff `ρ ≤ chunk − k`, and the cheapest such pivot is
`kp = chunk − ρ`. No field appears in that derivation, so **it transfers to RS–16
unchanged** — where it would apply at shapes GF(2⁸) cannot reach at all.

It also has a consequence GF(2⁸) cannot see, because GF(2⁸) has no transform
decoder: the coset-saving pivot forces `kp + m = 2·chunk` exactly, so the
transform decoder's width `npo2(kp+m)` halves against padding's.

And it has a cost: **§4.3's byte-identity coincidence dies**, because both
collapses there need the data node set to be a subspace, i.e. `kp` a power of
two. That would remove RS–16's strongest standing oracle.

That is a proposal, not a result, and nothing in this artifact implements it.

---

# Part 6 — Attribution

Most of the algebra in Parts 2–5 is other people's.

## 6.1 The mathematics

| | |
|---|---|
| **Lin–Chung–Han 2014** (arXiv:1404.3458) | the novel polynomial basis and its additive FFT — the whole of Part 2. §V is Part 3's decoder |
| **Didier 2009** (arXiv:0901.1886) | the Walsh–Hadamard erasure locator of Part 3. Short, open access, and the idea most likely to be mis-attributed to the Leopard lineage |
| **Gao–Mateer 2010** | the additive FFT as such, if Part 2's derivation leaves you wanting the general treatment |
| **Lin–Alloum–Al-Naffouri 2017** | the principal pivot transform for an arbitrary pivot set — the whole of §5.2's machinery |
| **Tang–Lin 2020**, IEEE Comm. Letters **24**(4) 716–719 | **the closest prior work, and the one that most narrows §6.2.** Their `partialFFT(u, y, t, s, β)` takes a prefix pivot of size `s`, and `s` is **structurally the same object as this project's `kp`** — derived from their construction rather than swept, but the object is theirs as much as ours. They solve arbitrary *n* by puncturing a full-field code, sizing their transform by the PARITY count where `chunk` here is sized by *k*. Found by a forward-citation check on the 2017 paper, which has exactly one citing paper: this one |
| **Cantor** | the basis of §2.9 |
| **Schechter** | the closed-form Cauchy inverse of §1.4(c) |

## 6.2 What this project claims as its own

The transform is Lin–Chung–Han's; the prefix pivot set is
Lin–Alloum–Al-Naffouri's. What is this project's is:

1. **The FREEDOM in `kp`, not the pivot itself** (§5.2). The prefix pivot is
   Lin–Alloum–Al-Naffouri's and appears in Tang–Lin too, where their `s` is the
   same object. **What is left after reading them** is leaving its length free
   over `[k, min(chunk, 256 − m)]`, the node budget that gives that reachable
   region, and the measured optimum. **This claim has been narrowed once
   already**, by the forward-citation check that found Tang–Lin; treat it as
   narrow.

   > **Tang–Lin has not been benchmarked here.** At *f* = 100 their
   > `T = next_pow2(200) = 256` and their encode is one size-256 IFFT, one FFT
   > and one `partialFFT` — plausibly competitive on this grid, and **nothing
   > here has run it.** Their own conclusion cuts the other way for these
   > shapes: the decoder *"is somewhat complicated for RS codes whose parity
   > symbols are few."*
2. **The transform-encode / Cauchy-matrix-decode pairing with O(k) diagonals**
   (§1.7, §4.3).
3. **The truncatable-head / all-ones-tail split of the locator** — an improvement
   on the published algorithm that halves its transform work.
4. **RS–8 itself**, and the measurement model of §1.6 — a fresh erasure pattern
   per trial, which is what makes setup cost visible at all.

`LIMITS.md` §4 states what is *not* claimed, including that the literature was
not exhaustively searched.

## 6.3 Software

| | project | how it is used here |
|---|---|---|
| ISA-L 2.31.1 | `intel/isa-l`, BSD-3-Clause | GF(2⁸) kernels and `gf_gen_cauchy1_matrix`; **patched** — `isal-patches/` |
| `reed-solomon-simd` 3.1.0 | `AndersTrier/reed-solomon-simd` | benchmarked stock from crates.io; RS–16's encoder is a port of its low-rate encoder onto a different field |
| Leopard-RS | `catid/leopard`, BSD-3-Clause | the ancestor of the skew and locator code both GF(2¹⁶) codecs inherit. Not shipped |
| Firedancer `reedsol` | `firedancer-io/firedancer`, Apache-2.0 | pinned, regenerated for reach only — `references/` |
| `monad-raptor` | `category-labs/monad-bft`, **GPL-3.0** | R10. Vendored verbatim under its own LICENSE |
| `raptorq` 2.0.1 | `cberner/raptorq` | RaptorQ, from crates.io |

`MANIFEST.md` carries the full provenance, including pinned commits.
