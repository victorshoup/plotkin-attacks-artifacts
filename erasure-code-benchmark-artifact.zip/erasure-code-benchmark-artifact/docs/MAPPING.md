# Paper claim → code

Where each object in the paper's two appendices is implemented, and what the
paper's names correspond to in the source and in the CSVs.

**Function names, not line numbers.** This file addresses code by function and
by file. Line numbers drift the first time anyone edits, and this artifact is
meant to be edited — re-measuring on your own hardware is the point. Where a
line number appears it is a hint, not an address.

**Notation.** The paper writes `K` for the number of source symbols and `n` for
the codeword length. The harness, the CSVs and the C driver write `k` and `T`
for the same two quantities. `f` and the symbol/shard size mean the same thing
everywhere. `m = n − K` is the parity count.

---

## 1. The two appendices

| paper | what it needs from this artifact |
|---|---|
| `app:benchmarks` — Implementation and performance evaluation | the whole harness: `benchmark.sh`, `robust_benchmark.py`, `grid.py`, all four codecs |
| `app:rs-algebra` — Reed–Solomon constructions and decoding algorithms | `codec/rs_point.c`, and `proofs/`, which re-derives the same results sharing no code with the driver |

The main paper's attack results are **out of scope** and their implementation is
not in this repository.

## 2. Implementations

| paper name | harness label(s) | implementation |
|---|---|---|
| R10 | `r10` | `monad-raptor/` (vendored, GPL-3.0), driven by `run_r10` in `src/main.rs` |
| RaptorQ | `rq` | `raptorq` 2.0.1 from crates.io, driven by `run_rq` |
| **RS–8** | `isal_x` (encode and decode) | `codec/rs_point.c --field 8`, `ISAL8_NODES=eval ISAL8_ENCODE=fft` |
| **RS–16** | `isal_x16_imat`, `isal_x16_inter` | `codec/rs_point.c --field 16`, `ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_ENC_LAYOUT=inter` |
| Firedancer reference | `fd_reedsol` | `references/fd_point.c` over `references/fdrs/`, ceilings raised |
| `reed-solomon-simd` reference | `rs` | stock 3.1.0 from crates.io, driven by `run_rs` |

Three labels in `ALL_LABELS` are **nulls** rather than paper codecs, and exist so
that a claim about a change can be measured against the configuration it
replaced: `isal_cauchy` (the pure Cauchy GF(2⁸) code with the matrix encoder),
`isal_ge` (stock ISA-L Gaussian elimination in place of the closed-form plan),
and `isal_cauchy16` (GF(2¹⁶) in its historical linear-node matrix-encoder
configuration). `isal_cauchy` runs in the default label set anyway, because
emission order inside a point is load-bearing — see `HARNESS.md` §4.

**`isal_x_dec` is an instrument, not a deployment configuration.** It is the same
code as RS–8 — same nodes, same pivot base, same plan, same rows — encoded by the
matrix encoder. It existed so that RS–8's decode column would not be measured
behind its own transform encoder's work buffer in the interleaved loop. Since the
grid is measured in phase-isolated legs, no encoder runs inside a decode timer,
and **the paper takes RS–8's decode from `isal_x` itself**. The two agree, and
their agreement is the check that the isolation worked. An earlier version of
the paper took RS–8's decode from a control leg; the current one does not.
`isal_x_dec` still supplies the RS–8 figure of the all-parity stress test in
`results/paper-data/`, which is a decode-only leg.

## 3. Tables

> **READ THIS BEFORE THE TABLE. The grid figures come from PHASE-ISOLATED LEGS,
> not from a plain `./benchmark.sh` run.** `./phase_campaign_leg.sh` runs the
> grid three times — `both`, `encode`, `decode` — and **encode figures are read
> from the encode leg and decode figures from the decode leg.** The interleaved
> `both` leg is the null; it appears only as a delta and **will not reproduce a
> paper number.** The two differ because each timer is contaminated by the other
> operation's cache footprint, and the deltas do not point one way.
>
> This table said `./benchmark.sh` until 6 September 2026, which was wrong and
> could not be reached by anyone following it: `BENCH_PHASE` was dropped when
> this extract was first assembled and only restored on 6 September. If you are
> reading a reference CSV whose name has no `-encode`/`-decode` tag, it is a
> `both` leg.

**Two data columns, and they are not interchangeable.** *The paper's data* is
the set of files the table was computed from, shipped byte-identical in
`results/paper-data/`. `python3 results/paper-data/reproduce_tables.py`
recomputes the archived publication quantities from them and checks them
against the frozen expected outputs recorded in the script. *The
comparison baseline* is a later run of this artifact's own code, which
`compare.py` diffs a local run against. It agrees with the paper in shape, but a
second run of the same benchmark is not the same numbers: see
`results/README.md`. Until 11 September 2026 this table listed only the
baselines, under the heading "reference data", which read as though the paper
had been computed from them. It was not.

| paper table | produced by | the paper's data (`results/paper-data/`) | comparison baseline (`results/`) |
|---|---|---|---|
| `tab:performance` — selected absolute timings | `./phase_campaign_leg.sh`; **encode from the encode leg, decode from the decode leg** | `robust-summary-encode-20260831-155527.csv`, `robust-summary-decode-20260831-160228.csv` | `reference-grid-{encode,decode}.csv` |
| `tab:performance-ratios` — full-grid ratios | ditto | ditto | ditto |
| `tab:consumption` — received-symbol consumption | decode leg; the `{label}_consumed_*` columns | `robust-summary-decode-20260831-160228.csv` | `reference-grid-decode.csv` |
| `tab:large-f-decode` and the f = 257 / 513 figures — beyond the grid to f = 2047 | `./largef_sweep.py` — **a different protocol**, 15 trials per invocation, not the grid's 20 | `largef-decode-{1,4}mib-20260831-201046.csv` | `reference-largef-decode-{1,4}mib.csv` |
| `tab:throughput-floors` | encode and decode legs; `R_src = 8·K·B / t` | the two grid legs above | `reference-grid-{encode,decode}.csv` |
| Firedancer at K = m = 32 (prose) | a separate leg, not scripted in this artifact | `fd-native-20260831-201046.csv` | — |
| all-parity stress test (prose) | a separate decode-only leg, not scripted in this artifact | `arrivals-grid-20260907-100222.csv` | — |
| — | the interleaved null; nothing in the paper | `robust-summary-20260831-154312.csv` | `reference-grid.csv` |

**Labels differ between the two columns.** The paper's data come from the
development tree, where RS–16's matrix-decode label is `isal_cauchy16` and its
transform-decode label is `isal_cauchy16_fft`. In this artifact those are
`isal_x16_imat` and `isal_x16_inter`, and `isal_cauchy16` here names the
historical null. The configurations behind the labels are identical.
`results/paper-data/README.md` gives the full map.

## 4. The Reed–Solomon appendix (`app:rs-algebra`), subsection by subsection

| paper subsection | in the driver | independent re-derivation |
|---|---|---|
| `app:generalized-cauchy` — systematic evaluation RS as a generalized Cauchy code | `cauchy_entry`, `eval_entry`, `gen_entry` (`codec/rs_point.c`) | `proofs/pivot_check.py` |
| `app:subspace-shortening` — subspace nodes, shortening, pivoting | RS–8: `fft8_pick_kp`, `ppt_build`, `fft8_encode`. RS–16: `cantor_basis16`, `g16_nodes_init`, `fft_coset_init` | `proofs/pivot_check.py`, `proofs/ppt_theorem_check.py`, `proofs/fft_cauchy_check.py` |
| `app:identity-row-reduction` | the survivor bookkeeping in `run_gf8` / `run_gf16` | `proofs/standalone_cauchy_check.rs` (dependency-free; `rustc -O` it directly) |
| `app:closed-form-fold` | `cauchy_inverse`, `fold_closed_form8`, `fold_closed_form16` | `proofs/standalone_cauchy_check.rs` |
| `app:composite-field` — GF(2¹⁶) = GF(2⁸)[z]/(z²+z+0x20) | `field_selftest`, and the GF(2¹⁶) section of `rs_point.c` | asserted at every run by `field_selftest` |
| `app:additive-fft` | `fft8_skew_init` / `fft_skew_init`, `fft8_encode`, `fft16_encode`, `fft16_decode`, `cantor_basis16` | `proofs/fft_cauchy_check.py` |

`ALGORITHMS.md` is the prose companion to this row set: it explains what the
implementations do, which the paper's appendix justifies but does not describe.

## 5. `codec/rs_point.c`'s section map

One translation unit, ~6 200 lines, deliberately not split — `codec/README.md`
gives the reasoning. It is in four banner-delimited sections plus `main`:

| section | contents |
|---|---|
| **GF(2⁸)** | the systematic Cauchy generator (`cauchy_entry`), the evaluation-node generator (`eval_entry`), the switch between them (`gen_entry`), the closed-form Cauchy inverse (`cauchy_inverse`) and fold (`fold_closed_form8`), node mapping (`node_of`), and `run_gf8` |
| **GF(2¹⁶)** | the composite tower and its self-test (`field_selftest`), the Cantor basis solved as a 16×16 GF(2) system (`cantor_basis16`), the GF(2¹⁶) generator and plan (`fold_closed_form16`), and `run_gf16` |
| **the additive-FFT encoder** | the GF(2¹⁶) transform: skew tables (`fft_skew_init`), coset scalars (`fft_coset_init`), the encoder (`fft16_encode`), the transform decoder with its Walsh–Hadamard locator (`fwht`, `eval_poly_low`, `formal_derivative`, `fft16_decode`), and the matrix tail |
| **GF(2⁸) additive FFT with the principal pivot transform** | the pivot base chooser (`fft8_pick_kp`), the pivot op list (`ppt_build`), the transform encoder (`fft8_encode`), the fused coset walk (`fft8_fused_coset`) |
| **field selection** | `--field auto\|8\|16` dispatch, then `main` |

`codec/fft_kernels.S` holds the hand-written butterfly; it is reachable only
under `ISAL16_FFT_BLOCK3=1` and is **not** on any default path. `codec/KNOBS.md`
is the full knob reference; `DEFAULTS.md` in this directory is the shorter
statement of what is on by default and why.

## 6. Scope of this mapping

This file maps the publication's stable names, tables, and appendix objects
to the artifact. It does not track textual discrepancies between manuscript
drafts.

For RS–16, the emitted-code normalization is documented in
`ALGORITHMS.md` §4.3: `fft16_encode` applies the inverse per-coset scalar
before emission, and `fft16_decode` restores the scalar on received parity
symbols.

For the archived benchmark campaign,
`results/paper-data/reproduce_tables.py` checks the frozen derived outputs
against the shipped measurement files.

## 7. CSV columns

`results/README.md` describes the reference files. Two column names in the
detail CSV, `tape_field` and `tape_gen`, are **inert** and always emit `-`: they
name a codec this artifact does not ship, and are kept because
`codec/rs_point.c`, `references/fd_point.c` and `src/main.rs` emit one identical
15-column header. One format across three drivers beats two tidier names in one
of them. `LIMITS.md` records it.

Never read the summary CSV by column position. The column count is
`10 + 11·len(LABELS)` and `LABELS` depends on `BENCH_LABELS` and on which codecs
are available at a shape. `compare.py` matches by name from the header for
exactly this reason.

## 8. Citations to documents that are not in this artifact

Comments in `codec/rs_point.c`, `src/main.rs`, the harness scripts and
`codec/KNOBS.md` cite two kinds of document that **are not published with this
artifact**:

* **The project's internal working notes** — filenames of the form
  `PERF-NOTES-*.md`, `HANDOVER-*.md`, `ARCHITECTURE.md`, `SOURCES.txt`.
* **The project's internal status report** — cited as "report §1.9",
  "§4.5", "rev 22a §A1.1" and similar.

**They are deliberately not shipped**, and the citations are deliberately left
in. Each one records *which measurement licensed a line of code*: why a default
is what it is, why a knob exists, why a pass was fused. Stripping them would edit
measured source for cosmetic reasons and remove the audit trail that makes the
code checkable. What follows decodes them.

| cited as | what it covers | shipped equivalent |
|---|---|---|
| `PERF-NOTES-FFT-GF8-PPT.md` | the GF(2⁸) transform encoder, the pivot base, and every fusion | `ALGORITHMS.md` §5.2–§5.6, `DEFAULTS.md` |
| `PERF-NOTES-LARGE-F.md` | the GF(2¹⁶) transform beyond the grid: layouts, blocking, the assembly kernel, build flags | `DEFAULTS.md`, `LIMITS.md` §2 |
| `PERF-NOTES-PPT.md` | the principal pivot transform in both fields | `ALGORITHMS.md` §5.2–§5.3 |
| `PERF-NOTES-FFT-CAUCHY.md` | the structural result: an FFT-encodable code with the Cauchy matrix decode | `ALGORITHMS.md` §1.7, §4.3 |
| `PERF-NOTES-FFT-GF8.md`, `-FFT-GRID.md` | whether a transform encoder pays below T = 256, and on the full grid | `ALGORITHMS.md` §1.8 |
| `PERF-NOTES-GF16-KERNEL.md` | a negative result: the GF(2¹⁶) decode apply is at its arithmetic floor | `DEFAULTS.md`, `ISAL16_APPLY` |
| `PERF-NOTES-GF16-PIVOT-PROBE.md` | the GF(2¹⁶) pivot measured without implementing it | `ALGORITHMS.md` §5.8 |
| `PERF-NOTES-DECODE.md` | hardware-counter analysis of the GF(2⁸) decode gap | `HARNESS.md` §1 |
| `PERF-NOTES-ALLOCATOR.md` | the allocator contract, and why `warm` is the default | `HARNESS.md` §3 |
| `PERF-NOTES-STRIPING.md`, `STRIPING-DECISION.md` | striping measured on all three codecs | `HARNESS.md` §6 |
| `ARCHITECTURE.md` | the working tree's code map | `MAPPING.md` §5, `HARNESS.md` |
| `SOURCES.txt` | third-party provenance | `MANIFEST.md` |
| `HANDOVER-*.md` | session records | nothing; their durable content is in `docs/` |
| "report §x.y", "rev NN §x.y" | the internal status report | the paper's `app:benchmarks` and `app:rs-algebra` |

`check_links.py`, run by `check.sh`, enforces the distinction: a bare
filename with no directory component is a citation and is ignored; anything
with a path in it must resolve, and must not reach outside this directory.

**A citation is not a promise that the document is here.** If one of these names
is the only justification you can find for something, the shipped answer is in
the table's right-hand column, and if it is not, that is a gap worth reporting.

