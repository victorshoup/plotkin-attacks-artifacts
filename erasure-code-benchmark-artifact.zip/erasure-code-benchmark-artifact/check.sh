#!/bin/sh
# check.sh -- environment report and correctness of every codec across the grid,
# before any timing run. Paste its whole output back.
#
# The f grid and the T <= 256 boundary come from grid.py, so this script and
# robust_benchmark.py cannot disagree.
#
# EXTRACTED for the public artifact: tape-reed-solomon is not part of it, so the
# tape labels, the vendored crate's regression suite, and the cross-library
# parity oracle are gone. What replaced the last of those is stated at its old
# site. Relative paths are still the working tree's, so this stays runnable
# there. The C driver is in `codec/`; firedancer's is in `references/`.
set -eu

# ---------------------------------------------------------------- BASELINE
# The bare driver emits RS-8 in GF(2^8) and the recommended Cantor/transform
# code in GF(2^16). Several oracles below are about the MATRIX codes instead --
# the Cauchy generator with a linear node set -- because that is where the
# independent decode-plan and fold differentials live. This suite therefore
# states that baseline once, here, rather than at every call site.
#
# A command that wants something else sets it on its own invocation, which wins
# over an export. The section "COMPILED DEFAULTS" at the end unsets these and
# asserts the real defaults are what DEFAULTS.md says they are.
export ISAL8_NODES=cauchy ISAL8_ENCODE=matrix
export ISAL16_NODES=linear ISAL16_ENCODE=matrix ISAL16_DECODE=matrix
export ISAL16_ENC_LAYOUT=plane ISAL16_DEC_LAYOUT=plane ISAL16_FFT_TAIL=12
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
FS_ALL=$($PY -c 'import grid; print(" ".join(map(str, grid.FS)))')
FS_GF8=$($PY -c 'import grid; print(" ".join(map(str, grid.FS_LOW)))')
TARGETS=$($PY -c 'import grid; print(" ".join(str(b) for _, b in grid.TARGETS))')
SPOT_TARGET=1048576   # every f is checked at this size; GF(2^8) f at all sizes

echo "===== ENVIRONMENT ====="
date -u +"utc:    %Y-%m-%dT%H:%M:%SZ"
# NO HOSTNAME. This report is echoed into check-verified.log, which SHIPS, and
# a machine name identifies the builder without telling a reader anything they
# can use -- the CPU model, core count, governor, boost state and SIMD flags
# below are the provenance that matters, and they are all here. The working
# tree keeps its hostname line: it runs on more than one machine and needs to
# tell them apart.
echo "system: $(uname -srm)"
if command -v lscpu >/dev/null 2>&1; then
    lscpu | grep -Ei 'model name|^cpu\(s\)|^thread|^core|l3 cache' | sed 's/  */ /g; s/^/cpu:    /'
    lscpu | grep -i '^flags' | tr ' ' '\n' | grep -Ex 'avx2|avx512f|avx512bw|avx512vl|gfni|ssse3' | sort | tr '\n' ' ' | sed 's/^/simd:   /'; echo
elif command -v sysctl >/dev/null 2>&1; then
    echo "cpu:    $(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo unknown)"
    echo "cores:  $(sysctl -n hw.ncpu 2>/dev/null || echo ?)"
fi
echo "rustc:  $(rustc --version)"
echo "gov:    $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo n/a)"
echo "boost:  $(cat /sys/devices/system/cpu/cpufreq/boost 2>/dev/null || echo n/a)"
echo "pin:    ${BENCH_CPU:-none (set BENCH_CPU=N for taskset)}"
echo "cargo:  $(cargo --version)"
echo "grid:   $($PY -c 'import grid; print(len(grid.FS), "f values,", len(grid.FS)*len(grid.TARGETS), "points;", len(grid.FS_LOW), "of them GF(2^8)-capable")')"

# ------------------------------------------------------- HARDWARE: A REFUSAL
#
# GFNI and AVX-512VL are REQUIRED, and their absence is a refusal rather than a
# degradation story. Every GF(2^8) and GF(2^16) kernel this artifact measures is
# written against `vgf2p8affineqb` and 512-bit lanes; without them the C driver
# falls back to paths that were never the subject of any measurement here, and
# the numbers it would print are not the numbers this artifact is about. A
# reader is far better served by being told the machine cannot reproduce the
# paper than by a full run of quietly different figures.
#
# CPUID.7.0:ECX.GFNI[bit 8] and CPUID.7.0:EBX.AVX512VL[bit 31], read from
# /proc/cpuinfo where Linux has already decoded them.
missing=""
if [ -r /proc/cpuinfo ]; then
    for bit in gfni avx512vl; do
        grep -qw "$bit" /proc/cpuinfo || missing="$missing $bit"
    done
    if [ -n "$missing" ]; then
        echo >&2
        echo "ERROR: this CPU is missing:$missing" >&2
        echo "       This artifact REQUIRES GFNI and AVX-512VL. Every kernel it" >&2
        echo "       measures is written against them; without them the driver" >&2
        echo "       takes fallback paths that no figure here describes, and a" >&2
        echo "       run would print numbers that are not this artifact's." >&2
        echo "       See docs/LIMITS.md. Refusing rather than degrading." >&2
        exit 1
    fi
    echo "simd-req: gfni + avx512vl present"
else
    echo "simd-req: CANNOT CHECK (no /proc/cpuinfo) -- see docs/LIMITS.md" >&2
fi

# ------------------------- MEASUREMENT HYGIENE: WARN ON WHAT WE CANNOT FIX
#
# None of these is fatal: each is a property of the machine or the invocation
# that only the operator can change, and correctness does not depend on any of
# them. But a stranger on an unpinned laptop with boost on gets noisy numbers
# and, until now, NOTHING IN THE OUTPUT SAID SO. The report's own protocol
# (section 1.9) pins all four; these lines say which of them this run has.
warn=0
w(){ echo "WARN:   $*" >&2; warn=$((warn+1)); }
[ -n "${BENCH_CPU:-}" ] || w "BENCH_CPU is unset -- no taskset pinning. Runs migrate between cores
        and across CCDs; set BENCH_CPU=N (the report uses 4)."
command -v setarch >/dev/null 2>&1 || \
    w "setarch not found -- ASLR stays ON. Layout is then redrawn every process
        and absolute timings carry a documented spread of up to 1.9x."
# `performance` and `userspace` both give a clock that does not chase load --
# userspace means the operator has pinned the frequency, which is exactly how
# the report's own figures were taken (fixed 4.5 GHz). Warn only on the
# governors that actually vary the clock; a false warning in an artifact just
# teaches its reader to ignore warnings.
gov=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo "")
case "$gov" in
    ""|performance|userspace) ;;
    *) w "governor is '$gov' -- it varies the clock under load. Use
        'performance', or 'userspace' with the frequency pinned." ;;
esac
# Under `userspace` the APPLIED frequency is scaling_setspeed. scaling_min_freq
# and scaling_max_freq are only the permitted bounds and normally differ even
# when the clock is pinned, so reading those instead reports a false alarm on a
# correctly configured machine -- which this check did, on the very machine the
# report's figures come from.
if [ "$gov" = userspace ]; then
    sp=$(cat /sys/devices/system/cpu/cpu${BENCH_CPU:-0}/cpufreq/scaling_setspeed 2>/dev/null || echo "")
    case "$sp" in
        ""|'<unsupported>') w "governor is 'userspace' but cpu${BENCH_CPU:-0} scaling_setspeed is
        unreadable, so the frequency may not be pinned." ;;
        *) echo "freq:   cpu${BENCH_CPU:-0} pinned at $((sp / 1000)) MHz (userspace)" ;;
    esac
fi
boost=$(cat /sys/devices/system/cpu/cpufreq/boost 2>/dev/null || echo "")
[ "$boost" != 1 ] || \
    w "boost is enabled -- the clock is not fixed, so run-to-run spread rises.
        The report's figures were taken with it off, at a fixed 4.5 GHz."
if [ "$warn" -gt 0 ]; then
    echo "        ($warn hygiene warning(s). CORRECTNESS IS UNAFFECTED -- every check" >&2
    echo "        below is exact. These bear on TIMING runs only.)" >&2
else
    echo "hygiene: pinned, ASLR off, governor fixed, boost off"
fi

echo
echo "===== BUILD ====="
./bootstrap.sh
if ! ./bootstrap-isal.sh; then
    echo "ISA-L build failed; ISA-L points will be skipped (not fatal)." >&2
fi
: "${RAYON_NUM_THREADS:=1}"; export RAYON_NUM_THREADS
# The Rust side is only measured at parity with the C side if it is built for
# this CPU, and the line above sets that ONLY when RUSTFLAGS is unset. A
# RUSTFLAGS exported for any other reason silently drops it to baseline x86-64
# and every rs_simd figure in the run is wrong, with nothing in the output
# saying so. HANDOVER-2026-08-24.md section 3.1.
check_rustflags() {
    case "${RUSTFLAGS:-}" in
        *target-cpu*) ;;
        *) echo "ERROR: RUSTFLAGS is set but does not carry -C target-cpu:" >&2
           echo "         RUSTFLAGS=${RUSTFLAGS:-}" >&2
           echo "       The Rust codecs would be built for baseline x86-64 while" >&2
           echo "       the C driver is built -march=native. Unset RUSTFLAGS, or" >&2
           echo "       add -C target-cpu=native to it." >&2
           exit 1 ;;
    esac
}
if [ -z "${RUSTFLAGS+x}" ]; then RUSTFLAGS="-C target-cpu=native"; export RUSTFLAGS; fi
check_rustflags
if ! cargo build --release --bin erasure-baseline; then
    echo
    echo "BUILD FAILED -- see the compiler errors above. Stopping."
    exit 1
fi
if [ -x ./codec/rs-point ]; then echo "rs-point: built (both fields)"; else
    echo "rs-point: NOT BUILT -- run (cd isal && make). Refusing to run: the ISA-L"
    echo "          points would be silently skipped rather than checked." >&2; exit 1; fi
if [ -x ./references/fd-point ]; then
    echo "fd-point: built ($(./references/fd-point --k 32 --m 32 --shard-bytes 4096 \
          --trials 1 --warmup 0 2>/dev/null | tail -1 | cut -d, -f7) backend)"
else
    echo "fd-point: NOT BUILT -- run (cd isal && make). Refusing to run: the" >&2
    echo "          firedancer nulls would be silently skipped." >&2; exit 1; fi

BIN=./target/release/erasure-baseline
fail=0

shard_bytes() { $PY -c "import grid,sys; print(grid.aligned_shard_bytes(int(sys.argv[1]), int(sys.argv[2])))" "$1" "$2"; }
rq_ok() { $PY -c "import grid,sys; sys.exit(0 if grid.rq_available(int(sys.argv[1])) else 1)" "$1"; }
gf16_ok() { $PY -c "import grid,sys; sys.exit(0 if grid.gf16_available(int(sys.argv[1])) else 1)" "$1"; }

run() {  # run <label> <args...>; records a failure and prints the tail of stderr
    lbl=$1; shift
    if ! "$@" >/dev/null 2>/tmp/rc.$$; then
        res="$res FAILED($lbl):$(tr -d '\n' < /tmp/rc.$$ | tail -c 60)"
        fail=$((fail + 1))
    fi
    rm -f /tmp/rc.$$
}

echo
# ----------------------------------------------- REFERENCES: PATHS RESOLVE
#
# Cheap, and it belongs before the arithmetic because it checks a different
# thing: that this tree describes itself correctly. The extraction renamed
# isal/ into codec/ and references/, and fifteen references inside comments and
# Markdown kept naming the old layout -- a compiler checks an #include, and
# NOTHING checked those. It also catches a reference that reaches outside this
# directory, which resolves on the machine that wrote it and dangles the moment
# the artifact is published on its own.
echo
echo "===== REFERENCES: every path resolves, and none escapes the tree ====="
if $PY ./check_links.py; then
    :
else
    echo "  -- see docs/MAPPING.md section 8 for what is a path and what is a" >&2
    echo "     citation to a document this artifact deliberately does not ship." >&2
    fail=$((fail + 1))
fi

echo "===== CORRECTNESS: EVERY f, ALL CODECS (at 1 MiB) ====="
printf '%-5s %-5s %-6s %-9s %-6s %s\n' f k T shard field result
for f in $FS_ALL; do
    k=$((f + 1)); T=$((3 * f + 1))
    sb=$(shard_bytes "$SPOT_TARGET" "$k"); res=ok
    run rs   $BIN --f "$f" --shard-bytes "$sb" --codec rs   --trials 2 --warmup 1
    run r10  $BIN --f "$f" --shard-bytes "$sb" --codec r10  --trials 2 --warmup 1
    if rq_ok "$sb"; then
        run rq $BIN --f "$f" --shard-bytes "$sb" --codec rq --trials 2 --warmup 1
    fi
    if [ "$T" -le 256 ]; then
        fld=gf8
        if [ -x ./codec/rs-point ]; then
            run isal-cf ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                --trials 2 --warmup 1
        fi
    else
        fld=gf16
    fi
    # isal_cauchy16 spans the T = 256 boundary -- it is the only codec here that
    # runs unchanged on both sides of it -- so it sits outside the if/else.
    if [ -x ./codec/rs-point ] && gf16_ok "$f"; then
        run isal16-cf ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" --plan cauchy \
            --trials 2 --warmup 1
    fi
    printf '%-5s %-5s %-6s %-9s %-6s %s\n' "$f" "$k" "$T" "$sb" "$fld" "$res"
done

echo
echo "===== CORRECTNESS: GF(2^8) f AT EVERY MESSAGE SIZE ====="
echo "isal-cf and isal-nf are the same decode plan with the two folds of the"
echo "received-source columns -- the closed-form identity and the explicit B^-1 E"
echo "product. Both verify their reconstruction against the source per trial."
echo "This section once also carried a cross-library digest against"
echo "tape-reed-solomon, which computes the same GF(2^8) Cauchy code. That"
echo "library is not part of this artifact. The independent check that remains,"
echo "and is the stronger one, is the GF(2^8) PAIR section below: byte-identical"
echo "parity against firedancer's reedsol, a separate codebase."
printf '%-5s %-5s %-6s %-9s %s\n' f k shard variants result
for f in $FS_GF8; do
    k=$((f + 1)); T=$((3 * f + 1))
    for target in $TARGETS; do
        sb=$(shard_bytes "$target" "$k"); res=ok
        if [ -x ./codec/rs-point ]; then
            run isal-cf ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                --fold closed-form --trials 2 --warmup 1
            run isal-nf ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                --fold naive --trials 2 --warmup 1
        fi
        printf '%-5s %-5s %-6s %-9s %s\n' "$f" "$k" "$sb" \
            "isal-cf,isal-nf" "$res"
    done
done

echo
echo "===== CORRECTNESS: isal_cauchy16 INTERNAL DIFFERENTIAL ====="
echo "isal_cauchy16 builds GF(2^16) as GF(2^8)[z]/(z^2+z+0x20) over ISA-L's GF(2^8)"
echo "kernels. That field is isomorphic to, but not the same representation as, the"
echo "GF(2^16) in reed-solomon-simd, so its parity bytes do NOT match, and no"
echo "cross-library oracle is available in this field at all."
echo "What replaces it: two independent decode plans (closed-form Cauchy vs O(k^3)"
echo "Gaussian elimination over the same field, sharing no code) and two independent"
echo "folds (the closed-form identity vs the explicit B^-1 E product). All four must"
echo "reconstruct the original source bytes, which each run verifies per trial."
printf '%-5s %-5s %-6s %-9s %s\n' f k T variants result
if [ -x ./codec/rs-point ]; then
    for f in $FS_ALL; do
        k=$((f + 1)); T=$((3 * f + 1))
        sb=$(shard_bytes "$SPOT_TARGET" "$k"); res=ok
        gf16_ok "$f" || { printf '%-5s %-5s %-6s %-9s %s\n' "$f" "$k" "$T" "$sb" \
            "SKIPPED(T>65536)"; continue; }
        run cf-closed ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
            --plan cauchy --fold closed-form --trials 2 --warmup 1
        run cf-naive  ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
            --plan cauchy --fold naive --trials 2 --warmup 1
        run ge        ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
            --plan ge --trials 2 --warmup 1
        printf '%-5s %-5s %-6s %-9s %s\n' "$f" "$k" "$T" "$sb" "$res"
    done
else
    echo "rs-point NOT BUILT -- section skipped." >&2; fail=1
fi

# ===== TWO ENCODERS, ONE CODE =====
# Above T = 256 there is no cross-library digest -- the composite field makes one
# impossible (report 1.4) -- so this takes its place. ISAL16_ENCODE=matrix and
# =fft compute the SAME code (report 2.5), so their parity must agree byte for
# byte. This is what caught a heap overflow that no timing figure would reveal.
echo
echo "===== ENCODER ORACLE: matrix vs additive-FFT parity, T > 256 ====="
for f in 86 96 129 132 134 160 192 224 254 255 256; do
    k=$((f + 1))
    for mib in 1 4; do
        sb=$(( ((mib * 1048576 / k + 63) / 64) * 64 ))
        # ISAL16_ENC_LAYOUT=plane is PINNED on both sides, and must be.
        # This oracle asks whether the two encoders compute the same CODE, and
        # `inter` is a different element ORDERING of the same code -- it changes
        # the parity bytes on purpose (codec/KNOBS.md). Since 2026-08-26 `inter`
        # is the compiled default whenever the transform encoder runs, while the
        # matrix encoder can only emit planes, so leaving the layout unstated
        # would compare plane against inter and fail for a reason that is not a
        # bug. Stating it is the same rule the harness labels now follow.
        ref=$(ISAL16_NODES=cantor ISAL16_ENCODE=matrix ISAL16_ENC_LAYOUT=plane \
              ./codec/rs-point --field 16 \
              --f "$f" --shard-bytes "$sb" --digest 2>/dev/null | grep -o 'parity=.*')
        for v in "ISAL16_FFT_TAIL=12" "ISAL16_FFT_TAIL=0" "ISAL16_FFT_ASM=0" \
                 "ISAL16_FFT_BLOCK3=1" "ISAL16_FFT_KERNEL=scalar"; do
            got=$(env ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_ENC_LAYOUT=plane \
                  $v ./codec/rs-point \
                  --field 16 --f "$f" --shard-bytes "$sb" --digest 2>/dev/null \
                  | grep -o 'parity=.*')
            if [ "$ref" != "$got" ]; then
                echo "MISMATCH f=$f mib=$mib [$v]" >&2
                fail=1
            fi
        done
    done
done
[ "$fail" -eq 0 ] && echo "matrix and FFT parity agree at every shape and kernel."

# ===== COMPILED DEFAULTS ARE THE RECOMMENDED CONFIGURATION =====
# DEFAULTS.md policy 1: the default IS the best measured configuration. Nothing
# checked that, and on 2026-08-26 four GF(2^16) knobs were found still at
# revision-18 behaviour -- which had already inverted one published ratio
# (firedancer, 24 Aug) and then inverted a second (leopard, 26 Aug). This
# asserts the claim instead of trusting it: the BARE driver must agree, byte for
# byte, with the driver told to use DEFAULTS.md's recommended block.
#
# `env -u` because this file exports the historical baseline above.
echo
echo "===== COMPILED DEFAULTS: the bare driver must be the recommended codec ====="
UNSET="env -u ISAL8_NODES -u ISAL8_ENCODE -u ISAL16_NODES -u ISAL16_ENCODE \
       -u ISAL16_DECODE -u ISAL16_ENC_LAYOUT -u ISAL16_DEC_LAYOUT -u ISAL16_FFT_TAIL"
dflt_bad=0
for f in 32 85 128 255; do
    k=$((f + 1)); sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    if [ "$f" -le 85 ]; then
        bare=$($UNSET ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" \
               --plan cauchy --digest 2>/dev/null | grep -o 'parity=.*')
        want=$($UNSET ISAL8_NODES=eval ISAL8_ENCODE=fft ISAL8_INTERP=auto \
               ISAL8_FFT_BLOCK3=1 ISAL8_FUSE=1 ISAL8_PPT_FUSE=1 ISAL8_COSET_FUSE=1 \
               ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" \
               --plan cauchy --digest 2>/dev/null | grep -o 'parity=.*')
        [ "$bare" = "$want" ] || { echo "GF(2^8) default is not X at f=$f" >&2; dflt_bad=1; }
    fi
    bare=$($UNSET ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
           --digest 2>/dev/null | grep -o 'parity=.*')
    want=$($UNSET ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_ENC_LAYOUT=inter \
           ISAL16_DEC_LAYOUT=inter ISAL16_FFT_TAIL=04 \
           ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
           --digest 2>/dev/null | grep -o 'parity=.*')
    [ "$bare" = "$want" ] || { echo "GF(2^16) default is not the recommended set at f=$f" >&2; dflt_bad=1; }
done
# ...and every historical value must still be reachable -- DEFAULTS.md policy 3.
for f in 32 85 128; do
    k=$((f + 1)); sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    old=$(ISAL16_NODES=linear ISAL16_ENCODE=matrix ISAL16_ENC_LAYOUT=plane \
          ISAL16_DEC_LAYOUT=plane ISAL16_FFT_TAIL=12 \
          ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" --digest \
          2>/dev/null | grep -o 'parity=.*')
    new=$($UNSET ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" \
          --digest 2>/dev/null | grep -o 'parity=.*')
    [ "$old" != "$new" ] || { echo "the rev-18 null is unreachable at f=$f" >&2; dflt_bad=1; }
done
if [ "$dflt_bad" -eq 0 ]; then
    echo "  the bare driver is X in GF(2^8) and the recommended code in GF(2^16),"
    echo "  and every historical value is still reachable as its null."
else
    fail=1
fi

# The GF(2^8) pair: ISAL8_NODES=eval selects the evaluation code on the nodes
# 0..T-1, ISAL8_ENCODE=fft encodes it with the additive FFT + PPT, and the plan
# decodes it with the two diagonals of PERF-NOTES-FFT-GF8-PPT.md section 3. Two
# oracles, and the second is stronger than anything the GF(2^16) transform has:
#
#   1. matrix encode == FFT encode, at every kernel and lane width -- the same
#      equality the T > 256 block above checks, one field down.
#   2. both == references/fd-point, an INDEPENDENT implementation in another codebase,
#      byte for byte. fd-point-generic recomputes it by table lookup instead of
#      GFNI, so the agreement is not a shared-bug artefact.
echo
echo "===== GF(2^8) PAIR: eval-node parity, against itself and against firedancer ====="
n=0
for f in 5 8 15 31 32 33 40 48 56 63 64 65 72 80 85; do
    k=$((f + 1))
    for mib in 1 4; do
        sb=$(( ((mib * 1048576 / k + 63) / 64) * 64 ))
        ref=$(ISAL8_NODES=eval ISAL8_INTERP=ppt ./codec/rs-point --field 8 --f "$f" \
              --shard-bytes "$sb" --plan cauchy --digest 2>/dev/null | grep -o 'parity=.*')
        fdp=$(./references/fd-point --f "$f" --shard-bytes "$sb" --digest 2>/dev/null \
              | grep -o 'parity=.*')
        if [ "$ref" != "$fdp" ]; then
            echo "MISMATCH vs firedancer f=$f mib=$mib" >&2; fail=1
        fi
        for v in "ISAL8_FFT_BLOCK=1" "ISAL8_FFT_BLOCK=0" "ISAL8_FFT_W=512" \
                 "ISAL8_FFT_KERNEL=scalar"; do
            got=$(env ISAL8_NODES=eval ISAL8_INTERP=ppt ISAL8_ENCODE=fft $v ./codec/rs-point \
                  --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy --digest 2>/dev/null \
                  | grep -o 'parity=.*')
            if [ "$ref" != "$got" ]; then
                echo "MISMATCH f=$f mib=$mib [$v]" >&2; fail=1
            fi
        done
        n=$((n + 1))
    done
done
# And the decode: both folds must round-trip the eval-node code, which is what
# exercises the two diagonals. --fold naive shares no code with the closed form.
for f in 5 31 33 48 63 65 85; do
    k=$((f + 1)); sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    for fold in closed-form naive; do
        if ! ISAL8_NODES=eval ISAL8_INTERP=ppt ISAL8_ENCODE=fft ./codec/rs-point --field 8 \
             --f "$f" --shard-bytes "$sb" --plan cauchy --fold "$fold" --trials 3 \
             --warmup 1 >/dev/null 2>&1; then
            echo "ROUND-TRIP FAILED f=$f fold=$fold" >&2; fail=1
        fi
    done
done
[ "$fail" -eq 0 ] && echo "  eval-node parity agrees with firedancer and across 4 kernels, $n shapes"
[ "$fail" -eq 0 ] && echo "  eval-node decode round-trips at 7 shapes x 2 folds"

# ISAL8_INTERP: the PIVOT BASE kp, which ppt and pad are the two ends of.
#
# Interpolate the degree-<kp polynomial through the data at 0..k-1 and ZEROS at
# k..kp-1, pivoting only the top chunk-kp coordinates; parity starts at kp.
# kp = k is plain PPT (firedancer's code), kp = chunk is the fully zero-padded
# shortened code, and anything between trades pivots against nodes. The budget
# is exact -- parity occupies kp..kp+m-1, so kp <= 256-m -- and `auto` takes
# kp = min(chunk, 256-m), the most padding that fits.
#
# Only kp = k is firedancer's code, so `fd-point` is an oracle for that setting
# and this block does not ask it to be one for any other. What IS an oracle at
# every kp, and is the stronger of the two, is the matrix encoder built from
# gen_entry over the same node set: an independent implementation inside this
# tree, byte for byte, at every kernel and lane width.
#
# Four further nulls that only this block can run:
#   * auto == ppt exactly when min(chunk,256-m) == k, and == pad exactly when it
#     equals chunk. That is the check that kp is selecting a code rather than
#     silently doing nothing, and it pins `auto`'s rule to arithmetic.
#   * =pad must be REFUSED when chunk + m > 256 rather than encoding garbage.
#     A matrix tail cannot rescue it: a tail changes how a parity shard is
#     computed, not which node it sits at.
#   * an explicit kp outside [k, min(chunk,256-m)] must be refused.
#   * an interior kp must round-trip -- the case that caught the direct-parity
#     shards being read from w[k+j] instead of w[kp+j], which is correct at both
#     endpoints and wrong at every pivot between them.
echo
echo "===== GF(2^8) PIVOT BASE: every kp, against the matrix encoder ====="
np=0
for f in 5 8 15 31 32 33 40 48 56 63 64 65 66 72 80 85; do
    k=$((f + 1)); m=$((2 * f))
    ch=1; while [ "$ch" -lt "$k" ]; do ch=$((ch * 2)); done
    mx=$((256 - m)); [ "$mx" -gt "$ch" ] && mx=$ch          # kp_best = auto's choice
    mid=$(( (k + mx) / 2 ))
    for mib in 1 4; do
        sb=$(( ((mib * 1048576 / k + 63) / 64) * 64 ))
        # $3 is an optional kernel override, and `|| true` because a REFUSED
        # setting exits nonzero with no digest -- which is a result this block
        # tests for, not an error. Both matter under `set -eu`.
        dig() { v=${3:-}; env ISAL8_NODES=eval ISAL8_INTERP="$1" ISAL8_ENCODE="$2" $v \
                ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                --digest 2>/dev/null | grep -o 'parity=.*' || true; }
        # the standing oracle, at three settings, and across four kernels for auto
        for kp in auto ppt "$mid"; do
            ref=$(dig "$kp" matrix)
            [ -n "$ref" ] || { echo "PIVOT no digest f=$f kp=$kp" >&2; fail=1; }
            got=$(dig "$kp" fft)
            [ "$ref" = "$got" ] || { echo "PIVOT MISMATCH f=$f mib=$mib kp=$kp" >&2; fail=1; }
        done
        aref=$(dig auto matrix)
        for v in "ISAL8_FFT_BLOCK=1" "ISAL8_FFT_BLOCK=0" "ISAL8_FFT_W=512" \
                 "ISAL8_FFT_KERNEL=scalar" "ISAL8_FUSE=0" \
                 "ISAL8_FFT_BLOCK3=1" "ISAL8_FFT_BLOCK3=1 ISAL8_FUSE=0" \
                 "ISAL8_PPT_FUSE=0" "ISAL8_PPT_FUSE=0 ISAL8_FFT_BLOCK3=1" \
                 "ISAL8_COSET_FUSE=0" "ISAL8_COSET_FUSE=0 ISAL8_FFT_BLOCK3=1"; do
            got=$(dig auto fft "$v")
            [ "$aref" = "$got" ] || { echo "PIVOT MISMATCH f=$f mib=$mib auto [$v]" >&2; fail=1; }
        done
        # AUTO'S CHOICE IS A FUNCTION OF (k, m) AND NOTHING ELSE. It picks a
        # CODE by costing every feasible pivot base, so it must not move when a
        # KERNEL knob moves -- those cannot change parity by contract. This is
        # the check that caught fft8_pick_kp reading ISAL8_FFT_BLOCK3.
        for v in "ISAL8_FFT_BLOCK3=1" "ISAL8_FFT_BLOCK=0" "ISAL8_FFT_KERNEL=scalar" \
                 "ISAL8_FUSE=0" "ISAL8_PPT_FUSE=0" "ISAL8_COSET_FUSE=0"; do
            [ "$aref" = "$(dig auto matrix "$v")" ] || { \
                echo "AUTO MOVED under a kernel knob f=$f [$v]" >&2; fail=1; }
        done
        # auto coincides with ppt or pad at some shapes and not others -- which
        # is which is the cost model's business, not an invariant. What IS one:
        # =pad must be refused above chunk + m = 256.
        if [ "$mx" -ne "$ch" ]; then
            [ -z "$(dig pad matrix)" ] || { \
                echo "PAD ACCEPTED above chunk+m<=256 at f=$f" >&2; fail=1; }
        fi
        adiff=$([ "$aref" = "$(dig ppt matrix)" ] && echo same || echo differ)
        eval "seen_$adiff=1"
        np=$((np + 1))
    done
    # an explicit kp outside [k, kp_best] must be refused
    sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    for bad in $((k - 1)) $((mx + 1)); do
        if [ "$bad" -ge 1 ] && ISAL8_NODES=eval ISAL8_INTERP="$bad" \
             ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
             --digest >/dev/null 2>&1; then
            echo "PIVOT ACCEPTED out of range f=$f kp=$bad" >&2; fail=1
        fi
    done
done
# Round-trip at an INTERIOR pivot and at both ends: the decoder reads the moved
# parity nodes through node_of(), and --fold naive recomputes the same rows from
# gen_entry sharing no code with the closed form.
for f in 5 31 33 48 63 64 65 72 85; do
    k=$((f + 1)); m=$((2 * f))
    ch=1; while [ "$ch" -lt "$k" ]; do ch=$((ch * 2)); done
    mx=$((256 - m)); [ "$mx" -gt "$ch" ] && mx=$ch
    sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    for kp in ppt auto $(( (k + mx) / 2 )); do
        for fold in closed-form naive; do
            for enc in matrix fft; do
                if ! ISAL8_NODES=eval ISAL8_INTERP="$kp" ISAL8_ENCODE=$enc \
                     ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                     --fold "$fold" --trials 3 --warmup 1 >/dev/null 2>&1; then
                    echo "PIVOT ROUND-TRIP FAILED f=$f kp=$kp fold=$fold enc=$enc" >&2; fail=1
                fi
            done
        done
    done
done
[ "$fail" -eq 0 ] && echo "  every pivot base agrees with the matrix encoder, $np shapes x 3 kp x 11 kernels"
[ "$fail" -eq 0 ] && [ "${seen_same:-0}" = 1 ] && [ "${seen_differ:-0}" = 1 ] || { \
    [ "$fail" -eq 0 ] && { echo "auto never differs from ppt, or never agrees" >&2; fail=1; }; }
[ "$fail" -eq 0 ] && echo "  auto is kernel-invariant at 6 knobs, and both agrees with and differs from ppt"
[ "$fail" -eq 0 ] && echo "  decode round-trips at 9 shapes x 3 kp x 2 folds x 2 encoders"

echo "===== ALL-PARITY ARRIVALS: the maximum residual system, r = k ====="
# --arrivals parity hands the receiver ONLY parity shards, so every original is
# missing and r = k -- the largest residual Cauchy system the decoder can be
# asked for. Every other decode in this suite runs under `random`, where r is
# about 2k/3 at this rate, so without this section r = k is asserted NOWHERE.
#
# It is a BOUNDARY and not merely a bigger case. The decode rows are
# [ B^-1 | B^-1 E ], and B^-1 E has k - r columns; at r = k that block is EMPTY
# and fold_closed_form8 computes nothing at all. A closed form handed a
# degenerate input is precisely the thing that is silently wrong, and neither
# closed form had ever been run there.
#
# Verification is on by default, so a NON-ZERO EXIT IS THE ROUND-TRIP FAILURE --
# the same contract the sections above rely on.
pfail=0
for f in 5 31 33 48 63 65 85; do
    k=$((f + 1)); sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    for fold in closed-form naive; do
        for enc in matrix fft; do
            if ! ISAL8_NODES=eval ISAL8_INTERP=auto ISAL8_ENCODE=$enc \
                 ./codec/rs-point --field 8 --f "$f" --shard-bytes "$sb" --plan cauchy \
                 --fold "$fold" --arrivals parity --trials 3 --warmup 1 >/dev/null 2>&1; then
                echo "ALL-PARITY ROUND-TRIP FAILED gf8 f=$f fold=$fold enc=$enc" >&2
                pfail=1
            fi
        done
    done
done
[ "$pfail" -eq 0 ] && echo "  GF(2^8)  round-trips at 7 shapes x 2 folds x 2 encoders, r = k"
for f in 86 129 200 254 511; do
    k=$((f + 1)); sb=$(( ((1048576 / k + 63) / 64) * 64 ))
    gf16_ok "$f" || continue
    for fold in closed-form naive; do
        for dec in matrix fft; do
            if ! ISAL16_NODES=cantor ISAL16_ENCODE=fft ISAL16_DECODE=$dec \
                 ISAL16_ENC_LAYOUT=inter ISAL16_DEC_LAYOUT=inter ISAL16_FFT_TAIL=04 \
                 ./codec/rs-point --field 16 --f "$f" --shard-bytes "$sb" --plan cauchy \
                 --fold "$fold" --arrivals parity --trials 3 --warmup 1 >/dev/null 2>&1; then
                echo "ALL-PARITY ROUND-TRIP FAILED gf16 f=$f fold=$fold dec=$dec" >&2
                pfail=1
            fi
        done
    done
done
[ "$pfail" -eq 0 ] && echo "  GF(2^16) round-trips at 5 shapes x 2 folds x 2 decoders, r = k"
# The transform decoder cannot tell this mode from `random`; running it here is
# not redundant, it is the null that says a failure above belongs to the matrix
# decoder's residual system and not to the arrival machinery itself.
[ "$pfail" -ne 0 ] && fail=$((fail + 1))
echo
echo
echo "===== FIREDANCER reedsol: THE FOUR NULLS THE PORT RESTS ON ====="
echo "references/fdrs is the firedancer src/ballet/reedsol tree, regenerated at raised"
echo "shred ceilings so it reaches the whole T <= 256 region; see its README."
echo "Null 1, that their generators reproduce their own shipped sources, is the"
echo "expensive one and lives in references/fdrs/regen.sh, which refuses to write"
echo "without it. Nulls 2-4 are here."
if [ ! -x ./references/fd-point ]; then
    echo "fd-point: NOT BUILT -- run ./bootstrap-isal.sh." >&2
    fail=$((fail + 1))
else
    fdfail=0
    # Null 2: the regenerated code computes the same code as upstream, at every shape the
    # pinned 67/67 clone can also express. Skipped, loudly, without the clone.
    if [ -x ./references/fd-point-upstream ]; then
        n=0
        for shape in "--f 31" "--f 32" "--f 33" "--k 32 --m 32" "--k 16 --m 16" \
                     "--k 8 --m 60" "--k 64 --m 67" "--k 67 --m 67" "--k 1 --m 67"; do
            for sb in 4096 16512; do
                n=$((n + 1))
                # shellcheck disable=SC2086
                a=$(./references/fd-point          $shape --shard-bytes "$sb" --digest)
                # shellcheck disable=SC2086
                b=$(./references/fd-point-upstream $shape --shard-bytes "$sb" --digest)
                if [ "$a" != "$b" ]; then
                    echo "REGEN MISMATCH [$shape] sb=$sb" >&2; fdfail=$((fdfail + 1))
                fi
            done
        done
        echo "  null 2 regeneration:   $n shapes against the pinned clone"
    else
        echo "  null 2 regeneration:   SKIPPED -- needs references/fd-point-upstream,"
        echo "                         built from a pinned clone at firedancer/"
    fi
    # Null 3: the two arithmetic backends agree. These parity bytes belong to a
    # code no other library computes, so this is the only independent check on
    # them that exists.
    n=0
    for f in $($PY -c 'import grid; print(" ".join(map(str, grid.FS_LOW)))'); do
        k=$((f + 1))
        for mib in 1 4; do
            sb=$(( ((mib * 1048576 / k + 63) / 64) * 64 ))
            n=$((n + 1))
            a=$(./references/fd-point         --f "$f" --shard-bytes "$sb" --digest)
            b=$(./references/fd-point-generic --f "$f" --shard-bytes "$sb" --digest)
            if [ "$a" != "$b" ]; then
                echo "BACKEND MISMATCH f=$f mib=$mib" >&2; fdfail=$((fdfail + 1))
            fi
        done
    done
    echo "  null 3 gfni vs generic: $n shapes"
    # Null 4: every grid shape round-trips through fd_reedsol_recover with
    # exactly the first k arrivals.
    n=0
    for f in $($PY -c 'import grid; print(" ".join(map(str, grid.FS_LOW)))'); do
        k=$((f + 1))
        for mib in 1 4; do
            sb=$(( ((mib * 1048576 / k + 63) / 64) * 64 ))
            n=$((n + 1))
            if ! ./references/fd-point --f "$f" --shard-bytes "$sb" --trials 3 --warmup 1 \
                 >/dev/null 2>&1; then
                echo "ROUND-TRIP FAILED f=$f mib=$mib" >&2; fdfail=$((fdfail + 1))
            fi
        done
    done
    echo "  null 4 round-trip:      $n shapes"
    if [ "$fdfail" -eq 0 ]; then
        echo "firedancer port verifies."
    else
        echo "$fdfail firedancer check(s) FAILED" >&2
        fail=$((fail + fdfail))
    fi
fi

echo
echo "===== PROOFS: independent re-derivations of the Reed-Solomon appendix ====="
echo "proofs/ shares no code with the driver, which is the point of it. Nothing"
echo "here invoked it until 9 September 2026, and that is exactly how"
echo "fft_cauchy_check.py came to ship unable to run at all: the gen_probe it"
echo "measures through was dropped at extraction and no check noticed for the"
echo "life of the artifact. A proof nobody runs is a proof nobody checks."
echo "MANIFEST.md carries the full account. Output is shown only on failure."
# fft_cauchy_check.py reads reed-solomon-simd's generator through this probe.
# It is a separate bin target, so a plain `cargo build` does not produce it.
if cargo build --release --bin gen_probe >/tmp/gp.$$ 2>&1; then
    echo "  gen_probe:                  built"
else
    echo "  gen_probe:                  BUILD FAILED" >&2
    sed 's/^/    /' /tmp/gp.$$ >&2
    fail=$((fail + 1))
fi
rm -f /tmp/gp.$$
proof_run() {
    lbl=$1; shift
    if "$@" >/tmp/pr.$$ 2>&1; then
        sum=$(grep -m1 -E 'RESULT:|ALL PIVOT-BASE CLAIMS VERIFY|All decode assertions' /tmp/pr.$$ || true)
        if [ -n "$sum" ]; then echo "  $lbl PASS -- $sum"; else echo "  $lbl PASS"; fi
    else
        echo "  $lbl FAILED" >&2
        sed 's/^/    /' /tmp/pr.$$ >&2
        fail=$((fail + 1))
    fi
    rm -f /tmp/pr.$$
}
proof_run "pivot_check.py:            " $PY ./proofs/pivot_check.py
proof_run "ppt_theorem_check.py:      " $PY ./proofs/ppt_theorem_check.py
proof_run "fft_cauchy_check.py:       " $PY ./proofs/fft_cauchy_check.py
# standalone_cauchy_check.rs is deliberately not a bin target: it depends on
# nothing in this crate and is compiled straight by rustc, which is what makes
# it standalone. Built into a temporary file so the tree stays clean.
scc=/tmp/scc.$$
if rustc -O ./proofs/standalone_cauchy_check.rs -o "$scc" >/tmp/sc.$$ 2>&1; then
    proof_run "standalone_cauchy_check.rs:" "$scc"
else
    echo "  standalone_cauchy_check.rs: BUILD FAILED" >&2
    sed 's/^/    /' /tmp/sc.$$ >&2
    fail=$((fail + 1))
fi
rm -f "$scc" /tmp/sc.$$

echo
if [ "$fail" -eq 0 ]; then
    echo "All points verify."
    echo "Run:  BENCH_CPU=4 ./benchmark.sh 2>&1 | tee run.log     (recommended)"
    echo "Adding the nulls (rs rate variants, the O(k^3) GE decode plan):"
    echo "      BENCH_LABELS=full BENCH_CPU=4 ./benchmark.sh 2>&1 | tee run-full.log"
else
    echo "$fail check(s) FAILED -- stop, do not trust timings."
    exit 1
fi
