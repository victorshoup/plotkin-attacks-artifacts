# Software artifact — benchmark harness and Reed–Solomon implementations

The software artifact for the benchmark and Reed–Solomon appendices
(`app:benchmarks`, `app:rs-algebra`) of *Plotkin Attacks! On the (Mis)use of
Raptor Codes in Asynchronous Verifiable Information Dispersal* —
the benchmark harness and the two experimental Reed–Solomon implementations,
**RS–8** (GF(2⁸), n ≤ 256) and **RS–16** (GF(2¹⁶), all n).

Its purpose is to let a reader **reproduce the appendix measurements, or
re-measure them on different hardware.** The second is the demanding one, and
most of what is here exists to serve it.

## Requirements

**AVX-512 and GFNI are required.** Exactly `CPUID.7.0:ECX.GFNI` and
`CPUID.7.0:EBX.AVX512VL`. In practice AMD Zen 4 or Zen 5, Intel server from
Ice Lake-SP on, or Intel client through Rocket Lake — **not** Intel client from
Alder Lake on. `check.sh` refuses rather than degrading; `docs/LIMITS.md` §1
says why.

Also: a C toolchain, `nasm`, `python3`, and `cargo` with rustc ≥ 1.89.

## Running it

    ./check.sh        # correctness, oracles, environment report
    ./benchmark.sh    # the full 192-point grid, ~8 minutes

Always `check.sh` first — it is not a smoke test but the reason a timing run can
be believed. The whole grid is a lunch break, not an overnight job.

**Before you run either, read [`docs/REPRODUCING.md`](docs/REPRODUCING.md).**
Several parts of the protocol silently invalidate numbers without producing an
error — a bare `cargo build` alone costs about 20% on the codec that carries most
of the appendix tables.

To compare your run against ours:

    python3 compare.py results/robust-summary-<stamp>.csv

To recompute the archived publication quantities from the exact measurement
files that produced them:

    python3 results/paper-data/reproduce_tables.py

Those files ship in `results/paper-data/`; the reference CSVs `compare.py`
uses are different runs. `results/README.md` says why both are here.

## What is most worth measuring elsewhere

**Where the RS–16 matrix/transform decoder crossover lands on your machine.** The
paper places it between f = 206 and f = 212 at 0.5 and 1 MiB, between 200 and 206 at 2 MiB,
and between 224 and 230 at 4 MiB, and treats the choice as a receiver-local
dispatch rather than a monotone threshold. It is cache-dependent and will move on a
different memory hierarchy. Both decoders consume the same emitted codewords, so
the comparison is internal to one run and does not depend on reproducing our
absolute times at all. `docs/REPRODUCING.md` §5.

## Layout

The scripts sit at the top level and the C driver one directory down, mirroring
how the benchmark actually runs.

| path | contents |
|---|---|
| `check.sh`, `benchmark.sh`, `grid.py`, `robust_benchmark.py`, `compare.py`, … | the harness |
| `codec/` | `rs_point.c` and kernels — RS–8 and RS–16, **one file, not split** |
| `references/` | the Firedancer comparison adapter and its generated sources |
| `Cargo.toml`, `src/main.rs`, `monad-raptor/` | R10 and RaptorQ, the Rust baseline (**`monad-raptor/` is a GPL-3.0 subtree**) |
| `isal-patches/` | the GFNI kernel patch over stock ISA-L. **Not optional** — see `docs/REPRODUCING.md` §3.2 |
| `proofs/` | independent re-derivations of the Reed–Solomon appendix |
| `results/` | reference CSVs to compare a local run against, and in `results/paper-data/` the measurements the paper's tables were computed from |
| `docs/` | see [`docs/README.md`](docs/README.md) |

## Licence

MIT, **except `monad-raptor/`**, which is vendored third-party code under
GPL-3.0-or-later and carries its own `LICENSE` and `VENDORED.md`.

See `MANIFEST.md` for provenance.
