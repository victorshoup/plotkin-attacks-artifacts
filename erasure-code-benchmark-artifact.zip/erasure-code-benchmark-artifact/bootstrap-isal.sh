#!/bin/sh
# Fetch and build ISA-L, then build the isal-point driver.
#
# Uses ISA-L's standalone Makefile.unx, so the ONLY build dependency is an
# assembler (nasm). No autoconf/automake/libtool, no ./autogen.sh, no root.
set -eu
cd "$(dirname "$0")"
ROOT=$(pwd)
VER=2.31.1
SRC="$ROOT/isa-l-$VER"

# No early exit on "the driver already exists". It used to test for isal-point
# and isal-point16, which the merge into rs-point retired -- so the guard has
# been dead for weeks, and had it ever fired it would have skipped the build of
# a driver whose source had changed. `make` below is incremental and the ISA-L
# fetch and library build are separately guarded, so re-running is cheap; a
# stale measured binary is not. HANDOVER-2026-08-24.md section 6.

# nasm without root: apt-get download + dpkg -x need no privileges.
if ! command -v nasm >/dev/null 2>&1; then
    if [ -x "$ROOT/localtools/usr/bin/nasm" ]; then
        PATH="$ROOT/localtools/usr/bin:$PATH"; export PATH
    else
        echo "nasm not found; fetching it into ./localtools (no root needed)..."
        mkdir -p "$ROOT/localtools"
        (cd "$ROOT/localtools" && apt-get download nasm >/dev/null 2>&1 \
            && for d in nasm_*.deb; do dpkg -x "$d" .; done) || {
            echo "MISSING BUILD DEPENDENCY: nasm, and the rootless fetch failed." >&2
            echo "  With root:     sudo apt-get install nasm" >&2
            echo "  Without root:  apt-get download nasm && dpkg -x nasm_*.deb ~/localtools" >&2
            echo "                 then re-run with PATH=~/localtools/usr/bin:\$PATH" >&2
            exit 1
        }
        PATH="$ROOT/localtools/usr/bin:$PATH"; export PATH
    fi
fi
echo "assembler: $(nasm -v)"

if [ ! -d "$SRC" ]; then
    echo "Downloading ISA-L v$VER..."
    curl -fsSL "https://codeload.github.com/intel/isa-l/tar.gz/refs/tags/v$VER" \
        -o "$ROOT/isa-l.tar.gz"
    tar xzf "$ROOT/isa-l.tar.gz" -C "$ROOT"
    rm -f "$ROOT/isa-l.tar.gz"
fi

# Local patches to the ISA-L tree. The tree itself is gitignored (it is fetched,
# not vendored), so anything we change to it has to live here or it evaporates on
# the next clean checkout. Applied idempotently: `patch -R --dry-run` succeeding
# means it is already in, so re-running this script is safe.
# NOT OPTIONAL, AND THE MISSING-DIRECTORY CASE IS NOW FATAL. This block used to
# be wrapped in `if [ -d isal-patches ]`, so a tree without the directory built
# STOCK ISA-L and said nothing. That is exactly what happened when this artifact
# was first assembled: the patch set was not copied across, the build succeeded,
# check.sh passed -- correctness does not depend on which kernel does the
# arithmetic -- and the grid then came out 1.75x slow on matrix encode and 1.58x
# slow on GF(2^8) decode against the report. Every affected label is one whose
# kernels these patches replace, which is how it was tracked down.
#
# The patched kernels ARE the measured configuration: report section 1.2 lists
# them as ours, a 991-line patch over stock v2.31.1. A build without them is not
# a slower version of this artifact, it is a different one.
if [ ! -d "$ROOT/isal-patches" ]; then
    echo "ERROR: isal-patches/ is missing." >&2
    echo "       The GFNI kernels this artifact measures are a patch over stock" >&2
    echo "       ISA-L v2.31.1 (report 1.2). Without it the build silently uses" >&2
    echo "       stock kernels and every ISA-L figure is wrong by up to 1.75x." >&2
    exit 1
fi
if [ -d "$ROOT/isal-patches" ]; then
    n_applied=0
    for pf in "$ROOT"/isal-patches/*.patch; do
        [ -e "$pf" ] || continue
        n_applied=$((n_applied+1))
        if patch -d "$SRC" -p1 -R --dry-run -f <"$pf" >/dev/null 2>&1; then
            echo "isal patch already applied: $(basename "$pf")"
        elif patch -d "$SRC" -p1 --dry-run -f <"$pf" >/dev/null 2>&1; then
            patch -d "$SRC" -p1 <"$pf" >/dev/null
            echo "isal patch applied: $(basename "$pf")"
            rm -f "$SRC/bin/isa-l.a"      # force a rebuild
        else
            echo "ISA-L PATCH FAILED TO APPLY: $(basename "$pf")" >&2
            echo "The tree may be a different ISA-L version than the patch expects." >&2
            exit 1
        fi
    done
    if [ "$n_applied" -eq 0 ]; then
        echo "ERROR: isal-patches/ exists but contains no *.patch files." >&2
        exit 1
    fi
fi

# Makefile.unx produces bin/isa-l.a and needs only make + nasm + cc.
if [ ! -f "$SRC/bin/isa-l.a" ]; then
    (cd "$SRC" && make -f Makefile.unx -j"$(nproc 2>/dev/null || echo 4)" >/dev/null)
fi
# Relative, not absolute: this line is echoed into check-verified.log, which
# SHIPS. An absolute path there publishes the builder's home directory and
# username to every reader, and says nothing a relative path does not.
echo "ISA-L v$VER built: ${SRC#"$PWD/"}/bin/isa-l.a"

# TWO Makefiles since the tree was assembled: codec/ is our codec and driver,
# references/ is firedancer's reedsol behind our adapter. Both are built with
# the same CFLAGS and against the same isa-l.a, which is the point of building
# them from one place.
# ISAL_SRC IS NOT PASSED. Both Makefiles default it to a RELATIVE path, which is
# what keeps the builder's home directory out of check-verified.log -- make
# echoes the whole compiler invocation and that echo ships. Overriding it from
# here would either reintroduce an absolute path or write a parent-relative path
# literal into this script, which check_links.py correctly reads as escaping the
# tree since it cannot know make's cwd. So the Makefiles own the path and this
# asserts they agree with $VER rather than restating it. (This comment used to
# contain the literal it warns about, and check_links caught that too.)
# Two assertions, and neither writes a path literal: check_links.py reads a
# literal parent-relative path in a script as escaping the tree, and it is right
# to -- it cannot know make's cwd. So the version is checked without the prefix,
# and relativity is checked as "does not begin with a slash".
for mk in "$ROOT/codec/Makefile" "$ROOT/references/Makefile"; do
    grep -q "ISAL_SRC ?= .*isa-l-$VER\$" "$mk" || {
        echo "ERROR: $mk does not default ISAL_SRC to isa-l-$VER" >&2
        echo "       bootstrap fetched v$VER; the Makefile must match." >&2
        exit 1
    }
    grep -qE '^ISAL_SRC \?= [^/]' "$mk" || {
        echo "ERROR: $mk sets an ABSOLUTE ISAL_SRC." >&2
        echo "       make echoes the compiler invocation into check-verified.log," >&2
        echo "       which ships, so the path must be relative." >&2
        exit 1
    }
done
cd "$ROOT/codec"
make all
cd "$ROOT/references"
make all
echo "rs-point and probes built"
