# Reproducing the finite verification

Requirements: Rust/Cargo with the locked dependencies already present in the local Cargo
cache, a POSIX shell, `shasum`, and Python 3 only if intentionally rebuilding tables from
the separate predecessor inputs. Verification itself does not use Python or the network.

From the artifact root:

```bash
./verify_artifact.sh
./quick_verify.sh
THREADS=4 ./full_verify.sh
```

`quick_verify.sh` checks file integrity, Rust tests, complete table coverage, every support's
precode validity and source reconstruction, all-ESI Encoder equality for direct-discovery
supports, eight Encoder spots for every converted support, representative exact canonical
and random weights, and the exact hypergeometric calculation.

`full_verify.sh` additionally checks every claimed canonical `f` and recomputes the exact
65,521-ESI weight `M` for every random witness. The thread count is clamped to 1 through 8.
All Cargo invocations use `--locked --offline` and temporary build directories.

For interpreting the curated discovery evidence, direct intermediate-code enumeration was
exhaustive through weights 1 through 6 for every standardized `K=4..47`. Additional
representative searches exhausted `K=48,64,128` through weight 6 and `K=256,512,1024`
through weight 4. No exhaustive intermediate-space search through `K=8192` is claimed.

Maintainer-only table reconstruction, when the predecessor artifact and investigation are
available as sibling directories:

```bash
python3 tools/build_witness_tables.py \
  --old-artifact ../sparse-intermediate-investigation/r10-larger-n-artifact \
  --investigation ../sparse-intermediate-investigation \
  --output-root .
```

This construction command is not a proof step. Regenerated tables must still pass the
independent verifier and artifact integrity must be intentionally refreshed.
