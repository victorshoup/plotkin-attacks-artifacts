#!/usr/bin/env python3
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
rows = []
for path in sorted(root.rglob("*")):
    if not path.is_file() or path.name == "SHA256SUMS.txt" or "target" in path.parts:
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    rows.append(f"{digest}  {path.relative_to(root).as_posix()}")
(root / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n")
print(f"hashed_files={len(rows)}")

