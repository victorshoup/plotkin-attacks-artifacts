# Curated investigation evidence

- `small_k_minimum_weights.csv`: minimum valid and attack-candidate weights after exhaustive
  search of every exact weight 1 through 6 for every standardized `K=4..45`.
- `small_k_search_statistics.csv`: exact candidate counts and measured discovery runtimes.
- `representative_comparison.csv` and `representative_search_statistics.csv`: direct-search
  comparisons above the old threshold and explicit exhausted ranges. In particular, the
  statistics continue the exhaustive exact-weight-1-through-weight-6 enumeration at
  `K=46,47`; they also record the representative exhaustive searches at `K=48,64,128`
  through weight 6 and `K=256,512,1024` through weight 4.
- `current_witness_intermediate_weights.csv`: independently reconstructed intermediate
  supports and weights for all predecessor family-distinct witnesses.

These files document discovery and migration. They are not read by the proof verifier.

Taken together, the small-`K` and representative statistics establish exhaustive direct
intermediate-code enumeration through weights 1 through 6 for every standardized
`K=4..47`. No exhaustive intermediate-space search through `K=8192` is claimed.
