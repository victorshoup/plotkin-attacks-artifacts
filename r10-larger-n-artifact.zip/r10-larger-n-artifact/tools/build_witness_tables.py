#!/usr/bin/env python3
"""Construct compact intermediate-support tables from reviewed predecessor data.

This is provenance/construction tooling, not part of proof verification. The verifier
consumes only the emitted tables and the pinned R10 implementation.
"""

import argparse
import csv
from collections import defaultdict
from pathlib import Path

MAX_F = 16380
REPRESENTATIVE_OVERRIDES = {46, 47, 48, 64, 128, 256, 512, 1024}


def read_csv(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def pair_key(row):
    return row["family"], int(row["K"]), row["source_pair"]


def candidate_rows(path):
    rows = read_csv(path)
    for row in rows:
        if row["verification_status"] != "VERIFIED":
            raise ValueError("candidate input is not independently verified")
    return rows


def support_record(row, provenance):
    return {
        "K": int(row["K"]),
        "support": row["intermediate_support"],
        "intermediate_weight": int(row["intermediate_weight"]),
        "source_support": row["source_representation"],
        "provenance": provenance,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--old-artifact", type=Path, required=True)
    parser.add_argument("--investigation", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    old = args.old_artifact
    inv = args.investigation
    out = args.output_root

    current = {pair_key(row): row for row in read_csv(inv / "current_witness_intermediate_weights.csv")}
    small = candidate_rows(inv / "new_sparse_intermediate_candidates.csv")
    representative = candidate_rows(inv / "representative_sparse_candidates.csv")

    small_canonical = defaultdict(list)
    small_random = {}
    for row in small:
        k = int(row["K"])
        if "canonical" in row["purpose"]:
            small_canonical[k].append(row)
        if "random" in row["purpose"]:
            small_random[k] = row

    rep_canonical = defaultdict(list)
    rep_random = {}
    for row in representative:
        k = int(row["K"])
        if "canonical" in row["purpose"]:
            rep_canonical[k].append(row)
        if "random" in row["purpose"]:
            rep_random[k] = row

    old_fixed = read_csv(old / "witnesses/canonical_fixed_pairs.csv")
    old_random = read_csv(old / "witnesses/random_fullcycle_pairs.csv")
    fixed_by_k = {int(row["K"]): row for row in old_fixed}
    random_by_k = {int(row["K"]): row for row in old_random}

    canonical = []
    for k in [30, 34] + list(range(35, 8193)):
        if k in small_canonical:
            for row in small_canonical[k]:
                record = support_record(row, "small_direct_exhaustive_weights_1_6")
                record["f_ranges"] = row["canonical_validity_range"]
                canonical.append(record)
        elif k in rep_canonical:
            for row in rep_canonical[k]:
                max_weight = 6 if k <= 128 else 4
                record = support_record(row, f"representative_direct_exhaustive_weights_1_{max_weight}")
                record["f_ranges"] = row["canonical_validity_range"]
                canonical.append(record)
        else:
            old_row = fixed_by_k[k]
            source_pair = f'{old_row["a"]};{old_row["b"]}'
            weight_row = current[("canonical", k, source_pair)]
            canonical.append({
                "K": k,
                "support": weight_row["intermediate_support"],
                "intermediate_weight": int(weight_row["intermediate_weight"]),
                "f_ranges": f"{(k + 1) // 2}-{MAX_F}",
                "source_support": source_pair,
                "provenance": "converted_verified_old_source_pair",
            })

    random = []
    for k in [25, 29, 30, 31] + list(range(34, 8193)):
        if k in small_random:
            row = small_random[k]
            record = support_record(row, "small_direct_exhaustive_weights_1_6")
            record["M"] = int(row["full_cycle_weight_M"])
            random.append(record)
        elif k in rep_random:
            row = rep_random[k]
            max_weight = 6 if k <= 128 else 4
            record = support_record(row, f"representative_direct_exhaustive_weights_1_{max_weight}")
            record["M"] = int(row["full_cycle_weight_M"])
            random.append(record)
        else:
            old_row = random_by_k[k]
            source_pair = f'{old_row["a"]};{old_row["b"]}'
            weight_row = current[("random", k, source_pair)]
            random.append({
                "K": k,
                "support": weight_row["intermediate_support"],
                "intermediate_weight": int(weight_row["intermediate_weight"]),
                "M": int(old_row["M"]),
                "source_support": source_pair,
                "provenance": "converted_verified_old_source_pair",
            })

    canonical.sort(key=lambda row: (row["K"], [int(x) for x in row["support"].split(";")]))
    random.sort(key=lambda row: row["K"])
    write_csv(
        out / "witnesses/canonical_intermediate_witnesses.csv",
        ["K", "support", "intermediate_weight", "f_ranges", "source_support", "provenance"],
        canonical,
    )
    write_csv(
        out / "witnesses/random_intermediate_witnesses.csv",
        ["K", "support", "intermediate_weight", "M", "source_support", "provenance"],
        random,
    )

    new_canonical = defaultdict(list)
    for row in canonical:
        new_canonical[row["K"]].append(row["support"])
    new_random = {row["K"]: row["support"] for row in random}

    mapping = []
    for row in old_fixed:
        k = int(row["K"])
        pair = f'{row["a"]};{row["b"]}'
        old_weight = current[("canonical", k, pair)]
        replacements = new_canonical[k]
        mapping.append({
            "family": "canonical",
            "K": k,
            "old_source_support": pair,
            "old_intermediate_support": old_weight["intermediate_support"],
            "old_intermediate_weight": old_weight["intermediate_weight"],
            "old_selection_ranges": f"{(k + 1) // 2}-{MAX_F}",
            "new_intermediate_supports": "|".join(replacements),
            "disposition": "retained_as_intermediate" if old_weight["intermediate_support"] in replacements else "superseded_by_stronger_intermediate",
        })

    k47_ranges = defaultdict(list)
    for row in read_csv(old / "witnesses/canonical_k47_intervals.csv"):
        pair = f'{row["a"]};{row["b"]}'
        k47_ranges[pair].append(f'{row["f_first"]}-{row["f_last"]}')
    for pair, ranges in sorted(k47_ranges.items()):
        old_weight = current[("canonical", 47, pair)]
        mapping.append({
            "family": "canonical",
            "K": 47,
            "old_source_support": pair,
            "old_intermediate_support": old_weight["intermediate_support"],
            "old_intermediate_weight": old_weight["intermediate_weight"],
            "old_selection_ranges": ";".join(ranges),
            "new_intermediate_supports": "|".join(new_canonical[47]),
            "disposition": "superseded_by_uniform_intermediate",
        })

    for row in old_random:
        k = int(row["K"])
        pair = f'{row["a"]};{row["b"]}'
        old_weight = current[("random", k, pair)]
        replacement = new_random[k]
        mapping.append({
            "family": "random",
            "K": k,
            "old_source_support": pair,
            "old_intermediate_support": old_weight["intermediate_support"],
            "old_intermediate_weight": old_weight["intermediate_weight"],
            "old_selection_ranges": "",
            "new_intermediate_supports": replacement,
            "disposition": "retained_as_intermediate" if old_weight["intermediate_support"] == replacement else "superseded_by_stronger_intermediate",
        })

    mapping.sort(key=lambda row: (row["family"], row["K"], row["old_source_support"]))
    write_csv(
        out / "OLD_TO_NEW_WITNESS_MAPPING.csv",
        ["family", "K", "old_source_support", "old_intermediate_support", "old_intermediate_weight", "old_selection_ranges", "new_intermediate_supports", "disposition"],
        mapping,
    )
    print(f"canonical_rows={len(canonical)}")
    print(f"random_rows={len(random)}")
    print(f"mapping_rows={len(mapping)}")


if __name__ == "__main__":
    main()
