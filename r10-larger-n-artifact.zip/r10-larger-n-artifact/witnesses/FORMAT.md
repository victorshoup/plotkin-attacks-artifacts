# Intermediate witness formats

All CSV files are UTF-8 with one header row, decimal zero-based indices, semicolon-separated
index supports, and Unix line endings. The primary certificate is always `support`: the
support of a nonzero valid R10 intermediate difference immediately before LT encoding.

## `canonical_intermediate_witnesses.csv`

Columns:

- `K`: standardized source dimension;
- `support`: intermediate-symbol support;
- `intermediate_weight`: number of support indices;
- `f_ranges`: semicolon-separated inclusive ranges (`a-b`, or `a` for a singleton) on
  which the support has transmitted weight at most `f` over ESIs `0..4f-1`;
- `source_support`: redundantly recovered support in the predecessor artifact's
  non-systematic source basis;
- `provenance`: discovery/conversion class, unused by the finite proof.

There is one row for `K=30`, two rows for `K=34`, and one row for every `K=35..8192`.
The two `K=34` rows jointly cover every `17<=f<=16380`. Every other row covers the
complete eligible range `ceil(K/2)..16380`. There is no `K=47` special interval table.

## `random_intermediate_witnesses.csv`

Columns:

- `K`, `support`, `intermediate_weight`, `source_support`, and `provenance` as above;
- `M`: exact transmitted weight on the complete ESI population `0..65520`.

There is one fixed row for `K=25,29,30,31` and every `K=34..8192`. Every row satisfies
the exact integer condition `4M < 65521`. Selection is independent of `f`, `n`, the
realized ESI set, and the later honest set.

`source_support` is redundant provenance. The verifier recovers it from `support`,
reconstructs the full intermediate vector, and rejects any mismatch.

