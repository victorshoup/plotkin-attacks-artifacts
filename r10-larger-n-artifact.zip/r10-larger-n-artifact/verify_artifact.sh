#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/r10-sparse-integrity.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
cd "$ROOT"

find . -type f ! -path './SHA256SUMS.txt' -print | sed 's#^\./##' | LC_ALL=C sort > "$TMP/actual.txt"
cut -c 67- SHA256SUMS.txt | LC_ALL=C sort > "$TMP/manifest.txt"
diff -u "$TMP/manifest.txt" "$TMP/actual.txt"
shasum -a 256 -c SHA256SUMS.txt
echo 'PASS: every non-manifest artifact file is listed and matches SHA256SUMS.txt'

