# Provenance

## Authoritative inputs

- predecessor artifact ZIP SHA-256:
  `908d0041c6b343a337578efe503d8fd52d1128c3dcda73972ed75593dd36f740`;
- sparse-intermediate investigation ZIP SHA-256:
  `8e9731ea03c5b92263c01bf033e19de7cbb45cc5c86d06fb88f40623c133c6d9`;
- pinned `monad-raptor` commit:
  `fcafa0d7cb96c18588530c992f25c3d4a73b13dd`.

The complete pinned source snapshot and locked dependency graph were copied unchanged from
the predecessor artifact. The public verifier depends on that local tree and requires no
network access.

## Witness construction

Direct intermediate-code enumeration was exhaustive through weights 1 through 6 for every
standardized `K=4..47`. Additional representative searches exhausted `K=48,64,128` through
weight 6 and `K=256,512,1024` through weight 4. These candidates received an independent
all-65,521-ESI Encoder comparison before inclusion.

For the remaining larger sizes, the predecessor artifact's verified source-pair selection
was converted into its exact intermediate support through the pinned LDPC and Half maps.
Every retained converted support has weight 4 or 6. The resulting support—not the source
pair—is the proof certificate.

`tools/build_witness_tables.py` records the lightweight deterministic construction. Its
external inputs are provenance material; neither it nor discovery state is used by the
verifier. `OLD_TO_NEW_WITNESS_MAPPING.csv` records every predecessor selection and whether
its intermediate support was retained or superseded.

## Evidence boundary

The compact tables are claims. `verifier/src/main.rs` independently checks support syntax,
precode constraints, source recovery, reconstruction equality, LT weights, table coverage,
and public Encoder agreement. Discovery heuristics and structural notes are not proof
premises.
