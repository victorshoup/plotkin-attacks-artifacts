# Sparse-intermediate R10 witness artifact

This artifact verifies strengthened finite adversarial-erasure witnesses for standard R10.
Its proof-critical object is a sparse nonzero valid R10 intermediate difference immediately
before LT encoding—not a source-coordinate pair.

## Results

- Canonical prefixes: every standardized `K=34..8192`, plus isolated `K=30`.
- Uniform random ESIs: every standardized `K=34..8192`, plus isolated
  `K=25,29,30,31`.

At `K=34`, exactly two weight-4 supports cover the complete eligible `f` range. Every
`K>=35` uses one canonical support for its entire eligible range. In particular, `K=47`
now uses one weight-6 support instead of the predecessor's 15 source pairs and 259
selection intervals. Random witnesses use one fixed support per covered `K` and satisfy
the exact full-cycle inequality `4M<65521`.

See `CLAIMS.md` for the precise finite propositions and exclusions.

## Why intermediate supports

Write the intermediate vector as `z=(x,p,h)` for source, LDPC, and Half symbols. The
pinned implementation gives

```text
p + G_LDPC x      = 0
h + G_Half (x,p)  = 0.
```

Thus valid intermediate differences form the kernel of the corresponding block parity-check
matrix. The witness tables store the sparse support of `z`. The first `K` coordinates
recover the non-systematic source difference, but that redundant representation is no longer
the certificate.

An LT output bit is nonzero exactly when its exact RFC 5053 neighbor row meets the support
with odd parity. This permits direct prefix and full-cycle checking.

## Verification

```bash
./verify_artifact.sh
./quick_verify.sh
THREADS=4 ./full_verify.sh
```

The verifier consumes only the two compact witness tables and the pinned implementation.
It does not consume discovery results or the old source-pair tables. See `REPRODUCING.md`
and `witnesses/FORMAT.md`.

## Discovery, honestly separated

Direct intermediate-code enumeration was exhaustive through weights 1 through 6 for every
standardized `K=4..47`. Additional representative searches exhausted `K=48,64,128` through
weight 6 and `K=256,512,1024` through weight 4. For most remaining larger `K`, an efficient
empirical shortcut searched source words `e_a+e_b` in a non-systematic source basis, after
which selected words were converted to intermediate supports of weight 4 or 6. No theorem
is claimed that this heuristic must succeed, and no exhaustive sparse search through
`K=8192` is claimed. Discovery is described in `PROVENANCE.md`; correctness depends only on
direct verification of the stored supports.

Omitted `K` values are not claimed safe.
