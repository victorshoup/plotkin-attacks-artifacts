#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/r10-sparse-quick.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

"$ROOT/verify_artifact.sh"
CARGO_TARGET_DIR="$TMP/target" cargo test --release --locked --offline --manifest-path "$ROOT/verifier/Cargo.toml"
CARGO_TARGET_DIR="$TMP/target" cargo run --release --locked --offline --manifest-path "$ROOT/verifier/Cargo.toml" -- quick
echo 'PASS: compact intermediate tables, constraints, source recovery, Encoder comparisons, selected exact weights, and probability verified'

