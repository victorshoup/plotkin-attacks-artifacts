# Finite claims checked by this artifact

## Common setup

For standardized R10 source size `K`, let `z` be a nonzero valid intermediate difference
immediately before the LT stage. Each proof-critical row stores the support of `z`.
The pinned implementation is identified by `UPSTREAM_COMMIT`.

The non-systematic source coordinates used for recovery differ from systematic coordinates
by an invertible change of basis. This does not change the transmitted R10 code.

## Canonical-prefix proposition

Let `f>=1`, `4f<=65520`, and `3f+1<=n<=4f`. For every standardized

```text
K = 30 or 34 <= K <= 8192,
```

and every honest set of `n-f` positions inside ESIs `0..n-1`, there is a subset of
`n-2f` honest positions whose standard R10 rows have rank less than `K`.

If `K>2f`, rank deficiency follows from row count. Otherwise the canonical table selects
a valid nonzero intermediate difference with weight at most `f` on `0..4f-1`.
Restriction to `0..n-1` and zero-set intersection give the result. `K=34` uses two rows
whose claimed `f` ranges jointly cover the eligible domain; every other covered `K` uses
one row selected by `K` alone.

## Random-ESI proposition

For every standardized

```text
K in {25,29,30,31} or 34 <= K <= 8192,
```

the random table fixes one valid nonzero intermediate difference with exact full-cycle
weight `M` on `Omega={0,...,65520}` and `4M<65521`.

For fixed `K,f` with `K<=2f` and `4f<=65520`, sampling `4f` distinct ESIs uniformly
without replacement gives witness weight

```text
W ~ Hypergeometric(65521, M, 4f).
```

Its mean is below `f`; the hypergeometric median bound gives `Pr[W<=f]>=1/2`. On that
event, every honest set of `3f` sampled rows contains an annihilated subset of `2f` rows.
For `K>2f`, row count already gives rank deficiency.

## Exclusions

This artifact does not claim safety for omitted `K`, optimality of the stated thresholds,
a deterministic result for arbitrary ESI sets, an exhaustive intermediate-space search
through `K=8192`, or an asymptotic theorem. Direct intermediate-code enumeration was
exhaustive through weights 1 through 6 for every standardized `K=4..47`. Additional
representative searches exhausted `K=48,64,128` through weight 6 and `K=256,512,1024`
through weight 4.
