#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/r10-sparse-full.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
THREADS="${THREADS:-4}"

"$ROOT/verify_artifact.sh"
CARGO_TARGET_DIR="$TMP/target" cargo test --release --locked --offline --manifest-path "$ROOT/verifier/Cargo.toml"
CARGO_TARGET_DIR="$TMP/target" cargo run --release --locked --offline --manifest-path "$ROOT/verifier/Cargo.toml" -- full "$THREADS"
echo 'PASS: every canonical interval and every random full-cycle witness verified against the pinned implementation'

