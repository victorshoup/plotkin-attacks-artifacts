use monad_raptor::{Encoder, r10::CodeParameters};
use std::{
    env,
    error::Error,
    fs::{self, File},
    io::{BufWriter, Write},
    path::Path,
};

const MAX_ESI_COUNT: usize = 65_520;

#[derive(Clone, Copy)]
struct FixedCase {
    k: usize,
    a: usize,
    b: usize,
    expected_intermediate_weight: usize,
    expected_max_ratio_f: usize,
    expected_max_ratio_weight: usize,
    expected_min_margin: isize,
}

const FIXED_CASES: [FixedCase; 8] = [
    FixedCase {
        k: 46,
        a: 35,
        b: 38,
        expected_intermediate_weight: 4,
        expected_max_ratio_f: 61,
        expected_max_ratio_weight: 56,
        expected_min_margin: 3,
    },
    FixedCase {
        k: 48,
        a: 10,
        b: 21,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 16_228,
        expected_max_ratio_weight: 15_838,
        expected_min_margin: 3,
    },
    FixedCase {
        k: 61,
        a: 11,
        b: 13,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 3_880,
        expected_max_ratio_weight: 3_359,
        expected_min_margin: 9,
    },
    FixedCase {
        k: 62,
        a: 3,
        b: 4,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 426,
        expected_max_ratio_weight: 386,
        expected_min_margin: 5,
    },
    FixedCase {
        k: 73,
        a: 2,
        b: 3,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 120,
        expected_max_ratio_weight: 119,
        expected_min_margin: 1,
    },
    FixedCase {
        k: 75,
        a: 1,
        b: 2,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 54,
        expected_max_ratio_weight: 53,
        expected_min_margin: 1,
    },
    FixedCase {
        k: 84,
        a: 1,
        b: 2,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 43,
        expected_max_ratio_weight: 42,
        expected_min_margin: 1,
    },
    FixedCase {
        k: 8_192,
        a: 3,
        b: 4,
        expected_intermediate_weight: 6,
        expected_max_ratio_f: 7_036,
        expected_max_ratio_weight: 93,
        expected_min_margin: 4_043,
    },
];

fn fail(message: impl Into<String>) -> Box<dyn Error> {
    std::io::Error::other(message.into()).into()
}

fn intermediate_weight(
    k: usize,
    a: usize,
    b: usize,
) -> Result<(usize, usize, usize, usize), Box<dyn Error>> {
    let parameters = CodeParameters::new(k)?;
    let s = parameters.num_ldpc_symbols();
    let h = parameters.num_half_symbols();
    let l = parameters.num_intermediate_symbols();
    let mut source = vec![0u8; k];
    source[a] = 1;
    source[b] = 1;

    let mut ldpc = vec![0u8; s];
    parameters.g_ldpc(|row, column| ldpc[row] ^= source[column]);
    let mut half = vec![0u8; h];
    parameters.g_half(|row, column| {
        let value = if column < k {
            source[column]
        } else {
            ldpc[column - k]
        };
        half[row] ^= value;
    });

    let weight = source
        .iter()
        .chain(&ldpc)
        .chain(&half)
        .filter(|&&x| x != 0)
        .count();
    Ok((weight, s, h, l))
}

fn packed_basis_encoder(k: usize) -> Result<(Encoder<'static>, usize), Box<dyn Error>> {
    let bytes_per_symbol = k.div_ceil(8);
    let mut source = vec![0u8; k * bytes_per_symbol];
    for j in 0..k {
        source[j * bytes_per_symbol + j / 8] = 1u8 << (j % 8);
    }
    // Encoder borrows its source. This bounded validation process intentionally keeps
    // the basis alive until process exit so the ordinary public Encoder API is used.
    let source: &'static [u8] = Box::leak(source.into_boxed_slice());
    Ok((Encoder::new(source, bytes_per_symbol)?, bytes_per_symbol))
}

fn bit(output: &[u8], column: usize) -> usize {
    usize::from((output[column / 8] >> (column % 8)) & 1)
}

fn validate_fixed_pairs(output_dir: &Path) -> Result<(), Box<dyn Error>> {
    let prefix_file = File::create(output_dir.join("real_encoder_fixed_pair_prefixes.csv"))?;
    let mut prefixes = BufWriter::new(prefix_file);
    writeln!(prefixes, "K,a,b,f,n,weight,margin,pass")?;

    let summary_file = File::create(output_dir.join("real_encoder_fixed_pair_summary.csv"))?;
    let mut summaries = BufWriter::new(summary_file);
    writeln!(
        summaries,
        "K,a,b,intermediate_weight,max_ratio,max_ratio_f,max_ratio_weight,min_margin,all_attack_nontrivial,expected_intermediate_weight,expected_max_ratio_f,expected_max_ratio_weight,expected_min_margin,summary_match"
    )?;

    for case in FIXED_CASES {
        let (actual_iw, _, _, _) = intermediate_weight(case.k, case.a, case.b)?;
        if actual_iw != case.expected_intermediate_weight {
            return Err(fail(format!(
                "K={} pair ({},{}) intermediate weight mismatch: actual {}, expected {}",
                case.k, case.a, case.b, actual_iw, case.expected_intermediate_weight
            )));
        }

        let mut source = vec![0u8; case.k];
        source[case.a] = 1;
        source[case.b] = 1;
        let encoder = Encoder::new(&source, 1)?;
        let mut weight = 0usize;
        let mut max_ratio = -1.0f64;
        let mut max_ratio_f = 0usize;
        let mut max_ratio_weight = 0usize;
        let mut min_margin = isize::MAX;
        let mut all_attack = true;

        for esi in 0..MAX_ESI_COUNT {
            let mut encoded = [0u8; 1];
            encoder.encode_symbol(&mut encoded, esi);
            weight += usize::from(encoded[0] != 0);
            let n = esi + 1;
            if n % 4 == 0 {
                let f = n / 4;
                if 2 * f >= case.k {
                    let margin = f as isize - weight as isize;
                    let pass = weight <= f;
                    writeln!(
                        prefixes,
                        "{},{},{},{},{},{},{},{}",
                        case.k,
                        case.a,
                        case.b,
                        f,
                        n,
                        weight,
                        margin,
                        if pass { "PASS" } else { "FAIL" }
                    )?;
                    let ratio = weight as f64 / n as f64;
                    if ratio > max_ratio {
                        max_ratio = ratio;
                        max_ratio_f = f;
                        max_ratio_weight = weight;
                    }
                    min_margin = min_margin.min(margin);
                    all_attack &= pass;
                }
            }
        }

        let summary_match = all_attack
            && max_ratio_f == case.expected_max_ratio_f
            && max_ratio_weight == case.expected_max_ratio_weight
            && min_margin == case.expected_min_margin;
        writeln!(
            summaries,
            "{},{},{},{},{:.12},{},{},{},{},{},{},{},{},{}",
            case.k,
            case.a,
            case.b,
            actual_iw,
            max_ratio,
            max_ratio_f,
            max_ratio_weight,
            min_margin,
            all_attack,
            case.expected_intermediate_weight,
            case.expected_max_ratio_f,
            case.expected_max_ratio_weight,
            case.expected_min_margin,
            if summary_match { "PASS" } else { "FAIL" }
        )?;
        prefixes.flush()?;
        summaries.flush()?;

        if !summary_match {
            return Err(fail(format!(
                "K={} pair ({},{}) real-Encoder summary mismatch: max at f={} weight={}, min margin={}, all_attack={}",
                case.k, case.a, case.b, max_ratio_f, max_ratio_weight, min_margin, all_attack
            )));
        }
    }
    Ok(())
}

fn validate_k47(output_dir: &Path) -> Result<(), Box<dyn Error>> {
    const K: usize = 47;
    let (encoder, bytes_per_symbol) = packed_basis_encoder(K)?;
    let pairs: Vec<(usize, usize)> = (0..K)
        .flat_map(|a| (a + 1..K).map(move |b| (a, b)))
        .collect();
    let mut weights = vec![0usize; pairs.len()];
    let mut output = vec![0u8; bytes_per_symbol];
    let mut prefixes = BufWriter::new(File::create(
        output_dir.join("real_encoder_k47_exhaustive_prefixes.csv"),
    )?);
    writeln!(prefixes, "K,f,n,min_pair_weight,margin,a,b,pass")?;

    let mut all_attack = true;
    let mut smallest_margin = isize::MAX;
    let mut boundary = (0usize, 0usize, 0usize, 0usize);
    for esi in 0..MAX_ESI_COUNT {
        output.fill(0);
        encoder.encode_symbol(&mut output, esi);
        for (index, &(a, b)) in pairs.iter().enumerate() {
            weights[index] += bit(&output, a) ^ bit(&output, b);
        }
        let n = esi + 1;
        if n % 4 == 0 {
            let f = n / 4;
            if 2 * f >= K {
                let (index, &minimum) = weights
                    .iter()
                    .enumerate()
                    .min_by_key(|&(_, weight)| weight)
                    .unwrap();
                let (a, b) = pairs[index];
                let margin = f as isize - minimum as isize;
                let pass = minimum <= f;
                writeln!(
                    prefixes,
                    "{K},{f},{n},{minimum},{margin},{a},{b},{}",
                    if pass { "PASS" } else { "FAIL" }
                )?;
                if margin < smallest_margin {
                    smallest_margin = margin;
                    boundary = (f, minimum, a, b);
                }
                all_attack &= pass;
                if !pass {
                    prefixes.flush()?;
                    return Err(fail(format!(
                        "K=47 source-pair certificate failed at f={f}: minimum {minimum}, pair ({a},{b})"
                    )));
                }
            }
        }
    }
    prefixes.flush()?;

    let (f, minimum, a, b) = boundary;
    let expected_match = all_attack && (f, minimum, smallest_margin, a, b) == (24, 18, 6, 5, 19);
    let mut summary = BufWriter::new(File::create(
        output_dir.join("real_encoder_k47_exhaustive_summary.csv"),
    )?);
    writeln!(
        summary,
        "K,all_nontrivial_f_attack,smallest_margin_f,min_pair_weight,smallest_margin,a,b,expected_f,expected_weight,expected_margin,expected_a,expected_b,summary_match"
    )?;
    writeln!(
        summary,
        "47,{all_attack},{f},{minimum},{smallest_margin},{a},{b},24,18,6,5,19,{}",
        if expected_match { "PASS" } else { "FAIL" }
    )?;
    summary.flush()?;
    if !expected_match {
        return Err(fail(format!(
            "K=47 real-Encoder summary mismatch: f={f}, weight={minimum}, margin={smallest_margin}, pair=({a},{b})"
        )));
    }
    Ok(())
}

fn validate_k45(output_dir: &Path) -> Result<(), Box<dyn Error>> {
    const K: usize = 45;
    const F: usize = 15_574;
    const N: usize = 4 * F;
    let (encoder, bytes_per_symbol) = packed_basis_encoder(K)?;
    let pairs: Vec<(usize, usize)> = (0..K)
        .flat_map(|a| (a + 1..K).map(move |b| (a, b)))
        .collect();
    let mut weights = vec![0usize; pairs.len()];
    let mut output = vec![0u8; bytes_per_symbol];
    for esi in 0..N {
        output.fill(0);
        encoder.encode_symbol(&mut output, esi);
        for (index, &(a, b)) in pairs.iter().enumerate() {
            weights[index] += bit(&output, a) ^ bit(&output, b);
        }
    }

    let mut pair_file = BufWriter::new(File::create(
        output_dir.join("real_encoder_k45_f15574_pair_weights.csv"),
    )?);
    writeln!(pair_file, "K,f,n,a,b,weight,margin,attack_by_source_pair")?;
    for (&(a, b), &weight) in pairs.iter().zip(&weights) {
        writeln!(
            pair_file,
            "{K},{F},{N},{a},{b},{weight},{},{}",
            F as isize - weight as isize,
            weight <= F
        )?;
    }
    pair_file.flush()?;

    let (index, &minimum) = weights
        .iter()
        .enumerate()
        .min_by_key(|&(_, weight)| weight)
        .unwrap();
    let (a, b) = pairs[index];
    let failure_by = minimum as isize - F as isize;
    let expected_match = (minimum, a, b, failure_by) == (15_859, 31, 37, 285);
    let mut summary = BufWriter::new(File::create(
        output_dir.join("real_encoder_k45_f15574_summary.csv"),
    )?);
    writeln!(
        summary,
        "K,f,n,min_pair_weight,a,b,source_pair_failure_by,expected_min_weight,expected_a,expected_b,expected_failure_by,summary_match,scope"
    )?;
    writeln!(
        summary,
        "45,15574,62296,{minimum},{a},{b},{failure_by},15859,31,37,285,{},source_pairs_only",
        if expected_match { "PASS" } else { "FAIL" }
    )?;
    summary.flush()?;
    if !expected_match {
        return Err(fail(format!(
            "K=45 f=15574 real-Encoder mismatch: minimum {minimum}, pair ({a},{b}), failure by {failure_by}"
        )));
    }
    Ok(())
}

fn validate_precode(output_dir: &Path) -> Result<(), Box<dyn Error>> {
    let mut file = BufWriter::new(File::create(
        output_dir.join("compiled_precode_support.csv"),
    )?);
    writeln!(
        file,
        "K,a,b,S,H,L,intermediate_weight,expected_intermediate_weight,status"
    )?;
    for case in FIXED_CASES {
        let (weight, s, h, l) = intermediate_weight(case.k, case.a, case.b)?;
        let pass = weight == case.expected_intermediate_weight;
        writeln!(
            file,
            "{},{},{},{s},{h},{l},{weight},{},{}",
            case.k,
            case.a,
            case.b,
            case.expected_intermediate_weight,
            if pass { "PASS" } else { "FAIL" }
        )?;
        if !pass {
            file.flush()?;
            return Err(fail(format!(
                "K={} pair ({},{}) precode weight mismatch: actual {}, expected {}",
                case.k, case.a, case.b, weight, case.expected_intermediate_weight
            )));
        }
    }
    file.flush()?;
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let output_dir = env::args().nth(1).ok_or_else(|| {
        fail("usage: cargo run --release --example r10_n4f_boundary_validate -- <output-dir>")
    })?;
    let output_dir = Path::new(&output_dir);
    fs::create_dir_all(output_dir)?;

    validate_fixed_pairs(output_dir)?;
    validate_k47(output_dir)?;
    validate_k45(output_dir)?;
    validate_precode(output_dir)?;
    println!("PASS: every requested compiled-Rust Encoder and precode check matched");
    Ok(())
}
