use monad_raptor::{r10::CodeParameters, Encoder};
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 5 {
        eprintln!(
            "usage: cargo run --release --example r10_structure_trace -- <K> <n> <source_i> <source_j>"
        );
        std::process::exit(2);
    }

    let k: usize = args[1].parse().unwrap();
    let n: usize = args[2].parse().unwrap();
    let source_i: usize = args[3].parse().unwrap();
    let source_j: usize = args[4].parse().unwrap();
    assert!(source_i < source_j && source_j < k);

    let params = CodeParameters::new(k).unwrap();
    let s = params.num_ldpc_symbols();
    let h = params.num_half_symbols();
    let l = params.num_intermediate_symbols();

    let mut source = vec![0u8; k];
    source[source_i] = 1;
    source[source_j] = 1;

    let mut ldpc = vec![0u8; s];
    params.g_ldpc(|row, column| ldpc[row] ^= source[column]);

    let mut half = vec![0u8; h];
    let mut half_column_masks = vec![0u16; k + s];
    params.g_half(|row, column| {
        half_column_masks[column] |= 1u16 << row;
        let value = if column < k {
            source[column]
        } else {
            ldpc[column - k]
        };
        half[row] ^= value;
    });

    let mut intermediate = Vec::with_capacity(l);
    intermediate.extend_from_slice(&source);
    intermediate.extend_from_slice(&ldpc);
    intermediate.extend_from_slice(&half);
    assert_eq!(intermediate.len(), l);

    println!(
        "parameter,{k},{n},{source_i},{source_j},{s},{h},{l},{},{},{}",
        params.num_intermediate_symbols_prime(),
        params.systematic_index(),
        intermediate.iter().filter(|&&value| value != 0).count()
    );

    let source_i_triple = params.ldpc_triple(source_i);
    let source_j_triple = params.ldpc_triple(source_j);
    println!(
        "ldpc_triple,{k},{n},{source_i},{source_j},{source_i},{},{},{}",
        source_i_triple.0, source_i_triple.1, source_i_triple.2
    );
    println!(
        "ldpc_triple,{k},{n},{source_i},{source_j},{source_j},{},{},{}",
        source_j_triple.0, source_j_triple.1, source_j_triple.2
    );

    for (index, &value) in intermediate.iter().enumerate() {
        let (block, block_index) = if index < k {
            ("source", index)
        } else if index < k + s {
            ("ldpc", index - k)
        } else {
            ("half", index - k - s)
        };
        println!(
            "intermediate,{k},{n},{source_i},{source_j},{index},{block},{block_index},{value}"
        );
    }

    let mut half_mask_xor = 0u16;
    for index in 0..k + s {
        if intermediate[index] != 0 {
            let (block, block_index) = if index < k {
                ("source", index)
            } else {
                ("ldpc", index - k)
            };
            let mask = half_column_masks[index];
            half_mask_xor ^= mask;
            println!(
                "half_column,{k},{n},{source_i},{source_j},{index},{block},{block_index},{mask:04x}"
            );
        }
    }
    println!("half_xor,{k},{n},{source_i},{source_j},{half_mask_xor:04x}");

    let encoder = Encoder::new(&source, 1).unwrap();
    assert_eq!(encoder.num_source_symbols(), k);

    for esi in 0..n {
        let mut indices = Vec::new();
        params.lt_sequence_op(esi, |index| indices.push(index));

        let mut source_parity = 0u8;
        let mut ldpc_parity = 0u8;
        let mut half_parity = 0u8;
        for &index in &indices {
            if index < k {
                source_parity ^= intermediate[index];
            } else if index < k + s {
                ldpc_parity ^= intermediate[index];
            } else {
                half_parity ^= intermediate[index];
            }
        }
        let traced_output = source_parity ^ ldpc_parity ^ half_parity;
        let mut actual = [0u8; 1];
        encoder.encode_symbol(&mut actual, esi);
        assert_eq!(actual[0], traced_output, "ESI={esi}");

        let joined = indices
            .iter()
            .map(usize::to_string)
            .collect::<Vec<_>>()
            .join(";");
        println!(
            "esi,{k},{n},{source_i},{source_j},{esi},{},{joined},{source_parity},{ldpc_parity},{half_parity},{traced_output},{}",
            indices.len(), actual[0]
        );
    }
}
