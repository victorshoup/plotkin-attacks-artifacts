use monad_raptor::Encoder;
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 3 {
        eprintln!("usage: cargo run --release --example r10_extract -- <K> <n>");
        std::process::exit(2);
    }
    let k: usize = args[1].parse().unwrap();
    let n: usize = args[2].parse().unwrap();
    let b = k.div_ceil(8);
    let mut src = vec![0u8; k * b];
    for j in 0..k {
        src[j * b + j / 8] |= 1u8 << (j % 8);
    }
    let enc = Encoder::new(&src, b).unwrap();
    assert_eq!(enc.num_source_symbols(), k);
    for esi in 0..n {
        let mut out = vec![0u8; b];
        enc.encode_symbol(&mut out, esi);
        print!("{}", esi);
        for byte in out {
            print!(",{:02x}", byte);
        }
        println!();
    }
}
