use monad_raptor::Encoder;

fn fnv1a64(data: &[u8]) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for &b in data {
        h ^= u64::from(b);
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

fn extract(k: usize, n: usize) -> Vec<Vec<u8>> {
    let b = k.div_ceil(8);
    let mut src = vec![0u8; k * b];
    for j in 0..k {
        src[j * b + j / 8] |= 1u8 << (j % 8);
    }
    let enc = Encoder::new(&src, b).unwrap();
    assert_eq!(enc.num_source_symbols(), k);
    let mut rows = Vec::with_capacity(n);
    for esi in 0..n {
        let mut out = vec![0u8; b];
        enc.encode_symbol(&mut out, esi);
        rows.push(out);
    }
    rows
}

fn lcg(state: &mut u64) -> u8 {
    *state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    (*state >> 56) as u8
}

fn validate_random_source(k: usize, n: usize, rows: &[Vec<u8>]) {
    let symbol_len = 23usize;
    let mut state = 0x726170746f723130u64 ^ ((k as u64) << 32) ^ n as u64;
    let mut src = vec![0u8; k * symbol_len];
    for b in &mut src { *b = lcg(&mut state); }
    let enc = Encoder::new(&src, symbol_len).unwrap();
    for esi in 0..n {
        let mut actual = vec![0u8; symbol_len];
        enc.encode_symbol(&mut actual, esi);
        let mut predicted = vec![0u8; symbol_len];
        for j in 0..k {
            if ((rows[esi][j / 8] >> (j % 8)) & 1) != 0 {
                for z in 0..symbol_len {
                    predicted[z] ^= src[j * symbol_len + z];
                }
            }
        }
        assert_eq!(actual, predicted, "K={k} n={n} ESI={esi}");
    }
}

#[test]
fn packed_generator_matches_python_source_model_and_real_encoder() {
    let cases: &[(usize, usize, u64)] = &[
        (16, 256, 0x829a89b6701ebefd),
        (20, 256, 0xc4efcb10ea8ce8bf),
        (32, 256, 0x05b3ff003ebe49de),
        (65, 256, 0x3e4c8c9d71f94a26),
        (24, 512, 0xef57896b656add73),
        (129, 512, 0x7c519e4590863716),
    ];
    for &(k, n, expected) in cases {
        let rows = extract(k, n);
        let flat: Vec<u8> = rows.iter().flatten().copied().collect();
        assert_eq!(fnv1a64(&flat), expected, "source-model digest mismatch for K={k}, n={n}");
        validate_random_source(k, n, &rows);
    }
}
