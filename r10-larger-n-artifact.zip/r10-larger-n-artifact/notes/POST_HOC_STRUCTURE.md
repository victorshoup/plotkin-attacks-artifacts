# Post hoc structural notes

These notes contain exploratory, post hoc analysis of structural features of the R10
precode that may help explain the observed sparse intermediate witnesses. The analysis was
developed after the witnesses were found empirically and is not used in the proofs or
verification procedures.

Adjacent or otherwise nearby source coordinates often cancel most of their three LDPC
contributions. The remaining source and LDPC coordinates can also have strongly overlapping
Half-code column masks, leaving a valid intermediate difference of weight four or six.
An LT row is nonzero on such a difference precisely when its neighbor set intersects the
support in odd parity.

This observation motivated an efficient large-`K` discovery heuristic. It is not a proof
that a bounded source-pair search always succeeds, not a classification of sparse precode
words, and not needed once a stored intermediate support is verified directly.

