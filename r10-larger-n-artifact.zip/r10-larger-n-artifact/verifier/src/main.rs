use monad_raptor::{
    Encoder,
    r10::{CodeParameters, lt::MAX_TRIPLES},
};
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    error::Error,
    fs,
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
    thread,
};

const Q: usize = 65_521;
const MAX_PREFIX: usize = 65_520;
const MAX_F: usize = 16_380;
const MAX_K: usize = 8192;
const EXPECTED_CANONICAL_ROWS: usize = 8161;
const EXPECTED_RANDOM_ROWS: usize = 8163;

type DynError = Box<dyn Error + Send + Sync>;

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct Support(Vec<usize>);

#[derive(Clone, Debug)]
struct CanonicalWitness {
    support: Support,
    weight: usize,
    ranges: Vec<(usize, usize)>,
    source: Vec<usize>,
    provenance: String,
}

#[derive(Clone, Debug)]
struct RandomWitness {
    support: Support,
    weight: usize,
    m: usize,
    source: Vec<usize>,
    provenance: String,
}

#[derive(Clone, Debug)]
struct Tables {
    canonical: BTreeMap<usize, Vec<CanonicalWitness>>,
    random: BTreeMap<usize, RandomWitness>,
}

fn fail(message: impl Into<String>) -> DynError {
    std::io::Error::other(message.into()).into()
}

fn root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("verifier has artifact parent")
        .to_path_buf()
}

fn parse_usize(text: &str, context: &str) -> Result<usize, DynError> {
    text.parse()
        .map_err(|error| fail(format!("invalid {context} {text:?}: {error}")))
}

fn parse_list(text: &str, context: &str) -> Result<Vec<usize>, DynError> {
    if text.is_empty() {
        return Ok(Vec::new());
    }
    text.split(';')
        .map(|value| parse_usize(value, context))
        .collect()
}

fn parse_ranges(text: &str) -> Result<Vec<(usize, usize)>, DynError> {
    let mut ranges = Vec::new();
    for part in text.split(';') {
        let mut pieces = part.split('-');
        let first = parse_usize(
            pieces.next().ok_or_else(|| fail("missing range start"))?,
            "range",
        )?;
        let last = pieces
            .next()
            .map(|value| parse_usize(value, "range"))
            .transpose()?
            .unwrap_or(first);
        if pieces.next().is_some() || first > last {
            return Err(fail(format!("invalid range {part:?}")));
        }
        ranges.push((first, last));
    }
    Ok(ranges)
}

fn read_rows(path: &Path, header: &str) -> Result<Vec<Vec<String>>, DynError> {
    let text = fs::read_to_string(path)?;
    let mut lines = text.lines();
    if lines.next() != Some(header) {
        return Err(fail(format!("unexpected header in {}", path.display())));
    }
    lines
        .filter(|line| !line.is_empty())
        .map(|line| Ok(line.split(',').map(str::to_owned).collect()))
        .collect()
}

fn read_tables() -> Result<Tables, DynError> {
    let witness_dir = root().join("witnesses");
    let mut canonical: BTreeMap<usize, Vec<CanonicalWitness>> = BTreeMap::new();
    let canonical_rows = read_rows(
        &witness_dir.join("canonical_intermediate_witnesses.csv"),
        "K,support,intermediate_weight,f_ranges,source_support,provenance",
    )?;
    if canonical_rows.len() != EXPECTED_CANONICAL_ROWS {
        return Err(fail(format!(
            "canonical row count {}, expected {EXPECTED_CANONICAL_ROWS}",
            canonical_rows.len()
        )));
    }
    for row in canonical_rows {
        if row.len() != 6 {
            return Err(fail("canonical row has wrong width"));
        }
        let k = parse_usize(&row[0], "canonical K")?;
        canonical.entry(k).or_default().push(CanonicalWitness {
            support: Support(parse_list(&row[1], "canonical support")?),
            weight: parse_usize(&row[2], "canonical weight")?,
            ranges: parse_ranges(&row[3])?,
            source: parse_list(&row[4], "canonical source")?,
            provenance: row[5].clone(),
        });
    }

    let mut random = BTreeMap::new();
    let random_rows = read_rows(
        &witness_dir.join("random_intermediate_witnesses.csv"),
        "K,support,intermediate_weight,M,source_support,provenance",
    )?;
    if random_rows.len() != EXPECTED_RANDOM_ROWS {
        return Err(fail(format!(
            "random row count {}, expected {EXPECTED_RANDOM_ROWS}",
            random_rows.len()
        )));
    }
    for row in random_rows {
        if row.len() != 6 {
            return Err(fail("random row has wrong width"));
        }
        let k = parse_usize(&row[0], "random K")?;
        let witness = RandomWitness {
            support: Support(parse_list(&row[1], "random support")?),
            weight: parse_usize(&row[2], "random weight")?,
            m: parse_usize(&row[3], "random M")?,
            source: parse_list(&row[4], "random source")?,
            provenance: row[5].clone(),
        };
        if random.insert(k, witness).is_some() {
            return Err(fail(format!("duplicate random K={k}")));
        }
    }
    let tables = Tables { canonical, random };
    verify_table_coverage(&tables)?;
    Ok(tables)
}

fn required_canonical_k(k: usize) -> bool {
    k == 30 || (34..=MAX_K).contains(&k)
}

fn required_random_k(k: usize) -> bool {
    matches!(k, 25 | 29 | 30 | 31) || (34..=MAX_K).contains(&k)
}

fn verify_table_coverage(tables: &Tables) -> Result<(), DynError> {
    let expected_canonical = (4..=MAX_K)
        .filter(|&k| required_canonical_k(k))
        .collect::<BTreeSet<_>>();
    let actual_canonical = tables.canonical.keys().copied().collect::<BTreeSet<_>>();
    if actual_canonical != expected_canonical {
        return Err(fail("canonical K coverage mismatch"));
    }
    let expected_random = (4..=MAX_K)
        .filter(|&k| required_random_k(k))
        .collect::<BTreeSet<_>>();
    let actual_random = tables.random.keys().copied().collect::<BTreeSet<_>>();
    if actual_random != expected_random {
        return Err(fail("random K coverage mismatch"));
    }
    for (&k, rows) in &tables.canonical {
        if rows.len() != if k == 34 { 2 } else { 1 } {
            return Err(fail(format!("canonical K={k} has {} rows", rows.len())));
        }
        let first_f = k.div_ceil(2);
        let mut covered = vec![false; MAX_F + 1];
        for row in rows {
            for &(first, last) in &row.ranges {
                if first < first_f || last > MAX_F {
                    return Err(fail(format!(
                        "canonical K={k} range outside eligible domain"
                    )));
                }
                covered[first..=last].fill(true);
            }
        }
        if covered[first_f..=MAX_F].iter().any(|&value| !value) {
            return Err(fail(format!("canonical K={k} has incomplete f coverage")));
        }
    }
    Ok(())
}

fn reconstructed_intermediate(params: &CodeParameters, source: &[u8]) -> Vec<u8> {
    let k = params.num_source_symbols();
    let s = params.num_ldpc_symbols();
    let h = params.num_half_symbols();
    let mut z = vec![0u8; k + s + h];
    z[..k].copy_from_slice(source);
    params.g_ldpc(|row, column| z[k + row] ^= source[column]);
    params.g_half(|row, column| z[k + s + row] ^= z[column]);
    z
}

fn validate_support(
    k: usize,
    support: &Support,
    claimed_weight: usize,
    claimed_source: &[usize],
) -> Result<Vec<u8>, DynError> {
    let params = CodeParameters::new(k)?;
    let values = &support.0;
    if values.is_empty()
        || values.len() != claimed_weight
        || values.windows(2).any(|window| window[0] >= window[1])
        || values
            .iter()
            .any(|&index| index >= params.num_intermediate_symbols())
    {
        return Err(fail(format!("malformed support at K={k}: {values:?}")));
    }
    let source_indices = values
        .iter()
        .copied()
        .filter(|&index| index < k)
        .collect::<Vec<_>>();
    if source_indices != claimed_source || source_indices.is_empty() {
        return Err(fail(format!("source recovery mismatch at K={k}")));
    }
    let mut source = vec![0u8; k];
    for &index in &source_indices {
        source[index] = 1;
    }
    let z = reconstructed_intermediate(&params, &source);
    let actual = z
        .iter()
        .enumerate()
        .filter_map(|(index, &value)| (value != 0).then_some(index))
        .collect::<Vec<_>>();
    if actual != *values {
        return Err(fail(format!(
            "pinned precode reconstruction mismatch at K={k}"
        )));
    }
    let s = params.num_ldpc_symbols();
    let mut ldpc_checks = z[k..k + s].to_vec();
    params.g_ldpc(|row, column| ldpc_checks[row] ^= z[column]);
    let mut half_checks = z[k + s..].to_vec();
    params.g_half(|row, column| half_checks[row] ^= z[column]);
    if ldpc_checks
        .iter()
        .chain(half_checks.iter())
        .any(|&value| value != 0)
    {
        return Err(fail(format!("precode constraint failure at K={k}")));
    }
    Ok(z)
}

fn support_mask(length: usize, support: &Support) -> Vec<bool> {
    let mut mask = vec![false; length];
    for &index in &support.0 {
        mask[index] = true;
    }
    mask
}

fn in_ranges(ranges: &[(usize, usize)], f: usize) -> bool {
    ranges.iter().any(|&(first, last)| first <= f && f <= last)
}

fn verify_k(tables: &Tables, k: usize, canonical: bool, random: bool) -> Result<(), DynError> {
    let params = CodeParameters::new(k)?;
    let canonical_rows = if canonical {
        tables.canonical.get(&k).cloned().unwrap_or_default()
    } else {
        Vec::new()
    };
    let random_row = if random {
        tables.random.get(&k).cloned()
    } else {
        None
    };
    let mut supports = Vec::<Support>::new();
    for row in &canonical_rows {
        validate_support(k, &row.support, row.weight, &row.source)?;
        if !supports.contains(&row.support) {
            supports.push(row.support.clone());
        }
    }
    if let Some(row) = &random_row {
        validate_support(k, &row.support, row.weight, &row.source)?;
        if !supports.contains(&row.support) {
            supports.push(row.support.clone());
        }
    }
    let masks = supports
        .iter()
        .map(|support| support_mask(params.num_intermediate_symbols(), support))
        .collect::<Vec<_>>();
    let mut counts = vec![0usize; supports.len()];
    let limit = if random_row.is_some() { Q } else { MAX_PREFIX };
    for esi in 0..limit {
        let mut parity = vec![false; supports.len()];
        params.lt_sequence_op(esi, |symbol| {
            for index in 0..supports.len() {
                parity[index] ^= masks[index][symbol];
            }
        });
        for (count, bit) in counts.iter_mut().zip(parity) {
            *count += usize::from(bit);
        }
        if esi < MAX_PREFIX && (esi + 1) % 4 == 0 {
            let f = (esi + 1) / 4;
            for row in &canonical_rows {
                if in_ranges(&row.ranges, f) {
                    let index = supports
                        .iter()
                        .position(|support| support == &row.support)
                        .unwrap();
                    if counts[index] > f {
                        return Err(fail(format!(
                            "canonical failure K={k}, f={f}, weight={}",
                            counts[index]
                        )));
                    }
                }
            }
        }
    }
    if let Some(row) = random_row {
        let index = supports
            .iter()
            .position(|support| support == &row.support)
            .unwrap();
        let actual = counts[index];
        if actual != row.m || 4 * actual >= Q {
            return Err(fail(format!(
                "random failure K={k}: claimed M={}, actual M={actual}",
                row.m
            )));
        }
    }
    Ok(())
}

fn verify_range(
    tables: &Tables,
    canonical: bool,
    random: bool,
    requested_threads: usize,
) -> Result<(), DynError> {
    if MAX_TRIPLES != Q {
        return Err(fail(format!("MAX_TRIPLES={MAX_TRIPLES}, expected {Q}")));
    }
    let ks = (4..=MAX_K)
        .filter(|&k| {
            (canonical && tables.canonical.contains_key(&k))
                || (random && tables.random.contains_key(&k))
        })
        .collect::<Vec<_>>();
    let threads = requested_threads.clamp(1, 8).min(ks.len());
    let chunk_size = ks.len().div_ceil(threads);
    let progress = Arc::new(AtomicUsize::new(0));
    let total = ks.len();
    eprintln!(
        "verification: {total} K values, canonical={canonical}, random={random}, threads={threads}"
    );
    let nested = thread::scope(|scope| {
        let mut handles = Vec::new();
        for chunk in ks.chunks(chunk_size) {
            let progress = Arc::clone(&progress);
            handles.push(scope.spawn(move || {
                for &k in chunk {
                    verify_k(tables, k, canonical, random)?;
                    let done = progress.fetch_add(1, Ordering::Relaxed) + 1;
                    if done % 250 == 0 || done == total {
                        eprintln!("verification progress: {done}/{total}");
                    }
                }
                Ok::<(), DynError>(())
            }));
        }
        handles
            .into_iter()
            .map(|handle| handle.join().expect("worker panicked"))
            .collect::<Result<Vec<_>, _>>()
    });
    nested?;
    if canonical {
        println!("canonical PASS: K=30 and every K=34..8192; every claimed f interval verified");
    }
    if random {
        let maximum = tables
            .random
            .iter()
            .map(|(&k, row)| (row.m, k))
            .max()
            .unwrap();
        println!(
            "random PASS: K=25,29,30,31 and every K=34..8192; {} witnesses; maximum M={} at K={}; 4M={} < Q={Q}",
            tables.random.len(),
            maximum.0,
            maximum.1,
            4 * maximum.0
        );
    }
    Ok(())
}

fn direct_provenance(provenance: &str) -> bool {
    provenance.starts_with("small_direct_") || provenance.starts_with("representative_direct_")
}

fn verify_encoder_one(
    k: usize,
    support: &Support,
    source_indices: &[usize],
    all_esis: bool,
) -> Result<(), DynError> {
    let params = CodeParameters::new(k)?;
    let z = validate_support(k, support, support.0.len(), source_indices)?;
    let mut source = vec![0u8; k];
    for &index in source_indices {
        source[index] = 1;
    }
    let encoder = Encoder::new(&source, 1)?;
    let spots = [0usize, 1, 2, 3, 95, 1024, 65_519, 65_520];
    let esis: Box<dyn Iterator<Item = usize>> = if all_esis {
        Box::new(0..Q)
    } else {
        Box::new(spots.into_iter())
    };
    for esi in esis {
        let mut direct = 0u8;
        params.lt_sequence_op(esi, |symbol| direct ^= z[symbol]);
        let mut actual = [0u8; 1];
        encoder.encode_symbol(&mut actual, esi);
        if direct != actual[0] {
            return Err(fail(format!(
                "Encoder mismatch K={k}, support={:?}, ESI={esi}",
                support.0
            )));
        }
    }
    Ok(())
}

fn verify_encoder_comparison(tables: &Tables) -> Result<(), DynError> {
    let mut seen = BTreeSet::new();
    let mut exact = 0usize;
    let mut spots = 0usize;
    for (&k, rows) in &tables.canonical {
        for row in rows {
            if seen.insert((k, row.support.clone())) {
                let all = direct_provenance(&row.provenance);
                verify_encoder_one(k, &row.support, &row.source, all)?;
                exact += usize::from(all);
                spots += usize::from(!all);
            }
        }
    }
    for (&k, row) in &tables.random {
        if seen.insert((k, row.support.clone())) {
            let all = direct_provenance(&row.provenance);
            verify_encoder_one(k, &row.support, &row.source, all)?;
            exact += usize::from(all);
            spots += usize::from(!all);
        }
    }
    println!(
        "Encoder comparison PASS: {exact} direct-discovery supports checked on all {Q} ESIs; {spots} converted supports checked at 8 ESIs"
    );
    Ok(())
}

#[derive(Default)]
struct KahanSum {
    sum: f64,
    correction: f64,
}

impl KahanSum {
    fn add(&mut self, value: f64) {
        let adjusted = value - self.correction;
        let next = self.sum + adjusted;
        self.correction = (next - self.sum) - adjusted;
        self.sum = next;
    }
}

fn hypergeom_cdf(q: usize, m: usize, n: usize, threshold: usize) -> f64 {
    let low = n.saturating_sub(q - m);
    let high = n.min(m);
    if threshold < low {
        return 0.0;
    }
    if threshold >= high {
        return 1.0;
    }
    let mode =
        ((((n + 1) as u128) * ((m + 1) as u128) / ((q + 2) as u128)) as usize).clamp(low, high);
    let mut total = KahanSum::default();
    let mut cdf = KahanSum::default();
    total.add(1.0);
    if mode <= threshold {
        cdf.add(1.0);
    }
    let mut k = mode;
    let mut weight = 1.0;
    while k > low {
        weight *=
            (k as f64) * ((q - m - n + k) as f64) / (((m - k + 1) as f64) * ((n - k + 1) as f64));
        k -= 1;
        total.add(weight);
        if k <= threshold {
            cdf.add(weight);
        }
    }
    k = mode;
    weight = 1.0;
    while k < high {
        weight *=
            ((m - k) as f64) * ((n - k) as f64) / (((k + 1) as f64) * ((q - m - n + k + 1) as f64));
        k += 1;
        total.add(weight);
        if k <= threshold {
            cdf.add(weight);
        }
    }
    cdf.sum / total.sum
}

fn verify_probability(tables: &Tables) -> Result<(), DynError> {
    let mut minimum = (f64::INFINITY, 0usize, 0usize, 0usize);
    for f in 1..=MAX_F {
        let worst = tables
            .random
            .iter()
            .filter(|(k, _)| **k <= 2 * f)
            .max_by_key(|(_, row)| row.m);
        if let Some((&k, row)) = worst {
            let probability = hypergeom_cdf(Q, row.m, 4 * f, f);
            if probability < minimum.0 {
                minimum = (probability, k, f, row.m);
            }
        }
    }
    if minimum.0 < 0.5 {
        return Err(fail(format!("probability below 1/2: {:.17}", minimum.0)));
    }
    println!(
        "probability PASS: minimum fixed-witness probability {:.17} at K={}, f={}, M={}",
        minimum.0, minimum.1, minimum.2, minimum.3
    );
    Ok(())
}

fn verify_quick(tables: &Tables) -> Result<(), DynError> {
    for k in [25usize, 30, 34, 35, 46, 47, 48, 64, 1024, 8192] {
        verify_k(
            tables,
            k,
            tables.canonical.contains_key(&k),
            tables.random.contains_key(&k),
        )?;
    }
    verify_encoder_comparison(tables)?;
    verify_probability(tables)?;
    println!(
        "quick PASS: table coverage, selected exact weights, constraints, source recovery, Encoder comparisons, and probability"
    );
    Ok(())
}

fn usage(program: &str) {
    eprintln!(
        "usage: {program} {{quick|canonical [threads]|random [threads]|full [threads]|probability|encoder}}"
    );
}

fn main() -> Result<(), DynError> {
    let args = env::args().collect::<Vec<_>>();
    let mode = args.get(1).map(String::as_str).unwrap_or("quick");
    let tables = read_tables()?;
    match mode {
        "quick" => verify_quick(&tables)?,
        "canonical" | "random" | "full" => {
            let threads = args
                .get(2)
                .map(|value| parse_usize(value, "threads"))
                .transpose()?
                .unwrap_or(4);
            verify_range(
                &tables,
                matches!(mode, "canonical" | "full"),
                matches!(mode, "random" | "full"),
                threads,
            )?;
            verify_encoder_comparison(&tables)?;
            if mode == "full" {
                verify_probability(&tables)?;
            }
        }
        "probability" => verify_probability(&tables)?,
        "encoder" => verify_encoder_comparison(&tables)?,
        _ => {
            usage(&args[0]);
            return Err(fail(format!("unknown mode {mode:?}")));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tables_have_exact_coverage_and_k47_is_uniform() {
        let tables = read_tables().unwrap();
        assert_eq!(
            tables.canonical.values().map(Vec::len).sum::<usize>(),
            EXPECTED_CANONICAL_ROWS
        );
        assert_eq!(tables.random.len(), EXPECTED_RANDOM_ROWS);
        let k47 = &tables.canonical[&47];
        assert_eq!(k47.len(), 1);
        assert_eq!(k47[0].support.0, vec![30, 32, 35, 41, 51, 54]);
        assert_eq!(k47[0].ranges, vec![(24, MAX_F)]);
    }

    #[test]
    fn known_small_support_reconstructs_exactly() {
        let tables = read_tables().unwrap();
        let row = &tables.canonical[&30][0];
        validate_support(30, &row.support, 4, &[20, 22, 25]).unwrap();
    }

    #[test]
    fn all_random_rows_satisfy_integer_criterion() {
        let tables = read_tables().unwrap();
        assert!(tables.random.values().all(|row| 4 * row.m < Q));
    }
}
