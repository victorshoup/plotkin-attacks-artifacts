# Artifact layout

- `README.md`, `CLAIMS.md`, `PROVENANCE.md`, `REPRODUCING.md`: public documentation.
- `witnesses/`: compact proof-critical intermediate-support tables and schema.
- `verifier/`: independent table-only Rust verifier with locked local dependency.
- `monad-raptor/`, `UPSTREAM_COMMIT`: unchanged pinned implementation snapshot.
- `OLD_TO_NEW_WITNESS_MAPPING.csv`: machine-readable migration audit.
- `tools/`: lightweight maintainer table construction only.
- `investigation/`: curated exhaustive-`K=4..47` and representative search summaries.
- `notes/`: explicitly non-proof-critical post hoc structural context.
- `logs/`: recorded verification and construction outputs.
- `verify_artifact.sh`, `quick_verify.sh`, `full_verify.sh`: public entry points.
- `SHA256SUMS.txt`: complete integrity manifest for every other file.

Build products, Cargo target directories, Monte Carlo outputs, historical raw dumps,
predecessor source-pair witness tables, and duplicate predecessor artifacts are excluded.
