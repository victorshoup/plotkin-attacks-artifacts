# Provenance

## Authoritative parent artifact

This package was derived only from `raptorq-subfield-appendix-artifact-rev3.zip`.
The parent ZIP has SHA-256
`2c4e1c0200d4669a904c60c21fabfbf392bc3467d361217520ad3a938228647f`.
Its ZIP payload contains 31,842 files with 346,867,793 uncompressed file bytes.

Revision 3 remains the authoritative archival snapshot of the complete saved empirical campaigns.
This slim derivative is intended as the publication/review artifact when shipping all cached intermediate records is unnecessary.

## Slimming operation

The slimming operation was performed on 9 September 2026.
It did not rerun either large empirical campaign.
It did not change any retained paper-facing CSV, exact certificate, scientific source file, frozen configuration, selected witness, or profile position mask.

The principal omissions are:

- the complete `empirical/raw/` cache from the full-domain campaign;
- the complete `esi_profiles/raw/` cache from the profile campaign;
- duplicate/full canonical ESI-list storage beyond the retained hash index;
- large per-instance derived tables whose compact aggregates are retained;
- raw validation scratch and worker-concurrency traces;
- one large revision-3 packaging-only profile import audit.

Every omitted parent-artifact file is listed individually in `provenance/REMOVED_REV3_FILES.csv.gz` with its original SHA-256 and regeneration category.
`provenance/REV3_UNCHANGED_SHA256.txt` identifies retained same-path files that remain byte-identical to revision 3.

## Scientific identity

The paper-facing data under `paper_data/` are unchanged.
The exact GF(4), GF(16), and Delsarte certificate material is unchanged.
The empirical/search implementations and analysis source are unchanged.
The pinned independent `nanorq` source is unchanged.
The selected witnesses are unchanged.
The full-domain compact aggregate summaries retained by the paper-data generator are unchanged.
The compact ESI-profile summaries retained by the paper-facing profile comparisons are unchanged.

The original revision-3 scientific digest commitments remain in `provenance/scientific_digests.txt`.
Two of those commitments cover the complete omitted raw empirical caches and therefore cannot be recomputed from the slim package without rerunning the corresponding campaigns.
This is intentional.
The retained material is independently protected by the slim checksum universe and by the revision-3 identity manifest.

## Reproduction boundary

Normal verification does not rerun either large empirical campaign.
The raw records are deterministic outputs of preserved source, seeds, and configurations.
The expensive `env JOBS_OVERRIDE=2 ./reproduce_all.sh --full` path remains available to regenerate them.

The exact Delsarte verification requires Python only.
The exhaustive GF(4) and GF(16) dimension replays and the empirical search implementation use C.
No Rust toolchain is required by `verify_artifact.sh --exact`.

The initial slimming environment did not contain Rust/Cargo, so the original slimming audit relied on the frozen revision-3 GF(4) outputs.
A subsequent C implementation of the GF(4) rank-only certificate independently reproduced both frozen 477-row endpoint tables byte-for-byte under GCC and Clang.
The historical Rust source and frozen `_rust.csv` filenames remain in the package solely as provenance for the independently generated revision-3 certificate.
See `GF4_C_MIGRATION_AUDIT.md`.

## Archived revision-3 metadata

The original revision-3 `README.md`, `CLAIMS.md`, `MANIFEST.md`, `PROVENANCE.md`, and superseded packaging verification entry points are preserved under `provenance/rev3_original_metadata/`.
They are retained for audit history only.
They describe the complete archival revision 3, including raw files deliberately omitted here.
