# Revision 3 compiler verification

Tests were run on 2026-09-06 on `arm64-apple-darwin25.1.0` against the complete
integrated staging tree before final packaging.

| invocation | compiler identity | result | warning count | warning-log path |
|---|---|---:|---:|---|
| `./verify_artifact.sh` | Apple clang 17.0.0 (`clang-1700.4.4.1`) via `/usr/bin/cc` | PASS | 0 | none; temporary warning captures were empty |
| `CC=clang ./verify_artifact.sh` | Apple clang 17.0.0 (`clang-1700.4.4.1`) via `/usr/bin/clang` | PASS | 0 | none; temporary warning captures were empty |

The exact first two `--version` lines recorded by both runs were:

```text
Apple clang version 17.0.0 (clang-1700.4.4.1)
Target: arm64-apple-darwin25.1.0
```

No genuine GNU GCC executable was installed under `gcc`, `gcc-14`, `gcc-15`,
or `gcc-16`. `/usr/bin/gcc --version` reports the same Apple Clang identity and
therefore was not misclassified as GNU GCC or counted as a second compiler
family. The delivered `FINAL_VERIFICATION_REV3.log` contains the complete
fresh-extraction default-compiler run; this file records the concise compiler
matrix.

Both complete runs included checksum-universe verification, historical import
hashes, both empirical analyses, GF(4)/GF(16) dimensions, Delsarte certificates,
all main/profile saved records and identities, 5 main selected witnesses, and
11 profile selected witnesses. A compiler exit failure remained fatal.
