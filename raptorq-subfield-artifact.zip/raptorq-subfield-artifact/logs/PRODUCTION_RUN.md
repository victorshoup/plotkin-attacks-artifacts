# Production run record

Command launched after the final-code pilot passed:

```sh
/usr/bin/time -p env JOBS_OVERRIDE=2 ./raptorq-subfield-appendix-artifact/reproduce_all.sh --full
```

Configuration: master seed `202609050001`, schema 4, exactly two
single-threaded workers, 40 non-early-stopping greedy paths per main instance.

- Pilot projection: 55,051.498 seconds / 15.292 hours on two cores.
- Guarded projection: 66,061.798 seconds / 18.350 hours.
- Main grid actual: 43,922 wall seconds.
- Sensitivity actual: 489 wall seconds.
- Production empirical phases: 44,411 seconds / 12 h 20 min 11 s.
- Enclosing initial command: 44,557.20 real seconds, 88,661.48 user seconds,
  234.81 system seconds.
- Instances: 451,400.
- Paths: 18,017,000.
- Maximum observed worker concurrency: 2; final active workers: 0.

The initial command completed all scientific searches and then exited during
derived SVG generation because the old plotting utility capacity was 1,024
rows. The new positive table has 2,070 rows. Raising this analysis-only constant
to 4,096 passed warning-clean and ASan/UBSan runs. All summaries, previews, and
paper data were subsequently regenerated from the untouched saved raw results.
See `PROVENANCE.md` for the complete discrepancy list.
