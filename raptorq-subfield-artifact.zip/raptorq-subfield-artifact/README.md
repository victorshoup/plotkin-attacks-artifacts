# RaptorQ subfield Appendix A reproducibility artifact, revision 3 slim derivative

This package is a publication-oriented derivative of `raptorq-subfield-appendix-artifact-rev3.zip`.
The authoritative revision-3 ZIP has SHA-256
`2c4e1c0200d4669a904c60c21fabfbf392bc3467d361217520ad3a938228647f`.
The slimming operation changes packaging only.
Every retained scientific source, certificate, paper-facing CSV, compact aggregate, configuration, position mask, and selected witness is preserved byte-for-byte from revision 3.
No paper-facing numerical result was regenerated or replaced during slimming.

## Why this package is smaller

Revision 3 preserved the complete raw output of two deterministic empirical campaigns, including hundreds of thousands of instance records and nearly twenty million recorded greedy paths.
Those records are useful as a forensic archive because they permit analysis without rerunning the search.
They are not irreducible experimental observations: the source, seeds, configurations, and deterministic generators that reproduce them are already included.

This derivative therefore omits the bulky raw caches and large per-instance derived caches while retaining compact paper-facing evidence.
`provenance/REMOVED_REV3_FILES.csv.gz` records every omitted revision-3 path, its byte count, its original SHA-256, its category, and the reproduction command or reason for omission.
The omitted raw campaigns can be regenerated from the retained source with the expensive `reproduce_all.sh --full` path.
A normal verification of this package does **not** rerun either full campaign.

The retained revision-3 `paper_data/README.md` uses the older phrase “RFC-invalid” for `K<10` heat-map cells.
The current paper instead treats those cells simply as outside the experiment’s `K>=10` domain.
The CSV values are unchanged; this derivative preserves the revision-3 paper-data files byte-for-byte.

## Public entry points

From the extracted top-level directory:

```sh
./verify_artifact.sh
./analyze_existing.sh
./smoke_test.sh
```

`verify_artifact.sh` checks the checksum universe, revision-3 byte identity of retained files, the complete removal manifest, compact workload accounting, exact Delsarte certificates, retained aggregate-to-paper transformations, and all shipped selected witnesses against the pinned independent `nanorq` implementation.
It does not rerun either large empirical campaign.

The extended command

```sh
./verify_artifact.sh --extended
```

additionally regenerates the deterministic ESI-profile position masks and repair-locality data.

The strongest command

```sh
./verify_artifact.sh --exact
```

includes the extended checks and also regenerates the exhaustive GF(16) and GF(4) dimension tables for byte-for-byte comparison with the frozen tables.
Both dimension replays are implemented in C; the Delsarte verification is Python-only.
No Rust toolchain is required for the active publication-verification path.
The historical GF(4) Rust source and the frozen output filenames ending in `_rust.csv` are retained only to preserve revision-3 provenance and byte-level identity.

`analyze_existing.sh` deterministically rebuilds every main paper-facing table that can be derived from the retained compact aggregate summaries and checks the retained ESI-profile comparison tables that have the same property.
It does not require raw instance caches.

`smoke_test.sh` copies the slim artifact to temporary storage and runs the original small empirical smoke test there.
It exercises the C search implementation and independent oracle without modifying the extracted artifact.

## Expensive complete reproduction

The original full scientific reproduction machinery is retained.
To regenerate the omitted full-domain campaign, exact components, selected witnesses, and ESI-profile campaign, run:

```sh
env JOBS_OVERRIDE=2 ./reproduce_all.sh --full
```

This is intentionally expensive and is not required merely to verify the publication artifact.
The runner enforces exactly two process-level CPU workers and one thread per worker.

The profile campaign can also be regenerated separately into `build/esi_profile_reproduction/` with:

```sh
./esi_profiles/reproduce_profiles.sh --full
```

## Retained scientific evidence

The slim package retains:

- `paper_data/`: all paper-facing CSVs used for figures, tables, and numerical statements;
- `empirical/summaries/`: compact full-domain aggregate summaries needed to regenerate the main paper data;
- `esi_profiles/summaries/`: compact profile aggregates needed for the published profile comparisons;
- `empirical/witnesses/selected/` and `esi_profiles/witnesses/selected/`: all selected explicit witnesses;
- `dimensions/gf4/` and `dimensions/gf16/`: exact finite dimension certificates, frozen outputs, and C replay sources; the historical GF(4) Rust source is retained for provenance;
- `delsarte/`: exact-rational GF(4) Delsarte certificates and verifier;
- `source/current_empirical/` and `esi_profiles/source/`: the empirical implementations and analysis code;
- `source/nanorq/`: the pinned independent RaptorQ oracle at commit `6295a9525893b9a757dd57431db76fc6ecceafac`;
- all frozen campaign configurations, seeds, and profile position masks;
- `empirical/honest_esi_sets/index.csv`: compact SHA-256 commitments to the 5,000 canonical full-domain honest-ESI lists;
- validation ledgers for the selected witnesses and compact provenance records.

The large omitted files are caches rather than unique observations.
Their original hashes remain committed by the removal manifest.

## Exact and empirical statements

GF(4) dimensions are an exhaustive finite computation over the standardized parameter domain.
The result is `kappa4=1` at `K=30` and `max(0,K-3*H_HDPC)` otherwise.

GF(16) dimensions are an exhaustive finite computation over the same domain.
The result is `kappa16=max(0,K-H_HDPC)` with no exceptions.

The GF(4) Delsarte certificates are exact rational computations.
The universal contradiction begins at `f=72`, where the upper code dimension is 42 and the standardized intermediate code has dimension 43.

All reported search fractions are finite-search success fractions for the documented randomized greedy heuristic.
A failed search is not evidence that no low-weight word exists.
The matched-random expected-word calculation is an existence benchmark, not a search-success probability.

## Trust boundary

`source/current_empirical/` and `esi_profiles/source/` are implementations under test.
`source/nanorq/` is the independent decoder oracle and was not modified to make a witness pass.

The original revision-3 packaging metadata is preserved under `provenance/rev3_original_metadata/` for audit history.
Those archived files describe the full archival revision 3 and are not active entry points for this slim derivative.
