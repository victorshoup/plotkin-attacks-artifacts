# Paper-facing data

These CSVs are the source of record for in-LaTeX `pgfplots` figures and tables.
The three heat-map tables contain the full 22-by-40 rectangular plotting domain;
`valid=0` distinguishes RFC-invalid `K<10` cells from measured zero-success
cells. No interpolation is used.

`dimension_vs_empirical_transition.csv` contains the four requested Delta=0
markers. `gf256_deep_tail.csv` is intentionally separate from the main heat map.
`search_sensitivity.csv` is the aggregate breadth/depth comparison, while
`search_sensitivity_paired.csv` retains every paired sample and the mechanical
canonical minimum-weight monotonicity check.

All success fractions are observed finite-search fractions. `log2_E_q` is an
expected low-weight word count for the matched-random ensemble, not a search
success probability.
