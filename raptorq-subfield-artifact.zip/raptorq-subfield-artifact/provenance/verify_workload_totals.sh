#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)

# Derive the configured full-domain workload without requiring the omitted raw
# instance cache.
. "$ARTIFACT/empirical/config/master.conf"
delta0_points=$((DELTA0_F_MAX - DELTA0_F_MIN + 1))
positive_points=$(awk 'END{print NR-1}' "$ARTIFACT/empirical/config/positive_grid.csv")
deep_points=$(awk 'END{print NR-1}' "$ARTIFACT/empirical/config/deep_tail_grid.csv")
sensitivity_points=$(awk 'END{print NR-1}' "$ARTIFACT/empirical/config/deeper_grid.csv")
main_instances=$((delta0_points*SAMPLES_DELTA0*3*2 + positive_points*SAMPLES_POSITIVE*3*2 + deep_points*SAMPLES_POSITIVE*2))
sensitivity_instances=$((sensitivity_points*SAMPLES_POSITIVE*2))
total_main=$((main_instances+sensitivity_instances))
total_main_paths=$((main_instances*GREEDY_PATHS+sensitivity_instances))
test "$total_main" = 451400
test "$total_main_paths" = 18017000

# Derive the profile workload directly from the three frozen job tables.
profile_instances=$(awk -F, 'NR>1{s+=$8}END{print s+0}' \
    "$ARTIFACT/esi_profiles/config/primary_jobs.csv" \
    "$ARTIFACT/esi_profiles/config/headline_supplement_jobs.csv" \
    "$ARTIFACT/esi_profiles/config/sentinel_jobs.csv")
profile_paths=$((profile_instances*40))
test "$profile_instances" = 47500
test "$profile_paths" = 1900000

test "$(awk 'END{print NR-1}' "$ARTIFACT/empirical/summaries/delta0.csv")" = 111
test "$(awk 'END{print NR-1}' "$ARTIFACT/empirical/summaries/positive_grid.csv")" = 2070
test "$(awk 'END{print NR-1}' "$ARTIFACT/empirical/summaries/gf256_deep_tail.csv")" = 71
test "$(awk 'END{print NR-1}' "$ARTIFACT/esi_profiles/summaries/point_summary.csv")" = 475
test "$(awk 'END{print NR-1}' "$ARTIFACT/esi_profiles/summaries/profile_comparison_all.csv")" = 235

echo "CONFIGURED WORKLOAD PASS: main=451400/18017000 profile=47500/1900000 combined=498900/19917000"
