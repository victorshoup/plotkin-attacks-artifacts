#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
GF4_EXPECTED=4418ee1cdf6743b7419a43d26e6a1c47a9ccc65c4e93178bd72b93704086cb4f
GF16_EXPECTED=af0470fe536e40fd3e490863144405c063dade13676f58726c83469b6b01dcc4
PAPER_EXPECTED=b241363d6847161cbf4d906077ca9470b155ecf867b7a78a66d9946278866551

gf4=$(awk -F, 'NR>1{print $3 "," $4 "," $5 "," $6}' \
    "$HERE/gf4_historical_import_manifest.csv" | LC_ALL=C sort | \
    shasum -a 256 | awk '{print $1}')
test "$gf4" = "$GF4_EXPECTED"

gf16=$(find "$ARTIFACT/dimensions/gf16" -type f \
    ! -name verify_gf16_certificate.sh ! -name verify_gf16_certificate_fast.sh -print | LC_ALL=C sort | \
    while IFS= read -r file; do
        relative=${file#"$ARTIFACT/"}
        hash=$(shasum -a 256 "$file" | awk '{print $1}')
        printf '%s,%s\n' "$relative" "$hash"
    done | shasum -a 256 | awk '{print $1}')
test "$gf16" = "$GF16_EXPECTED"

paper=$(find "$ARTIFACT/paper_data" -maxdepth 1 -type f -print | \
    LC_ALL=C sort | while IFS= read -r file; do
        relative=${file#"$ARTIFACT/"}
        hash=$(shasum -a 256 "$file" | awk '{print $1}')
        printf '%s,%s\n' "$relative" "$hash"
    done | shasum -a 256 | awk '{print $1}')
test "$paper" = "$PAPER_EXPECTED"

# The full empirical-core and integrated-profile scientific digests from rev3
# commit to omitted raw caches and therefore cannot be recomputed without a
# campaign replay. Their original values remain recorded in scientific_digests.txt.
grep -q '^rev2_scientific_core_sha256=8632080212e7cc92ef35ab4a21416150efd0f22581b939c76fb20c51bf72e249$' "$HERE/scientific_digests.txt"
grep -q '^integrated_profile_scientific_sha256=4c644eea57a088626b05a7dfa662acc04f6c30a619e0ff09bca14b3f5f6a0f70$' "$HERE/scientific_digests.txt"

echo "RETAINED SCIENTIFIC DIGEST PASS: gf4=$gf4 gf16=$gf16 main_paper_data=$paper"
echo "NOTE: full raw empirical digests are provenance commitments; rerun reproduce_all.sh --full to recompute them."
