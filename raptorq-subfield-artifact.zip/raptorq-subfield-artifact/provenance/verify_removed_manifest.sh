#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
FILE="$HERE/REMOVED_REV3_FILES.csv.gz"
gzip -t "$FILE"
rows=$(gzip -dc "$FILE" | awk 'END{print NR-1}')
bytes=$(gzip -dc "$FILE" | awk -F, 'NR>1{s+=$2}END{printf "%.0f",s}')
test "$rows" = 31348
test "$bytes" = 326610243
echo "REMOVAL MANIFEST PASS: $rows omitted revision-3 files, $bytes bytes committed by path and SHA-256"
