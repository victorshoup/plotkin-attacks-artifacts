#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
MANIFEST="$HERE/REV3_UNCHANGED_SHA256.txt"
test -s "$MANIFEST"
(cd "$ARTIFACT" && shasum -a 256 -c "$MANIFEST") >/dev/null
count=$(wc -l < "$MANIFEST" | tr -d ' ')
echo "REV3 IDENTITY PASS: $count retained files are byte-identical to authoritative revision 3"
