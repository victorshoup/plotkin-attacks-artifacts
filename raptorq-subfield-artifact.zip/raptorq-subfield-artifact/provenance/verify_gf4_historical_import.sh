#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
MANIFEST="$HERE/gf4_historical_import_manifest.csv"
EXPECTED_ARTIFACT=GF4_RAPTORQ_EXPERIMENT_HANDOFF_2026-09-01.zip
EXPECTED_HASH=4205cbb083f2a5d36569b727275b0049226f69b6cc49b0c68cb0483594039a19

test -s "$MANIFEST"
count=0
while IFS=, read -r original original_hash member target expected role; do
    test "$original" = original_artifact && continue
    test "$original" = "$EXPECTED_ARTIFACT"
    test "$original_hash" = "$EXPECTED_HASH"
    test -n "$member"
    test -n "$role"
    test -f "$ARTIFACT/$target"
    observed=$(shasum -a 256 "$ARTIFACT/$target" | awk '{print $1}')
    test "$observed" = "$expected"
    count=$((count + 1))
done < "$MANIFEST"

test "$count" = 63
echo "GF(4) HISTORICAL IMPORT PASS: $count materialized files match frozen member hashes; nested ZIP not required"
