BEGIN { FS="," }
FNR==1 {
    delete c
    for (i=1;i<=NF;i++) c[$i]=i
    if (!("restart_budget" in c)) exit 2
    next
}
{
    instances++
    paths += $(c["restart_budget"])
}
END { print instances+0 "," paths+0 }
