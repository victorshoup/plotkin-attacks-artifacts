# Manifest guide

`CHECKSUMS.txt` is the single authoritative machine-readable file universe. It
covers every packaged file except itself; recreated `build/` output is excluded.

## Entry points

- `verify_artifact.sh`: complete saved-artifact verification, not a campaign
  rerun.
- `analyze_existing.sh`: exact deterministic regeneration from saved data for
  both empirical components.
- `reproduce_all.sh --full`: expensive two-worker end-to-end reproduction.
- `package.sh`: checksum regeneration, nested-archive guard, and ZIP creation.

## Scientific components

- `dimensions/gf4/`: exact GF(4) dimension evidence and the minimum complete
  frozen Rust/vendor source needed to reproduce it.
- `dimensions/gf16/`: exact GF(16) certificate, results, C source, and checks.
- `delsarte/`: exact rational GF(4) verifiers, nine certificates, and logs.
- `empirical/`: original full-domain Appendix A search and matched-random data,
  canonical honest-ESI store, summaries, witnesses, and validation evidence.
- `esi_profiles/`: later canonical/repair profile configuration, position masks,
  raw records, summaries, witnesses, validation, audit, and profile-specific
  scientific source.
- `paper_data/`: eleven original paper-facing CSVs, byte-identical to revision
  2.
- `paper_data/esi_profiles/`: eight authoritative profile paper-facing CSVs,
  byte-identical to the completed profile campaign.
- `source/current_empirical/`: original C campaign, analysis, and audit source.
- `source/nanorq/`: shared pinned independent-oracle source.

## Provenance and logs

- `provenance/gf4_historical_import_manifest.csv`: 63-file frozen trust record
  replacing the removed historical GF(4) ZIP.
- `provenance/GF4_HISTORICAL_IMPORT_AUDIT.csv`: classification of all 282 old
  artifact members, retained and omitted.
- `provenance/ESI_PROFILE_IMPORT_AUDIT.csv`: path/hash/classification record for
  the completed profile artifact integration.
- `provenance/scientific_digests.txt`: rev2 core, profile, historical GF(4), and
  unified preservation digests.
- `provenance/verify_*.sh`: machine checks for imports, digests, and workload.
- `logs/`: retained production records and revision-3 compiler verification
  summary.

Diagnostic SVGs are previews. Machine-readable CSVs and exact certificates are
the scientific records.
