# Revision 3 provenance

## Immutable construction inputs

Input 1 is `raptorq-subfield-appendix-artifact-rev2.zip`, SHA-256
`bf2c03393ebfcc6203557bba8f6eb022a782e29eaea03acfd0c38cac8699091b`.
It is the sole authoritative base for all pre-existing Appendix A scientific
material.

Input 2 is `raptorq-esi-profile-comparison-2026-09-06.zip`, SHA-256
`fc1db8a7ab1197fffe5643fb1e6169f65658efda611859da48449da27ce35f15`.
It is the authoritative source for the completed ESI-profile scientific
evidence.

The historical provenance input was
`GF4_RAPTORQ_EXPERIMENT_HANDOFF_2026-09-01.zip`, SHA-256
`4205cbb083f2a5d36569b727275b0049226f69b6cc49b0c68cb0483594039a19`.
It was authoritative only for frozen GF(4) dimension and Delsarte material.

All three input hashes were checked before construction. Neither current input
ZIP was overwritten or deleted.

## Construction statement

Revision 3 is revision 2 plus the completed profile campaign, with packaging
and verification integration only. It changes no revision-2 scientific result
and no completed-profile scientific result. No new experiment was run. No
scientific C, Rust, or Python source was changed to silence a warning or ease
integration. Wrapper changes select `${CC:-cc}`, keep warnings visible and
nonfatal, resolve native integrated paths, and make verification read-only.

The profile campaign remains scientifically distinct from the original
full-domain experiment. Its full-domain columns reference the retained main
baseline, not a rerun. Every such published row is mapped exactly in
`esi_profiles/audit/full_domain_baseline_mapping.csv`.

The profile campaign used master seed `202609060101`, schema 4, 40 complete
paths per instance, no early stop, at most two concurrent single-threaded
workers, and no matched-random or adaptive grid. Its completed workload was
47,500 instances and 1,900,000 paths; batch wall time was 3,666 seconds
(61 minutes 6 seconds). Worker logs record maximum concurrency two.

## Byte-level deduplication

The entire completed-profile `nanorq` tree was compared byte-for-byte with
`source/nanorq/` and was identical. Four Appendix source snapshots, five
baseline summary snapshots, and one shared table were also exact duplicates.
Only after those comparisons were 132 duplicate files (10,058,705 bytes)
omitted. The retained shared paths are recorded with both hashes in
`provenance/ESI_PROFILE_IMPORT_AUDIT.csv`.

Profile-specific source remains under `esi_profiles/source/`; raw data, masks,
summaries, witnesses, validation evidence, seed/configuration, and paper data
retain their authoritative bytes. There is no second profile checksum universe.

## Historical GF(4) materialization

The old historical ZIP is absent from revision 3. Before removal, all 282
members were hashed and classified. The 26 paths already materialized in
revision 2 were checked byte-for-byte against their original members. A fresh
Rust replay dependency audit found 37 additional required source/build/license
files; they were materialized in exact original bytes under
`dimensions/gf4/source/`.

The resulting 63 retained files total 668,821 bytes. The complete frozen
member-to-path trust record is
`provenance/gf4_historical_import_manifest.csv`. The full audit records 219
omitted members totaling 64,455,676 bytes, consisting of obsolete empirical
work, unrelated tools/tests, and historical documentation not needed for a
current claim. The manifest verifier and fresh locked Cargo replay establish
that the removed ZIP is no longer required. Delsarte verification uses the
native exact-rational source and certificates.

## Scientific preservation digests

Using the unchanged revision-2 scientific-file definition, both the input
revision-2 core and retained revision-3 core have digest
`8632080212e7cc92ef35ab4a21416150efd0f22581b939c76fb20c51bf72e249`.

The standalone and integrated profile scientific content, after recorded path
normalization and excluding only package/wrapper metadata, both have digest
`4c644eea57a088626b05a7dfa662acc04f6c30a619e0ff09bca14b3f5f6a0f70`.

The domain-separated unified revision-3 scientific digest is
`a32268ad5e5de3713da2e9acd06605f851f9a5cef96eba16230e7b4b1641b3f4`.
Definitions and component digests are in
`provenance/scientific_digests.txt` and are independently recomputed by
`provenance/verify_scientific_digests.sh`.

## Independent oracle and warning policy

`source/nanorq/` is a clean independent oracle pinned at commit
`6295a9525893b9a757dd57431db76fc6ecceafac`. It is not the implementation under
test and was not modified. Saved verification copies and builds it only in a
temporary directory.

GNU GCC may emit a conservative range-analysis warning for unchanged profile
scientific `memset` code while compilation succeeds. Revision 3 records such
warnings and continues; a compiler exit failure remains fatal. Actual compiler
commands, versions, outcomes, warning counts, and log paths are recorded in
`logs/REV3_COMPILER_VERIFICATION.md` after fresh-extraction testing.

## Audit map

The public sidecar `ARTIFACT_REV2_TO_REV3_AUDIT.md` explains construction and
verification. `ARTIFACT_REV2_TO_REV3_CHANGED_FILES.txt` enumerates every
pre-existing revision-2 path modified or removed. The packaged CSV audits cover
every profile input path and every historical GF(4) member. The final tree has
one checksum universe and no nested ZIP/TAR artifacts.
