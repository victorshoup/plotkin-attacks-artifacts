#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CC=${CC:-cc}
export CC
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1
TEMP=$(mktemp -d /tmp/rq-unified-analysis-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/profile_summaries" "$TEMP/profile_paper"
cp -R "$HERE/source/nanorq" "$TEMP/nanorq"
export NANORQ_CHECKOUT="$TEMP/nanorq"

env JOBS_OVERRIDE=2 "$HERE/reproduce_all.sh" --analyze-existing

SUMMARY_OUTPUT_DIR="$TEMP/profile_summaries" \
PAPER_OUTPUT_DIR="$TEMP/profile_paper" \
    "$HERE/esi_profiles/analyze.sh" > "$TEMP/profile_analysis.log"
for file in instance_results.csv zero_set_structure.csv point_summary.csv \
    zero_set_rank_aggregate.csv profile_comparison_all.csv delta0_markers.csv \
    witness_weight_split.csv paired_profile_outcomes.csv \
    canonical_witness_systematic_summary.csv; do
    cmp "$HERE/esi_profiles/summaries/$file" \
        "$TEMP/profile_summaries/$file"
done
for file in delta0_profile_comparison.csv positive_profile_comparison.csv \
    gf256_deep_profile_comparison.csv profile_headline_points.csv \
    systematic_count_effect.csv zero_set_rank_profile_comparison.csv \
    projective_profile_comparison.csv repair_prefix_locality.csv; do
    cmp "$HERE/paper_data/esi_profiles/$file" "$TEMP/profile_paper/$file"
done

echo "UNIFIED EXISTING-DATA ANALYSIS PASS: main and ESI-profile derived data reproduced"
