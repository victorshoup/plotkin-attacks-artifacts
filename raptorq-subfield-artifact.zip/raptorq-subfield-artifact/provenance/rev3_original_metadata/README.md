# RaptorQ subfield Appendix A reproducibility artifact, revision 3

This is the single public reproducibility artifact for Appendix A. Revision 3
combines five evidence classes in one native directory tree:

1. exact exhaustive GF(4) intermediate-code dimensions;
2. exact exhaustive GF(16) intermediate-code dimensions;
3. exact-rational GF(4) Delsarte certificates;
4. the full-domain RaptorQ subfield experiment and matched-random controls; and
5. the later ESI-profile comparison experiment.

No paper file is included or changed. Construction of revision 3 ran no new
empirical search and changed no scientific source, raw data, witness,
certificate, summary, or paper-facing scientific file.

## Public entry points

From the extracted top-level directory:

```sh
./verify_artifact.sh
./analyze_existing.sh
env JOBS_OVERRIDE=2 ./reproduce_all.sh --full
```

`verify_artifact.sh` is the saved-data verifier. It checks the single checksum
universe, frozen provenance, exact dimensions and certificates, every saved
empirical record and structural identity, deterministic summaries, paper data,
and all selected independent `nanorq` validations. It does not rerun either
large empirical campaign.

`analyze_existing.sh` deterministically regenerates and compares derived data
from both saved empirical components. It also performs no search.

`reproduce_all.sh --full` is the expensive end-to-end scientific reproduction
path. It runs the exact components, the original full-domain campaign, the
profile campaign, analysis, and selected-witness validation. Its hard contract
is exactly two CPU-intensive process workers, each single-threaded; common
thread-library limits are set to one.

Artifact-controlled C compilation uses `${CC:-cc}`. For example:

```sh
CC=clang ./verify_artifact.sh
CC=gcc-14 ./verify_artifact.sh
```

Compiler exit failure is a verification failure. Compiler warnings remain
visible and recorded but are nonfatal; scientific source was not changed and
no broad or compiler-specific warning suppression was added.

## Exact and empirical statements

- GF(4): over all 477 RFC-valid standardized `Kprime` values and all 477 band
  minima, `kappa4=1` at `K=30` and `max(0,K-3*H_HDPC)` otherwise.
- GF(16): over the same domain, `kappa16=max(0,K-H_HDPC)` with no exceptions.
- GF(4) Delsarte: exact rational certificates cover `f=68..76`. The universal
  contradiction begins at `f=72`, where the upper dimension is 42 and the
  standardized intermediate code has dimension 43.
- All search fractions are observed finite-search success fractions for the
  documented heuristic. Failure to find a low-weight word is not evidence that
  none exists. The matched-random expected-word calculation is an existence
  benchmark, not a search-success probability.

## Original full-domain empirical component

`empirical/` is the original Appendix A experiment. `full-domain` means honest
ESIs sampled uniformly without replacement from the complete 24-bit RFC 6330
ESI domain. Master seed `202609050001`, schema 4, makes each honest list depend
only on `(f,sample)` and reuses it across applicable fields and overheads.

The retained data contain 451,400 instances and 18,017,000 recorded paths:
22,200 Delta-zero instances; 414,000 positive-grid instances; 14,200 GF(256)
tail instances; and 1,000 search-sensitivity instances. On the 690-point
positive grid, RaptorQ has at least one observed success at 347 GF(4), 145
GF(16), and 427 GF(256) points. The GF(256) deep tail includes nonmonotone
success islands; these are finite-search extrema, not monotone boundaries.

The 451,400 records reference 5,000 canonical ordered ESI lists stored once by
`(f,sample)` under `empirical/honest_esi_sets/`. The exhaustive lossless
canonicalization audit is in `empirical/validation/`.

## ESI-profile empirical component

`esi_profiles/` is a distinct later experiment; it is not a rerun of the
full-domain campaign. It asks whether a natural deployment prefix changes the
observed finite-search landscape:

- `canonical`: transmitted ESIs are `0,...,3f`; the honest set is a uniformly
  random `2f+1` subset.
- `low-repair`: transmitted ESIs are `K,...,K+3f`; this is an explanatory
  all-repair control, not a proposed deployment.
- `shifted-repair`: at five sentinels only, a contiguous repair window starts
  at `2^23`; this too is explanatory.

Canonical and low-repair reuse the same party-position mask at fixed
`(f,sample)`. The component stores 4,100 distinct masks once (1,190,856
uncompressed bytes) and references them from 47,500 saved instances. Its 475
redundant point-level list tables (39,093,230 bytes) were removed only after an
exhaustive pairing/hash audit; no scientific information was lost because each
concrete ESI list is exactly reconstructed from its mask and profile offset.

The saved workload is 46,600 primary, 400 headline-supplement, and 500
shifted-repair instances: 47,500 instances and 1,900,000 paths. Combined with
the original component, revision 3 contains 498,900 empirical instances and
19,917,000 recorded search paths. `provenance/verify_workload_totals.sh`
derives these counts from the retained machine-readable records.

The Delta-zero transitions change little. GF(4) and GF(16) positive-overhead
behavior is broadly similar in aggregate. GF(256) changes more, but not in one
direction: canonical sampling is easier for the specified search at some
points and harder at others. At `(f,Delta)=(96,61)`, the observed counts are
6/100 full-domain, 9/100 canonical, and 18/100 low-repair. Deep GF(256)
successes remain visible. The low-repair locality diagnostic finds no raw-rank
or duplicate-row anomaly. Systematic-coordinate count is not consistently
associated with reduced success, while successful canonical witnesses often
force many systematic coordinates to zero. All 11 selected profile witnesses
pass the pinned independent `nanorq` audit.

`esi_profiles/audit/full_domain_baseline_mapping.csv` maps every published
profile row containing a full-domain value to the exact retained main-data row;
unavailable points are never replaced by neighboring points.

## Trust and packaging boundaries

`source/current_empirical/` and `esi_profiles/source/` are implementations under
test. `source/nanorq/`, pinned at commit
`6295a9525893b9a757dd57431db76fc6ecceafac`, is the independent oracle and was
not modified to make a witness pass.

The old historical GF(4) ZIP is not packaged. The minimum complete source,
result, certificate, verifier, license, and provenance material required for
current GF(4) claims is materialized natively. The 63-file frozen trust record
is `provenance/gf4_historical_import_manifest.csv`; its verifier checks every
retained byte. `provenance/GF4_HISTORICAL_IMPORT_AUDIT.csv` classifies all 282
members of the historical artifact, including the 219 intentionally omitted
members unrelated to current claims.

There is one authoritative `CHECKSUMS.txt`, covering every packaged file except
itself. The final tree contains no nested ZIP or TAR artifact.
