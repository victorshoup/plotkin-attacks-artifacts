# Claim and evidence map

Every search statement below is empirical finite-search evidence. Search
failure is never promoted to a negative coding-theoretic result.

| Claim | Status | Evidence | Verification |
|---|---|---|---|
| For every RFC-valid `K`, `kappa4=1` at `K=30` and `max(0,K-3*H_HDPC)` otherwise | Exact exhaustive finite computation | `dimensions/gf4/` | frozen import manifest plus `dimensions/gf4/verify_gf4_dimensions.sh` |
| For every RFC-valid `K`, `kappa16=max(0,K-H_HDPC)`, with no exceptions | Exact exhaustive finite computation | `dimensions/gf16/` | `dimensions/gf16/verify_gf16_certificate.sh` |
| Exact GF(4) Delsarte contradiction begins at `f=72`; at `(n,d)=(145,73)`, upper dimension 42 contradicts dimension 43 | Exact rational computation | `delsarte/` | nine certificates checked by `verify_delsarte_certificates.py` |
| Delta-zero observed transition markers | Empirical, 100 samples per point | `paper_data/delta0_transition.csv` | raw-data regeneration and count audit |
| Positive-overhead heat maps over 690 valid full-domain points | Empirical | `paper_data/positive_heatmap_gf*.csv` | all cells regenerate from saved records |
| Matched-random comparisons | Empirical search plus analytic existence benchmark | `paper_data/matched_random_summary.csv` | all random ranks and generator regression checked |
| GF(256) deep-tail disappear/reappear behavior | Empirical, nonmonotone finite-search observation | `paper_data/gf256_deep_tail.csv` | complete 71-point actual/random tail |
| Complete-zero-set rank decomposition | Exact identities on empirical witnesses | `paper_data/zero_set_rank_summary.csv` | 52,409 witnesses; zero applicable failures |
| Breadth-versus-depth sensitivity | Paired empirical diagnostic | `paper_data/search_sensitivity*.csv` | 1,000 paired instances and seed/nesting checks |
| Five selected full-domain witnesses encode the claimed differences and zero sets | Independent finite validation | `empirical/witnesses/selected/` | pinned `nanorq` oracle |
| Full-domain ESI canonicalization is lossless | Exhaustive serialization audit | `empirical/honest_esi_sets/` | all 451,400 references and equal normalized digest |

## ESI-profile findings

| Claim | Status | Evidence | Verification |
|---|---|---|---|
| Canonical-prefix Delta-zero transition changes little relative to full-domain sampling | Empirical finite-search evidence | `paper_data/esi_profiles/delta0_profile_comparison.csv` | exact regeneration and baseline mapping |
| GF(4) and GF(16) positive-overhead behavior remains broadly similar | Empirical finite-search evidence | `positive_profile_comparison.csv` | 60 points per field, 100 paired samples |
| GF(256) changes more substantially, but not monotonically in one direction | Empirical finite-search evidence | `positive_profile_comparison.csv`; `gf256_deep_profile_comparison.csv` | pointwise full/canonical/low comparisons |
| Canonical sampling is sometimes easier and sometimes harder for the specified search | Empirical finite-search evidence | `positive_profile_comparison.csv`; `paired_profile_outcomes.csv` | paired party-position masks and search seeds |
| Deep GF(256) successes remain visible | Empirical finite-search evidence | `gf256_deep_profile_comparison.csv` | 11 requested deep points |
| At `(96,61)`, full-domain/canonical/low-repair counts are `6/100`, `9/100`, and `18/100` | Empirical finite-search evidence | `profile_headline_points.csv` | exact full-domain-row mapping and saved counts |
| Low repair prefix has no raw-rank or duplicate-row anomaly in the stated diagnostic | Descriptive empirical diagnostic | `repair_prefix_locality.csv` | 71 `(f,K)` pairs and 16 stratified controls each |
| More systematic honest coordinates are not consistently associated with reduced observed success | Descriptive empirical association, not causality | `systematic_count_effect.csv` | exact hypergeometric mean sanity check; 235 canonical points |
| Successful canonical witnesses often force many systematic coordinates to zero | Descriptive empirical finding | `zero_set_rank_profile_comparison.csv` | all witness split and zero-count identities |
| Eleven selected profile witnesses encode and decode consistently | Independent finite validation | `esi_profiles/witnesses/selected/` | pinned `nanorq` oracle; 11/11 passed |

The complete profile data include 47,500 saved instances and 1,900,000 paths.
The expected matched-random low-weight count `E_q` is never treated as a
search-success probability; when below one it supports only the usual Markov
upper bound.
