#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TEMP=$(mktemp -d /tmp/rq-artifact-verify-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
CC=${CC:-cc}
export CC
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1

echo "VERIFY COMPILER: $CC"
"$CC" --version 2>&1 | sed -n '1,2p'

verify_checksum_universe() {
    test -s "$HERE/CHECKSUMS.txt"
    if ! (cd "$HERE" && shasum -a 256 -c CHECKSUMS.txt) > \
        "$TEMP/checksums.log" 2>&1; then
        cat "$TEMP/checksums.log" >&2
        exit 1
    fi
    (cd "$HERE" && find . -type f ! -path './build/*' \
        ! -name CHECKSUMS.txt -print | LC_ALL=C sort > "$TEMP/actual_files")
    awk '{sub(/^[0-9a-f]+  /, "./"); print}' "$HERE/CHECKSUMS.txt" | \
        LC_ALL=C sort > "$TEMP/manifest_files"
    cmp "$TEMP/actual_files" "$TEMP/manifest_files"
    echo "CHECKSUM UNIVERSE PASS: $(wc -l < "$TEMP/manifest_files" | tr -d ' ') files"
}

verify_checksum_universe

if find "$HERE" -type f \( -name '*.zip' -o -name '*.tar' -o \
    -name '*.tar.gz' -o -name '*.tgz' \) -print -quit | grep -q .; then
    echo "ERROR: nested archive found in unified artifact" >&2
    exit 1
fi

"$HERE/provenance/verify_gf4_historical_import.sh"
"$HERE/provenance/verify_esi_profile_import.sh"
"$HERE/provenance/verify_scientific_digests.sh"
"$HERE/provenance/verify_workload_totals.sh"
"$HERE/esi_profiles/audit/verify_full_domain_baseline_mapping.sh"

# Build the independent oracle only in the verifier's temporary directory so
# verification never changes a checksummed source tree.
cp -R "$HERE/source/nanorq" "$TEMP/nanorq"
make -C "$TEMP/nanorq" -j2 libnanorq.a > "$TEMP/nanorq_build.log" 2>&1
if grep -i 'warning:' "$TEMP/nanorq_build.log" > "$TEMP/nanorq_warnings"; then
    echo "NANORQ COMPILER WARNINGS (nonfatal):" >&2
    cat "$TEMP/nanorq_warnings" >&2
fi
export NANORQ_CHECKOUT="$TEMP/nanorq"

"$HERE/dimensions/gf4/verify_gf4_dimensions.sh"
"$HERE/dimensions/gf16/verify_gf16_certificate.sh"
(cd "$HERE/delsarte" && python3 verify_delsarte_certificates.py) > \
    "$TEMP/delsarte_verification.log"
test "$(grep -c '^verified ' "$TEMP/delsarte_verification.log")" = 9
grep -q '^verified f72_n145_d73_delsarte_exact.txt:.*U4=42, kappa4=43, margin=1' \
    "$TEMP/delsarte_verification.log"

"$HERE/analyze_existing.sh"
"$HERE/source/current_empirical/verify_saved_empirical.sh"
VALIDATION_OUTPUT_DIR="$TEMP/main_nanorq_validation" \
    "$HERE/source/current_empirical/validate_selected_witnesses.sh" \
    "$NANORQ_CHECKOUT"
"$HERE/esi_profiles/verify_component.sh"

test "$(cat "$HERE/empirical/validation/worker_concurrency/maximum")" = 2
grep -q '^JOBS=2$' "$HERE/empirical/validation/concurrency_environment.txt"
verify_checksum_universe

warning_count=$(grep -i -c 'warning:' "$TEMP/nanorq_build.log" || true)
echo "FULL SAVED-ARTIFACT VERIFICATION PASS: compiler=$CC nanorq_warnings=$warning_count"
