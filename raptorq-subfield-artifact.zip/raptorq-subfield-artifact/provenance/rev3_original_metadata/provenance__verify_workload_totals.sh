#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
COUNTER="$HERE/count_instances_and_paths.awk"
TEMP=$(mktemp -d /tmp/rq-workload-count-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

find "$ARTIFACT/empirical/raw" -type f -name instances.csv -print0 | \
    xargs -0 -n 200 awk -f "$COUNTER" > "$TEMP/main_parts"
awk -F, '{instances+=$1;paths+=$2}END{print instances "," paths}' \
    "$TEMP/main_parts" > "$TEMP/main"
test "$(cat "$TEMP/main")" = "451400,18017000"

awk -f "$COUNTER" "$ARTIFACT/esi_profiles/summaries/instance_results.csv" \
    > "$TEMP/profile"
test "$(cat "$TEMP/profile")" = "47500,1900000"

IFS=, read -r main_instances main_paths < "$TEMP/main"
IFS=, read -r profile_instances profile_paths < "$TEMP/profile"
test "$((main_instances + profile_instances))" = 498900
test "$((main_paths + profile_paths))" = 19917000
echo "UNIFIED WORKLOAD PASS: main=451400/18017000 profile=47500/1900000 combined=498900/19917000"
