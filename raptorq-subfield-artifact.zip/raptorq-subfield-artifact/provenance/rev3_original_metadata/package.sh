#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PARENT_DIR=$(CDPATH= cd -- "$ARTIFACT_DIR/.." && pwd)
ARTIFACT_NAME=${ARTIFACT_DIR##*/}
OUTPUT=${1:-"$PARENT_DIR/raptorq-subfield-appendix-artifact-rev3.zip"}
CHECKSUMS="$ARTIFACT_DIR/CHECKSUMS.txt"

if test -e "$OUTPUT"; then
    echo "STOP: output already exists: $OUTPUT" >&2
    exit 2
fi

if find "$ARTIFACT_DIR" -type f \( -name '*.zip' -o -name '*.tar' -o \
    -name '*.tar.gz' -o -name '*.tgz' \) -print -quit | grep -q .; then
    echo "STOP: nested ZIP/TAR artifact found" >&2
    exit 2
fi

(
    cd "$ARTIFACT_DIR"
    find . -type f ! -path './build/*' ! -name CHECKSUMS.txt -print |
        LC_ALL=C sort | while IFS= read -r relative; do
            shasum -a 256 "${relative#./}"
        done > "$CHECKSUMS"
    shasum -a 256 -c CHECKSUMS.txt > /dev/null
    echo "CHECKSUM MANIFEST PASS"
)

(
    cd "$PARENT_DIR"
    COPYFILE_DISABLE=1 zip -X -q -9 -r "$OUTPUT" "$ARTIFACT_NAME" \
        -x "$ARTIFACT_NAME/build/*"
)
unzip -tq "$OUTPUT"
bytes=$(wc -c < "$OUTPUT" | tr -d ' ')
hash=$(shasum -a 256 "$OUTPUT" | awk '{ print $1 }')
echo "PACKAGE PASS: $OUTPUT"
echo "bytes=$bytes"
echo "sha256=$hash"
