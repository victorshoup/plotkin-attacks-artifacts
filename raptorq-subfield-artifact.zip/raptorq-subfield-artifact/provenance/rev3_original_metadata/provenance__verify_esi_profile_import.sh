#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
AUDIT="$HERE/ESI_PROFILE_IMPORT_AUDIT.csv"
EXPECTED_DIGEST=4c644eea57a088626b05a7dfa662acc04f6c30a619e0ff09bca14b3f5f6a0f70
TEMP=$(mktemp -d /tmp/rq-profile-import-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

scientific=0
duplicates=0
while IFS=, read -r original target original_hash recorded_hash classification status; do
    test "$original" = original_path && continue
    case "$classification" in
        scientific_*)
            test -f "$ARTIFACT/$target"
            observed=$(shasum -a 256 "$ARTIFACT/$target" | awk '{print $1}')
            test "$observed" = "$original_hash"
            test "$recorded_hash" = "$original_hash"
            printf '%s,%s\n' "$original" "$observed" >> "$TEMP/integrated"
            scientific=$((scientific + 1))
            ;;
    esac
    if test "$status" = deduplicated_identical; then
        test "$recorded_hash" = "$original_hash"
        duplicates=$((duplicates + 1))
    fi
done < "$AUDIT"

test "$scientific" = 20112
test "$duplicates" = 132
digest=$(LC_ALL=C sort "$TEMP/integrated" | shasum -a 256 | awk '{print $1}')
test "$digest" = "$EXPECTED_DIGEST"
echo "ESI-PROFILE IMPORT PASS: $scientific scientific files; digest=$digest; $duplicates byte-identical duplicates omitted"
