#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
MANIFEST="$HERE/REV3_UNCHANGED_SHA256.txt"
TEMP=$(mktemp /tmp/rq-profile-retained-XXXXXX)
trap 'rm -f "$TEMP"' EXIT
awk '$2 ~ /^(esi_profiles|paper_data\/esi_profiles)\// {print}' "$MANIFEST" > "$TEMP"
test -s "$TEMP"
(cd "$ARTIFACT" && shasum -a 256 -c "$TEMP") >/dev/null
count=$(wc -l < "$TEMP" | tr -d ' ')
echo "ESI-PROFILE RETAINED-SNAPSHOT PASS: $count retained files match revision 3 byte-for-byte"
