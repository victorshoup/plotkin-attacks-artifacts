# Exact quaternary Delsarte boundary near f=72

This note records the local Delsarte calculation independently of the low-rank-shortening
experiments. A scaled floating-point LP was used only to discover supports and active
constraints. Every certified bound below is a rational polynomial checked at every integer
distance with Python exact fractions by:

    python3 gf4/verify_delsarte_certificates.py

For \(n=2f+1\) and \(d=f+1\), a certificate supplies nonnegative rational coefficients
\(y_j\), with \(\sum_jy_j=1\), such that

\[
F(i)=\sum_j y_j\frac{K_j^{(4,n)}(i)}{\binom nj3^j}\le 0
\quad(d\le i\le n).
\]

Consequently \(A_4(n,d)\le M_f=1/y_0\). If \(M_f<4^{U+1}\), every quaternary linear code
with these parameters has dimension at most \(U\).

## Certified table

| f | n | d | K | K' | H | kappa4 | exact power interval for M_f | U4(f) | margin | result |
|---:|---:|---:|---:|---:|---:|---:|:---:|---:|---:|:---|
| 68 | 137 | 69 | 69 | 69 | 10 | 39 | \(4^{40}<M_{68}<4^{41}\) | 40 | -1 | no contradiction |
| 69 | 139 | 70 | 70 | 75 | 10 | 40 | \(4^{41}<M_{69}<4^{42}\) | 41 | -1 | no contradiction |
| 70 | 141 | 71 | 71 | 75 | 10 | 41 | \(4^{41}<M_{70}<4^{42}\) | 41 | 0 | no contradiction |
| 71 | 143 | 72 | 72 | 75 | 10 | 42 | \(4^{42}<M_{71}<4^{43}\) | 42 | 0 | no contradiction |
| 72 | 145 | 73 | 73 | 75 | 10 | 43 | \(4^{42}<M_{72}<4^{43}\) | 42 | 1 | universal contradiction |
| 73 | 147 | 74 | 74 | 75 | 10 | 44 | \(4^{43}<M_{73}<4^{44}\) | 43 | 1 | universal contradiction |
| 74 | 149 | 75 | 75 | 75 | 10 | 45 | \(4^{43}<M_{74}<4^{44}\) | 43 | 2 | universal contradiction |
| 75 | 151 | 76 | 76 | 84 | 10 | 46 | \(4^{44}<M_{75}<4^{45}\) | 44 | 2 | universal contradiction |
| 76 | 153 | 77 | 77 | 84 | 10 | 47 | \(4^{44}<M_{76}<4^{45}\) | 44 | 3 | universal contradiction |

Here “margin” is \(\kappa_4-U_4(f)\). The exact rational bounds for the five contradictory
points are:

- \(M_{72}=4299884844946792237094812159690541128892968599552000000000 /
  75299934928462000984224829305841\).
- \(M_{73}=9528162859518415197819680991792176157026403250894326988800 /
  81711562233493904706638167652441\).
- \(M_{74}=213785432770666651136302575546454110467253737579257790464 /
  794172736254317253856957143379\).
- \(M_{75}=515527608511988748776786398587637931674172358353137852460564480 /
  478075096966246396015211254979160467\).
- \(M_{76}=22799846997600037851012368466070447138576609099210817536000000 /
  24025649413764625931214329477522391\).

The complete exact fractions for \(f=68,\ldots,76\), including all coefficients, are in the
individual certificate files and delsarte_exact_certificates/summary.json. Some certificates
are deliberately non-optimal: exact feasibility and the displayed integer dimension bound
are all that the universal consequence needs. Separate exact LP-optimality witnesses are
included and checked for \(f=68,69,72,76\).

## Lower-boundary interpretation

Scaled numerical optimization gave candidate optimal values of \(\log_4 A_4\) equal to
approximately 40.613525, 41.227943, 41.688104, and 42.155850 at
\(f=68,69,70,71\), respectively. These are discovery results, not theorem statements. The
exact feasible polynomials at \(f=70,71\) give integer bounds equal to, rather than below,
the RaptorQ dimensions 41 and 42. Thus no exact contradiction is certified below 72 in the
examined neighborhood, and \(f=72\) is the first certified contradiction. The study does not
claim a global impossibility result for every conceivable stronger coding bound below 72.

At \(f=72,\ldots,76\), \(\kappa_4>U_4(f)\), so every honest row set contains a bad
\(f+1\)-subset. The existing binary universal theorem begins at \(f=77\). The arguments
therefore join without a gap and cover every RFC-valid \(K=f+1\) point with \(f\ge72\).

## Universal overhead obtained from the same certificates

For these points \(H=10\) and, away from the isolated \(K=30\) exception,
\(\kappa_4(K)=K-30\). Hence the smallest universally attacked source dimension is
\(K_{\min}=U_4(f)+31\).

| f | U4(f) | K_min | largest Delta=f+1-K | RFC K' at K_min |
|---:|---:|---:|---:|---:|
| 72 | 42 | 73 | 0 | 75 |
| 73 | 43 | 74 | 0 | 75 |
| 74 | 43 | 74 | 1 | 75 |
| 75 | 44 | 75 | 1 | 75 |
| 76 | 44 | 75 | 2 | 75 |

These overhead statements are universal consequences of the same exact coding bounds; they
are not empirical success frequencies.
