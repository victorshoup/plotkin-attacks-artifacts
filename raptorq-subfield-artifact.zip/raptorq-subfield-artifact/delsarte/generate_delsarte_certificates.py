#!/usr/bin/env python3
"""Deterministically reconstruct the local GF(4) Delsarte certificates.

The supports and active constraints were discovered with a scaled floating-point LP.
All reconstruction below is Gaussian elimination over fractions; the generated files are
accepted as evidence only after verify_delsarte_certificates.py checks them independently.
"""

from fractions import Fraction
from math import comb
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "delsarte_exact_certificates"

# (support, active distances, K', exact-optimality witness requested)
CASES = {
    68: (list(range(26)) + [29],
         [69, 75, 76, 81, 82, 86, 87, 91, 92, 95, 96, 99, 100,
          103, 104, 107, 108, 111, 112, 115, 116, 119, 120, 124, 128, 129],
         69, True),
    69: (list(range(27)) + [29],
         [70, 76, 77, 82, 83, 87, 88, 92, 93, 96, 97, 101, 102,
          105, 106, 109, 110, 113, 114, 117, 118, 121, 122, 125, 126, 130, 131],
         75, True),
    # These two exact feasible polynomials corroborate the local numerical study but do
    # not carry LP-optimality witnesses and do not produce RaptorQ contradictions.
    70: (list(range(28)) + [30, 31],
         [71, 77, 78, 83, 84, 88, 89, 93, 94, 98, 99, 102, 103,
          106, 107, 110, 111, 114, 115, 119, 120, 123, 124, 127, 128, 132, 133, 140, 141],
         75, False),
    71: (list(range(28)) + [30, 31],
         [72, 78, 79, 84, 85, 89, 90, 94, 95, 99, 100, 104, 105,
          108, 109, 112, 113, 116, 117, 120, 121, 124, 125, 128, 129, 133, 134, 142, 143],
         75, False),
    72: (list(range(28)) + [30, 31],
         [73, 79, 80, 85, 86, 90, 91, 95, 96, 100, 101, 104, 105,
          108, 109, 112, 113, 116, 117, 121, 122, 125, 126, 129, 130, 134, 135, 144, 145],
         75, True),
    73: (list(range(28)) + [30, 31],
         [74, 80, 81, 86, 87, 91, 92, 96, 97, 101, 102, 105, 106,
          109, 110, 113, 114, 117, 118, 122, 123, 126, 127, 130, 131, 135, 136, 145, 146],
         75, False),
    74: (list(range(28)) + [30, 31],
         [75, 81, 82, 87, 88, 92, 93, 97, 98, 102, 103, 106, 107,
          110, 111, 114, 115, 118, 119, 123, 124, 127, 128, 131, 132, 136, 137, 146, 147],
         75, False),
    75: (list(range(28)) + [30, 31],
         [76, 82, 83, 88, 89, 93, 94, 98, 99, 103, 104, 108, 109,
          111, 112, 115, 116, 119, 120, 124, 125, 128, 129, 132, 133, 137, 138, 147, 148],
         84, False),
    76: (list(range(29)) + [31, 32],
         [77, 83, 84, 89, 90, 94, 95, 99, 100, 104, 105, 108, 109,
          113, 114, 117, 118, 121, 122, 125, 126, 129, 130, 133, 134, 137, 138, 142, 143, 153],
         84, True),
}


def frac_text(value):
    return f"{value.numerator}/{value.denominator}"


def krawtchouk(q, n, j, x):
    return sum(
        (-1) ** t * (q - 1) ** (j - t) * comb(x, t) * comb(n - x, j - t)
        for t in range(j + 1)
        if t <= x and j - t <= n - x
    )


def normalized_krawtchouk(q, n, j, x):
    return Fraction(krawtchouk(q, n, j, x), comb(n, j) * (q - 1) ** j)


def solve(matrix, rhs):
    size = len(matrix)
    augmented = [row[:] + [value] for row, value in zip(matrix, rhs)]
    for column in range(size):
        pivot = next(row for row in range(column, size) if augmented[row][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [value / scale for value in augmented[column]]
        for row in range(size):
            if row != column and augmented[row][column]:
                scale = augmented[row][column]
                augmented[row] = [
                    value - scale * pivot_value
                    for value, pivot_value in zip(augmented[row], augmented[column])
                ]
    return [augmented[row][-1] for row in range(size)]


def dimension_upper(m_bound):
    upper = 0
    while Fraction(4 ** (upper + 1)) <= m_bound:
        upper += 1
    return upper


def reconstruct(f, support, active, kprime, optimality):
    q, n, d, k, h = 4, 2 * f + 1, f + 1, f + 1, 10
    matrix = [[Fraction(1) for _ in support]]
    matrix += [
        [normalized_krawtchouk(q, n, j, distance) for j in support]
        for distance in active
    ]
    y = solve(matrix, [Fraction(1)] + [Fraction(0)] * len(active))
    assert all(value >= 0 for value in y)
    y0 = y[support.index(0)]
    m_bound = 1 / y0
    upper = dimension_upper(m_bound)
    kappa4 = k - 3 * h

    dual = None
    if optimality:
        dual_matrix = [
            [Fraction(1)] + [normalized_krawtchouk(q, n, j, distance) for distance in active]
            for j in support
        ]
        dual = solve(dual_matrix, [Fraction(j == 0) for j in support])
        assert dual[0] == y0

    lines = [
        "format=gf4_delsarte_rational_v2",
        f"q={q}", f"f={f}", f"n={n}", f"d={d}", f"K={k}",
        f"Kprime={kprime}", f"H_HDPC={h}", f"kappa4={kappa4}",
        f"dimension_upper={upper}",
        "support=" + " ".join(map(str, support)),
        "active_distances=" + " ".join(map(str, active)),
        "y_coefficients:",
    ]
    lines += [f"y {j} {frac_text(value)}" for j, value in zip(support, y)]
    lines += [f"M_bound={frac_text(m_bound)}"]
    if dual is not None:
        lines += ["lp_optimality_witness:", f"lambda {frac_text(dual[0])}"]
        lines += [f"mu {distance} {frac_text(value)}" for distance, value in zip(active, dual[1:])]
    lines.append("")

    filename = f"f{f}_n{n}_d{d}_delsarte_exact.txt"
    (OUT / filename).write_text("\n".join(lines))
    return {
        "f": f, "n_h": n, "d": d, "K": k, "Kprime": kprime,
        "H_HDPC": h, "kappa4": kappa4,
        "M_bound_numerator": m_bound.numerator,
        "M_bound_denominator": m_bound.denominator,
        "dimension_upper": upper, "margin": kappa4 - upper,
        "lp_optimality_certified": optimality,
        "certificate": f"gf4/delsarte_exact_certificates/{filename}",
    }


def main():
    OUT.mkdir(exist_ok=True)
    summary = [reconstruct(f, *CASES[f]) for f in sorted(CASES)]
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"generated {len(summary)} exact rational certificates in {OUT}")


if __name__ == "__main__":
    main()
