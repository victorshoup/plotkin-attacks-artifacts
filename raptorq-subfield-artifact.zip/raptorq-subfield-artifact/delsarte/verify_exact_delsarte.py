#!/usr/bin/env python3
from fractions import Fraction
from math import comb
from pathlib import Path
import re

CERT = Path(__file__).with_name('f72_delsarte_exact_certificate.txt')
text = CERT.read_text()
q = int(re.search(r'q=(\d+)', text).group(1))
n = int(re.search(r'n=(\d+)', text).group(1))
d = int(re.search(r'd=(\d+)', text).group(1))
ys = {}
for line in text.splitlines():
    m = re.fullmatch(r'(\d+)\s+(-?\d+)/(\d+)', line.strip())
    if m:
        ys[int(m.group(1))] = Fraction(int(m.group(2)), int(m.group(3)))

y = [ys.get(j, Fraction(0)) for j in range(n+1)]
assert sum(y) == 1
assert all(v >= 0 for v in y)

def kraw(j, x):
    s = 0
    for t in range(j+1):
        if t <= x and j-t <= n-x:
            s += (-1)**t * (q-1)**(j-t) * comb(x,t) * comb(n-x,j-t)
    return s

def F(x):
    return sum(y[j] * Fraction(kraw(j,x), comb(n,j)*(q-1)**j) for j in range(n+1))

vals = [F(i) for i in range(d,n+1)]
assert all(v <= 0 for v in vals)
y0 = y[0]
Mnum, Mden = y0.denominator, y0.numerator
assert Fraction(4**42) < Fraction(Mnum,Mden) < Fraction(4**43)
print(f'exact Delsarte certificate verified for q={q}, n={n}, d={d}')
print(f'support size = {sum(v != 0 for v in y)}')
print(f'active constraints = {sum(v == 0 for v in vals)}')
print(f'y0 = {y0}')
print(f'A_4({n},{d}) <= 1/y0 = {Mnum}/{Mden}')
print('4^42 < 1/y0 < 4^43, hence every GF(4)-linear code has dimension <= 42')
