#!/usr/bin/env python3
"""Verify every consolidated GF(4) Delsarte certificate using exact arithmetic only."""

from fractions import Fraction
from math import comb
from pathlib import Path
import argparse


DEFAULT_DIR = Path(__file__).resolve().parent / "delsarte_exact_certificates"


def parse_fraction(text):
    numerator, denominator = text.split("/")
    return Fraction(int(numerator), int(denominator))


def krawtchouk(q, n, j, x):
    return sum(
        (-1) ** t * (q - 1) ** (j - t) * comb(x, t) * comb(n - x, j - t)
        for t in range(j + 1)
        if t <= x and j - t <= n - x
    )


def normalized_krawtchouk(q, n, j, x):
    return Fraction(krawtchouk(q, n, j, x), comb(n, j) * (q - 1) ** j)


def verify(path):
    scalars, y, mu = {}, {}, {}
    lam = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.endswith(":"):
            continue
        if line.startswith("y "):
            _, index, value = line.split()
            y[int(index)] = parse_fraction(value)
        elif line.startswith("mu "):
            _, distance, value = line.split()
            mu[int(distance)] = parse_fraction(value)
        elif line.startswith("lambda "):
            lam = parse_fraction(line.split()[1])
        elif "=" in line:
            key, value = line.split("=", 1)
            scalars[key] = value

    q, n, d = (int(scalars[key]) for key in ("q", "n", "d"))
    f, k, h = (int(scalars[key]) for key in ("f", "K", "H_HDPC"))
    kappa4, claimed_upper = (int(scalars[key]) for key in ("kappa4", "dimension_upper"))
    assert q == 4 and n == 2 * f + 1 and d == f + 1 and k == f + 1
    assert kappa4 == k - 3 * h

    coefficients = [y.get(j, Fraction(0)) for j in range(n + 1)]
    assert sum(coefficients) == 1
    assert all(value >= 0 for value in coefficients)

    def polynomial(distance):
        return sum(
            coefficients[j] * normalized_krawtchouk(q, n, j, distance)
            for j in range(n + 1)
        )

    values = [polynomial(distance) for distance in range(d, n + 1)]
    assert all(value <= 0 for value in values)
    y0 = coefficients[0]
    assert y0 > 0
    m_bound = 1 / y0
    assert m_bound == parse_fraction(scalars["M_bound"])
    assert Fraction(4 ** claimed_upper) <= m_bound < Fraction(4 ** (claimed_upper + 1))

    optimal = lam is not None
    if optimal:
        assert lam == y0
        assert all(value >= 0 for value in mu.values())
        for j in range(n + 1):
            lhs = lam + sum(
                value * normalized_krawtchouk(q, n, j, distance)
                for distance, value in mu.items()
            )
            assert lhs >= Fraction(j == 0)

    return {
        "f": f, "n": n, "d": d, "kappa4": kappa4,
        "upper": claimed_upper, "margin": kappa4 - claimed_upper,
        "support": sum(value != 0 for value in coefficients),
        "active": sum(value == 0 for value in values), "optimal": optimal,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("certificates", nargs="*", type=Path)
    args = parser.parse_args()
    paths = args.certificates or sorted(DEFAULT_DIR.glob("f*_delsarte_exact.txt"))
    assert paths, "no certificates selected"
    for path in paths:
        result = verify(path)
        print(
            f"verified {path.name}: f={result['f']}, (n,d)=({result['n']},{result['d']}), "
            f"U4={result['upper']}, kappa4={result['kappa4']}, margin={result['margin']}, "
            f"support={result['support']}, active={result['active']}, "
            f"LP-optimal={result['optimal']}"
        )


if __name__ == "__main__":
    main()
