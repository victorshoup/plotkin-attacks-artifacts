#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TEMP=$(mktemp -d /tmp/rq-slim-verify-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
CC=${CC:-cc}
export CC
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1
RUN_EXTENDED=0
RUN_EXACT=0
case "${1:-}" in
    "") ;;
    --extended) RUN_EXTENDED=1 ;;
    --exact) RUN_EXTENDED=1; RUN_EXACT=1 ;;
    *) echo "usage: $0 [--extended|--exact]" >&2; exit 2 ;;
esac

verify_checksum_universe()
{
    test -s "$HERE/CHECKSUMS.txt"
    if ! (cd "$HERE" && shasum -a 256 -c CHECKSUMS.txt) > "$TEMP/checksums.log" 2>&1; then
        cat "$TEMP/checksums.log" >&2
        exit 1
    fi
    (cd "$HERE" && find . -type f ! -path './build/*' ! -path './esi_profiles/build/*' \
        ! -name CHECKSUMS.txt -print | LC_ALL=C sort > "$TEMP/actual_files")
    awk '{sub(/^[0-9a-f]+  /, "./"); print}' "$HERE/CHECKSUMS.txt" | \
        LC_ALL=C sort > "$TEMP/manifest_files"
    cmp "$TEMP/actual_files" "$TEMP/manifest_files"
    echo "CHECKSUM UNIVERSE PASS: $(wc -l < "$TEMP/manifest_files" | tr -d ' ') files"
}

run_profile_helpers()
{
    mkdir -p "$TEMP/profile_bin" "$TEMP/profile_masks"
    "$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
        -I"$HERE/source/current_empirical" \
        "$HERE/esi_profiles/source/position_mask_generator.c" \
        -o "$TEMP/profile_bin/position_mask_generator"
    POSITION_MASK_OUTPUT="$TEMP/profile_masks/masks.csv" \
    POSITION_MASK_GENERATOR="$TEMP/profile_bin/position_mask_generator" \
        "$HERE/esi_profiles/build_position_masks.sh" >/dev/null
    cmp "$HERE/esi_profiles/position_masks/masks.csv" "$TEMP/profile_masks/masks.csv"
    echo "PROFILE MASK REGENERATION PASS"

    "$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
        -I"$HERE/source/current_empirical" \
        "$HERE/esi_profiles/source/repair_locality.c" \
        -o "$TEMP/profile_bin/repair_locality"
    "$TEMP/profile_bin/repair_locality" "$HERE/esi_profiles/config/primary_jobs.csv" \
        "$TEMP/repair_prefix_locality_raw.csv" 202609060101
    awk -f "$HERE/esi_profiles/source/locality_summary.awk" \
        "$TEMP/repair_prefix_locality_raw.csv" > "$TEMP/locality.unsorted"
    {
        head -n 1 "$TEMP/locality.unsorted"
        tail -n +2 "$TEMP/locality.unsorted" | sort -t, -k1,1n -k2,2n
    } > "$TEMP/repair_prefix_locality.csv"
    cmp "$HERE/paper_data/esi_profiles/repair_prefix_locality.csv" \
        "$TEMP/repair_prefix_locality.csv"
    echo "PROFILE LOCALITY REGENERATION PASS"

}

run_witnesses()
{
    cp -R "$HERE/source/nanorq" "$TEMP/nanorq"
    make -C "$TEMP/nanorq" -j2 libnanorq.a > "$TEMP/nanorq_build.log" 2>&1
    "$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
        -I"$TEMP/nanorq/include" -I"$TEMP/nanorq/deps" \
        "$HERE/source/current_empirical/nanorq_witness_audit.c" \
        "$TEMP/nanorq/libnanorq.a" -o "$TEMP/nanorq_witness_audit"

    main_count=0
    for witness in "$HERE"/empirical/witnesses/selected/*/witnesses/witness_*.txt; do
        test -f "$witness"
        "$TEMP/nanorq_witness_audit" "$witness" >> "$TEMP/main_witnesses.log" 2>&1
        main_count=$((main_count+1))
    done
    test "$main_count" = 5
    test "$(grep -c '^NANORQ FULL WITNESS PASS:' "$TEMP/main_witnesses.log")" = 5

    profile_count=0
    for witness in "$HERE"/esi_profiles/witnesses/selected/*/witness_*.txt; do
        test -f "$witness"
        "$TEMP/nanorq_witness_audit" "$witness" >> "$TEMP/profile_witnesses.log" 2>&1
        profile_count=$((profile_count+1))
    done
    test "$profile_count" = 11
    test "$(grep -c '^NANORQ FULL WITNESS PASS:' "$TEMP/profile_witnesses.log")" = 11

    python3 - "$HERE" <<'PY'
from pathlib import Path
import csv, hashlib, sys
root=Path(sys.argv[1])
with open(root/'empirical/validation/nanorq_validation.csv', newline='') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==5
for r in rows:
    p=root/r['witness_file']
    assert p.is_file()
    assert hashlib.sha256(p.read_bytes()).hexdigest()==r['witness_sha256']
with open(root/'esi_profiles/validation/selected_witnesses.csv', newline='') as f:
    rows=list(csv.DictReader(f))
rows=[r for r in rows if r['result']=='pass']
assert len(rows)==11
for r in rows:
    p=root/'esi_profiles'/r['witness_file']
    assert p.is_file()
    assert hashlib.sha256(p.read_bytes()).hexdigest()==r['witness_sha256']
print('SELECTED WITNESS LEDGER PASS: 5 full-domain + 11 profile witnesses')
PY

    echo "INDEPENDENT NANORQ WITNESS VALIDATION PASS: main=$main_count profile=$profile_count"
}

verify_checksum_universe

if find "$HERE" -type f \( -name '*.zip' -o -name '*.tar' -o -name '*.tar.gz' -o -name '*.tgz' \) \
    -print -quit | grep -q .; then
    echo "ERROR: nested archive found in slim artifact" >&2
    exit 1
fi

"$HERE/provenance/verify_rev3_identity.sh"
"$HERE/provenance/verify_removed_manifest.sh"
"$HERE/provenance/verify_gf4_historical_import.sh"
"$HERE/provenance/verify_esi_profile_import.sh"
"$HERE/provenance/verify_scientific_digests.sh"
"$HERE/provenance/verify_workload_totals.sh"
"$HERE/esi_profiles/audit/verify_full_domain_baseline_mapping.sh"
"$HERE/analyze_existing.sh"

(
    cd "$HERE/delsarte"
    python3 verify_delsarte_certificates.py
) > "$TEMP/delsarte.log"
test "$(grep -c '^verified ' "$TEMP/delsarte.log")" = 9
grep -q '^verified f72_n145_d73_delsarte_exact.txt:.*U4=42, kappa4=43, margin=1' "$TEMP/delsarte.log"
echo "DELSARTE VERIFICATION PASS: 9 exact rational certificates"

if test "$RUN_EXACT" = 1; then
    "$HERE/dimensions/gf16/verify_gf16_certificate_fast.sh"
    "$HERE/dimensions/gf4/verify_gf4_dimensions_c.sh"
    exact_status=pass
else
    echo "EXACT DIMENSION REPLAYS SKIPPED: use ./verify_artifact.sh --exact to rerun GF(16) and GF(4) certificates"
    exact_status=skipped
fi

run_witnesses

if test "$RUN_EXTENDED" = 1; then
    run_profile_helpers
else
    echo "PROFILE-HELPER REPLAYS SKIPPED: use ./verify_artifact.sh --extended to regenerate position masks and locality data"
fi

verify_checksum_universe
warning_count=0
if test -f "$TEMP/nanorq_build.log"; then
    warning_count=$(grep -i -c 'warning:' "$TEMP/nanorq_build.log" || true)
fi
echo "SLIM SAVED-ARTIFACT VERIFICATION PASS: extended=$RUN_EXTENDED exact=$exact_status nanorq_warnings=$warning_count"
