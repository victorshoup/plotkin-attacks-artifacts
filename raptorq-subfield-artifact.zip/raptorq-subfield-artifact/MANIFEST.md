# Manifest

This is the slim publication derivative of Appendix A artifact revision 3.
The package separates compact evidence from reproducible raw caches.

## Top-level evidence

- `README.md`: public usage and scope.
- `CLAIMS.md`: claim-to-evidence map for the slim package.
- `PROVENANCE.md`: relationship to authoritative revision 3 and construction record.
- `SLIMMING_AUDIT.md`: precise packaging audit and size accounting.
- `GF4_C_MIGRATION_AUDIT.md`: independent C reproduction of the frozen GF(4) dimension certificate and removal of the active Cargo dependency.
- `CHECKSUMS.txt`: checksum universe for this slim package.
- `verify_artifact.sh`: normal saved-artifact verifier; `--extended` adds profile-helper regeneration; `--exact` also replays GF(16)/GF(4) dimension certificates.
- `analyze_existing.sh`: aggregate-to-paper deterministic analysis checks.
- `smoke_test.sh`: small temporary-copy empirical smoke test.
- `reproduce_all.sh`: original expensive end-to-end reproduction runner.

## Scientific directories

- `paper_data/`: complete paper-facing data, unchanged from revision 3.
- `empirical/config/`: full-domain campaign configuration and seeds.
- `empirical/summaries/`: retained compact full-domain aggregate summaries.
- `empirical/witnesses/selected/`: five selected full-domain witnesses and their compact local records.
- `empirical/honest_esi_sets/index.csv`: hash/index commitment to the 5,000 canonical sampled ESI lists.
- `esi_profiles/config/`: ESI-profile campaign configuration and seeds.
- `esi_profiles/position_masks/masks.csv`: 4,100 deterministic profile position masks.
- `esi_profiles/summaries/`: retained compact profile aggregates.
- `esi_profiles/witnesses/selected/`: eleven independently validated profile witnesses.
- `dimensions/gf4/`: frozen GF(4) exhaustive certificate outputs, active C replay source, and historical Rust source retained for provenance.
- `dimensions/gf16/`: frozen GF(16) exhaustive certificate outputs and C source.
- `delsarte/`: exact-rational certificates, generators, and verifiers.
- `source/current_empirical/`: full-domain empirical/search/analysis source.
- `esi_profiles/source/`: profile campaign and analysis source.
- `source/nanorq/`: pinned independent RaptorQ implementation.

## Provenance directories

- `provenance/REV3_UNCHANGED_SHA256.txt`: authoritative revision-3 hashes for every same-path retained file that remains byte-identical.
- `provenance/REV3_MODIFIED_PACKAGING.csv`: same-path packaging/verification entry points intentionally changed for the slim derivative, with old and new hashes.
- `provenance/REMOVED_REV3_FILES.csv.gz`: path-level record of every omitted revision-3 file, including original hash and regeneration rule.
- `provenance/scientific_digests.txt`: original revision-3 scientific digest commitments.
- `provenance/gf4_historical_import_manifest.csv`: frozen native-materialization record for the older GF(4) certificate source.
- `provenance/rev3_original_metadata/`: archived revision-3 packaging documents and superseded verification entry points.

## Intentionally omitted caches

The package does not ship `empirical/raw/` or `esi_profiles/raw/`.
It also omits large per-instance derived tables whose paper-facing aggregates are retained.
The omitted material is deterministic output of the preserved source and configuration, or packaging-only audit scratch.
Every omitted revision-3 path is committed in `provenance/REMOVED_REV3_FILES.csv.gz`.
