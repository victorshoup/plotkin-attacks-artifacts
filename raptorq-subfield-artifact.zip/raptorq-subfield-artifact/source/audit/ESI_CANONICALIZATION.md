# ESI canonicalization audit

The final artifact stores each ordered honest ESI list once per scientific key
`(f,sample)`. The canonical ID includes both that key and the SHA-256 of the
ASCII space-separated list followed by one LF byte.

`canonicalize_esi_storage.sh` operates only after the scientific campaign and
selected-witness replay. Before removing point-level lists it:

1. reads all 225,700 original RaptorQ list occurrences;
2. compares all repeated representations at fixed `(f,sample)` exactly;
3. hashes all 5,000 canonical serializations;
4. creates RaptorQ and matched-random references for all 451,400 instances;
5. compares the sorted reference identity relation with every raw instance;
6. appends the canonical ID/hash to each instance record;
7. hashes normalized scientific content, including all result and structural
   rows, before and after storage conversion; and
8. deletes duplicated point-level list files only after all prior checks pass.

`audit_esi_dedup.sh` is the repeatable final-state audit. Exact size savings and
the pre/post digest are retained in `empirical/validation/`.
