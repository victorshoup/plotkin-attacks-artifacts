# Embedded independent oracle

This directory is a clean `git archive` export of `nanorq` commit
`6295a9525893b9a757dd57431db76fc6ecceafac`. It is included so the selected
witness validation remains self-contained after extraction. The Appendix A
campaign did not modify this oracle, and it is not the implementation under
test.
