BEGIN { FS = ","; OFS = "," }

FNR == 1 {
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

{
    if (rows == 0) {
        field = $(column["field"])
        f = $(column["f"])
        delta = $(column["Delta"])
        K = $(column["K"])
        kappa = $(column["kappa"])
    }
    ++rows
    success = $(column["success"]) + 0
    weight = $(column["minimum_word_weight"]) + 0
    saving = $(column["rank_saving"]) + 0
    restart = $(column["first_success_restart"]) + 0
    if (success) {
        successful_weight[++successes] = weight
        successful_saving[successes] = saving
        successful_restart[successes] = restart
    } else if (weight >= 0 && (best_failed_weight < 0 || weight < best_failed_weight)) {
        best_failed_weight = weight
    }
}

function sort_numeric(values, count,    i,j,value) {
    for (i = 2; i <= count; ++i) {
        value = values[i]
        j = i - 1
        while (j >= 1 && values[j] > value) {
            values[j + 1] = values[j]
            --j
        }
        values[j + 1] = value
    }
}

function median(values, count) {
    if (count == 0) return -1
    sort_numeric(values, count)
    if (count % 2) return values[(count + 1) / 2]
    return (values[count / 2] + values[count / 2 + 1]) / 2
}

END {
    best_failed_weight = best_failed_weight == "" ? -1 : best_failed_weight
    if (successes > 0) {
        sort_numeric(successful_weight, successes)
        weight_min = successful_weight[1]
        weight_max = successful_weight[successes]
        weight_median = median(successful_weight, successes)
        saving_median = median(successful_saving, successes)
        restart_median = median(successful_restart, successes)
    } else {
        weight_min = weight_median = weight_max = -1
        saving_median = restart_median = -1
    }
    printf "%s,%d,%d,%d,%d,%d,%d,%d,%.6f,%g,%g,%g,%g,%g,%g\n", \
        ensemble, field, f, delta, K, kappa, rows, successes, \
        rows ? successes / rows : 0, weight_min, weight_median, weight_max, \
        best_failed_weight, saving_median, restart_median
}
