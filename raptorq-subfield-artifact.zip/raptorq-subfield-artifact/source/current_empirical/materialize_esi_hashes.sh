#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
INPUT="$ARTIFACT_DIR/empirical/summaries/paired_esi_audit.csv"
OUTPUT_DIR="$ARTIFACT_DIR/empirical/honest_esi_sets"
OUTPUT="$OUTPUT_DIR/esi_sets_with_sha256.csv"
TEMP=$(mktemp /tmp/rq-esi-hashes-XXXXXX)
trap 'rm -f "$TEMP"' EXIT

mkdir -p "$OUTPUT_DIR"
echo "f,sample,field_count,record_count,honest_set_seed,esi_count,serialization,sha256,honest_ESIs" \
    > "$OUTPUT"

tail -n +2 "$INPUT" | while IFS=, read -r f sample fields records seed list; do
    # Canonical serialization is the exact ASCII space-separated list followed
    # by one LF byte.  It is both portable and directly reconstructible.
    printf '%s\n' "$list" > "$TEMP"
    digest=$(shasum -a 256 "$TEMP" | awk '{print $1}')
    count=$(awk '{print NF}' "$TEMP")
    expected=$((2 * f + 1))
    test "$count" = "$expected"
    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
        "$f" "$sample" "$fields" "$records" "$seed" "$count" \
        "ascii_space_separated_lf_v1" "$digest" "$list" >> "$OUTPUT"
done

rows=$(($(wc -l < "$OUTPUT") - 1))
test "$rows" = 5000
echo "ESI HASH MATERIALIZATION PASS: $rows canonical (f,sample) sets"
