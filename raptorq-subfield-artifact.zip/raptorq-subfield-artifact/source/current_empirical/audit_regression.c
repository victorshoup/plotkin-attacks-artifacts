#define _POSIX_C_SOURCE 200809L

/*
 * Standalone Phase-1 regression harness.
 *
 * The campaign implementation is included unchanged so its internal helpers can
 * be tested directly.  Pinned nanorq is linked as an independent RFC oracle.
 */
#define main rq_campaign_entrypoint
#include "rq_empirical.c"
#undef main

#include "io.h"
#include "nanorq.h"
#include "params.h"
#include "rand.h"
#include "tuple.h"

#include <assert.h>

#define REQUIRE(condition, ...)                                                \
    do {                                                                       \
        if (!(condition)) {                                                    \
            fprintf(stderr, "AUDIT FAIL: ");                                  \
            fprintf(stderr, __VA_ARGS__);                                      \
            fprintf(stderr, "\n");                                            \
            return false;                                                      \
        }                                                                      \
    } while (0)

static uint8_t reference_mul(uint8_t a, uint8_t b)
{
    uint16_t product = 0;
    uint16_t multiplicand = a;
    uint8_t multiplier = b;
    while (multiplier != 0) {
        if ((multiplier & 1u) != 0) {
            product ^= multiplicand;
        }
        multiplier >>= 1;
        multiplicand <<= 1;
        if ((multiplicand & 0x100u) != 0) {
            multiplicand ^= 0x11du;
        }
    }
    return (uint8_t)product;
}

static uint8_t field_pow(uint8_t value, unsigned exponent)
{
    uint8_t result = 1;
    while (exponent != 0) {
        if ((exponent & 1u) != 0) {
            result = gf_mul(result, value);
        }
        value = gf_mul(value, value);
        exponent >>= 1;
    }
    return result;
}

static int subfield_index(const subfield *sf, uint8_t value)
{
    for (int i = 0; i < sf->q; ++i) {
        if (sf->elems[i] == value) {
            return i;
        }
    }
    return -1;
}

static bool test_field_arithmetic(void)
{
    gf256_init();
    bool exponent_seen[256] = {false};
    for (int i = 0; i < 255; ++i) {
        REQUIRE(gf_exp[i] != 0, "GF(256) exponent table contains zero");
        REQUIRE(!exponent_seen[gf_exp[i]],
                "GF(256) exponent table repeats at exponent %d", i);
        exponent_seen[gf_exp[i]] = true;
    }
    for (int a = 0; a < 256; ++a) {
        for (int b = 0; b < 256; ++b) {
            REQUIRE(gf_mul((uint8_t)a, (uint8_t)b) ==
                        reference_mul((uint8_t)a, (uint8_t)b),
                    "GF(256) multiplication mismatch at %d,%d", a, b);
            REQUIRE(((uint8_t)a ^ (uint8_t)b) == ((uint8_t)b ^ (uint8_t)a),
                    "GF(256) addition mismatch at %d,%d", a, b);
        }
        if (a == 0) {
            REQUIRE(gf_inv[a] == 0, "zero inverse sentinel changed");
        } else {
            REQUIRE(gf_mul((uint8_t)a, gf_inv[a]) == 1,
                    "GF(256) inverse mismatch at %d", a);
        }
    }

    const int fields[] = {4, 16, 256};
    for (size_t fq = 0; fq < sizeof(fields) / sizeof(fields[0]); ++fq) {
        subfield sf;
        subfield_init(&sf, fields[fq]);
        int roots = 0;
        for (int x = 0; x < 256; ++x) {
            bool root = field_pow((uint8_t)x, (unsigned)sf.q) == (uint8_t)x;
            bool listed = subfield_index(&sf, (uint8_t)x) >= 0;
            REQUIRE(root == listed,
                    "GF(%d) embedding/root mismatch at octet %d", sf.q, x);
            roots += root;
        }
        REQUIRE(roots == sf.q, "GF(%d) has %d fixed roots", sf.q, roots);
        for (int i = 0; i < sf.q; ++i) {
            uint8_t a = sf.elems[i];
            for (int j = 0; j < sf.q; ++j) {
                uint8_t b = sf.elems[j];
                REQUIRE(subfield_index(&sf, a ^ b) >= 0,
                        "GF(%d) addition closure failure", sf.q);
                REQUIRE(subfield_index(&sf, gf_mul(a, b)) >= 0,
                        "GF(%d) multiplication closure failure", sf.q);
            }
            if (a != 0) {
                REQUIRE(subfield_index(&sf, gf_inv[a]) >= 0,
                        "GF(%d) inverse escaped subfield", sf.q);
            }
        }
        for (int x = 0; x < 256; ++x) {
            uint8_t reconstructed = 0;
            for (int t = 0; t < sf.degree; ++t) {
                REQUIRE(subfield_index(&sf, sf.decomp[x][t]) >= 0,
                        "GF(%d) decomposition coefficient escaped subfield",
                        sf.q);
                reconstructed ^= gf_mul(sf.decomp[x][t], gf_exp[t]);
            }
            REQUIRE(reconstructed == (uint8_t)x,
                    "GF(%d) decomposition mismatch at %d", sf.q, x);
        }
        if (sf.q == 4) {
            const uint8_t expected[4] = {0x00, 0x01, 0xd6, 0xd7};
            for (int i = 0; i < 4; ++i) {
                REQUIRE(sf.elems[i] == expected[i],
                        "GF(4) embedding mismatch at index %d", i);
            }
        }
    }
    fprintf(stderr, "PASS field arithmetic and GF(4)/GF(16) embeddings\n");
    return true;
}

static bool same_params(const rq_params *campaign, const params *oracle)
{
    return campaign->K == (int)oracle->K &&
           campaign->Kp == (int)oracle->Kprime &&
           campaign->J == (int)oracle->J &&
           campaign->S == (int)oracle->S &&
           campaign->H == (int)oracle->H &&
           campaign->W == (int)oracle->W &&
           campaign->L == (int)oracle->L &&
           campaign->P == (int)oracle->P &&
           campaign->P1 == (int)oracle->P1;
}

static bool compare_tuple_and_indices(int K, uint32_t X)
{
    rq_params campaign = get_params(K);
    params oracle = params_init((u32)K);
    tuple ot = gen_tuple((u32)X, &oracle);
    uint32_t A = 53591u + (uint32_t)campaign.J * 997u;
    if ((A & 1u) == 0) {
        ++A;
    }
    uint32_t B = 10267u * ((uint32_t)campaign.J + 1u);
    uint32_t y = B + X * A;
    int d = rq_degree(rq_rand(y, 0, 1048576u), campaign.W);
    uint32_t a = 1u + rq_rand(y, 1, (uint32_t)campaign.W - 1u);
    uint32_t b = rq_rand(y, 2, (uint32_t)campaign.W);
    int d1 = d < 4 ? 2 + (int)rq_rand(X, 3, 2) : 2;
    uint32_t a1 = 1u + rq_rand(X, 4, (uint32_t)campaign.P1 - 1u);
    uint32_t b1 = rq_rand(X, 5, (uint32_t)campaign.P1);
    REQUIRE(d == (int)ot.d && a == ot.a && b == ot.b &&
                d1 == (int)ot.d1 && a1 == ot.a1 && b1 == ot.b1,
            "tuple mismatch K=%d X=%u", K, X);

    int campaign_indices[MAX_DEG];
    int campaign_count = encoding_indices(X, &campaign, campaign_indices);
    u32 oracle_indices[GENC_MAX];
    u32_vec oracle_vec = {
        .m = GENC_MAX,
        .n = 0,
        .s = 0,
        .a = oracle_indices,
    };
    u32 oracle_count = params_set_idxs(&oracle, (u32)X, &oracle_vec);
    REQUIRE(campaign_count == (int)oracle_count,
            "index-count mismatch K=%d X=%u", K, X);
    for (int i = 0; i < campaign_count; ++i) {
        REQUIRE(campaign_indices[i] == (int)oracle_indices[i],
                "encoding-index mismatch K=%d X=%u position=%d",
                K, X, i);
        for (int j = 0; j < i; ++j) {
            REQUIRE(campaign_indices[i] != campaign_indices[j],
                    "duplicate encoding index K=%d X=%u", K, X);
        }
    }
    return true;
}

static bool test_rfc_parameters_and_tuples(void)
{
    REQUIRE(RQ_PARAMS_COUNT == (size_t)K_padded_size,
            "RFC table length mismatch: campaign=%zu nanorq=%u",
            (size_t)RQ_PARAMS_COUNT, K_padded_size);
    for (size_t i = 0; i < RQ_PARAMS_COUNT; ++i) {
        REQUIRE(RQ_PARAMS[i].kp == K_padded[i] &&
                    RQ_PARAMS[i].J == J_K_padded[i] &&
                    RQ_PARAMS[i].S == S_H_W[i][0] &&
                    RQ_PARAMS[i].H == S_H_W[i][1] &&
                    RQ_PARAMS[i].W == S_H_W[i][2],
                "RFC table mismatch at row %zu", i);
        int band_min = i == 0 ? 1 : (int)RQ_PARAMS[i - 1].kp + 1;
        const int checks[2] = {band_min, (int)RQ_PARAMS[i].kp};
        for (int k = 0; k < 2; ++k) {
            rq_params campaign = get_params(checks[k]);
            params oracle = params_init((u32)checks[k]);
            REQUIRE(same_params(&campaign, &oracle),
                    "derived RFC parameter mismatch at K=%d", checks[k]);
            REQUIRE(campaign.P1 >= campaign.P && is_prime(campaign.P1),
                    "P1 convention failure at K=%d", checks[k]);
        }
    }

    const int K_values[] = {30, 31, 32, 42, 43, 44, 49, 55,
                            60, 61, 62, 63, 65, 73, 100};
    const uint32_t X_values[] = {0, 1, 29, 30, 61, 62, 63, 64,
                                 65, 1000, 65535, 16777215};
    for (size_t k = 0; k < sizeof(K_values) / sizeof(K_values[0]); ++k) {
        for (size_t x = 0; x < sizeof(X_values) / sizeof(X_values[0]); ++x) {
            REQUIRE(compare_tuple_and_indices(K_values[k], X_values[x]),
                    "tuple/index comparison failed");
        }
    }
    for (uint32_t y = 0; y < 4096; y += 17) {
        for (uint8_t i = 0; i < 8; ++i) {
            const uint32_t moduli[] = {1, 2, 7, 10, 13, 251, 1048576};
            for (size_t m = 0; m < sizeof(moduli) / sizeof(moduli[0]); ++m) {
                REQUIRE(rq_rand(y, i, moduli[m]) == rnd_get(y, i, moduli[m]),
                        "RFC Rand mismatch y=%u i=%u m=%u",
                        y, i, moduli[m]);
            }
        }
    }
    fprintf(stderr, "PASS all 477 RFC table rows, P1, Rand, tuples, and indices\n");
    return true;
}

static bool test_subfield_spaces(void)
{
    const int K_values[] = {30, 31, 44, 65, 73, 100};
    const int fields[] = {4, 16, 256};
    for (size_t fq = 0; fq < sizeof(fields) / sizeof(fields[0]); ++fq) {
        subfield sf;
        subfield_init(&sf, fields[fq]);
        for (size_t kk = 0; kk < sizeof(K_values) / sizeof(K_values[0]); ++kk) {
            rq_params p = get_params(K_values[kk]);
            matrix_u8 constraints = build_subfield_constraints(&p, &sf);
            int kappa = 0;
            uint8_t *basis = kernel_basis_of_matrix(&constraints, &kappa);
            int lower = p.K - sf.degree * p.H;
            if (lower < 0) {
                lower = 0;
            }
            REQUIRE(kappa >= lower,
                    "GF(%d) dimension %d below bound %d at K=%d",
                    sf.q, kappa, lower, p.K);
            if (sf.q == 256) {
                REQUIRE(kappa == p.K,
                        "GF(256) dimension %d != K=%d", kappa, p.K);
            }
            for (int r = 0; r < constraints.nrows; ++r) {
                for (int c = 0; c < constraints.ncols; ++c) {
                    REQUIRE(subfield_index(&sf,
                                constraints.rows[(size_t)r * constraints.ncols + c]) >= 0,
                            "GF(%d) constraint coefficient escaped subfield",
                            sf.q);
                }
            }
            for (int b = 0; b < kappa; ++b) {
                const uint8_t *vector = basis + (size_t)b * p.L;
                for (int c = 0; c < p.L; ++c) {
                    REQUIRE(subfield_index(&sf, vector[c]) >= 0,
                            "GF(%d) basis value escaped subfield", sf.q);
                }
                for (int r = 0; r < constraints.nrows; ++r) {
                    REQUIRE(dot_product(constraints.rows + (size_t)r * p.L,
                                        vector, p.L) == 0,
                            "GF(%d) basis violates expanded constraint", sf.q);
                }
            }

            uint8_t *full = build_constraint_matrix(&p);
            for (int b = 0; b < kappa; ++b) {
                const uint8_t *vector = basis + (size_t)b * p.L;
                for (int r = 0; r < p.S + p.H; ++r) {
                    REQUIRE(dot_product(full + (size_t)r * p.L,
                                        vector, p.L) == 0,
                            "GF(%d) basis violates RFC precode row", sf.q);
                }
                for (int isi = p.K; isi < p.Kp; ++isi) {
                    int row = p.S + p.H + isi;
                    REQUIRE(dot_product(full + (size_t)row * p.L,
                                        vector, p.L) == 0,
                            "GF(%d) basis violates padding row", sf.q);
                }
            }
            matrix_u8 source = build_source_projection(&p, basis, kappa);
            REQUIRE(matrix_rank(&source) == kappa,
                    "GF(%d) source projection rank failure at K=%d",
                    sf.q, p.K);
            free_matrix(&source);
            free(full);
            free(basis);
            free_matrix(&constraints);
        }
    }
    fprintf(stderr, "PASS subfield constraint spaces and source projections\n");
    return true;
}

static uint64_t vector_code(const subfield *sf, const uint8_t *vector, int n)
{
    uint64_t code = 0;
    uint64_t place = 1;
    for (int i = 0; i < n; ++i) {
        int digit = subfield_index(sf, vector[i]);
        if (digit < 0) {
            die("audit vector escaped subfield");
        }
        code += (uint64_t)digit * place;
        place *= (uint64_t)sf->q;
    }
    return code;
}

static bool test_one_linear_algebra_case(int q, int nrows, int ncols,
                                         uint64_t seed)
{
    subfield sf;
    subfield_init(&sf, q);
    matrix_u8 matrix = {
        .rows = xcalloc((size_t)nrows * ncols, 1),
        .nrows = nrows,
        .ncols = ncols,
    };
    rng64 rng;
    rng_init(&rng, seed);
    for (int i = 0; i < nrows * ncols; ++i) {
        matrix.rows[i] = sf.elems[rng_below_uniform(&rng, (size_t)q)];
    }
    int rank = matrix_rank(&matrix);
    int nullity = 0;
    uint8_t *kernel = kernel_basis_of_matrix(&matrix, &nullity);
    REQUIRE(rank + nullity == ncols,
            "rank-nullity failure q=%d", q);
    for (int k = 0; k < nullity; ++k) {
        for (int r = 0; r < nrows; ++r) {
            REQUIRE(dot_product(matrix.rows + (size_t)r * ncols,
                                kernel + (size_t)k * ncols,
                                ncols) == 0,
                    "kernel membership failure q=%d", q);
        }
    }

    bool ok = false;
    uint64_t coefficient_count = checked_power_u64((uint64_t)q, nrows, &ok);
    REQUIRE(ok, "row-span coefficient count overflow");
    uint64_t vector_count = checked_power_u64((uint64_t)q, ncols, &ok);
    REQUIRE(ok && vector_count <= 65536, "row-span vector count overflow");
    bool *seen = xcalloc((size_t)vector_count, sizeof(bool));
    int *digits = xcalloc((size_t)nrows, sizeof(int));
    uint8_t *value = xcalloc((size_t)ncols, 1);
    uint64_t distinct = 0;
    for (uint64_t code = 0; code < coefficient_count; ++code) {
        uint64_t z = code;
        memset(value, 0, (size_t)ncols);
        for (int r = 0; r < nrows; ++r) {
            digits[r] = (int)(z % (uint64_t)q);
            z /= (uint64_t)q;
            uint8_t coefficient = sf.elems[digits[r]];
            for (int c = 0; c < ncols; ++c) {
                value[c] ^= gf_mul(coefficient,
                                   matrix.rows[(size_t)r * ncols + c]);
            }
        }
        uint64_t encoded = vector_code(&sf, value, ncols);
        if (!seen[encoded]) {
            seen[encoded] = true;
            ++distinct;
        }
    }
    uint64_t expected = checked_power_u64((uint64_t)q, rank, &ok);
    REQUIRE(ok && distinct == expected,
            "rank/span cardinality mismatch q=%d got=%" PRIu64
            " expected=%" PRIu64,
            q, distinct, expected);
    free(value);
    free(digits);
    free(seen);
    free(kernel);
    free_matrix(&matrix);
    return true;
}

static int brute_minimum_weight(const matrix_u8 *matrix, const subfield *sf)
{
    bool ok = false;
    uint64_t count = checked_power_u64((uint64_t)sf->q, matrix->ncols, &ok);
    if (!ok) {
        die("audit brute-force count overflow");
    }
    int best = matrix->nrows + 1;
    uint8_t *coefficients = xcalloc((size_t)matrix->ncols, 1);
    for (uint64_t code = 1; code < count; ++code) {
        uint64_t z = code;
        for (int c = 0; c < matrix->ncols; ++c) {
            coefficients[c] = sf->elems[z % (uint64_t)sf->q];
            z /= (uint64_t)sf->q;
        }
        int weight = 0;
        for (int r = 0; r < matrix->nrows; ++r) {
            weight += dot_product(matrix->rows + (size_t)r * matrix->ncols,
                                  coefficients, matrix->ncols) != 0;
        }
        if (weight < best) {
            best = weight;
        }
    }
    free(coefficients);
    return best;
}

static bool test_projective_case(int q, int dimension)
{
    subfield sf;
    subfield_init(&sf, q);
    bool ok = false;
    uint64_t all_count = checked_power_u64((uint64_t)q, dimension, &ok);
    REQUIRE(ok && all_count <= 65536, "projective test count overflow");
    bool *seen = xcalloc((size_t)all_count, sizeof(bool));
    uint8_t *vector = xcalloc((size_t)dimension, 1);
    uint64_t unique = 0;
    for (uint64_t code = 1; code < all_count; ++code) {
        uint64_t z = code;
        for (int c = 0; c < dimension; ++c) {
            vector[c] = sf.elems[z % (uint64_t)q];
            z /= (uint64_t)q;
        }
        canonical_projective(vector, dimension);
        int first = row_first_nonzero(vector, dimension);
        REQUIRE(first >= 0 && vector[first] == 1,
                "projective normalization failure q=%d", q);
        uint64_t normalized = vector_code(&sf, vector, dimension);
        if (!seen[normalized]) {
            seen[normalized] = true;
            ++unique;
        }
    }
    uint64_t expected = projective_direction_count(q, dimension, &ok);
    REQUIRE(ok && unique == expected,
            "projective direction mismatch q=%d d=%d got=%" PRIu64
            " expected=%" PRIu64,
            q, dimension, unique, expected);
    free(vector);
    free(seen);

    matrix_u8 matrix = {
        .rows = xcalloc((size_t)11 * dimension, 1),
        .nrows = 11,
        .ncols = dimension,
    };
    rng64 rng;
    rng_init(&rng, UINT64_C(0xa5a5f00d12340000) ^ (uint64_t)q);
    for (int i = 0; i < matrix.nrows * matrix.ncols; ++i) {
        matrix.rows[i] = sf.elems[rng_below_uniform(&rng, (size_t)q)];
    }
    int closure_dummy = 0;
    candidate result = enumerate_stage(&matrix, &sf, &closure_dummy, 0,
                                       0, UINT64_MAX);
    REQUIRE(result.valid, "projective enumeration returned no candidate");
    REQUIRE(result.directions_enumerated == expected,
            "enumeration count mismatch q=%d", q);
    REQUIRE(result.weight == brute_minimum_weight(&matrix, &sf),
            "enumeration minimum mismatch q=%d", q);
    REQUIRE(!row_is_zero(result.coefficient_vector, dimension),
            "enumeration returned zero coefficient vector q=%d", q);
    int actual_weight = 0;
    for (int r = 0; r < matrix.nrows; ++r) {
        actual_weight += dot_product(matrix.rows + (size_t)r * dimension,
                                     result.coefficient_vector,
                                     dimension) != 0;
    }
    REQUIRE(actual_weight == result.weight,
            "enumeration selected-vector weight mismatch q=%d", q);
    free_candidate(&result);
    free_matrix(&matrix);
    return true;
}

static bool test_linear_algebra_and_projective_search(void)
{
    for (uint64_t seed = 1; seed <= 12; ++seed) {
        REQUIRE(test_one_linear_algebra_case(4, 4, 4, seed),
                "GF(4) linear algebra case failed");
        REQUIRE(test_one_linear_algebra_case(16, 3, 3, seed),
                "GF(16) linear algebra case failed");
        REQUIRE(test_one_linear_algebra_case(256, 2, 2, seed),
                "GF(256) linear algebra case failed");
    }
    REQUIRE(test_projective_case(4, 4), "GF(4) projective case failed");
    REQUIRE(test_projective_case(16, 3), "GF(16) projective case failed");
    REQUIRE(test_projective_case(256, 2), "GF(256) projective case failed");
    fprintf(stderr, "PASS linear algebra and exact projective enumeration\n");
    return true;
}

static bool test_sampling(void)
{
    const uint64_t seed = UINT64_C(0x0123456789abcdef);
    uint32_t first[129];
    uint32_t second[129];
    rng64 a;
    rng64 b;
    rng_init(&a, seed);
    rng_init(&b, seed);
    sample_full_domain(first, RQ_ESI_DOMAIN, 129, &a);
    sample_full_domain(second, RQ_ESI_DOMAIN, 129, &b);
    REQUIRE(memcmp(first, second, sizeof(first)) == 0,
            "full-domain sampler is not deterministic");
    for (int i = 0; i < 129; ++i) {
        REQUIRE(first[i] < RQ_ESI_DOMAIN,
                "full-domain sampler out of range");
        if (i > 0) {
            REQUIRE(first[i - 1] < first[i],
                    "full-domain sampler repeated or unsorted ESI");
        }
    }
    uint32_t consecutive[97];
    rng_init(&a, seed);
    sample_consecutive(consecutive, 97, 97, &a);
    for (int i = 0; i < 97; ++i) {
        REQUIRE(consecutive[i] == (uint32_t)i,
                "consecutive full sample mismatch at %d", i);
    }

    const int f = 64;
    const int delta = 7;
    const int K = f + 1 - delta;
    const int sample = 3;
    const uint64_t master = UINT64_C(202609030001);
    uint64_t honest_seed = master
        ^ (uint64_t)K * UINT64_C(0x9e3779b97f4a7c15)
        ^ (uint64_t)sample * UINT64_C(0x85ebca6b27d4eb2f);
    uint64_t search_seed = rotate_left_u64(master, 17)
        ^ (uint64_t)K * UINT64_C(0xc2b2ae3587b73a21)
        ^ (uint64_t)sample * UINT64_C(0x165667b19e3779f9);
    for (int q_index = 0; q_index < 3; ++q_index) {
        const int q = (int[]){4, 16, 256}[q_index];
        (void)q;
        uint64_t paired_honest = master
            ^ (uint64_t)K * UINT64_C(0x9e3779b97f4a7c15)
            ^ (uint64_t)sample * UINT64_C(0x85ebca6b27d4eb2f);
        uint64_t paired_search = rotate_left_u64(master, 17)
            ^ (uint64_t)K * UINT64_C(0xc2b2ae3587b73a21)
            ^ (uint64_t)sample * UINT64_C(0x165667b19e3779f9);
        REQUIRE(paired_honest == honest_seed && paired_search == search_seed,
                "field-dependent paired seed detected");
    }
    fprintf(stderr, "PASS deterministic, unique, paired ESI sampling\n");
    return true;
}

static uint8_t evaluate_intermediate(const uint8_t *intermediate,
                                     int symbol_size,
                                     int byte,
                                     uint32_t esi,
                                     const rq_params *p)
{
    int indices[MAX_DEG];
    uint32_t isi = esi_to_isi(esi, p);
    int count = encoding_indices(isi, p, indices);
    uint8_t value = 0;
    for (int i = 0; i < count; ++i) {
        value ^= intermediate[(size_t)indices[i] * symbol_size + byte];
    }
    return value;
}

static bool compare_encoder_at_K(int K)
{
    enum { SYMBOL_SIZE = 8 };
    rq_params p = get_params(K);
    uint8_t *source = xcalloc((size_t)K * SYMBOL_SIZE, 1);
    for (int i = 0; i < K; ++i) {
        for (int byte = 0; byte < SYMBOL_SIZE; ++byte) {
            source[(size_t)i * SYMBOL_SIZE + byte] =
                (uint8_t)(17 * K + 37 * i + 53 * byte + 11);
        }
    }

    uint8_t *A = build_constraint_matrix(&p);
    matrix_u8 full = {.rows = A, .nrows = p.L, .ncols = p.L};
    uint8_t *intermediate = xcalloc((size_t)p.L * SYMBOL_SIZE, 1);
    uint8_t *rhs = xcalloc((size_t)p.L, 1);
    uint8_t *solution = xcalloc((size_t)p.L, 1);
    for (int byte = 0; byte < SYMBOL_SIZE; ++byte) {
        memset(rhs, 0, (size_t)p.L);
        for (int i = 0; i < K; ++i) {
            rhs[p.S + p.H + i] = source[(size_t)i * SYMBOL_SIZE + byte];
        }
        REQUIRE(solve_full_column_rank(&full, rhs, solution),
                "campaign RFC matrix solve failed at K=%d", K);
        for (int i = 0; i < p.L; ++i) {
            intermediate[(size_t)i * SYMBOL_SIZE + byte] = solution[i];
        }
    }

    nanorq *rq = nanorq_encoder_new_ex((size_t)K * SYMBOL_SIZE,
                                       SYMBOL_SIZE, (uint16_t)K, 1, 1);
    REQUIRE(rq != NULL, "nanorq encoder creation failed at K=%d", K);
    REQUIRE(nanorq_precalculate(rq),
            "nanorq precalculate failed at K=%d", K);
    struct ioctx *io = ioctx_from_mem_ro(source, (size_t)K * SYMBOL_SIZE);
    REQUIRE(io != NULL, "nanorq memory IO failed at K=%d", K);
    REQUIRE(nanorq_generate_symbols(rq, 0, io),
            "nanorq intermediate generation failed at K=%d", K);

    for (int esi = 0; esi < K; ++esi) {
        uint8_t oracle[SYMBOL_SIZE];
        size_t written = nanorq_encode(rq, oracle, (uint32_t)esi, 0, io);
        REQUIRE(written == SYMBOL_SIZE,
                "nanorq systematic encode failed K=%d ESI=%d", K, esi);
        for (int byte = 0; byte < SYMBOL_SIZE; ++byte) {
            uint8_t campaign = evaluate_intermediate(intermediate, SYMBOL_SIZE,
                                                     byte, (uint32_t)esi, &p);
            REQUIRE(campaign == source[(size_t)esi * SYMBOL_SIZE + byte],
                    "campaign systematic-map failure K=%d ESI=%d byte=%d",
                    K, esi, byte);
            REQUIRE(campaign == oracle[byte],
                    "systematic oracle mismatch K=%d ESI=%d byte=%d",
                    K, esi, byte);
        }
    }

    const uint32_t repair_esis[] = {
        (uint32_t)K,
        (uint32_t)K + 1u,
        (uint32_t)K + 17u,
        1000u,
        65535u,
        16777215u,
    };
    for (size_t e = 0; e < sizeof(repair_esis) / sizeof(repair_esis[0]); ++e) {
        uint32_t esi = repair_esis[e];
        uint8_t oracle[SYMBOL_SIZE];
        size_t written = nanorq_encode(rq, oracle, esi, 0, io);
        REQUIRE(written == SYMBOL_SIZE,
                "nanorq repair encode failed K=%d ESI=%u", K, esi);
        for (int byte = 0; byte < SYMBOL_SIZE; ++byte) {
            uint8_t campaign = evaluate_intermediate(intermediate, SYMBOL_SIZE,
                                                     byte, esi, &p);
            REQUIRE(campaign == oracle[byte],
                    "repair oracle mismatch K=%d ESI=%u byte=%d got=%02x expected=%02x",
                    K, esi, byte, campaign, oracle[byte]);
        }
    }

    io->destroy(io);
    nanorq_free(rq);
    free(solution);
    free(rhs);
    free(intermediate);
    free(A);
    free(source);
    return true;
}

static bool test_against_nanorq_encoder(void)
{
    const int K_values[] = {30, 31, 42, 43, 49, 55, 61, 62, 65, 73, 100};
    for (size_t i = 0; i < sizeof(K_values) / sizeof(K_values[0]); ++i) {
        REQUIRE(compare_encoder_at_K(K_values[i]),
                "nanorq encoder comparison failed at K=%d", K_values[i]);
    }
    fprintf(stderr,
            "PASS systematic and repair evaluations against pinned nanorq\n");
    return true;
}

int main(void)
{
    REQUIRE(test_field_arithmetic(), "field arithmetic suite failed");
    REQUIRE(test_rfc_parameters_and_tuples(), "RFC tuple suite failed");
    REQUIRE(test_subfield_spaces(), "subfield-space suite failed");
    REQUIRE(test_linear_algebra_and_projective_search(),
            "linear algebra/projective suite failed");
    REQUIRE(test_sampling(), "sampling suite failed");
    REQUIRE(test_against_nanorq_encoder(), "nanorq oracle suite failed");
    fprintf(stderr, "AUDIT REGRESSION PASS\n");
    return 0;
}
