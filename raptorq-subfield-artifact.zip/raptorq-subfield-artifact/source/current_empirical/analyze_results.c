#define _POSIX_C_SOURCE 200809L

#include <float.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ROWS 10000
#define MAX_FIELDS 64
#define MAX_LINE 8192

typedef struct {
    char ensemble[16];
    int field;
    int f;
    int delta;
    int K;
    int kappa;
    int samples;
    int successes;
    double fraction;
} SearchRow;

typedef struct {
    int field;
    int f;
    int delta;
    int exact_d;
    long long directions;
    char reason[96];
} DeeperConfig;

typedef struct {
    char ensemble[16];
    int field;
    int residual_dimension;
    long long path_steps;
    double mean_largest;
    double nontrivial_fraction;
    double mean_saving;
    long long successful_steps;
    double successful_saving;
    long long failed_steps;
    double failed_saving;
} ProjectiveRow;

static void die(const char *message)
{
    fprintf(stderr, "ANALYSIS FAIL: %s\n", message);
    exit(2);
}

static int split_csv(char *line, char **field, int capacity)
{
    int count = 0;
    field[count++] = line;
    for (char *cursor = line; *cursor != '\0'; ++cursor) {
        if (*cursor == ',') {
            *cursor = '\0';
            if (count >= capacity) die("too many CSV fields");
            field[count++] = cursor + 1;
        } else if (*cursor == '\n' || *cursor == '\r') {
            *cursor = '\0';
            break;
        }
    }
    return count;
}

static int column_index(char **header, int count, const char *name)
{
    for (int i = 0; i < count; ++i) {
        if (strcmp(header[i], name) == 0) return i;
    }
    fprintf(stderr, "ANALYSIS FAIL: missing CSV column %s\n", name);
    exit(2);
}

static FILE *open_output(const char *directory, const char *name)
{
    char path[4096];
    int written = snprintf(path, sizeof(path), "%s/%s", directory, name);
    if (written < 0 || (size_t)written >= sizeof(path)) die("output path too long");
    FILE *result = fopen(path, "w");
    if (result == NULL) die("cannot open analysis output");
    return result;
}

static int read_search(const char *path, SearchRow *rows, int capacity)
{
    FILE *input = fopen(path, "r");
    if (input == NULL) die("cannot open search summary");
    char line[MAX_LINE];
    if (fgets(line, sizeof(line), input) == NULL) die("empty search summary");
    char *header[MAX_FIELDS];
    int fields = split_csv(line, header, MAX_FIELDS);
    int ensemble = column_index(header, fields, "ensemble");
    int q = column_index(header, fields, "field");
    int f = column_index(header, fields, "f");
    int delta = column_index(header, fields, "Delta");
    int K = column_index(header, fields, "K");
    int kappa = column_index(header, fields, "kappa");
    int samples = column_index(header, fields, "samples");
    int successes = column_index(header, fields, "successes");
    int fraction = column_index(header, fields, "success_fraction");
    int count = 0;
    while (fgets(line, sizeof(line), input) != NULL) {
        if (count >= capacity) die("too many search rows");
        char *value[MAX_FIELDS];
        int n = split_csv(line, value, MAX_FIELDS);
        if (n != fields) die("inconsistent search CSV row");
        SearchRow *row = &rows[count++];
        snprintf(row->ensemble, sizeof(row->ensemble), "%s", value[ensemble]);
        row->field = atoi(value[q]);
        row->f = atoi(value[f]);
        row->delta = atoi(value[delta]);
        row->K = atoi(value[K]);
        row->kappa = atoi(value[kappa]);
        row->samples = atoi(value[samples]);
        row->successes = atoi(value[successes]);
        row->fraction = strtod(value[fraction], NULL);
    }
    if (fclose(input) != 0) die("cannot close search summary");
    return count;
}

static SearchRow *find_search(SearchRow *rows, int count, const char *ensemble,
                              int field, int f, int delta)
{
    for (int i = 0; i < count; ++i) {
        if (strcmp(rows[i].ensemble, ensemble) == 0 && rows[i].field == field &&
            rows[i].f == f && rows[i].delta == delta) return &rows[i];
    }
    return NULL;
}

static long double log2_add(long double a, long double b)
{
    if (!isfinite(a)) return b;
    if (!isfinite(b)) return a;
    if (b > a) {
        long double temporary = a;
        a = b;
        b = temporary;
    }
    return a + log1pl(exp2l(b - a)) / logl(2.0L);
}

static long double log2_nonzero_vectors(int q, int dimension)
{
    if (dimension == 0) return -INFINITY;
    long double exponent = (long double)dimension * log2l((long double)q);
    return exponent + log1pl(-exp2l(-exponent)) / logl(2.0L);
}

static long double first_moment_log2(int q, int f, int kappa)
{
    int n = 2 * f + 1;
    long double log_sum = -INFINITY;
    long double log_term = 0.0L;
    for (int weight = 1; weight <= f; ++weight) {
        log_term += log2l((long double)(n - weight + 1));
        log_term -= log2l((long double)weight);
        log_term += log2l((long double)(q - 1));
        log_sum = log2_add(log_sum, log_term);
    }
    return log2_nonzero_vectors(q, kappa) + log_sum -
           log2_nonzero_vectors(q, n);
}

static void write_comparison_row(FILE *output, const SearchRow *rq,
                                 const SearchRow *random)
{
    if (rq->field != random->field || rq->f != random->f ||
        rq->delta != random->delta || rq->K != random->K ||
        rq->kappa != random->kappa || rq->samples != random->samples) {
        die("RaptorQ/random point mismatch");
    }
    long double logarithm = first_moment_log2(rq->field, rq->f, rq->kappa);
    fprintf(output, "%d,%d,%d,%d,%d,%d,%d,%d,%.6f,%.6f,%.6f,",
            rq->field, rq->f, rq->delta, rq->K, rq->kappa, rq->samples,
            rq->successes, random->successes, rq->fraction, random->fraction,
            rq->fraction - random->fraction);
    if (isfinite(logarithm)) fprintf(output, "%.12Lf", logarithm);
    fputc(',', output);
    long double moment = isfinite(logarithm) ? exp2l(logarithm) : 0.0L;
    if (moment > 0.0L && isfinite(moment) && moment <= LDBL_MAX) {
        fprintf(output, "%.12Le", moment);
    }
    fputc('\n', output);
}

static void write_search_products(SearchRow *rows, int count,
                                  const char *output_directory)
{
    const char *header =
        "field,f,Delta,K,kappa,samples,rq_successes,random_successes,"
        "rq_success_fraction,random_success_fraction,rq_minus_random_fraction,"
        "log2_first_moment,first_moment_if_representable\n";
    FILE *comparison = open_output(output_directory, "comparison.csv");
    FILE *delta0 = open_output(output_directory, "delta0.csv");
    FILE *positive = open_output(output_directory, "positive_grid.csv");
    FILE *deep_tail = open_output(output_directory, "gf256_deep_tail.csv");
    fputs(header, comparison);
    fputs(header, delta0);
    fputs(header, positive);
    fputs(header, deep_tail);
    for (int i = 0; i < count; ++i) {
        SearchRow *rq = &rows[i];
        if (strcmp(rq->ensemble, "rq") != 0) continue;
        SearchRow *random = find_search(rows, count, "random", rq->field,
                                        rq->f, rq->delta);
        if (random == NULL) die("missing matched random summary row");
        write_comparison_row(comparison, rq, random);
        if (rq->delta == 0) {
            write_comparison_row(delta0, rq, random);
        } else if (rq->delta <= 40) {
            write_comparison_row(positive, rq, random);
        } else {
            if (rq->field != 256) die("non-GF(256) deep-tail row");
            write_comparison_row(deep_tail, rq, random);
        }
    }
    if (fclose(comparison) != 0 || fclose(delta0) != 0 ||
        fclose(positive) != 0 || fclose(deep_tail) != 0)
        die("cannot close comparison output");

    FILE *kappa = open_output(output_directory, "kappa.csv");
    fputs("field,K,kappa,definition\n", kappa);
    bool emitted[MAX_ROWS] = {false};
    for (int field_index = 0; field_index < 3; ++field_index) {
        int q = field_index == 0 ? 4 : field_index == 1 ? 16 : 256;
        for (int K = 1; K <= 100; ++K) {
            SearchRow *found = NULL;
            for (int i = 0; i < count; ++i) {
                if (!emitted[i] && strcmp(rows[i].ensemble, "rq") == 0 &&
                    rows[i].field == q && rows[i].K == K) {
                    if (found != NULL && found->kappa != rows[i].kappa) {
                        die("kappa is inconsistent for fixed field and K");
                    }
                    found = &rows[i];
                    emitted[i] = true;
                }
            }
            if (found != NULL) {
                fprintf(kappa, "%d,%d,%d,%s\n", q, K, found->kappa,
                        q == 256 ? "kappa_equals_K" : "computed_subfield_kernel");
            }
        }
    }
    if (fclose(kappa) != 0) die("cannot close kappa output");

    FILE *boundary = open_output(output_directory, "observed_extrema.csv");
    fputs("ensemble,field,f,max_tested_Delta,largest_tested_Delta_at_least_0.8,"
          "largest_tested_Delta_with_any_success,interpretation\n", boundary);
    const char *ensembles[] = {"rq", "random"};
    for (int e = 0; e < 2; ++e) {
        for (int qi = 0; qi < 3; ++qi) {
            int q = qi == 0 ? 4 : qi == 1 ? 16 : 256;
            for (int f_value = 12; f_value <= 96; f_value += 4) {
                int max_tested = -1, high = -1, any = -1;
                for (int i = 0; i < count; ++i) {
                    SearchRow *row = &rows[i];
                    if (strcmp(row->ensemble, ensembles[e]) != 0 ||
                        row->field != q || row->f != f_value || row->delta <= 0)
                        continue;
                    if (row->delta > max_tested) max_tested = row->delta;
                    if (row->fraction >= 0.8 && row->delta > high) high = row->delta;
                    if (row->successes > 0 && row->delta > any) any = row->delta;
                }
                if (max_tested < 0) die("missing positive-grid boundary group");
                fprintf(boundary, "%s,%d,%d,%d,%d,%d,observed_finite_search_not_threshold\n",
                        ensembles[e], q, f_value, max_tested, high, any);
            }
        }
    }
    if (fclose(boundary) != 0) die("cannot close boundary output");
}

static int read_deeper_config(const char *path, DeeperConfig *rows, int capacity)
{
    FILE *input = fopen(path, "r");
    if (input == NULL) die("cannot open deeper configuration");
    char line[MAX_LINE];
    if (fgets(line, sizeof(line), input) == NULL) die("empty deeper configuration");
    int count = 0;
    while (fgets(line, sizeof(line), input) != NULL) {
        if (count >= capacity) die("too many deeper configurations");
        char *v[MAX_FIELDS];
        int n = split_csv(line, v, MAX_FIELDS);
        if (n != 6) die("invalid deeper configuration row");
        rows[count].field = atoi(v[0]);
        rows[count].f = atoi(v[1]);
        rows[count].delta = atoi(v[2]);
        rows[count].exact_d = atoi(v[3]);
        rows[count].directions = atoll(v[4]);
        snprintf(rows[count].reason, sizeof(rows[count].reason), "%s", v[5]);
        ++count;
    }
    if (fclose(input) != 0) die("cannot close deeper configuration");
    return count;
}

static void write_deeper_product(SearchRow *main_rows, int main_count,
                                 SearchRow *deep_rows, int deep_count,
                                 DeeperConfig *config, int config_count,
                                 const char *output_directory)
{
    FILE *output = open_output(output_directory, "deeper_enumeration.csv");
    fputs("ensemble,field,f,Delta,K,kappa,main_exact_d,deeper_exact_d,"
          "deeper_directions,samples,main_40_path_successes,"
          "deeper_canonical_path_successes,deeper_minus_main_successes,reason,"
          "interpretation\n", output);
    const char *ensembles[] = {"rq", "random"};
    for (int c = 0; c < config_count; ++c) {
        for (int e = 0; e < 2; ++e) {
            SearchRow *main = find_search(main_rows, main_count, ensembles[e],
                                          config[c].field, config[c].f,
                                          config[c].delta);
            SearchRow *deep = find_search(deep_rows, deep_count, ensembles[e],
                                          config[c].field, config[c].f,
                                          config[c].delta);
            if (main == NULL || deep == NULL) die("missing deeper comparison row");
            int main_d = main->field == 4 ? 8 : main->field == 16 ? 5 : 3;
            fprintf(output, "%s,%d,%d,%d,%d,%d,%d,%d,%lld,%d,%d,%d,%d,%s,"
                    "different_search_breadth_not_nested_success_test\n",
                    ensembles[e], main->field, main->f, main->delta, main->K,
                    main->kappa, main_d, config[c].exact_d,
                    config[c].directions, main->samples, main->successes,
                    deep->successes, deep->successes - main->successes,
                    config[c].reason);
        }
    }
    if (fclose(output) != 0) die("cannot close deeper output");
}

static int read_projective(const char *path, ProjectiveRow *rows, int capacity)
{
    FILE *input = fopen(path, "r");
    if (input == NULL) die("cannot open projective summary");
    char line[MAX_LINE];
    if (fgets(line, sizeof(line), input) == NULL) die("empty projective summary");
    char *header[MAX_FIELDS];
    int fields = split_csv(line, header, MAX_FIELDS);
    int ensemble = column_index(header, fields, "ensemble");
    int q = column_index(header, fields, "field");
    int d = column_index(header, fields, "residual_dimension");
    int steps = column_index(header, fields, "path_steps");
    int largest = column_index(header, fields, "mean_largest_class");
    int nontrivial = column_index(header, fields, "nontrivial_class_fraction");
    int saving = column_index(header, fields, "mean_cumulative_projective_saving");
    int success_steps = column_index(header, fields, "successful_path_steps");
    int success_saving = column_index(header, fields, "mean_saving_successful");
    int failure_steps = column_index(header, fields, "failed_path_steps");
    int failure_saving = column_index(header, fields, "mean_saving_failed");
    int count = 0;
    while (fgets(line, sizeof(line), input) != NULL) {
        if (count >= capacity) die("too many projective rows");
        char *v[MAX_FIELDS];
        int n = split_csv(line, v, MAX_FIELDS);
        if (n != fields) die("inconsistent projective CSV row");
        ProjectiveRow *row = &rows[count++];
        snprintf(row->ensemble, sizeof(row->ensemble), "%s", v[ensemble]);
        row->field = atoi(v[q]);
        row->residual_dimension = atoi(v[d]);
        row->path_steps = atoll(v[steps]);
        row->mean_largest = strtod(v[largest], NULL);
        row->nontrivial_fraction = strtod(v[nontrivial], NULL);
        row->mean_saving = strtod(v[saving], NULL);
        row->successful_steps = atoll(v[success_steps]);
        row->successful_saving = strtod(v[success_saving], NULL);
        row->failed_steps = atoll(v[failure_steps]);
        row->failed_saving = strtod(v[failure_saving], NULL);
    }
    if (fclose(input) != 0) die("cannot close projective summary");
    return count;
}

static ProjectiveRow *find_projective(ProjectiveRow *rows, int count,
                                      const char *ensemble, int field, int d)
{
    for (int i = 0; i < count; ++i) {
        if (strcmp(rows[i].ensemble, ensemble) == 0 && rows[i].field == field &&
            rows[i].residual_dimension == d) return &rows[i];
    }
    return NULL;
}

static void write_projective_product(ProjectiveRow *rows, int count,
                                     const char *output_directory)
{
    FILE *output = open_output(output_directory, "projective_comparison.csv");
    fputs("field,residual_dimension,rq_path_steps,random_path_steps,"
          "rq_mean_largest_class,random_mean_largest_class,"
          "rq_minus_random_mean_largest_class,rq_nontrivial_fraction,"
          "random_nontrivial_fraction,rq_minus_random_nontrivial_fraction,"
          "rq_mean_cumulative_saving,random_mean_cumulative_saving,"
          "rq_minus_random_mean_cumulative_saving,rq_successful_path_steps,"
          "rq_mean_saving_successful,rq_failed_path_steps,"
          "rq_mean_saving_failed\n", output);
    for (int i = 0; i < count; ++i) {
        ProjectiveRow *rq = &rows[i];
        if (strcmp(rq->ensemble, "rq") != 0) continue;
        ProjectiveRow *random = find_projective(rows, count, "random", rq->field,
                                                rq->residual_dimension);
        if (random == NULL) die("missing matched projective row");
        fprintf(output,
                "%d,%d,%lld,%lld,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,"
                "%.9f,%.9f,%.9f,%lld,%.9f,%lld,%.9f\n",
                rq->field, rq->residual_dimension, rq->path_steps,
                random->path_steps, rq->mean_largest, random->mean_largest,
                rq->mean_largest - random->mean_largest,
                rq->nontrivial_fraction, random->nontrivial_fraction,
                rq->nontrivial_fraction - random->nontrivial_fraction,
                rq->mean_saving, random->mean_saving,
                rq->mean_saving - random->mean_saving, rq->successful_steps,
                rq->successful_saving, rq->failed_steps, rq->failed_saving);
    }
    if (fclose(output) != 0) die("cannot close projective comparison output");
}

int main(int argc, char **argv)
{
    if (argc != 6) {
        fprintf(stderr, "usage: %s SEARCH.csv DEEPER.csv PROJECTIVE.csv "
                        "DEEPER_CONFIG.csv OUTPUT_DIRECTORY\n", argv[0]);
        return 2;
    }
    SearchRow main_rows[MAX_ROWS];
    SearchRow deep_rows[MAX_ROWS];
    ProjectiveRow projective_rows[MAX_ROWS];
    DeeperConfig config[MAX_ROWS];
    int main_count = read_search(argv[1], main_rows, MAX_ROWS);
    int deep_count = read_search(argv[2], deep_rows, MAX_ROWS);
    int projective_count = read_projective(argv[3], projective_rows, MAX_ROWS);
    int config_count = read_deeper_config(argv[4], config, MAX_ROWS);
    write_search_products(main_rows, main_count, argv[5]);
    write_deeper_product(main_rows, main_count, deep_rows, deep_count,
                         config, config_count, argv[5]);
    write_projective_product(projective_rows, projective_count, argv[5]);
    puts("ANALYSIS SUMMARIES PASS");
    return 0;
}
