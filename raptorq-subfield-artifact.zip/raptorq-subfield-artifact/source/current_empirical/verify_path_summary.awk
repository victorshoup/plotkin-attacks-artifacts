BEGIN { FS = ","; OFS = ","; file_number = 0 }

FNR == 1 {
    ++file_number
    delete column
    for (i = 1; i <= NF; ++i) column[$i] = i
    if (file_number == 1) {
        if (!("sample" in column) || !("kappa" in column) ||
            !("restart_budget" in column) ||
            !("successful_paths" in column)) exit 1
        instance_seed_name = ensemble == "rq" ? "honest_set_seed" : "random_matrix_seed"
        if (!(instance_seed_name in column)) exit 1
    } else if (file_number == 2) {
        if (!("residual_dimension" in column) || !("all_paths" in column) ||
            !("success_paths" in column) || !("failure_paths" in column)) exit 1
    }
    next
}

file_number == 1 {
    sample = $(column["sample"])
    known[sample] = 1
    kappa[sample] = $(column["kappa"])
    restarts[sample] = $(column["restart_budget"])
    successful[sample] = $(column["successful_paths"])
    expected_rows[sample] = kappa[sample] > exact_d ? kappa[sample] - exact_d : 0
    next
}

file_number == 2 {
    sample = $(column["sample"])
    dimension = $(column["residual_dimension"])
    if (!known[sample]) exit 1
    if ($(column["ensemble"]) != ensemble) exit 1
    if ($(column["all_paths"]) != restarts[sample]) exit 1
    if ($(column["success_paths"]) != successful[sample]) exit 1
    if ($(column["failure_paths"]) != restarts[sample] - successful[sample]) exit 1
    if ($(column["all_nontrivial_paths"]) > $(column["all_paths"]) ||
        $(column["success_nontrivial_paths"]) > $(column["success_paths"]) ||
        $(column["failure_nontrivial_paths"]) > $(column["failure_paths"])) exit 1
    if (dimension <= exact_d || dimension > kappa[sample]) exit 1
    key = sample SUBSEP dimension
    if (seen[key]++) exit 1
    if ($(column["all_largest_min"]) != $(column["all_chosen_min"]) ||
        $(column["all_largest_median"]) != $(column["all_chosen_median"]) ||
        $(column["all_largest_mean"]) != $(column["all_chosen_mean"]) ||
        $(column["all_largest_max"]) != $(column["all_chosen_max"])) exit 1
    ++observed_rows[sample]
    next
}

END {
    if (file_number != 2) exit 1
    for (sample in known) {
        if (observed_rows[sample] != expected_rows[sample]) exit 1
    }
}
