#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SOURCE_DIR="$ARTIFACT_DIR/source/current_empirical"
CONFIG="$EMPIRICAL_DIR/config/selected_witnesses.csv"
trace_tmp=$(mktemp /tmp/rq-selected-trace-XXXXXX.csv)
original_tmp=$(mktemp /tmp/rq-selected-original-XXXXXX.csv)
replay_tmp=$(mktemp /tmp/rq-selected-replay-XXXXXX.csv)
trap 'rm -f "$trace_tmp" "$original_tmp" "$replay_tmp"' EXIT

count=0
while IFS=, read -r field f delta sample region point_rule witness_rule; do
    test "$field" = field && continue
    phase=positive
    if test "$delta" -gt 40; then phase=deep_tail; fi
    original_directory="$EMPIRICAL_DIR/raw/$phase/rq/q${field}_f${f}_d${delta}"
    original="$original_directory/instances.csv"
    output="$EMPIRICAL_DIR/witnesses/selected/q${field}_f${f}_d${delta}_s${sample}"
    selected=$(awk -F, '
        NR == 1 { for (i = 1; i <= NF; ++i) c[$i] = i; next }
        $(c["success"]) == 1 {
            sample = $(c["sample"]) + 0
            if (!found || sample < best_sample) {
                found = 1
                best_sample = sample
            }
        }
        END { if (!found) exit 1; print best_sample }
    ' "$original")
    test "$selected" = "$sample"

    mkdir -p "$output"
    rm -f "$output/path_steps.csv.gz"
    "$EMPIRICAL_DIR/regenerate_trace.sh" rq "$field" "$f" "$delta" "$sample" "$output"

    awk -F, -v wanted="$sample" '
        BEGIN { OFS = "," }
        NR == 1 {
            for (i = 1; i <= NF; ++i) {
                c[$i] = i
                keep[i] = !($i == "construction_ms" || $i == "matrix_ms" ||
                            $i == "search_ms")
            }
            next
        }
        $(c["sample"]) == wanted {
            separator = ""
            for (i = 1; i <= NF; ++i) if (keep[i]) {
                printf "%s%s", separator, $i
                separator = OFS
            }
            printf "%s", ORS
        }
    ' "$original" > "$original_tmp"
    awk -F, '
        BEGIN { OFS = "," }
        NR == 1 {
            for (i = 1; i <= NF; ++i)
                keep[i] = !($i == "construction_ms" || $i == "matrix_ms" ||
                            $i == "search_ms")
            next
        }
        NR == 2 {
            separator = ""
            for (i = 1; i <= NF; ++i) if (keep[i]) {
                printf "%s%s", separator, $i
                separator = OFS
            }
            printf "%s", ORS
        }
    ' "$output/instances.csv" > "$replay_tmp"
    cmp "$original_tmp" "$replay_tmp"

    if test -s "$original_directory/esi_sets.csv"; then
        awk -F, -v wanted="$sample" '
            NR == 1 { for (i = 1; i <= NF; ++i) c[$i] = i; next }
            $(c["sample"]) == wanted { print }
        ' "$original_directory/esi_sets.csv" > "$original_tmp"
    else
        awk -F, -v field="$field" -v f="$f" -v delta="$delta" \
            -v sample="$sample" '
            BEGIN { OFS="," }
            NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
            $(c["f"])==f && $(c["sample"])==sample {
                print "rq",field,f,delta,f+1-delta,sample,
                      $(c["honest_set_seed"]),$(c["esi_count"]),
                      $(c["honest_ESIs"])
            }
        ' "$EMPIRICAL_DIR/honest_esi_sets/lists.csv" > "$original_tmp"
    fi
    tail -n +2 "$output/esi_sets.csv" > "$replay_tmp"
    cmp "$original_tmp" "$replay_tmp"

    if test "$field" = 4; then exact_d=8
    elif test "$field" = 16; then exact_d=5
    else exact_d=3
    fi
    awk -v exact_d="$exact_d" -f "$SOURCE_DIR/verify_instances.awk" \
        "$output/instances.csv"
    awk -v ensemble=rq -v exact_d="$exact_d" \
        -f "$SOURCE_DIR/verify_path_summary.awk" \
        "$output/instances.csv" "$output/path_summary.csv"
    gzip -dc "$output/path_steps.csv.gz" > "$trace_tmp"
    awk -v ensemble=rq -v exact_d="$exact_d" -v trace_mode=full \
        -v diagnostic_sample=-1 -f "$SOURCE_DIR/verify_path_steps.awk" \
        "$output/instances.csv" "$trace_tmp"
    awk -f "$SOURCE_DIR/verify_structure.awk" \
        "$output/zero_set_structure.csv"
    count=$((count + 1))
done < "$CONFIG"

expected=$(($(wc -l < "$CONFIG") - 1))
test "$count" = "$expected"
echo "SELECTED WITNESS REGENERATION PASS: $count witnesses"
