#define _POSIX_C_SOURCE 200809L

/* Full witness audit using only the pinned nanorq encoder as the RaptorQ oracle. */

#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "io.h"
#include "nanorq.h"

#define SYMBOL_SIZE 8
#define ESI_LIMIT (1u << 24)

static void fail(const char *message)
{
    fprintf(stderr, "AUDIT FAIL: %s\n", message);
    exit(2);
}

static void *xcalloc(size_t count, size_t size)
{
    void *result = calloc(count == 0 ? 1 : count, size == 0 ? 1 : size);
    if (result == NULL) {
        fail("out of memory");
    }
    return result;
}

static char *read_line_value(const char *path, const char *key)
{
    FILE *fp = fopen(path, "r");
    if (fp == NULL) {
        fail("cannot open witness file");
    }
    size_t key_length = strlen(key);
    char *line = NULL;
    size_t capacity = 0;
    char *result = NULL;
    while (getline(&line, &capacity, fp) >= 0) {
        if (strncmp(line, key, key_length) == 0 && line[key_length] == '=') {
            char *value = line + key_length + 1;
            size_t length = strlen(value);
            while (length > 0 &&
                   (value[length - 1] == '\n' || value[length - 1] == '\r')) {
                value[--length] = '\0';
            }
            result = strdup(value);
            break;
        }
    }
    free(line);
    fclose(fp);
    if (result == NULL) {
        fprintf(stderr, "AUDIT FAIL: missing witness key %s\n", key);
        exit(2);
    }
    return result;
}

static int parse_int_value(const char *path, const char *key)
{
    char *text = read_line_value(path, key);
    char *end = NULL;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' ||
        value < 0 || value > 1000000) {
        fprintf(stderr, "AUDIT FAIL: invalid integer key %s\n", key);
        exit(2);
    }
    free(text);
    return (int)value;
}

static uint32_t *parse_esi_list(const char *path, const char *key,
                                size_t *count_out)
{
    char *text = read_line_value(path, key);
    size_t capacity = 16;
    size_t count = 0;
    uint32_t *values = xcalloc(capacity, sizeof(uint32_t));
    char *save = NULL;
    for (char *token = strtok_r(text, " ", &save);
         token != NULL;
         token = strtok_r(NULL, " ", &save)) {
        char *end = NULL;
        errno = 0;
        unsigned long value = strtoul(token, &end, 10);
        if (errno != 0 || end == token || *end != '\0' || value >= ESI_LIMIT) {
            fail("invalid ESI list entry");
        }
        if (count == capacity) {
            capacity *= 2;
            uint32_t *grown = realloc(values, capacity * sizeof(uint32_t));
            if (grown == NULL) {
                fail("out of memory growing ESI list");
            }
            values = grown;
        }
        values[count++] = (uint32_t)value;
    }
    free(text);
    *count_out = count;
    return values;
}

static int hex_digit(int character)
{
    if (character >= '0' && character <= '9') {
        return character - '0';
    }
    character = tolower(character);
    if (character >= 'a' && character <= 'f') {
        return 10 + character - 'a';
    }
    return -1;
}

static uint8_t reference_mul(uint8_t a, uint8_t b)
{
    uint16_t product = 0;
    uint16_t multiplicand = a;
    uint8_t multiplier = b;
    while (multiplier != 0) {
        if ((multiplier & 1u) != 0) {
            product ^= multiplicand;
        }
        multiplier >>= 1;
        multiplicand <<= 1;
        if ((multiplicand & 0x100u) != 0) {
            multiplicand ^= 0x11du;
        }
    }
    return (uint8_t)product;
}

static uint8_t field_pow(uint8_t value, unsigned exponent)
{
    uint8_t result = 1;
    while (exponent != 0) {
        if ((exponent & 1u) != 0) {
            result = reference_mul(result, value);
        }
        value = reference_mul(value, value);
        exponent >>= 1;
    }
    return result;
}

static bool symbol_is_zero(const uint8_t symbol[SYMBOL_SIZE])
{
    for (int i = 0; i < SYMBOL_SIZE; ++i) {
        if (symbol[i] != 0) {
            return false;
        }
    }
    return true;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s WITNESS.txt\n", argv[0]);
        return 2;
    }
    const char *path = argv[1];
    int field = parse_int_value(path, "field");
    int f = parse_int_value(path, "f");
    int delta = parse_int_value(path, "Delta");
    int K = parse_int_value(path, "K");
    int reported_weight = parse_int_value(path, "weight");
    int reported_zeros = parse_int_value(path, "zeros");
    if (!(field == 4 || field == 16 || field == 256)) {
        fail("invalid field");
    }
    if (K != f + 1 - delta) {
        fail("K != f+1-Delta");
    }
    if (K <= 0 || K > 56403) {
        fail("K outside RFC range");
    }

    char *source_hex = read_line_value(path, "source_difference_hex");
    if (strlen(source_hex) != (size_t)(2 * K)) {
        fail("source_difference_hex has wrong length");
    }
    uint8_t *source = xcalloc((size_t)K * SYMBOL_SIZE, 1);
    bool source_nonzero = false;
    for (int i = 0; i < K; ++i) {
        int high = hex_digit(source_hex[2 * i]);
        int low = hex_digit(source_hex[2 * i + 1]);
        if (high < 0 || low < 0) {
            fail("invalid source hex digit");
        }
        uint8_t value = (uint8_t)((high << 4) | low);
        if (field_pow(value, (unsigned)field) != value) {
            fail("source value is outside declared subfield");
        }
        source[(size_t)i * SYMBOL_SIZE] = value;
        source_nonzero |= value != 0;
    }
    free(source_hex);
    if (!source_nonzero) {
        fail("source difference is zero");
    }

    size_t honest_count = 0;
    size_t listed_zero_count = 0;
    uint32_t *honest = parse_esi_list(path, "honest_ESIs", &honest_count);
    uint32_t *listed_zeros = parse_esi_list(path, "zero_ESIs",
                                            &listed_zero_count);
    if (honest_count != (size_t)(2 * f + 1)) {
        fail("honest ESI count is not 2f+1");
    }
    for (size_t i = 1; i < honest_count; ++i) {
        if (honest[i - 1] >= honest[i]) {
            fail("honest ESIs are repeated or unsorted");
        }
    }
    for (size_t i = 1; i < listed_zero_count; ++i) {
        if (listed_zeros[i - 1] >= listed_zeros[i]) {
            fail("zero ESIs are repeated or unsorted");
        }
    }

    nanorq *rq = nanorq_encoder_new_ex((size_t)K * SYMBOL_SIZE,
                                       SYMBOL_SIZE, (uint16_t)K, 1, 1);
    if (rq == NULL || !nanorq_precalculate(rq)) {
        fail("nanorq encoder setup failed");
    }
    struct ioctx *io = ioctx_from_mem_ro(source, (size_t)K * SYMBOL_SIZE);
    if (io == NULL || !nanorq_generate_symbols(rq, 0, io)) {
        fail("nanorq source generation failed");
    }

    for (int esi = 0; esi < K; ++esi) {
        uint8_t encoded[SYMBOL_SIZE];
        size_t written = nanorq_encode(rq, encoded, (uint32_t)esi, 0, io);
        if (written != SYMBOL_SIZE ||
            memcmp(encoded, source + (size_t)esi * SYMBOL_SIZE,
                   SYMBOL_SIZE) != 0) {
            fail("nanorq systematic-symbol mismatch");
        }
    }

    int actual_weight = 0;
    size_t actual_zero_count = 0;
    for (size_t i = 0; i < honest_count; ++i) {
        uint8_t encoded[SYMBOL_SIZE];
        size_t written = nanorq_encode(rq, encoded, honest[i], 0, io);
        if (written != SYMBOL_SIZE) {
            fail("nanorq honest-ESI encoding failed");
        }
        if (symbol_is_zero(encoded)) {
            if (actual_zero_count >= listed_zero_count ||
                listed_zeros[actual_zero_count] != honest[i]) {
                fail("serialized zero ESI list differs from nanorq");
            }
            ++actual_zero_count;
        } else {
            ++actual_weight;
        }
    }

    if (actual_zero_count != listed_zero_count) {
        fail("serialized zero ESI list has extra entries");
    }
    if (actual_weight != reported_weight ||
        actual_zero_count != (size_t)reported_zeros ||
        actual_weight + reported_zeros != (int)honest_count) {
        fail("reported weight/zero count differs from nanorq");
    }
    if (actual_weight > f || actual_zero_count < (size_t)(f + 1)) {
        fail("witness does not meet attack success criterion");
    }

    io->destroy(io);
    nanorq_free(rq);
    free(listed_zeros);
    free(honest);
    free(source);
    fprintf(stderr,
            "NANORQ FULL WITNESS PASS: field=%d f=%d Delta=%d K=%d "
            "weight=%d zeros=%zu honest=%zu\n",
            field, f, delta, K, actual_weight, actual_zero_count, honest_count);
    return 0;
}
