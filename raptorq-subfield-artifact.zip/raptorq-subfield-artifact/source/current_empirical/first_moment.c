#define main rq_subfield_campaign_program_main
#include "rq_empirical.c"
#undef main

#include <float.h>
#include <math.h>

static long double log2_add(long double a, long double b)
{
    if (!isfinite(a)) return b;
    if (!isfinite(b)) return a;
    if (b > a) {
        long double temporary = a;
        a = b;
        b = temporary;
    }
    return a + log1pl(exp2l(b - a)) / logl(2.0L);
}

static long double log2_nonzero_vectors(int q, int dimension)
{
    long double exponent = (long double)dimension * log2l((long double)q);
    return exponent + log1pl(-exp2l(-exponent)) / logl(2.0L);
}

static long double first_moment_log2(int q, int f, int kappa)
{
    int n = 2 * f + 1;
    long double log_sum = -INFINITY;
    long double log_term = 0.0L;
    for (int weight = 1; weight <= f; ++weight) {
        log_term += log2l((long double)(n - weight + 1));
        log_term -= log2l((long double)weight);
        log_term += log2l((long double)(q - 1));
        log_sum = log2_add(log_sum, log_term);
    }
    return log2_nonzero_vectors(q, kappa) + log_sum -
           log2_nonzero_vectors(q, n);
}

static int split_csv(char *line, char **field, int capacity)
{
    int count = 0;
    field[count++] = line;
    for (char *cursor = line; *cursor != '\0'; ++cursor) {
        if (*cursor == ',') {
            *cursor = '\0';
            if (count >= capacity) die("too many CSV fields");
            field[count++] = cursor + 1;
        } else if (*cursor == '\n' || *cursor == '\r') {
            *cursor = '\0';
            break;
        }
    }
    return count;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s ACTUAL_RQ_SUMMARY.csv\n", argv[0]);
        return 2;
    }
    FILE *input = fopen(argv[1], "r");
    if (input == NULL) die("cannot open actual summary for first moment");
    char *line = NULL;
    size_t length = 0;
    if (getline(&line, &length, input) < 0) die("empty actual summary");
    char *header[64];
    int header_count = split_csv(line, header, 64);
    int field_column = -1, f_column = -1, delta_column = -1;
    int K_column = -1, kappa_column = -1;
    for (int i = 0; i < header_count; ++i) {
        if (strcmp(header[i], "field") == 0) field_column = i;
        if (strcmp(header[i], "f") == 0) f_column = i;
        if (strcmp(header[i], "Delta") == 0) delta_column = i;
        if (strcmp(header[i], "K") == 0) K_column = i;
        if (strcmp(header[i], "kappa") == 0) kappa_column = i;
    }
    if (field_column < 0 || f_column < 0 || delta_column < 0 ||
        K_column < 0 || kappa_column < 0) {
        die("actual summary lacks first-moment input column");
    }
    puts("field,q,f,Delta,K,kappa,log2_first_moment,first_moment_if_representable");
    while (getline(&line, &length, input) >= 0) {
        char *value[64];
        int count = split_csv(line, value, 64);
        if (count != header_count) die("inconsistent actual summary CSV row");
        int field = atoi(value[field_column]);
        int f = atoi(value[f_column]);
        int delta = atoi(value[delta_column]);
        int K = atoi(value[K_column]);
        int kappa = atoi(value[kappa_column]);
        long double logarithm = first_moment_log2(field, f, kappa);
        long double moment = exp2l(logarithm);
        printf("%d,%d,%d,%d,%d,%d,%.12Lf,", field, field, f, delta, K,
               kappa, logarithm);
        if (isfinite(moment) && moment != 0.0L && moment <= LDBL_MAX) {
            printf("%.12Le", moment);
        }
        putchar('\n');
    }
    free(line);
    if (fclose(input) != 0) die("cannot close actual summary");
    return 0;
}
