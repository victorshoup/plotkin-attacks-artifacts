BEGIN { FS = ","; failures = 0 }

FNR == 1 {
    for (name in column) delete column[name]
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

function fail(message) {
    print FILENAME ":" FNR ": " message > "/dev/stderr"
    failures = 1
}

{
    ++rows
    q = $(column["field"]) + 0
    f = $(column["f"]) + 0
    K = $(column["K"]) + 0
    kappa = $(column["kappa"]) + 0
    rank_B = $(column["rank_B"]) + 0
    budget = $(column["restart_budget"]) + 0
    executed = $(column["restarts_executed"]) + 0
    success = $(column["success"]) + 0
    weight = $(column["minimum_word_weight"]) + 0
    zeros = column["number_of_zero_honest_ESIs"] \
        ? $(column["number_of_zero_honest_ESIs"]) + 0 \
        : $(column["number_of_zero_rows"]) + 0
    first = $(column["first_success_restart"]) + 0
    selected = $(column["selected_restart"]) + 0
    residual = $(column["residual_dimension"]) + 0
    directions = $(column["directions_enumerated"]) + 0
    canonical_success = $(column["canonical_success"]) + 0
    canonical_weight = $(column["canonical_weight"]) + 0
    canonical_zeros = $(column["canonical_zero_count"]) + 0
    canonical_residual = $(column["canonical_residual_dimension"]) + 0
    canonical_directions = $(column["canonical_directions_enumerated"]) + 0
    if (!(q == 4 || q == 16 || q == 256)) fail("invalid field")
    if (q == 256 && kappa != K) fail("GF(256) kappa is not K")
    if (rank_B < 0 || rank_B > kappa) fail("invalid induced rank")
    if (executed != budget) fail("not every configured path executed")
    if (kappa == 0) {
        if (success || weight != -1 || zeros != -1 || first != -1 ||
            selected != -1 || residual != -1 || directions != 0 ||
            canonical_success != 0 || canonical_weight != -1 ||
            canonical_zeros != -1 || canonical_residual != -1 ||
            canonical_directions != 0) {
            fail("zero-dimensional code did not report the exact empty outcome")
        }
        next
    }
    if (selected < 0 || selected >= budget) fail("invalid selected path")
    if (success != (weight <= f)) fail("success/weight mismatch")
    if (zeros != 2 * f + 1 - weight) fail("weight/zero-count mismatch")
    if (success && first < 0) fail("successful search lacks first path")
    if (!success && first != -1) fail("failed search has first-success path")
    expected_residual = kappa < exact_d ? kappa : exact_d
    if (residual != expected_residual) fail("did not stop at first exact threshold")
    power = 1
    for (i = 0; i < residual; ++i) power *= q
    expected_directions = (power - 1) / (q - 1)
    if (directions != expected_directions) fail("incomplete projective enumeration")
    if (canonical_success != (canonical_weight <= f))
        fail("canonical success/weight mismatch")
    if (canonical_zeros != 2 * f + 1 - canonical_weight)
        fail("canonical weight/zero-count mismatch")
    if (canonical_residual != expected_residual)
        fail("canonical path did not stop at first exact threshold")
    if (canonical_directions != expected_directions)
        fail("canonical path did not complete exact enumeration")
    if (column["full_column_rank"] &&
        ($(column["full_column_rank"]) != 1 || rank_B != kappa)) {
        fail("random matrix is not full column rank")
    }
}

END {
    if (rows == 0) fail("no instance rows")
    if (failures) exit 1
    print "INSTANCE VERIFICATION PASS: " rows " rows" > "/dev/stderr"
}
