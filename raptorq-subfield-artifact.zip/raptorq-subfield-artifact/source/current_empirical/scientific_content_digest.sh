#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
INDEX="$EMPIRICAL_DIR/honest_esi_sets/index.csv"

test -s "$INDEX"
{
    echo "SCIENTIFIC_CONTENT_DIGEST_V1"
    find "$EMPIRICAL_DIR/raw" -type f -name instances.csv | LC_ALL=C sort |
        while IFS= read -r file; do
            relative=${file#"$EMPIRICAL_DIR/"}
            printf '@FILE,%s\n' "$relative"
            cat "$file"
        done
    echo "@STRUCTURAL_RECORDS"
    find "$EMPIRICAL_DIR/raw" -type f -name zero_set_structure.csv | LC_ALL=C sort |
        while IFS= read -r file; do
            relative=${file#"$EMPIRICAL_DIR/"}
            printf '@FILE,%s\n' "$relative"
            cat "$file"
        done
} | awk -F, -v index_file="$INDEX" '
    BEGIN {
        OFS = ","
        if ((getline line < index_file) <= 0) exit 2
        ni = split(line, ih, FS)
        for (i = 1; i <= ni; ++i) ic[ih[i]] = i
        while ((getline line < index_file) > 0) {
            nv = split(line, iv, FS)
            key = iv[ic["f"]] SUBSEP iv[ic["sample"]]
            digest[key] = iv[ic["esi_list_sha256"]]
        }
        close(index_file)
    }
    /^SCIENTIFIC_CONTENT_DIGEST_V1$/ { print; next }
    $1 == "@STRUCTURAL_RECORDS" { structural = 1; print; next }
    $1 == "@FILE" { path = $2; print "FILE", path; next }
    $1 == "ensemble" || $1 == "field" {
        delete c
        delete keep
        for (i = 1; i <= NF; ++i) {
            c[$i] = i
            keep[i] = ($i != "esi_list_id" && $i != "esi_list_sha256")
        }
        if (!structural) print "INSTANCE_HEADER_WITH_ORDERED_ESI_SHA256"
        else print "STRUCTURAL_HEADER"
        next
    }
    {
        if (!structural) {
            key = $(c["f"]) SUBSEP $(c["sample"])
            if (!(key in digest)) exit 2
            printf "I,%s", digest[key]
        } else {
            printf "S"
        }
        for (i = 1; i <= NF; ++i) if (keep[i]) printf ",%s", $i
        printf "\n"
    }
' | shasum -a 256 | awk '{print $1}'
