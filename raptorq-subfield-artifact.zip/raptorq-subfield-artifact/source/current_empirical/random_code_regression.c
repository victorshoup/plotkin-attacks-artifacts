#define main rq_subfield_campaign_program_main
#include "rq_empirical.c"
#undef main

#include "random_code_common.h"

#define CHECK(condition, message) do { \
    if (!(condition)) { \
        fprintf(stderr, "RANDOM REGRESSION FAIL: %s\n", message); \
        return 1; \
    } \
} while (0)

int main(void)
{
    gf256_init();
    {
        static const uint8_t expected_abc[32] = {
            0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
            0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
            0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
            0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
        };
        static const uint8_t expected_counter_block[32] = {
            0xeb, 0x03, 0x3d, 0x9c, 0x3d, 0x11, 0x6d, 0xde,
            0x4f, 0x3c, 0xd2, 0xfb, 0xb7, 0x23, 0xf1, 0x13,
            0x61, 0x79, 0xe3, 0x62, 0x56, 0x28, 0x4e, 0x4b,
            0xe9, 0xe8, 0x78, 0x31, 0x5d, 0xfa, 0x33, 0x6d
        };
        uint8_t digest[32];
        sha256_digest((const uint8_t *)"abc", 3, digest);
        CHECK(memcmp(digest, expected_abc, sizeof(digest)) == 0,
              "SHA-256 standard abc vector mismatch");
        random_matrix_rng counter_rng;
        random_matrix_rng_init(&counter_rng, UINT64_C(0x0123456789abcdef));
        random_matrix_rng_refill(&counter_rng);
        CHECK(memcmp(counter_rng.block, expected_counter_block,
                     sizeof(counter_rng.block)) == 0,
              "SHA-256 counter encoding vector mismatch");
    }
    const int fields[] = {4, 16, 256};
    for (size_t index = 0; index < sizeof(fields) / sizeof(fields[0]); ++index) {
        int field = fields[index];
        subfield sf;
        subfield_init(&sf, field);
        uint64_t seed = random_code_derived_seed(UINT64_C(2026090300),
                                                 field, 8, 1, 3,
                                                 RANDOM_CODE_MATRIX_DOMAIN);
        CHECK(seed == random_code_derived_seed(UINT64_C(2026090300),
                                               field, 8, 1, 3,
                                               RANDOM_CODE_MATRIX_DOMAIN),
              "seed derivation is not deterministic");
        CHECK(seed != random_code_derived_seed(UINT64_C(2026090300),
                                               field, 8, 1, 4,
                                               RANDOM_CODE_MATRIX_DOMAIN),
              "sample domain separation failed");
        CHECK(seed != random_code_derived_seed(UINT64_C(2026090300),
                                               field, 8, 1, 3,
                                               RANDOM_CODE_SEARCH_DOMAIN),
              "matrix/search domain separation failed");

        int attempts_a = 0;
        int attempts_b = 0;
        matrix_u8 a = random_full_column_rank_matrix(9, 4, &sf, seed,
                                                      &attempts_a);
        matrix_u8 b = random_full_column_rank_matrix(9, 4, &sf, seed,
                                                      &attempts_b);
        CHECK(attempts_a == attempts_b, "deterministic attempt count mismatch");
        CHECK(memcmp(a.rows, b.rows, 9u * 4u) == 0,
              "deterministic matrix mismatch");
        CHECK(matrix_rank(&a) == 4, "matrix is not full column rank");
        for (int i = 0; i < 9 * 4; ++i) {
            bool member = false;
            for (int j = 0; j < sf.q; ++j) {
                member |= a.rows[i] == sf.elems[j];
            }
            CHECK(member, "matrix entry is outside declared field");
        }

        uint64_t search_seed = random_code_derived_seed(UINT64_C(2026090300),
                                                        field, 8, 1, 3,
                                                        RANDOM_CODE_SEARCH_DOMAIN);
        search_result first = search_explicit_word(&a, &sf, 4, 3,
                                                   search_seed, 3,
                                                   UINT64_C(70000), NULL);
        search_result second = search_explicit_word(&b, &sf, 4, 3,
                                                    search_seed, 3,
                                                    UINT64_C(70000), NULL);
        CHECK(first.best.valid == second.best.valid,
              "search validity is not deterministic");
        CHECK(first.best.weight == second.best.weight,
              "search weight is not deterministic");
        CHECK(first.best.rank_saving == second.best.rank_saving,
              "search geometry is not deterministic");
        FILE *trace_stream = tmpfile();
        CHECK(trace_stream != NULL, "cannot create temporary trace stream");
        FILE *summary_stream = tmpfile();
        CHECK(summary_stream != NULL, "cannot create temporary summary stream");
        trace_context trace = {
            .summary_stream = summary_stream,
            .full_stream = trace_stream,
            .write_full = true,
            .ensemble = "regression",
            .field = field,
            .f = 4,
            .delta = 0,
            .sample = 3,
            .instance_seed = seed
        };
        search_result traced = search_explicit_word(&a, &sf, 4, 3,
                                                    search_seed, 3,
                                                    UINT64_C(70000), &trace);
        CHECK(traced.restarts_executed == 3,
              "search did not execute every configured greedy path");
        CHECK(traced.best.valid && traced.best.residual_dimension == 3,
              "path did not stop at its first exact-enumeration threshold");
        bool direction_ok = false;
        uint64_t expected_directions = projective_direction_count(field, 3,
                                                                   &direction_ok);
        CHECK(direction_ok &&
                  traced.best.directions_enumerated == expected_directions,
              "path did not enumerate the complete projective residual space");
        rewind(trace_stream);
        int trace_lines = 0;
        char trace_line[2048];
        while (fgets(trace_line, sizeof(trace_line), trace_stream) != NULL) {
            ++trace_lines;
        }
        CHECK(trace_lines == 3,
              "path instrumentation did not record one d=4 step per path");
        rewind(summary_stream);
        int summary_lines = 0;
        while (fgets(trace_line, sizeof(trace_line), summary_stream) != NULL) {
            ++summary_lines;
        }
        CHECK(summary_lines == 1,
              "compact instrumentation did not record one d=4 summary");
        CHECK(traced.projective_steps == 3,
              "instance aggregate has the wrong projective-step count");
        CHECK(fclose(trace_stream) == 0,
              "cannot close temporary trace stream");
        CHECK(fclose(summary_stream) == 0,
              "cannot close temporary summary stream");
        free_candidate(&traced.best);
        free_candidate(&first.best);
        free_candidate(&second.best);
        free_matrix(&a);
        free_matrix(&b);
    }

    /* Production-scale rank/determinism checks, including >64 columns. */
    const int large_fields[] = {4, 16, 256};
    const int large_columns[] = {66, 86, 96};
    for (size_t index = 0;
         index < sizeof(large_fields) / sizeof(large_fields[0]);
         ++index) {
        subfield sf;
        subfield_init(&sf, large_fields[index]);
        uint64_t seed = random_code_derived_seed(UINT64_C(202609050001),
                                                 large_fields[index],
                                                 96, 1, 0,
                                                 RANDOM_CODE_MATRIX_DOMAIN);
        int attempts_a = 0;
        int attempts_b = 0;
        matrix_u8 a = random_full_column_rank_matrix(193,
                                                      large_columns[index],
                                                      &sf, seed,
                                                      &attempts_a);
        matrix_u8 b = random_full_column_rank_matrix(193,
                                                      large_columns[index],
                                                      &sf, seed,
                                                      &attempts_b);
        CHECK(attempts_a == attempts_b,
              "large deterministic attempt count mismatch");
        CHECK(memcmp(a.rows, b.rows,
                     193u * (size_t)large_columns[index]) == 0,
              "large deterministic matrix mismatch");
        CHECK(matrix_rank(&a) == large_columns[index],
              "production-scale matrix is not full rank");
        free_matrix(&a);
        free_matrix(&b);
    }
    fprintf(stderr,
            "RANDOM CODE REGRESSION PASS: SHA-256 vectors, deterministic seeds, full rank above 64 columns, field membership, clean stopping semantics, complete path traces\n");
    return 0;
}
