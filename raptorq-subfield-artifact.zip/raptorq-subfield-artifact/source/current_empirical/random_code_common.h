#ifndef RANDOM_CODE_COMMON_H
#define RANDOM_CODE_COMMON_H

#include "sha256_counter.h"

#define RANDOM_CODE_MATRIX_DOMAIN UINT64_C(0x52414e444f4d4d58)
#define RANDOM_CODE_SEARCH_DOMAIN UINT64_C(0x52414e4453454152)
#define RANDOM_CODE_GENERATOR_VERSION "sha256_counter_be_v3"

static uint64_t random_code_mix64(uint64_t value)
{
    value ^= value >> 30;
    value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27;
    value *= UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}

static uint64_t random_code_derived_seed(uint64_t master,
                                         int field,
                                         int f,
                                         int delta,
                                         int sample,
                                         uint64_t domain)
{
    uint64_t value = master ^ domain;
    value = random_code_mix64(value ^ (uint64_t)field *
                              UINT64_C(0x9e3779b97f4a7c15));
    value = random_code_mix64(value ^ (uint64_t)f *
                              UINT64_C(0xd6e8feb86659fd93));
    value = random_code_mix64(value ^ (uint64_t)delta *
                              UINT64_C(0xa5a3564e27f8862f));
    value = random_code_mix64(value ^ (uint64_t)sample *
                              UINT64_C(0x8cb92baa3f3d8dd7));
    return value;
}

typedef struct {
    uint64_t seed;
    uint64_t counter;
    uint8_t block[32];
    size_t offset;
} random_matrix_rng;

static void random_matrix_rng_init(random_matrix_rng *rng, uint64_t seed)
{
    rng->seed = seed;
    rng->counter = 0;
    rng->offset = sizeof(rng->block);
}

static void random_matrix_rng_refill(random_matrix_rng *rng)
{
    static const uint8_t domain[] = "rq-random-matrix-sha256-v1";
    uint8_t input[sizeof(domain) - 1u + 16u];
    memcpy(input, domain, sizeof(domain) - 1u);
    sha256_store_be64(input + sizeof(domain) - 1u, rng->seed);
    sha256_store_be64(input + sizeof(domain) - 1u + 8u, rng->counter);
    sha256_digest(input, sizeof(input), rng->block);
    if (rng->counter == UINT64_MAX) {
        die("random-matrix SHA-256 counter exhausted");
    }
    ++rng->counter;
    rng->offset = 0;
}

static uint64_t random_matrix_u64(random_matrix_rng *rng)
{
    if (rng->offset == sizeof(rng->block)) {
        random_matrix_rng_refill(rng);
    }
    uint64_t value = 0;
    for (int i = 0; i < 8; ++i) {
        value = (value << 8) | rng->block[rng->offset++];
    }
    return value;
}

/* Equal contiguous buckets after rejection give an unbiased bounded draw. */
static size_t random_matrix_index(random_matrix_rng *rng, size_t n)
{
    if (n == 0) {
        die("invalid random-matrix sampling bound");
    }
    uint64_t nn = (uint64_t)n;
    uint64_t bucket_size = UINT64_MAX / nn;
    uint64_t limit = bucket_size * nn;
    for (;;) {
        uint64_t value = random_matrix_u64(rng);
        if (value < limit) {
            return (size_t)(value / bucket_size);
        }
    }
}

static matrix_u8 random_full_column_rank_matrix(int nrows,
                                                 int ncols,
                                                 const subfield *sf,
                                                 uint64_t seed,
                                                 int *attempts_out)
{
    if (nrows < ncols || ncols < 0) {
        die("invalid random full-column-rank matrix dimensions");
    }
    matrix_u8 matrix = {
        .rows = xcalloc((size_t)nrows * ncols, 1),
        .nrows = nrows,
        .ncols = ncols
    };
    if (ncols == 0) {
        *attempts_out = 1;
        return matrix;
    }
    random_matrix_rng rng;
    random_matrix_rng_init(&rng, seed);
    int attempts = 0;
    do {
        ++attempts;
        for (int i = 0; i < nrows * ncols; ++i) {
            matrix.rows[i] = sf->elems[random_matrix_index(&rng,
                                                           (size_t)sf->q)];
        }
    } while (matrix_rank(&matrix) != ncols);
    *attempts_out = attempts;
    return matrix;
}

#endif
