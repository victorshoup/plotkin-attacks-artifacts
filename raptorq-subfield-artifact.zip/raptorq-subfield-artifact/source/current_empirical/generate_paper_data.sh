#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SUMMARIES="$EMPIRICAL_DIR/summaries"
OUTPUT="$ARTIFACT_DIR/paper_data"

mkdir -p "$OUTPUT"

cp "$SUMMARIES/delta0.csv" "$OUTPUT/delta0_transition.csv"
cp "$SUMMARIES/gf256_deep_tail.csv" "$OUTPUT/gf256_deep_tail.csv"
cp "$SUMMARIES/comparison.csv" "$OUTPUT/matched_random_summary.csv"
cp "$SUMMARIES/projective_comparison.csv" "$OUTPUT/projective_summary.csv"
cp "$SUMMARIES/zero_set_structure_aggregate.csv" \
    "$OUTPUT/zero_set_rank_summary.csv"
cp "$SUMMARIES/deeper_enumeration.csv" "$OUTPUT/search_sensitivity.csv"

# Emit the complete rectangular plotting domain.  Invalid K<10 cells are
# explicit rows and can therefore be styled differently from measured zeros.
for q in 4 16 256; do
    awk -F, -v wanted="$q" '
        BEGIN { OFS = "," }
        NR == 1 {
            for (i = 1; i <= NF; ++i) c[$i] = i
            next
        }
        $(c["field"]) == wanted {
            key = $(c["f"]) SUBSEP $(c["Delta"])
            seen[key] = 1
            kappa[key] = $(c["kappa"])
            samples[key] = $(c["samples"])
            rqn[key] = $(c["rq_successes"])
            rqp[key] = $(c["rq_success_fraction"])
            randomn[key] = $(c["random_successes"])
            randomp[key] = $(c["random_success_fraction"])
            moment[key] = $(c["log2_first_moment"])
        }
        END {
            print "field,f,delta,K,valid,kappa_q,samples,rq_successes," \
                  "rq_success_fraction,random_successes," \
                  "random_success_fraction,log2_E_q"
            rows = 0
            for (f = 12; f <= 96; f += 4) {
                for (delta = 1; delta <= 40; ++delta) {
                    K = f + 1 - delta
                    key = f SUBSEP delta
                    if (K >= 10) {
                        if (!seen[key]) {
                            print "missing measured heat-map cell", wanted, f, delta \
                                > "/dev/stderr"
                            exit 2
                        }
                        print wanted, f, delta, K, 1, kappa[key], samples[key], \
                              rqn[key], rqp[key], randomn[key], randomp[key], \
                              moment[key]
                    } else {
                        print wanted, f, delta, K, 0, "", 0, "", "", "", "", ""
                    }
                    ++rows
                }
            }
            if (rows != 880) exit 2
        }
    ' "$SUMMARIES/positive_grid.csv" > "$OUTPUT/positive_heatmap_gf${q}.csv"
done

# The requested transition markers are finite-grid observations, not
# probabilities or monotone coding-theoretic thresholds.
awk -F, '
    BEGIN { OFS = "," }
    NR == 1 {
        for (i = 1; i <= NF; ++i) c[$i] = i
        next
    }
    {
        q = $(c["field"]) + 0
        f = $(c["f"]) + 0
        k = $(c["kappa"]) + 0
        s = $(c["rq_successes"]) + 0
        if (k > 0 && (!(q in first_kappa) || f < first_kappa[q])) first_kappa[q] = f
        if (s > 0 && (!(q in first_any) || f < first_any[q])) first_any[q] = f
        if (s >= 5 && (!(q in first_5) || f < first_5[q])) first_5[q] = f
        if (s >= 10 && (!(q in first_10) || f < first_10[q])) first_10[q] = f
    }
    END {
        print "field,first_f_kappa_positive,first_f_any_observed_success," \
              "first_f_at_least_5_of_100,first_f_at_least_10_of_100," \
              "interpretation"
        qlist[1] = 4; qlist[2] = 16; qlist[3] = 256
        for (i = 1; i <= 3; ++i) {
            q = qlist[i]
            print q, first_kappa[q], first_any[q], first_5[q], first_10[q], \
                  "observed_search_success_on_f_9_through_45"
        }
    }
' "$SUMMARIES/delta0.csv" > "$OUTPUT/dimension_vs_empirical_transition.csv"

for q in 4 16 256; do
    test "$(($(wc -l < "$OUTPUT/positive_heatmap_gf${q}.csv") - 1))" = 880
done
test "$(($(wc -l < "$OUTPUT/delta0_transition.csv") - 1))" = 111
test "$(($(wc -l < "$OUTPUT/gf256_deep_tail.csv") - 1))" = 71
test "$(($(wc -l < "$OUTPUT/dimension_vs_empirical_transition.csv") - 1))" = 3

echo "PAPER DATA GENERATION PASS"
