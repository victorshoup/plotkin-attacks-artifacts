#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SOURCE_DIR="$ARTIFACT_DIR/source/current_empirical"
ROOT_DIR=$(CDPATH= cd -- "$ARTIFACT_DIR/.." && pwd)
if test -d "$ARTIFACT_DIR/source/nanorq"; then
    DEFAULT_NANORQ="$ARTIFACT_DIR/source/nanorq"
else
    DEFAULT_NANORQ="$ROOT_DIR/nanorq"
fi
NANORQ_CHECKOUT=${1:-"$DEFAULT_NANORQ"}
PINNED_COMMIT=6295a9525893b9a757dd57431db76fc6ecceafac
CHECKER="$ARTIFACT_DIR/build/nanorq_witness_audit"
CONFIG="$EMPIRICAL_DIR/config/selected_witnesses.csv"
OUTPUT_DIR=${VALIDATION_OUTPUT_DIR:-"$EMPIRICAL_DIR/validation"}
CSV="$OUTPUT_DIR/nanorq_validation.csv"
LOG="$OUTPUT_DIR/nanorq_validation.log"
CC=${CC:-cc}
export CC
CFLAGS='-O2 -std=c11 -Wall -Wextra -Wpedantic'

mkdir -p "$OUTPUT_DIR"
test -f "$NANORQ_CHECKOUT/libnanorq.a"
if test -d "$NANORQ_CHECKOUT/.git"; then
    actual_commit=$(git -C "$NANORQ_CHECKOUT" rev-parse HEAD)
    test -z "$(git -C "$NANORQ_CHECKOUT" status --short)"
else
    actual_commit=$(cat "$NANORQ_CHECKOUT/PINNED_COMMIT")
fi
test "$actual_commit" = "$PINNED_COMMIT"

"$CC" $CFLAGS -I"$NANORQ_CHECKOUT/include" -I"$NANORQ_CHECKOUT/deps" \
    "$SOURCE_DIR/nanorq_witness_audit.c" \
    "$NANORQ_CHECKOUT/libnanorq.a" -o "$CHECKER"

{
    echo "selected-witness independent validation"
    echo "nanorq commit: $actual_commit"
    echo "nanorq provenance: pinned commit; source tree was clean when exported"
    echo "compiler:"
    "$CC" --version
    echo "build command:"
    echo "$CC $CFLAGS -I<NANORQ>/include -I<NANORQ>/deps source/nanorq_witness_audit.c <NANORQ>/libnanorq.a -o build/nanorq_witness_audit"
} > "$LOG"

echo "field,f,Delta,K,sample,region,weight,zero_count,restart,source_difference_hex,intermediate_difference_hex,witness_file,witness_sha256,nanorq_commit,systematic_symbols,all_honest_ESIs,serialized_zero_ESIs,decoder_behavior,result" \
    > "$CSV"

passes=0
while IFS=, read -r field f delta sample region point_rule witness_rule; do
    test "$field" = field && continue
    relative="empirical/witnesses/selected/q${field}_f${f}_d${delta}_s${sample}/witnesses/witness_q${field}_f${f}_delta${delta}_sample${sample}.txt"
    witness="$ARTIFACT_DIR/$relative"
    test -s "$witness"
    witness_field=$(sed -n 's/^field=//p' "$witness")
    witness_f=$(sed -n 's/^f=//p' "$witness")
    witness_delta=$(sed -n 's/^Delta=//p' "$witness")
    witness_K=$(sed -n 's/^K=//p' "$witness")
    weight=$(sed -n 's/^weight=//p' "$witness")
    zeros=$(sed -n 's/^zeros=//p' "$witness")
    restart=$(sed -n 's/^restart=//p' "$witness")
    source_hex=$(sed -n 's/^source_difference_hex=//p' "$witness")
    intermediate_hex=$(sed -n 's/^intermediate_difference_hex=//p' "$witness")
    test "$witness_field" = "$field"
    test "$witness_f" = "$f"
    test "$witness_delta" = "$delta"
    witness_hash=$(shasum -a 256 "$witness" | awk '{ print $1 }')
    {
        echo
        echo "=== q=$field f=$f Delta=$delta sample=$sample region=$region ==="
        echo "command: $CHECKER $witness"
    } >> "$LOG"
    "$CHECKER" "$witness" >> "$LOG" 2>&1
    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
        "$field" "$f" "$delta" "$witness_K" "$sample" "$region" \
        "$weight" "$zeros" "$restart" "$source_hex" "$intermediate_hex" \
        "$relative" "$witness_hash" "$actual_commit" pass pass pass \
        not_exercised_not_required_for_difference_witness pass >> "$CSV"
    passes=$((passes + 1))
done < "$CONFIG"

expected=$(($(wc -l < "$CONFIG") - 1))
test "$passes" = "$expected"
test "$(grep -c '^NANORQ FULL WITNESS PASS:' "$LOG" || true)" = "$expected"
echo "NANORQ SELECTED WITNESS VALIDATION PASS: $passes witnesses"
