#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SOURCE_DIR="$ARTIFACT_DIR/source/current_empirical"
SUMMARIES="$EMPIRICAL_DIR/summaries"

"$SOURCE_DIR/audit_outputs.sh" "$EMPIRICAL_DIR"
awk -f "$SOURCE_DIR/verify_structure.awk" "$SUMMARIES/zero_set_structure.csv"

# Every matched-random row records a full-column-rank generator, except the
# intentionally matrix-free kappa=0 case, which records rank 0 and no search.
find "$EMPIRICAL_DIR/raw" -path '*/random/*' -name instances.csv -type f -print0 |
    xargs -0 cat | awk -F, '
        FNR == 1 {
            delete c
            for (i = 1; i <= NF; ++i) c[$i] = i
            next
        }
        $1 == "ensemble" {
            delete c
            for (i = 1; i <= NF; ++i) c[$i] = i
            next
        }
        {
            ++rows
            kappa = $(c["kappa"]) + 0
            attempts = $(c["generation_attempts"]) + 0
            fullrank = $(c["full_column_rank"]) + 0
            rank = $(c["rank_B"]) + 0
            if ($(c["random_generator"]) != "sha256_counter_be_v3") bad = 1
            if (kappa == 0) {
                if (rank != 0 || $(c["success"]) != 0 || \
                    $(c["directions_enumerated"]) != 0) bad = 1
            } else if (attempts < 1 || fullrank != 1 || rank != kappa) bad = 1
        }
        END {
            if (bad || rows != 225700) exit 2
            print "RANDOM MATRIX RANK PASS: " rows " rows"
        }
    '

# Independently map each GF(16) experimental K through the RFC Kprime table to
# obtain H, then compare the empirical kappa to the certified all-K formula
# max(0,K-H).  The endpoint table's kappa16 column is for K=Kprime and must not
# be compared directly when the empirical K lies inside an RFC padding band.
find "$EMPIRICAL_DIR/raw" -name instances.csv -type f -print0 |
    xargs -0 cat | awk -F, -v certificate="$ARTIFACT_DIR/dimensions/gf16/gf16_kprime_dimensions.csv" '
        BEGIN {
            if ((getline line < certificate) <= 0) exit 2
            nheader = split(line, header, FS)
            for (i = 1; i <= nheader; ++i) cert[header[i]] = i
            while ((getline line < certificate) > 0) {
                split(line, value, FS)
                hdpc[value[cert["Kprime"]]] = value[cert["H"]]
            }
            close(certificate)
        }
        $1 == "ensemble" || $1 == "field" {
            delete c
            for (i = 1; i <= NF; ++i) c[$i] = i
            next
        }
        $(c["field"]) == 16 {
            ++rows
            kp = $(c["Kprime"])
            K = $(c["K"]) + 0
            expected = K > hdpc[kp] ? K - hdpc[kp] : 0
            if (!(kp in hdpc) || $(c["kappa"]) != expected) {
                if (!bad)
                    print "GF16 empirical/certificate mismatch at input row", FNR \
                        > "/dev/stderr"
                bad = 1
            }
        }
        END {
            if (bad || rows == 0) exit 2
            print "GF16 EMPIRICAL/CERTIFICATE CROSS-CHECK PASS: " rows " rows"
        }
    '

"$SOURCE_DIR/verify_search_sensitivity.sh"
"$SOURCE_DIR/audit_esi_dedup.sh"
echo "SAVED EMPIRICAL VERIFICATION PASS"
