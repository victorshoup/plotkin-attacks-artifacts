BEGIN { FS = ","; OFS = ","; failures = 0 }

FNR == 1 {
    for (name in column) delete column[name]
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

{
    # Schema 4 deliberately keys honest-set generation only by (f,sample).
    # Combining every phase, field, and Delta in one invocation therefore checks
    # the central pairing rule directly rather than merely checking fields at a
    # fixed point.
    key = $(column["f"]) SUBSEP $(column["sample"])
    list = $(column["honest_ESIs"])
    seed = $(column["honest_set_seed"])
    field = $(column["field"])
    if (!(key in canonical)) {
        canonical[key] = list
        canonical_seed[key] = seed
    } else if (canonical[key] != list || canonical_seed[key] != seed) {
        print "ESI pairing mismatch at", key > "/dev/stderr"
        failures = 1
    }
    field_key = key SUBSEP field
    if (!(field_key in seen_field)) {
        seen_field[field_key] = 1
        ++field_count[key]
    }
    ++records[key]
}

END {
    print "f,sample,field_count,record_count,honest_set_seed,honest_ESIs"
    for (key in canonical) {
        if (expected_fields != "" && field_count[key] != expected_fields) {
            print "unexpected field count at", key, field_count[key] > "/dev/stderr"
            failures = 1
        }
        split(key, part, SUBSEP)
        print part[1], part[2], field_count[key], records[key], \
            canonical_seed[key], canonical[key]
    }
    if (failures) exit 1
}
