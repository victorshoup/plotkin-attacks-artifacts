#define main rq_subfield_campaign_program_main
#include "rq_empirical.c"
#undef main

#include "random_code_common.h"

typedef struct {
    int field;
    int f;
    int delta;
    int samples;
    int sample_start;
    int restarts;
    int max_residual_dimension;
    uint64_t max_directions;
    uint64_t master_seed;
    const char *output_path;
    trace_mode_kind trace_mode;
    const char *trace_summary_path;
    const char *trace_path;
    int diagnostic_sample;
} random_options;

static void random_usage(const char *program)
{
    fprintf(stderr,
            "usage: %s --field 4|16|256 --f N --delta N --samples N "
            "--sample-start N --restarts N --max-residual-d N "
            "--max-directions N --seed U64 --out FILE "
            "[--trace-mode summary|diagnostic|full] "
            "[--trace-summary-out FILE] [--trace-out FILE] "
            "[--diagnostic-sample N]\n",
            program);
}

int main(int argc, char **argv)
{
    random_options opts = {
        .field = 0,
        .f = -1,
        .delta = -1,
        .samples = 0,
        .sample_start = 0,
        .restarts = 0,
        .max_residual_dimension = 0,
        .max_directions = 0,
        .master_seed = 0,
        .output_path = NULL,
        .trace_mode = TRACE_MODE_SUMMARY,
        .trace_summary_path = NULL,
        .trace_path = NULL,
        .diagnostic_sample = -1
    };
    for (int i = 1; i < argc; ++i) {
#define RANDOM_VALUE() do { if (i + 1 >= argc) die("missing option value"); } while (0)
        if (strcmp(argv[i], "--field") == 0) {
            RANDOM_VALUE(); opts.field = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--f") == 0) {
            RANDOM_VALUE(); opts.f = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--delta") == 0) {
            RANDOM_VALUE(); opts.delta = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--samples") == 0) {
            RANDOM_VALUE(); opts.samples = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--sample-start") == 0) {
            RANDOM_VALUE(); opts.sample_start = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--restarts") == 0) {
            RANDOM_VALUE(); opts.restarts = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--max-residual-d") == 0) {
            RANDOM_VALUE(); opts.max_residual_dimension = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--max-directions") == 0) {
            RANDOM_VALUE(); opts.max_directions = parse_u64(argv[++i]);
        } else if (strcmp(argv[i], "--seed") == 0) {
            RANDOM_VALUE(); opts.master_seed = parse_u64(argv[++i]);
        } else if (strcmp(argv[i], "--out") == 0) {
            RANDOM_VALUE(); opts.output_path = argv[++i];
        } else if (strcmp(argv[i], "--trace-mode") == 0) {
            RANDOM_VALUE(); opts.trace_mode = parse_trace_mode(argv[++i]);
        } else if (strcmp(argv[i], "--trace-summary-out") == 0) {
            RANDOM_VALUE(); opts.trace_summary_path = argv[++i];
        } else if (strcmp(argv[i], "--trace-out") == 0) {
            RANDOM_VALUE(); opts.trace_path = argv[++i];
        } else if (strcmp(argv[i], "--diagnostic-sample") == 0) {
            RANDOM_VALUE(); opts.diagnostic_sample = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--help") == 0) {
            random_usage(argv[0]);
            return 0;
        } else {
            random_usage(argv[0]);
            die("unknown random-code option");
        }
#undef RANDOM_VALUE
    }
    if (!(opts.field == 4 || opts.field == 16 || opts.field == 256) ||
        opts.f < 1 || opts.delta < 0 || opts.f + 1 - opts.delta < 10 ||
        opts.samples <= 0 || opts.sample_start < 0 || opts.restarts <= 0 ||
        opts.max_residual_dimension <= 0 || opts.max_directions == 0 ||
        opts.output_path == NULL) {
        die("invalid random-code campaign options");
    }
    if (opts.trace_mode == TRACE_MODE_SUMMARY && opts.trace_path != NULL) {
        die("summary trace mode cannot write full path traces");
    }
    if (opts.trace_mode == TRACE_MODE_DIAGNOSTIC &&
        (opts.trace_path == NULL || opts.diagnostic_sample < 0)) {
        die("diagnostic trace mode requires --trace-out and --diagnostic-sample");
    }

    gf256_init();
    subfield sf;
    subfield_init(&sf, opts.field);
    int K = opts.f + 1 - opts.delta;
    int n = 3 * opts.f + 1;
    int h = 2 * opts.f + 1;
    rq_params p = get_params(K);
    int kappa = K;
    if (opts.field != 256) {
        matrix_u8 constraints = build_subfield_constraints(&p, &sf);
        int computed_kappa = 0;
        uint8_t *ambiguity_basis =
            kernel_basis_of_matrix(&constraints, &computed_kappa);
        kappa = computed_kappa;
        free(ambiguity_basis);
        free_matrix(&constraints);
    }
    if (kappa < 0 || kappa > h) {
        die("random-code kappa is outside full-column-rank range");
    }

    FILE *csv = fopen(opts.output_path, "w");
    if (csv == NULL) {
        die("cannot open random-code output CSV");
    }
    fprintf(csv,
            "ensemble,random_generator,field,f,n,h,K,Delta,Kprime,S,H_HDPC,W,L,P,P1,kappa,sample,"
            "random_matrix_seed,search_seed,generation_attempts,full_column_rank,rank_B,"
            "restart_budget,restarts_executed,max_residual_dimension,max_directions,"
            "success,minimum_word_weight,number_of_zero_rows,first_success_restart,"
            "selected_restart,selected_cardinality,selected_rank,rank_saving,"
            "residual_dimension,directions_enumerated,successful_paths,projective_steps,"
            "nontrivial_projective_steps,nontrivial_projective_fraction,"
            "largest_projective_class_max,largest_projective_class_mean,"
            "chosen_projective_class_mean,projective_saving_max,projective_saving_mean,"
            "generation_ms,search_ms,canonical_success,canonical_weight,"
            "canonical_zero_count,canonical_residual_dimension,"
            "canonical_directions_enumerated\n");
    FILE *trace_summary_csv = NULL;
    if (opts.trace_summary_path != NULL) {
        trace_summary_csv = fopen(opts.trace_summary_path, "w");
        if (trace_summary_csv == NULL) die("cannot open random path-summary CSV");
        fprintf(trace_summary_csv,
                "ensemble,field,f,Delta,sample,residual_dimension,"
                "all_paths,all_nontrivial_paths,all_nontrivial_fraction,"
                "all_largest_min,all_largest_median,all_largest_mean,all_largest_max,"
                "all_chosen_min,all_chosen_median,all_chosen_mean,all_chosen_max,"
                "all_saving_min,all_saving_median,all_saving_mean,all_saving_max,"
                "all_maximum_class_count_min,all_maximum_class_count_median,all_maximum_class_count_mean,all_maximum_class_count_max,"
                "success_paths,success_nontrivial_paths,success_nontrivial_fraction,"
                "success_largest_min,success_largest_median,success_largest_mean,success_largest_max,"
                "success_saving_min,success_saving_median,success_saving_mean,success_saving_max,"
                "failure_paths,failure_nontrivial_paths,failure_nontrivial_fraction,"
                "failure_largest_min,failure_largest_median,failure_largest_mean,failure_largest_max,"
                "failure_saving_min,failure_saving_median,failure_saving_mean,failure_saving_max\n");
    }
    FILE *trace_csv = NULL;
    if (opts.trace_path != NULL && opts.trace_mode != TRACE_MODE_SUMMARY) {
        trace_csv = fopen(opts.trace_path, "w");
        if (trace_csv == NULL) die("cannot open random path trace CSV");
        fprintf(trace_csv,
                "ensemble,field,f,Delta,sample,instance_seed,search_seed,path,residual_dimension,rows_represented,rows_already_zero,largest_class_size,maximum_class_count,chosen_class_size,rank_before,rank_after,cumulative_rows_imposed,cumulative_rank_consumed,cumulative_projective_saving,path_success,final_weight,final_zero_count\n");
    }

    int successes = 0;
    for (int offset = 0; offset < opts.samples; ++offset) {
        int sample = opts.sample_start + offset;
        uint64_t matrix_seed = random_code_derived_seed(opts.master_seed,
                                                        opts.field,
                                                        opts.f,
                                                        opts.delta,
                                                        sample,
                                                        RANDOM_CODE_MATRIX_DOMAIN);
        uint64_t search_seed = random_code_derived_seed(opts.master_seed,
                                                        opts.field,
                                                        opts.f,
                                                        opts.delta,
                                                        sample,
                                                        RANDOM_CODE_SEARCH_DOMAIN);
        uint64_t generation_start = now_ns();
        int attempts = 0;
        matrix_u8 matrix = random_full_column_rank_matrix(h,
                                                          kappa,
                                                          &sf,
                                                          matrix_seed,
                                                          &attempts);
        int rank_B = matrix_rank(&matrix);
        double generation_ms = (double)(now_ns() - generation_start) / 1e6;
        if (rank_B != kappa) {
            die("random matrix failed full-column-rank check");
        }

        uint64_t search_start = now_ns();
        trace_context trace = {
            .summary_stream = trace_summary_csv,
            .full_stream = trace_csv,
            .write_full = opts.trace_mode == TRACE_MODE_FULL ||
                          (opts.trace_mode == TRACE_MODE_DIAGNOSTIC &&
                           sample == opts.diagnostic_sample),
            .ensemble = "random",
            .field = opts.field,
            .f = opts.f,
            .delta = opts.delta,
            .sample = sample,
            .instance_seed = matrix_seed
        };
        search_result search = search_explicit_word(&matrix,
                                                    &sf,
                                                    opts.f,
                                                    opts.restarts,
                                                    search_seed,
                                                    opts.max_residual_dimension,
                                                    opts.max_directions,
                                                    &trace);
        double search_ms = (double)(now_ns() - search_start) / 1e6;
        successes += search.best.success;
        fprintf(csv,
                "random,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,"
                "%" PRIu64 ",%" PRIu64 ",%d,1,%d,%d,%d,%d,%" PRIu64 ","
                "%d,%d,%d,%d,%d,%d,%d,%d,%d,%" PRIu64 ",%d,%" PRIu64 ",%" PRIu64 ",%.6f,%d,%.3f,%.3f,%d,%.3f,%.3f,%.3f,%d,%d,%d,%d,%" PRIu64 "\n",
                RANDOM_CODE_GENERATOR_VERSION,
                opts.field, opts.f, n, h, K, opts.delta, p.Kp, p.S, p.H,
                p.W, p.L, p.P, p.P1, kappa, sample, matrix_seed, search_seed,
                attempts, rank_B, opts.restarts, search.restarts_executed,
                opts.max_residual_dimension, opts.max_directions,
                search.best.success ? 1 : 0,
                search.best.valid ? search.best.weight : -1,
                search.best.valid ? search.best.zeros : -1,
                search.first_success_restart,
                search.best.valid ? search.best.restart : -1,
                search.best.valid ? search.best.closure : -1,
                search.best.valid ? search.best.rank : -1,
                search.best.valid ? search.best.rank_saving : -1,
                search.best.valid ? search.best.residual_dimension : -1,
                search.best.valid ? search.best.directions_enumerated : 0,
                search.successful_paths,
                search.projective_steps,
                search.nontrivial_projective_steps,
                search.projective_steps == 0 ? 0.0 :
                    (double)search.nontrivial_projective_steps /
                    (double)search.projective_steps,
                search.largest_class_max,
                search.projective_steps == 0 ? 0.0 :
                    (double)search.largest_class_sum /
                    (double)search.projective_steps,
                search.projective_steps == 0 ? 0.0 :
                    (double)search.chosen_class_sum /
                    (double)search.projective_steps,
                search.projective_saving_max,
                search.projective_steps == 0 ? 0.0 :
                    (double)search.projective_saving_sum /
                    (double)search.projective_steps,
                generation_ms, search_ms,
                search.canonical_success,
                search.canonical_weight,
                search.canonical_zero_count,
                search.canonical_residual_dimension,
                search.canonical_directions_enumerated);
        fflush(csv);
        free_candidate(&search.best);
        free_matrix(&matrix);
    }
    if (fclose(csv) != 0) {
        die("cannot close random-code output CSV");
    }
    if (trace_summary_csv != NULL && fclose(trace_summary_csv) != 0) {
        die("cannot close random path-summary CSV");
    }
    if (trace_csv != NULL && fclose(trace_csv) != 0) {
        die("cannot close random path trace CSV");
    }
    fprintf(stderr,
            "RANDOM POINT q=%d f=%d Delta=%d K=%d kappa=%d success=%d/%d output=%s\n",
            opts.field, opts.f, opts.delta, K, kappa, successes, opts.samples,
            opts.output_path);
    return 0;
}
