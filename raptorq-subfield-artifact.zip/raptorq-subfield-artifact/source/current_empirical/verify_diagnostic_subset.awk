BEGIN { FS = ","; file_number = 0 }

FNR == 1 { ++file_number; next }

file_number == 1 {
    positive[$1 SUBSEP $2] = 1
    next
}

file_number == 2 {
    phase = $1
    ensemble = $2
    field = $3
    f = $4
    delta = $5
    sample = $6
    region = $7
    key = phase SUBSEP ensemble SUBSEP field SUBSEP f SUBSEP delta
    if (seen[key]++) exit 1
    if (!(ensemble == "rq" || ensemble == "random")) exit 1
    if (!(field == 4 || field == 16 || field == 256)) exit 1
    if (phase == "delta0") {
        if (delta != 0 || f < f0_min || f > f0_max ||
            sample < 0 || sample >= samples_delta0) exit 1
        if (region != "delta0-transition") exit 1
        delta0_fields[field]++
    } else if (phase == "positive") {
        if (!positive[f SUBSEP delta] ||
            sample < 0 || sample >= samples_positive) exit 1
        if (!(region == "shallow-positive-Delta" ||
              region == "transition-positive-Delta" ||
              region == "deep-positive-Delta")) exit 1
        positive_regions[field SUBSEP region]++
    } else exit 1
    pair_key = phase SUBSEP field SUBSEP f SUBSEP delta SUBSEP sample
    pair_count[pair_key]++
    ++rows
}

END {
    if (file_number != 2 || rows != 24) exit 1
    for (key in pair_count) if (pair_count[key] != 2) exit 1
    for (field in delta0_fields) if (delta0_fields[field] != 2) exit 1
    split("4 16 256", fields, " ")
    split("shallow-positive-Delta transition-positive-Delta deep-positive-Delta", regions, " ")
    for (i = 1; i <= 3; ++i) {
        if (delta0_fields[fields[i]] != 2) exit 1
        for (j = 1; j <= 3; ++j) {
            if (positive_regions[fields[i] SUBSEP regions[j]] != 2) exit 1
        }
    }
}
