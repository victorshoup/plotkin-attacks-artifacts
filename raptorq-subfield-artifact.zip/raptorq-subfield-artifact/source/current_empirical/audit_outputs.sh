#!/bin/bash
set -euo pipefail

if test "$#" != 1; then
    echo "usage: $0 ARTIFACT_DIRECTORY" >&2
    exit 2
fi

artifact=$1
raw="$artifact/raw"
summaries="$artifact/summaries"
configuration="$artifact/config/diagnostic_trace_subset.csv"

test -d "$raw"
test -s "$summaries/search_success.csv"
test -s "$summaries/comparison.csv"

find "$raw" -type f -name '*.gz' -print0 | xargs -0 gzip -t

instance_files=$(find "$raw" -type f -name instances.csv | wc -l | tr -d ' ')
instance_rows=$(find "$raw" -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '$1 != "ensemble" && $1 != "field" { ++n } END { print n + 0 }')
main_rows=$(find "$raw/delta0" "$raw/positive" "$raw/deep_tail" -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '$1 != "ensemble" && $1 != "field" { ++n } END { print n + 0 }')
deeper_rows=$(find "$raw/deeper" -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '$1 != "ensemble" && $1 != "field" { ++n } END { print n + 0 }')
random_rows=$(find "$raw" -path '*/random/*' -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '$1 != "ensemble" { ++n } END { print n + 0 }')
rq_rows=$(find "$raw" -path '*/rq/*' -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '$1 != "field" { ++n } END { print n + 0 }')
diagnostic_files=$(find "$raw" -type f -name path_steps.csv.gz | wc -l | tr -d ' ')
esi_files=$(find "$raw" -type f -name esi_sets.csv | wc -l | tr -d ' ')

test "$instance_files" = 4514
test "$instance_rows" = 451400
test "$main_rows" = 450400
test "$deeper_rows" = 1000
test "$random_rows" = 225700
test "$rq_rows" = 225700
test "$diagnostic_files" = 24
case "$esi_files" in
    2257) esi_storage=pre_dedup_point_files ;;
    0)
        test -s "$artifact/honest_esi_sets/index.csv"
        test -s "$artifact/honest_esi_sets/lists.csv"
        test -s "$artifact/honest_esi_sets/instance_references.csv.gz"
        esi_storage=canonical_deduplicated
        ;;
    *) echo "unexpected ESI-list file count: $esi_files" >&2; exit 2 ;;
esac

find "$raw" -path '*/random/*' -type f -name instances.csv -print0 |
    xargs -0 cat | awk -F, '
        $1 != "ensemble" {
            ++n
            if ($1 != "random" || $2 != "sha256_counter_be_v3" ||
                $20 < 1 || $21 != 1) bad = 1
        }
        END { if (bad || n != 225700) exit 1 }
    '

configured=0
while IFS=, read -r phase ensemble field f delta sample region rule; do
    test "$phase" = phase && continue
    configured=$((configured + 1))
    trace="$raw/$phase/$ensemble/q${field}_f${f}_d${delta}/path_steps.csv.gz"
    test -s "$trace"
    gzip -dc "$trace" | awk -F, -v expected="$sample" '
        NR == 1 { next }
        $5 != expected { exit 1 }
        END { if (NR <= 1) exit 1 }
    '
done < "$configuration"
test "$configured" = 24

main_rq_successes=$(find "$raw/delta0/rq" "$raw/positive/rq" "$raw/deep_tail/rq" \
    -type f -name instances.csv -print0 | xargs -0 cat | awk -F, '
        $1 == "field" {
            delete c
            for (i = 1; i <= NF; ++i) c[$i] = i
            next
        }
        $(c["success"]) == 1 { ++n }
        END { print n + 0 }
    ')
structure_rows=$(($(wc -l < "$summaries/zero_set_structure.csv") - 1))
test "$main_rq_successes" = "$structure_rows"

test "$(($(wc -l < "$summaries/search_success.csv") - 1))" = 4504
test "$(($(wc -l < "$summaries/comparison.csv") - 1))" = 2252
test "$(($(wc -l < "$summaries/delta0.csv") - 1))" = 111
test "$(($(wc -l < "$summaries/positive_grid.csv") - 1))" = 2070
test "$(($(wc -l < "$summaries/gf256_deep_tail.csv") - 1))" = 71
test "$(($(wc -l < "$summaries/deeper_enumeration.csv") - 1))" = 10

printf 'OUTPUT AUDIT PASS\n'
printf 'point_files=%s\n' "$instance_files"
printf 'instances=%s main=%s deeper=%s rq=%s random=%s\n' \
    "$instance_rows" "$main_rows" "$deeper_rows" "$rq_rows" "$random_rows"
printf 'diagnostic_full_trace_files=%s configured=%s\n' \
    "$diagnostic_files" "$configured"
printf 'esi_storage=%s point_level_esi_files=%s\n' "$esi_storage" "$esi_files"
printf 'random_generator=sha256_counter_be_v3 full_rank_rows=%s\n' "$random_rows"
printf 'main_rq_successes=%s structural_rows=%s\n' \
    "$main_rq_successes" "$structure_rows"
