#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
VALIDATION="$EMPIRICAL_DIR/validation"
now=$(date +%s)
start=$(stat -f %m "$VALIDATION/full_main_worklist.txt")
latest=$(find "$EMPIRICAL_DIR/raw" -name instances.csv -type f \
    -exec stat -f %m {} \; | sort -nr | head -1)
metrics=$(find "$EMPIRICAL_DIR/raw/delta0" "$EMPIRICAL_DIR/raw/positive" \
    "$EMPIRICAL_DIR/raw/deep_tail" -name instances.csv -type f -print0 |
    xargs -0 cat | awk -F, '
        $1=="field" || $1=="ensemble" {
            delete c; for(i=1;i<=NF;i++) c[$i]=i; next
        }
        {
            ms += $(c["search_ms"])+0
            if("construction_ms" in c) ms += $(c["construction_ms"])+0
            if("matrix_ms" in c) ms += $(c["matrix_ms"])+0
            if("generation_ms" in c) ms += $(c["generation_ms"])+0
            ++rows
        }
        END { printf "%d %.3f",rows,ms/1000 }
    ')
rows=${metrics%% *}
cpu=${metrics##* }
projected=$(awk -F= '$1=="projected_cpu_seconds"{print $2}' \
    "$VALIDATION/runtime_pilot/runtime_projection.txt")
awk -v elapsed="$((now-start))" -v age="$((now-latest))" -v rows="$rows" \
    -v cpu="$cpu" -v projected="$projected" \
    -v maximum="$(cat "$VALIDATION/worker_concurrency/maximum")" \
    -v active="$(cat "$VALIDATION/worker_concurrency/active")" 'BEGIN {
        printf "elapsed_hours=%.3f\n",elapsed/3600
        printf "latest_output_age_seconds=%d\n",age
        printf "instances_on_disk=%d\n",rows
        printf "instance_percent=%.3f\n",100*rows/451400
        printf "measured_cpu_seconds=%.3f\n",cpu
        printf "weighted_eta_hours=%.3f\n",(projected-cpu)/7200
        printf "maximum_workers=%d\nactive_workers=%d\n",maximum,active
    }'
