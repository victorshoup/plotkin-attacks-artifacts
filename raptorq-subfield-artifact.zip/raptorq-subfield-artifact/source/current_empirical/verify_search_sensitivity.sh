#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
CONFIG="$EMPIRICAL_DIR/config/deeper_grid.csv"
OUTPUT="$ARTIFACT_DIR/paper_data/search_sensitivity_paired.csv"
TEMP=$(mktemp -d /tmp/rq-sensitivity-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

echo "ensemble,field,f,Delta,sample,main_success,main_minimum_weight," \
"main_canonical_success,main_canonical_weight,main_canonical_residual_dimension," \
"main_canonical_directions,deeper_success,deeper_weight,deeper_residual_dimension," \
"deeper_directions,main_search_ms,deeper_search_ms,matrix_seed_equal," \
"canonical_minimum_monotonicity_ok" | tr -d ' ' > "$OUTPUT"

points=0
while IFS=, read -r field f delta deeper_d deeper_directions reason; do
    test "$field" = field && continue
    phase=positive
    test "$delta" -le 40 || phase=deep_tail
    for ensemble in rq random; do
        main="$EMPIRICAL_DIR/raw/$phase/$ensemble/q${field}_f${f}_d${delta}/instances.csv"
        deep="$EMPIRICAL_DIR/raw/deeper/$ensemble/q${field}_f${f}_d${delta}_exact${deeper_d}/instances.csv"
        awk -F, -v ensemble="$ensemble" '
            BEGIN { OFS = "," }
            NR == 1 {
                for (i = 1; i <= NF; ++i) c[$i] = i
                seed_column = ensemble == "rq" ? "honest_set_seed" : \
                              "random_matrix_seed"
                next
            }
            {
                print $(c["sample"]), $(c["success"]), \
                      $(c["minimum_word_weight"]), $(c["canonical_success"]), \
                      $(c["canonical_weight"]), \
                      $(c["canonical_residual_dimension"]), \
                      $(c["canonical_directions_enumerated"]), \
                      $(c["search_ms"]), $(c[seed_column])
            }
        ' "$main" > "$TEMP/main.csv"
        awk -F, -v ensemble="$ensemble" -v q="$field" -v f="$f" \
            -v delta="$delta" '
            BEGIN { OFS = "," }
            NR == FNR {
                main_success[$1] = $2; main_weight[$1] = $3
                canonical_success[$1] = $4; canonical_weight[$1] = $5
                canonical_d[$1] = $6; canonical_directions[$1] = $7
                main_ms[$1] = $8; matrix_seed[$1] = $9
                next
            }
            FNR == 1 {
                for (i = 1; i <= NF; ++i) c[$i] = i
                seed_column = ensemble == "rq" ? "honest_set_seed" : \
                              "random_matrix_seed"
                next
            }
            {
                sample = $(c["sample"])
                deep_success = $(c["success"])
                deep_weight = $(c["minimum_word_weight"])
                seed_equal = (matrix_seed[sample] == $(c[seed_column]))
                monotone = (deep_weight <= canonical_weight[sample])
                if (!seed_equal || !monotone) {
                    print "sensitivity nesting/seed failure", ensemble, q, f, \
                          delta, sample > "/dev/stderr"
                    bad = 1
                }
                print ensemble, q, f, delta, sample, main_success[sample], \
                      main_weight[sample], canonical_success[sample], \
                      canonical_weight[sample], canonical_d[sample], \
                      canonical_directions[sample], deep_success, deep_weight, \
                      $(c["residual_dimension"]), \
                      $(c["directions_enumerated"]), main_ms[sample], \
                      $(c["search_ms"]), seed_equal, monotone
                ++rows
            }
            END { if (bad || rows != 100) exit 2 }
        ' "$TEMP/main.csv" "$deep" >> "$OUTPUT"
    done
    points=$((points + 1))
done < "$CONFIG"

test "$points" = 5
test "$(($(wc -l < "$OUTPUT") - 1))" = 1000
echo "SEARCH SENSITIVITY PAIRING PASS: 1000 paired instances"
