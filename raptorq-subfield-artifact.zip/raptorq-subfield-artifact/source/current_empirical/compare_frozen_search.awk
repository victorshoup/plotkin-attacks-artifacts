BEGIN { FS = ","; OFS = ","; failures = 0 }

FILENAME == ARGV[1] && FNR == 1 {
    for (i = 1; i <= NF; ++i) old_column[$i] = i
    next
}

FILENAME == ARGV[1] {
    sample = $(old_column["sample"])
    old_success[sample] = $(old_column["success"]) + 0
    old_first[sample] = $(old_column["first_success_restart"]) + 0
    old_weight[sample] = $(old_column["minimum_word_weight"]) + 0
    old_residual[sample] = $(old_column["residual_dimension"]) + 0
    old_kappa[sample] = $(old_column["kappa"]) + 0
    next
}

FILENAME == ARGV[2] && FNR == 1 {
    for (i = 1; i <= NF; ++i) new_column[$i] = i
    next
}

FILENAME == ARGV[2] {
    sample = $(new_column["sample"])
    ++samples
    success = $(new_column["success"]) + 0
    first = $(new_column["first_success_restart"]) + 0
    weight = $(new_column["minimum_word_weight"]) + 0
    residual = $(new_column["residual_dimension"]) + 0
    kappa = $(new_column["kappa"]) + 0
    if (!(sample in old_success)) {
        print "missing frozen sample " sample > "/dev/stderr"
        failures = 1
    }
    if (success != old_success[sample]) {
        ++success_mismatches
        failures = 1
    }
    if (first != old_first[sample]) {
        ++first_mismatches
        failures = 1
    }
    if (kappa != old_kappa[sample]) {
        ++kappa_mismatches
        failures = 1
    }
    weight_changes += weight != old_weight[sample]
    residual_changes += residual != old_residual[sample]
}

END {
    print field, f, delta, samples, success_mismatches + 0, \
        first_mismatches + 0, kappa_mismatches + 0, \
        weight_changes + 0, residual_changes + 0
    if (failures) exit 1
}
