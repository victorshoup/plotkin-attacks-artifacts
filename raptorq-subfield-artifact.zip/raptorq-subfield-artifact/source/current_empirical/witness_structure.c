#define main rq_empirical_program_main
#include "rq_empirical.c"
#undef main

#include <ctype.h>

static char *witness_value(const char *path, const char *key)
{
    FILE *stream = fopen(path, "r");
    if (stream == NULL) die("cannot open witness");
    char *line = NULL;
    size_t capacity = 0;
    size_t key_length = strlen(key);
    while (getline(&line, &capacity, stream) >= 0) {
        if (strncmp(line, key, key_length) == 0 && line[key_length] == '=') {
            char *value = line + key_length + 1;
            value[strcspn(value, "\r\n")] = '\0';
            char *copy = xmalloc(strlen(value) + 1);
            strcpy(copy, value);
            free(line);
            fclose(stream);
            return copy;
        }
    }
    free(line);
    fclose(stream);
    die("required witness key missing");
    return NULL;
}

static int witness_integer(const char *path, const char *key)
{
    char *value = witness_value(path, key);
    int result = parse_int(value);
    free(value);
    return result;
}

static int hex_nibble(int value)
{
    if (value >= '0' && value <= '9') return value - '0';
    value = tolower(value);
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    return -1;
}

static uint8_t *witness_source(const char *path, int K)
{
    char *hex = witness_value(path, "source_difference_hex");
    if (strlen(hex) != (size_t)(2 * K)) die("wrong source hex length");
    uint8_t *source = xcalloc((size_t)K, 1);
    for (int i = 0; i < K; ++i) {
        int high = hex_nibble(hex[2 * i]);
        int low = hex_nibble(hex[2 * i + 1]);
        if (high < 0 || low < 0) die("invalid source hex");
        source[i] = (uint8_t)(16 * high + low);
    }
    free(hex);
    return source;
}

static uint32_t *witness_esis(const char *path, int *count_out)
{
    char *text = witness_value(path, "honest_ESIs");
    int capacity = 32;
    int count = 0;
    uint32_t *esis = xmalloc((size_t)capacity * sizeof(uint32_t));
    char *save = NULL;
    for (char *token = strtok_r(text, " ", &save); token != NULL;
         token = strtok_r(NULL, " ", &save)) {
        char *end = NULL;
        errno = 0;
        unsigned long value = strtoul(token, &end, 10);
        if (errno != 0 || end == token || *end != '\0' ||
            value >= RQ_ESI_DOMAIN) {
            die("invalid witness ESI");
        }
        if (count == capacity) {
            capacity *= 2;
            uint32_t *grown = realloc(esis,
                                      (size_t)capacity * sizeof(uint32_t));
            if (grown == NULL) die("out of memory growing witness ESI list");
            esis = grown;
        }
        esis[count++] = (uint32_t)value;
    }
    free(text);
    *count_out = count;
    return esis;
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s WITNESS.txt SAMPLE\n", argv[0]);
        return 2;
    }
    gf256_init();
    int field = witness_integer(argv[1], "field");
    int f = witness_integer(argv[1], "f");
    int delta = witness_integer(argv[1], "Delta");
    int K = witness_integer(argv[1], "K");
    int recorded_weight = witness_integer(argv[1], "weight");
    int recorded_zeros = witness_integer(argv[1], "zeros");
    int sample = parse_int(argv[2]);
    if (K != f + 1 - delta) die("witness K identity failed");

    subfield sf;
    subfield_init(&sf, field);
    rq_params p = get_params(K);
    matrix_u8 constraints = build_subfield_constraints(&p, &sf);
    int kappa = K;
    uint8_t *ambiguity = NULL;
    if (field == 256) {
        ambiguity = kernel_basis_with_expected_dimension(&constraints, K);
    } else {
        ambiguity = kernel_basis_of_matrix(&constraints, &kappa);
    }
    matrix_u8 source_projection = build_source_projection(&p,
                                                           ambiguity,
                                                           kappa);
    uint8_t *source = witness_source(argv[1], K);
    uint8_t *coefficients = xcalloc((size_t)kappa, 1);
    if (!solve_full_column_rank(&source_projection, source, coefficients)) {
        die("witness source is outside the claimed ambiguity code");
    }
    int esi_count = 0;
    uint32_t *esis = witness_esis(argv[1], &esi_count);
    if (esi_count != 2 * f + 1) die("wrong honest ESI count");
    matrix_u8 honest = build_induced_rows(&p,
                                          ambiguity,
                                          kappa,
                                          esis,
                                          esi_count);
    int weight = 0;
    for (int r = 0; r < honest.nrows; ++r) {
        weight += dot_product(honest.rows + (size_t)r * kappa,
                              coefficients,
                              kappa) != 0;
    }
    if (weight != recorded_weight || honest.nrows - weight != recorded_zeros) {
        die("witness weight/zero record mismatch");
    }
    candidate witness;
    memset(&witness, 0, sizeof(witness));
    witness.success = true;
    witness.weight = weight;
    witness.zeros = honest.nrows - weight;
    witness.coefficient_vector = coefficients;
    puts("ensemble,field,f,Delta,K,sample,zero_count,rank_B_Z,rank_G_Z,total_saving,raw_LT_saving,restriction_loss,rank_precode,rank_stacked,intersection_dimension,restricted_rank_identity_ok,intersection_identity_ok");
    write_zero_set_structure(stdout, field, f, delta, sample, &p, esis,
                             &honest, &constraints, &witness);

    free_matrix(&honest);
    free(esis);
    free(coefficients);
    free(source);
    free_matrix(&source_projection);
    free(ambiguity);
    free_matrix(&constraints);
    return 0;
}
