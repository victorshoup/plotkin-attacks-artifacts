#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
POINTS="$EMPIRICAL_DIR/config/selected_witness_points.csv"
SELECTED="$EMPIRICAL_DIR/config/selected_witnesses.csv"
MISSING="$EMPIRICAL_DIR/validation/unavailable_predetermined_witnesses.csv"

echo "field,f,Delta,sample,region,point_selection,witness_selection" > "$SELECTED"
echo "field,f,Delta,region,reason" > "$MISSING"
points=0
selected_count=0
while IFS=, read -r field f delta region point_rule witness_rule; do
    test "$field" = field && continue
    phase=positive
    test "$delta" -le 40 || phase=deep_tail
    input="$EMPIRICAL_DIR/raw/$phase/rq/q${field}_f${f}_d${delta}/instances.csv"
    sample=$(awk -F, '
        NR == 1 { for (i = 1; i <= NF; ++i) c[$i] = i; next }
        $(c["success"]) == 1 {
            value = $(c["sample"]) + 0
            if (!found || value < best) { found = 1; best = value }
        }
        END { if (found) print best }
    ' "$input")
    if test -n "$sample"; then
        printf '%s,%s,%s,%s,%s,%s,%s\n' "$field" "$f" "$delta" "$sample" \
            "$region" "$point_rule" "$witness_rule" >> "$SELECTED"
        selected_count=$((selected_count + 1))
    else
        printf '%s,%s,%s,%s,%s\n' "$field" "$f" "$delta" "$region" \
            "no_observed_success_in_100_samples" >> "$MISSING"
    fi
    points=$((points + 1))
done < "$POINTS"

test "$points" = 5
echo "PREDETERMINED WITNESS SELECTION PASS: $selected_count of $points points had an observed success"
