BEGIN { FS = ","; file_number = 0 }

FNR == 1 {
    ++file_number
    delete column
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

file_number == 1 {
    sample = $(column["sample"])
    known[sample] = 1
    kappa[sample] = $(column["kappa"])
    restarts[sample] = $(column["restart_budget"])
    successful[sample] = $(column["successful_paths"])
    next
}

file_number == 2 {
    sample = $(column["sample"])
    path = $(column["path"])
    dimension = $(column["residual_dimension"])
    if (!known[sample] || $(column["ensemble"]) != ensemble) exit 1
    if (trace_mode == "diagnostic" && sample != diagnostic_sample) exit 1
    if (path < 0 || path >= restarts[sample]) exit 1
    if (dimension <= exact_d || dimension > kappa[sample]) exit 1
    key = sample SUBSEP path SUBSEP dimension
    if (seen[key]++) exit 1
    path_key = sample SUBSEP path
    if (!(path_key in path_seen)) {
        path_seen[path_key] = 1
        traced_paths[sample]++
        traced_successes[sample] += $(column["path_success"])
        final_weight[path_key] = $(column["final_weight"])
        final_zeros[path_key] = $(column["final_zero_count"])
    } else if (final_weight[path_key] != $(column["final_weight"]) ||
               final_zeros[path_key] != $(column["final_zero_count"])) exit 1
    ++rows[sample]
    next
}

END {
    if (file_number != 2) exit 1
    for (sample in known) {
        expected_dimensions = kappa[sample] > exact_d ? kappa[sample] - exact_d : 0
        should_exist = trace_mode == "full" ||
            (trace_mode == "diagnostic" && sample == diagnostic_sample)
        if (should_exist && expected_dimensions > 0) {
            if (traced_paths[sample] != restarts[sample]) exit 1
            if (rows[sample] != restarts[sample] * expected_dimensions) exit 1
            if (traced_successes[sample] != successful[sample]) exit 1
        } else if (rows[sample] != 0) exit 1
    }
}
