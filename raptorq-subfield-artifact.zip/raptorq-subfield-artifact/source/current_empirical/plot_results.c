#define _POSIX_C_SOURCE 200809L

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ROWS 4096
#define MAX_FIELDS 64
#define MAX_LINE 4096

typedef struct {
    int field;
    int f;
    int delta;
    double rq;
    double random;
} Point;

typedef struct {
    int field;
    int d;
    double rq_nontrivial;
    double random_nontrivial;
    double rq_saving;
    double random_saving;
} ProjectivePoint;

static void die(const char *message)
{
    fprintf(stderr, "PLOT FAIL: %s\n", message);
    exit(2);
}

static int split_csv(char *line, char **field, int capacity)
{
    int count = 0;
    field[count++] = line;
    for (char *cursor = line; *cursor != '\0'; ++cursor) {
        if (*cursor == ',') {
            *cursor = '\0';
            if (count >= capacity) die("too many CSV fields");
            field[count++] = cursor + 1;
        } else if (*cursor == '\n' || *cursor == '\r') {
            *cursor = '\0';
            break;
        }
    }
    return count;
}

static int column_index(char **header, int count, const char *name)
{
    for (int i = 0; i < count; ++i) {
        if (strcmp(header[i], name) == 0) return i;
    }
    fprintf(stderr, "PLOT FAIL: missing CSV column %s\n", name);
    exit(2);
}

static int read_points(const char *path, Point *points, int capacity)
{
    FILE *input = fopen(path, "r");
    if (input == NULL) die("cannot open comparison CSV");
    char line[MAX_LINE];
    if (fgets(line, sizeof(line), input) == NULL) die("empty comparison CSV");
    char *header[MAX_FIELDS];
    int fields = split_csv(line, header, MAX_FIELDS);
    int q = column_index(header, fields, "field");
    int f = column_index(header, fields, "f");
    int delta = column_index(header, fields, "Delta");
    int rq = column_index(header, fields, "rq_success_fraction");
    int random = column_index(header, fields, "random_success_fraction");
    int count = 0;
    while (fgets(line, sizeof(line), input) != NULL) {
        if (count >= capacity) die("too many comparison rows");
        char *v[MAX_FIELDS];
        int n = split_csv(line, v, MAX_FIELDS);
        if (n != fields) die("inconsistent comparison CSV row");
        points[count].field = atoi(v[q]);
        points[count].f = atoi(v[f]);
        points[count].delta = atoi(v[delta]);
        points[count].rq = strtod(v[rq], NULL);
        points[count].random = strtod(v[random], NULL);
        ++count;
    }
    if (fclose(input) != 0) die("cannot close comparison CSV");
    return count;
}

static int read_projective(const char *path, ProjectivePoint *points, int capacity)
{
    FILE *input = fopen(path, "r");
    if (input == NULL) die("cannot open projective CSV");
    char line[MAX_LINE];
    if (fgets(line, sizeof(line), input) == NULL) die("empty projective CSV");
    char *header[MAX_FIELDS];
    int fields = split_csv(line, header, MAX_FIELDS);
    int q = column_index(header, fields, "field");
    int d = column_index(header, fields, "residual_dimension");
    int rn = column_index(header, fields, "rq_nontrivial_fraction");
    int mn = column_index(header, fields, "random_nontrivial_fraction");
    int rs = column_index(header, fields, "rq_mean_cumulative_saving");
    int ms = column_index(header, fields, "random_mean_cumulative_saving");
    int count = 0;
    while (fgets(line, sizeof(line), input) != NULL) {
        if (count >= capacity) die("too many projective rows");
        char *v[MAX_FIELDS];
        int n = split_csv(line, v, MAX_FIELDS);
        if (n != fields) die("inconsistent projective CSV row");
        points[count].field = atoi(v[q]);
        points[count].d = atoi(v[d]);
        points[count].rq_nontrivial = strtod(v[rn], NULL);
        points[count].random_nontrivial = strtod(v[mn], NULL);
        points[count].rq_saving = strtod(v[rs], NULL);
        points[count].random_saving = strtod(v[ms], NULL);
        ++count;
    }
    if (fclose(input) != 0) die("cannot close projective CSV");
    return count;
}

static FILE *svg_open(const char *directory, const char *name, int width, int height)
{
    char path[4096];
    int written = snprintf(path, sizeof(path), "%s/%s", directory, name);
    if (written < 0 || (size_t)written >= sizeof(path)) die("figure path too long");
    FILE *output = fopen(path, "w");
    if (output == NULL) die("cannot create SVG");
    fprintf(output,
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" "
            "viewBox=\"0 0 %d %d\">\n"
            "<rect width=\"100%%\" height=\"100%%\" fill=\"white\"/>\n"
            "<style>text{font-family:Helvetica,Arial,sans-serif;fill:#222}"
            ".axis{stroke:#333;stroke-width:1}.grid{stroke:#ddd;stroke-width:1}"
            ".rq{fill:none;stroke-width:2.6}.random{fill:none;stroke-width:1.8;"
            "stroke-dasharray:7 5}</style>\n",
            width, height, width, height);
    return output;
}

static const char *color(int q)
{
    return q == 4 ? "#1f77b4" : q == 16 ? "#d95f02" : "#2ca02c";
}

static void draw_axes(FILE *output, double left, double top, double width,
                      double height, const char *x_label, const char *y_label,
                      double x_min, double x_max, int x_ticks)
{
    for (int i = 0; i <= 4; ++i) {
        double y = top + height * i / 4.0;
        fprintf(output, "<line class=\"grid\" x1=\"%.1f\" y1=\"%.1f\" "
                        "x2=\"%.1f\" y2=\"%.1f\"/>\n", left, y,
                        left + width, y);
        fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"12\" "
                        "text-anchor=\"end\">%.2f</text>\n",
                        left - 8, y + 4, 1.0 - i / 4.0);
    }
    for (int i = 0; i <= x_ticks; ++i) {
        double x = left + width * i / x_ticks;
        double value = x_min + (x_max - x_min) * i / x_ticks;
        fprintf(output, "<line class=\"grid\" x1=\"%.1f\" y1=\"%.1f\" "
                        "x2=\"%.1f\" y2=\"%.1f\"/>\n", x, top, x,
                        top + height);
        fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"12\" "
                        "text-anchor=\"middle\">%.2g</text>\n",
                        x, top + height + 20, value);
    }
    fprintf(output, "<rect class=\"axis\" fill=\"none\" x=\"%.1f\" y=\"%.1f\" "
                    "width=\"%.1f\" height=\"%.1f\"/>\n", left, top,
                    width, height);
    fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"14\" "
                    "text-anchor=\"middle\">%s</text>\n",
                    left + width / 2, top + height + 43, x_label);
    fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"14\" "
                    "text-anchor=\"middle\" transform=\"rotate(-90 %.1f %.1f)\">"
                    "%s</text>\n", left - 50, top + height / 2,
                    left - 50, top + height / 2, y_label);
}

static void draw_polyline(FILE *output, Point *points, int count, int q, int f,
                          int delta_mode, int random, double left, double top,
                          double width, double height, double x_min, double x_max)
{
    fprintf(output, "<polyline class=\"%s\" stroke=\"%s\" points=\"",
            random ? "random" : "rq", color(q));
    for (int i = 0; i < count; ++i) {
        if (points[i].field != q || (f >= 0 && points[i].f != f)) continue;
        double xv = delta_mode ? (double)points[i].delta / points[i].f : points[i].f;
        double yv = random ? points[i].random : points[i].rq;
        double x = left + width * (xv - x_min) / (x_max - x_min);
        double y = top + height * (1.0 - yv);
        fprintf(output, "%.2f,%.2f ", x, y);
    }
    fputs("\"/>\n", output);
}

static void draw_legend(FILE *output, double x, double y)
{
    int qs[] = {4, 16, 256};
    for (int i = 0; i < 3; ++i) {
        fprintf(output, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\" "
                        "stroke=\"%s\" stroke-width=\"3\"/>\n",
                        x + 100 * i, y, x + 30 + 100 * i, y, color(qs[i]));
        fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"13\">GF(%d)</text>\n",
                        x + 38 + 100 * i, y + 4, qs[i]);
    }
    fprintf(output, "<line class=\"rq\" stroke=\"#222\" x1=\"%.1f\" y1=\"%.1f\" "
                    "x2=\"%.1f\" y2=\"%.1f\"/><text x=\"%.1f\" y=\"%.1f\" "
                    "font-size=\"13\">RaptorQ</text>\n", x + 380, y,
                    x + 420, y, x + 427, y + 4);
    fprintf(output, "<line class=\"random\" stroke=\"#222\" x1=\"%.1f\" y1=\"%.1f\" "
                    "x2=\"%.1f\" y2=\"%.1f\"/><text x=\"%.1f\" y=\"%.1f\" "
                    "font-size=\"13\">matched random</text>\n", x + 510, y,
                    x + 550, y, x + 557, y + 4);
}

static void plot_delta0(Point *points, int count, const char *directory)
{
    FILE *output = svg_open(directory, "delta0_success.svg", 1000, 620);
    fputs("<text x=\"500\" y=\"32\" font-size=\"21\" text-anchor=\"middle\">"
          "Delta=0 finite-search success</text>\n", output);
    draw_axes(output, 85, 75, 850, 455, "f", "observed success fraction",
              9, 45, 6);
    int qs[] = {4, 16, 256};
    for (int i = 0; i < 3; ++i) {
        draw_polyline(output, points, count, qs[i], -1, 0, 0,
                      85, 75, 850, 455, 9, 45);
        draw_polyline(output, points, count, qs[i], -1, 0, 1,
                      85, 75, 850, 455, 9, 45);
    }
    draw_legend(output, 90, 570);
    fputs("</svg>\n", output);
    if (fclose(output) != 0) die("cannot close delta-zero SVG");
}

static void plot_positive(Point *points, int count, const char *directory)
{
    FILE *output = svg_open(directory, "positive_grid_success.svg", 1100, 900);
    fputs("<text x=\"550\" y=\"30\" font-size=\"21\" text-anchor=\"middle\">"
          "Positive-Delta finite-search success on the normalized grid</text>\n", output);
    int fs[] = {48, 64, 80, 96};
    int qs[] = {4, 16, 256};
    for (int panel = 0; panel < 4; ++panel) {
        double left = panel % 2 == 0 ? 75 : 600;
        double top = panel < 2 ? 70 : 465;
        draw_axes(output, left, top, 430, 300, "Delta/f", "success fraction",
                  0, 0.72, 4);
        fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"17\" "
                        "font-weight=\"bold\">f=%d</text>\n", left + 8,
                        top + 22, fs[panel]);
        for (int i = 0; i < 3; ++i) {
            draw_polyline(output, points, count, qs[i], fs[panel], 1, 0,
                          left, top, 430, 300, 0, 0.72);
            draw_polyline(output, points, count, qs[i], fs[panel], 1, 1,
                          left, top, 430, 300, 0, 0.72);
        }
    }
    draw_legend(output, 125, 850);
    fputs("</svg>\n", output);
    if (fclose(output) != 0) die("cannot close positive-grid SVG");
}

static void projective_polyline(FILE *output, ProjectivePoint *points, int count,
                                int saving, int random, double left, double top,
                                double width, double height, int min_d, int max_d,
                                double max_y)
{
    fprintf(output, "<polyline class=\"%s\" stroke=\"%s\" points=\"",
            random ? "random" : "rq", random ? "#666" : "#2ca02c");
    for (int i = 0; i < count; ++i) {
        if (points[i].field != 256) continue;
        double value = saving ? (random ? points[i].random_saving : points[i].rq_saving)
                              : (random ? points[i].random_nontrivial : points[i].rq_nontrivial);
        double x = left + width * (points[i].d - min_d) / (max_d - min_d);
        double y = top + height * (1.0 - value / max_y);
        fprintf(output, "%.2f,%.2f ", x, y);
    }
    fputs("\"/>\n", output);
}

static void plot_projective(ProjectivePoint *points, int count,
                            const char *directory)
{
    int min_d = 100000, max_d = -1;
    double max_saving = 0;
    for (int i = 0; i < count; ++i) {
        if (points[i].field != 256) continue;
        if (points[i].d < min_d) min_d = points[i].d;
        if (points[i].d > max_d) max_d = points[i].d;
        if (points[i].rq_saving > max_saving) max_saving = points[i].rq_saving;
        if (points[i].random_saving > max_saving) max_saving = points[i].random_saving;
    }
    if (max_d <= min_d || max_saving <= 0) die("invalid GF(256) projective range");
    FILE *output = svg_open(directory, "gf256_projective_by_dimension.svg", 1100, 620);
    fputs("<text x=\"550\" y=\"30\" font-size=\"21\" text-anchor=\"middle\">"
          "GF(256) projective instrumentation pooled by residual dimension</text>\n", output);
    double lefts[] = {80, 610};
    const char *titles[] = {"nontrivial-class fraction", "mean cumulative projective saving"};
    for (int panel = 0; panel < 2; ++panel) {
        double left = lefts[panel], top = 90, width = 420, height = 410;
        double ymax = panel == 0 ? 1.0 : ceil(max_saving);
        for (int i = 0; i <= 4; ++i) {
            double y = top + height * i / 4.0;
            double value = ymax * (1.0 - i / 4.0);
            fprintf(output, "<line class=\"grid\" x1=\"%.1f\" y1=\"%.1f\" "
                            "x2=\"%.1f\" y2=\"%.1f\"/><text x=\"%.1f\" "
                            "y=\"%.1f\" font-size=\"12\" text-anchor=\"end\">%.2g</text>\n",
                            left, y, left + width, y, left - 7, y + 4, value);
        }
        fprintf(output, "<rect class=\"axis\" fill=\"none\" x=\"%.1f\" y=\"%.1f\" "
                        "width=\"%.1f\" height=\"%.1f\"/><text x=\"%.1f\" "
                        "y=\"%.1f\" font-size=\"16\" text-anchor=\"middle\">%s</text>\n",
                        left, top, width, height, left + width / 2, top - 15,
                        titles[panel]);
        for (int i = 0; i <= 4; ++i) {
            double x = left + width * i / 4.0;
            int d = (int)lround(min_d + (max_d - min_d) * i / 4.0);
            fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"12\" "
                            "text-anchor=\"middle\">%d</text>\n", x, top + height + 20, d);
        }
        fprintf(output, "<text x=\"%.1f\" y=\"%.1f\" font-size=\"14\" "
                        "text-anchor=\"middle\">residual dimension</text>\n",
                        left + width / 2, top + height + 45);
        projective_polyline(output, points, count, panel, 0, left, top, width,
                            height, min_d, max_d, ymax);
        projective_polyline(output, points, count, panel, 1, left, top, width,
                            height, min_d, max_d, ymax);
    }
    fputs("<line class=\"rq\" stroke=\"#2ca02c\" x1=\"360\" y1=\"560\" "
          "x2=\"410\" y2=\"560\"/><text x=\"420\" y=\"565\" "
          "font-size=\"14\">RaptorQ</text><line class=\"random\" stroke=\"#666\" "
          "x1=\"555\" y1=\"560\" x2=\"605\" y2=\"560\"/>"
          "<text x=\"615\" y=\"565\" font-size=\"14\">matched random</text>\n",
          output);
    fputs("<text x=\"550\" y=\"600\" font-size=\"12\" text-anchor=\"middle\">"
          "Pooled descriptive summaries; path counts by dimension are retained in the CSV.</text>\n",
          output);
    fputs("</svg>\n", output);
    if (fclose(output) != 0) die("cannot close projective SVG");
}

int main(int argc, char **argv)
{
    if (argc != 5) {
        fprintf(stderr, "usage: %s DELTA0.csv POSITIVE.csv PROJECTIVE.csv FIGURE_DIR\n",
                argv[0]);
        return 2;
    }
    Point delta0[MAX_ROWS], positive[MAX_ROWS];
    ProjectivePoint projective[MAX_ROWS];
    int delta0_count = read_points(argv[1], delta0, MAX_ROWS);
    int positive_count = read_points(argv[2], positive, MAX_ROWS);
    int projective_count = read_projective(argv[3], projective, MAX_ROWS);
    plot_delta0(delta0, delta0_count, argv[4]);
    plot_positive(positive, positive_count, argv[4]);
    plot_projective(projective, projective_count, argv[4]);
    puts("FIGURE GENERATION PASS");
    return 0;
}
