BEGIN { FS = ","; OFS = "," }

NR == 1 {
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

{
    key = $(column["field"]) SUBSEP $(column["f"]) SUBSEP $(column["Delta"])
    ++count[key]
    zeros[key] += $(column["zero_count"])
    total[key] += $(column["total_saving"])
    raw[key] += $(column["raw_LT_saving"])
    restriction[key] += $(column["restriction_loss"])
    if ($(column["total_saving"]) > max_total[key]) {
        max_total[key] = $(column["total_saving"])
    }
    if ($(column["raw_LT_saving"]) > max_raw[key]) {
        max_raw[key] = $(column["raw_LT_saving"])
    }
    if ($(column["restriction_loss"]) > max_restriction[key]) {
        max_restriction[key] = $(column["restriction_loss"])
    }
    restricted_value = $(column["restricted_rank_identity_ok"])
    if (restricted_value != -1 && restricted_value != 1) {
        ++restricted_failures[key]
    }
    intersection_value = $(column["intersection_identity_ok"])
    if (intersection_value != -1) {
        ++intersection_checks[key]
        if (intersection_value != 1) ++intersection_failures[key]
    }
}

END {
    print "field,f,Delta,witnesses,mean_zero_count,mean_total_saving," \
          "mean_raw_LT_saving,mean_restriction_loss,max_total_saving," \
          "max_raw_LT_saving,max_restriction_loss,restricted_identity_failures," \
          "intersection_checks,intersection_identity_failures"
    for (key in count) {
        split(key, part, SUBSEP)
        printf "%d,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%d,%d,%d,%d,%d,%d\n", \
            part[1], part[2], part[3], count[key], zeros[key] / count[key], \
            total[key] / count[key], raw[key] / count[key], \
            restriction[key] / count[key], max_total[key], max_raw[key], \
            max_restriction[key], restricted_failures[key] + 0, \
            intersection_checks[key] + 0, intersection_failures[key] + 0
    }
}
