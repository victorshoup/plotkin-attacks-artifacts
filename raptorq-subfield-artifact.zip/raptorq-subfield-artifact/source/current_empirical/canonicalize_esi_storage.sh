#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SOURCE_DIR="$ARTIFACT_DIR/source/current_empirical"
STORE="$EMPIRICAL_DIR/honest_esi_sets"
VALIDATION="$EMPIRICAL_DIR/validation"
TEMP=$(mktemp -d /tmp/rq-esi-canonicalize-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

mkdir -p "$STORE" "$VALIDATION"
raw_files=$(find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv | wc -l | tr -d ' ')
test "$raw_files" = 2257
find "$STORE" -mindepth 1 -delete

# Preserve every pre-dedup occurrence with its dataset/point identity while
# constructing the canonical key space. No list is changed or reordered.
echo "dataset,point_id,field,f,Delta,K,sample,honest_set_seed,honest_ESIs" > \
    "$TEMP/occurrences.csv"
find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv | LC_ALL=C sort |
    while IFS= read -r file; do
        relative=${file#"$EMPIRICAL_DIR/raw/"}
        dataset=${relative%%/*}
        point=${relative%/esi_sets.csv}
        point=${point##*/}
        awk -F, -v dataset="$dataset" -v point="$point" '
            BEGIN {OFS=","}
            NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
            {print dataset,point,$(c["field"]),$(c["f"]),$(c["Delta"]),
                   $(c["K"]),$(c["sample"]),$(c["honest_set_seed"]),
                   $(c["honest_ESIs"])}
        ' "$file" >> "$TEMP/occurrences.csv"
    done
test "$(($(wc -l < "$TEMP/occurrences.csv") - 1))" = 225700

# Compare all repeated lists integer-for-integer in their serialized order.
awk -F, '
    BEGIN {OFS=","}
    NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
    {
        key=$(c["f"]) SUBSEP $(c["sample"])
        list=$(c["honest_ESIs"]); seed=$(c["honest_set_seed"])
        if(!(key in canonical)) {canonical[key]=list; seeds[key]=seed}
        else if(canonical[key] != list || seeds[key] != seed) {
            print "losslessness mismatch for f/sample",key > "/dev/stderr"; bad=1
        }
    }
    END {
        if(bad) exit 2
        print "f,sample,esi_count,honest_set_seed,honest_ESIs"
        for(key in canonical){
            split(key,p,SUBSEP); n=split(canonical[key],e," ")
            if(n != 2*p[1]+1) exit 2
            print p[1],p[2],n,seeds[key],canonical[key]
        }
    }
' "$TEMP/occurrences.csv" > "$TEMP/lists_unsorted.csv"
{
    head -1 "$TEMP/lists_unsorted.csv"
    tail -n +2 "$TEMP/lists_unsorted.csv" | LC_ALL=C sort -t, -k1,1n -k2,2n
} > "$STORE/lists.csv"
test "$(($(wc -l < "$STORE/lists.csv") - 1))" = 5000

echo "f,sample,esi_count,honest_set_seed,esi_list_sha256,esi_list_id,relative_path,line_number" \
    > "$STORE/index.csv"
line_number=1
tail -n +2 "$STORE/lists.csv" | while IFS=, read -r f sample count seed list; do
    line_number=$((line_number + 1))
    printf '%s\n' "$list" > "$TEMP/list"
    digest=$(shasum -a 256 "$TEMP/list" | awk '{print $1}')
    id="f${f}_s${sample}_${digest}"
    printf '%s,%s,%s,%s,%s,%s,%s,%s\n' "$f" "$sample" "$count" "$seed" \
        "$digest" "$id" "empirical/honest_esi_sets/lists.csv" \
        "$line_number" >> "$STORE/index.csv"
done

# Produce two explicit references per original RQ occurrence: one for the RQ
# instance and one for its matched-random control at the same point/sample.
echo "dataset,ensemble,point_id,field,f,Delta,K,sample,esi_list_id,esi_list_sha256" \
    > "$TEMP/references.csv"
awk -F, -v index_file="$STORE/index.csv" '
    BEGIN {
        OFS=","; getline line < index_file; n=split(line,h,FS)
        for(i=1;i<=n;i++)ic[h[i]]=i
        while((getline line < index_file)>0){
            split(line,v,FS); key=v[ic["f"]] SUBSEP v[ic["sample"]]
            id[key]=v[ic["esi_list_id"]]; hash[key]=v[ic["esi_list_sha256"]]
        }
        close(index_file)
    }
    NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
    {
        key=$(c["f"]) SUBSEP $(c["sample"])
        if(!(key in id)) exit 2
        print $(c["dataset"]),"rq",$(c["point_id"]),$(c["field"]),
              $(c["f"]),$(c["Delta"]),$(c["K"]),$(c["sample"]),id[key],hash[key]
        print $(c["dataset"]),"random",$(c["point_id"]),$(c["field"]),
              $(c["f"]),$(c["Delta"]),$(c["K"]),$(c["sample"]),id[key],hash[key]
    }
' "$TEMP/occurrences.csv" >> "$TEMP/references.csv"
test "$(($(wc -l < "$TEMP/references.csv") - 1))" = 451400
gzip -n -9 -c "$TEMP/references.csv" > "$STORE/instance_references.csv.gz"

# Exhaustively prove that every pre-dedup scientific instance has exactly one
# reference. This covers all main and sensitivity RQ/random records.
echo "dataset,ensemble,point_id,field,f,Delta,K,sample" > "$TEMP/instance_keys.csv"
find "$EMPIRICAL_DIR/raw" -type f -name instances.csv | LC_ALL=C sort |
    while IFS= read -r file; do
        relative=${file#"$EMPIRICAL_DIR/raw/"}
        dataset=${relative%%/*}; remainder=${relative#*/}; ensemble=${remainder%%/*}
        point=${relative%/instances.csv}; point=${point##*/}
        awk -F, -v dataset="$dataset" -v ensemble="$ensemble" -v point="$point" '
            BEGIN{OFS=","}
            NR==1{for(i=1;i<=NF;i++)c[$i]=i; next}
            {print dataset,ensemble,point,$(c["field"]),$(c["f"]),
                   $(c["Delta"]),$(c["K"]),$(c["sample"])}
        ' "$file" >> "$TEMP/instance_keys.csv"
    done
awk -F, 'BEGIN{OFS=","} NR==1{next} {print $1,$2,$3,$4,$5,$6,$7,$8}' \
    "$TEMP/references.csv" > "$TEMP/reference_keys.csv"
tail -n +2 "$TEMP/instance_keys.csv" | LC_ALL=C sort > "$TEMP/instance_keys.sorted"
LC_ALL=C sort "$TEMP/reference_keys.csv" > "$TEMP/reference_keys.sorted"
cmp "$TEMP/instance_keys.sorted" "$TEMP/reference_keys.sorted"
test "$(wc -l < "$TEMP/instance_keys.sorted" | tr -d ' ')" = 451400

# Measure pre-dedup ESI material before any deletion.
pre_bytes=$(find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv -print0 |
    xargs -0 cat | wc -c | tr -d ' ')
pre_gzip_bytes=$(find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv -print0 |
    xargs -0 gzip -n -9 -c | wc -c | tr -d ' ')
pre_digest=$($SOURCE_DIR/scientific_content_digest.sh)

# Add an unambiguous canonical reference to every instance CSV in one streaming
# rewrite. Existing columns and values remain byte-for-byte field-equivalent.
find "$EMPIRICAL_DIR/raw" -type d | while IFS= read -r directory; do
    relative=${directory#"$EMPIRICAL_DIR/raw"}
    mkdir -p "$TEMP/rewritten$relative"
done
{
    find "$EMPIRICAL_DIR/raw" -type f -name instances.csv | LC_ALL=C sort |
        while IFS= read -r file; do
            relative=${file#"$EMPIRICAL_DIR/raw/"}
            printf '@FILE,%s\n' "$relative"
            cat "$file"
        done
} | awk -F, -v root="$TEMP/rewritten" -v index_file="$STORE/index.csv" '
    BEGIN {
        OFS=","; getline line < index_file; n=split(line,h,FS)
        for(i=1;i<=n;i++)ic[h[i]]=i
        while((getline line < index_file)>0){
            split(line,v,FS); key=v[ic["f"]] SUBSEP v[ic["sample"]]
            id[key]=v[ic["esi_list_id"]]; hash[key]=v[ic["esi_list_sha256"]]
        }
        close(index_file)
    }
    $1=="@FILE" {if(out!="")close(out); out=root "/" $2; next}
    $1=="ensemble" || $1=="field" {
        delete c
        for(i=1;i<=NF;i++)c[$i]=i
        print $0,"esi_list_id","esi_list_sha256" > out
        next
    }
    {
        key=$(c["f"]) SUBSEP $(c["sample"])
        if(!(key in id)) exit 2
        print $0,id[key],hash[key] > out
    }
    END {if(out!="")close(out)}
'
find "$TEMP/rewritten" -type f -name instances.csv | while IFS= read -r rewritten; do
    relative=${rewritten#"$TEMP/rewritten/"}
    mv "$rewritten" "$EMPIRICAL_DIR/raw/$relative"
done

# The duplicated full lists are now redundant and regenerable. Their deletion
# occurs only after the exhaustive pre-dedup comparison and reference audit.
find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv -delete

post_digest=$($SOURCE_DIR/scientific_content_digest.sh)
test "$pre_digest" = "$post_digest"
canonical_bytes=$(find "$STORE" -type f -print0 | xargs -0 cat | wc -c | tr -d ' ')
canonical_gzip_bytes=$(find "$STORE" -type f -print0 |
    xargs -0 gzip -n -9 -c | wc -c | tr -d ' ')

{
    echo "metric,value"
    echo "instance_records,451400"
    echo "pre_dedup_list_occurrences,225700"
    echo "canonical_lists,5000"
    echo "pre_dedup_esi_uncompressed_bytes,$pre_bytes"
    echo "pre_dedup_esi_gzip_bytes,$pre_gzip_bytes"
    echo "post_dedup_store_uncompressed_bytes,$canonical_bytes"
    echo "post_dedup_store_gzip_bytes,$canonical_gzip_bytes"
    echo "uncompressed_bytes_saved,$((pre_bytes - canonical_bytes))"
    echo "gzip_bytes_saved,$((pre_gzip_bytes - canonical_gzip_bytes))"
    echo "pre_scientific_content_sha256,$pre_digest"
    echo "post_scientific_content_sha256,$post_digest"
    echo "scientific_content_digest_equal,1"
    echo "exhaustive_pre_dedup_instance_reference_audit,pass"
} > "$VALIDATION/esi_dedup_size_and_digest.csv"
{
    echo "category,changed,scientific_value_changed,detail"
    echo "esi_storage_representation,1,0,225700_repeated_lists_to_5000_canonical_lists"
    echo "instance_esi_references,1,0,canonical_id_and_ordered_list_sha256_appended"
    echo "derived_indexes_manifests,1,0,index_and_exhaustive_reference_relation_added"
    echo "checksums_packaging_metadata,1,0,regenerated_after_canonicalization"
    echo "search_or_result_fields,0,0,scientific_content_digest_unchanged"
    echo "structural_fields,0,0,scientific_content_digest_unchanged"
} > "$VALIDATION/esi_packaging_diff.csv"

"$SOURCE_DIR/audit_esi_dedup.sh"
echo "ESI CANONICALIZATION PASS: packaging-only transformation; scientific digest $post_digest"
