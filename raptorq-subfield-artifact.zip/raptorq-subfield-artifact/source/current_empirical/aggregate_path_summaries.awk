BEGIN { FS = ","; OFS = "," }

$1 == "ensemble" {
    delete column
    for (i = 1; i <= NF; ++i) column[$i] = i
    next
}

{
    key = $(column["ensemble"]) SUBSEP $(column["field"]) SUBSEP \
          $(column["residual_dimension"])
    all_paths = $(column["all_paths"])
    success_paths = $(column["success_paths"])
    failure_paths = $(column["failure_paths"])
    count[key] += all_paths
    largest_sum[key] += all_paths * $(column["all_largest_mean"])
    nontrivial[key] += $(column["all_nontrivial_paths"])
    saving_sum[key] += all_paths * $(column["all_saving_mean"])
    success_count[key] += success_paths
    success_saving_sum[key] += success_paths * $(column["success_saving_mean"])
    failure_count[key] += failure_paths
    failure_saving_sum[key] += failure_paths * $(column["failure_saving_mean"])
}

END {
    print "ensemble,field,residual_dimension,path_steps,mean_largest_class,nontrivial_class_steps,nontrivial_class_fraction,mean_cumulative_projective_saving,successful_path_steps,mean_saving_successful,failed_path_steps,mean_saving_failed"
    for (key in count) {
        split(key, part, SUBSEP)
        printf "%s,%d,%d,%d,%.9f,%d,%.9f,%.9f,%d,%.9f,%d,%.9f\n", \
            part[1], part[2], part[3], count[key], \
            largest_sum[key] / count[key], nontrivial[key], \
            nontrivial[key] / count[key], saving_sum[key] / count[key], \
            success_count[key], \
            success_count[key] ? success_saving_sum[key] / success_count[key] : 0, \
            failure_count[key], \
            failure_count[key] ? failure_saving_sum[key] / failure_count[key] : 0
    }
}
