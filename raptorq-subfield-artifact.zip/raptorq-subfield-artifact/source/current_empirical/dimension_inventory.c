#define main rq_subfield_campaign_program_main
#include "rq_empirical.c"
#undef main

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: %s field f Delta\n", argv[0]);
        return 2;
    }
    int field = parse_int(argv[1]);
    int f = parse_int(argv[2]);
    int delta = parse_int(argv[3]);
    int K = f + 1 - delta;
    if (!(field == 4 || field == 16 || field == 256) || K <= 0) {
        die("invalid dimension-inventory arguments");
    }
    gf256_init();
    subfield sf;
    subfield_init(&sf, field);
    rq_params params = get_params(K);
    int kappa = K;
    if (field != 256) {
        matrix_u8 constraints = build_subfield_constraints(&params, &sf);
        uint8_t *basis = kernel_basis_of_matrix(&constraints, &kappa);
        free(basis);
        free_matrix(&constraints);
    }
    printf("%d,%d,%d,%d,%d\n", field, f, delta, K, kappa);
    return 0;
}
