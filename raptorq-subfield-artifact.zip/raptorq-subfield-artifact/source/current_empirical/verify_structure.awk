BEGIN { FS = ","; failures = 0 }
NR == 1 { for (i = 1; i <= NF; ++i) column[$i] = i; next }

function fail(message) {
    print FILENAME ":" FNR ": " message > "/dev/stderr"
    failures = 1
}

{
    ++rows
    q = $(column["field"]) + 0
    total = $(column["total_saving"]) + 0
    raw = $(column["raw_LT_saving"]) + 0
    restriction = $(column["restriction_loss"]) + 0
    zeros = $(column["zero_count"]) + 0
    rank_B = $(column["rank_B_Z"]) + 0
    rank_G = $(column["rank_G_Z"]) + 0
    if (total != zeros - rank_B) fail("total-saving identity failed")
    if (raw != zeros - rank_G) fail("raw-LT-saving identity failed")
    if (restriction != rank_G - rank_B) fail("restriction-loss identity failed")
    if (total != raw + restriction) fail("saving decomposition failed")
    restricted_ok = $(column["restricted_rank_identity_ok"]) + 0
    intersection_ok = $(column["intersection_identity_ok"]) + 0
    if (q == 256 && (restricted_ok != 1 || intersection_ok != 1))
        fail("applicable GF(256) precode/intersection identity failed")
    if (q != 256 && (restricted_ok != -1 || intersection_ok != -1))
        fail("non-GF(256) identity was not recorded as -1/not-applicable")
}

END {
    if (failures) exit 1
    print "STRUCTURE VERIFICATION PASS: " rows " rows" > "/dev/stderr"
}
