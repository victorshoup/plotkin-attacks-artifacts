BEGIN { FS = ","; OFS = "," }

$1 == "ensemble" { next }

{
    key = $1 SUBSEP $2 SUBSEP $9
    ++count[key]
    largest_sum[key] += $12
    saving_sum[key] += $19
    nontrivial[key] += $12 > 1
    success_count[key] += $20
    failure_count[key] += !$20
    if ($20) success_saving_sum[key] += $19
    else failure_saving_sum[key] += $19
    distribution[key SUBSEP $12]++
}

END {
    if (mode == "distribution") {
        print "ensemble,field,residual_dimension,largest_class_size,step_count"
        for (item in distribution) {
            split(item, part, SUBSEP)
            print part[1], part[2], part[3], part[4], distribution[item]
        }
    } else {
        print "ensemble,field,residual_dimension,step_count,mean_largest_class,nontrivial_class_steps,nontrivial_class_fraction,mean_cumulative_projective_saving,successful_steps,mean_saving_successful,failed_steps,mean_saving_failed"
        for (key in count) {
            split(key, part, SUBSEP)
            printf "%s,%d,%d,%d,%.9f,%d,%.9f,%.9f,%d,%.9f,%d,%.9f\n", \
                part[1], part[2], part[3], count[key], \
                largest_sum[key] / count[key], nontrivial[key], \
                nontrivial[key] / count[key], \
                saving_sum[key] / count[key], success_count[key], \
                success_count[key] ? success_saving_sum[key] / success_count[key] : 0, \
                failure_count[key], \
                failure_count[key] ? failure_saving_sum[key] / failure_count[key] : 0
        }
    }
}
