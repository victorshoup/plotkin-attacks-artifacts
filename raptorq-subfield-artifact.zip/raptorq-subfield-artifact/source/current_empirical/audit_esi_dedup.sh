#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
STORE="$EMPIRICAL_DIR/honest_esi_sets"
INDEX="$STORE/index.csv"
LISTS="$STORE/lists.csv"
REFERENCES="$STORE/instance_references.csv.gz"
TEMP=$(mktemp -d /tmp/rq-esi-final-audit-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

test -s "$INDEX"
test -s "$LISTS"
test -s "$REFERENCES"

# Verify every canonical serialization and its exact ordered-list SHA-256.
echo "f,sample,esi_count,honest_set_seed,esi_list_sha256,esi_list_id" > \
    "$TEMP/verified_index.csv"
tail -n +2 "$LISTS" | while IFS=, read -r f sample count seed list; do
    printf '%s\n' "$list" > "$TEMP/list"
    actual_count=$(awk '{print NF}' "$TEMP/list")
    expected_count=$((2 * f + 1))
    test "$count" = "$expected_count"
    test "$actual_count" = "$expected_count"
    digest=$(shasum -a 256 "$TEMP/list" | awk '{print $1}')
    id="f${f}_s${sample}_${digest}"
    printf '%s,%s,%s,%s,%s,%s\n' "$f" "$sample" "$count" "$seed" \
        "$digest" "$id" >> "$TEMP/verified_index.csv"
done

awk -F, 'BEGIN {OFS=","}
    NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
    {print $(c["f"]),$(c["sample"]),$(c["esi_count"]),
           $(c["honest_set_seed"]),$(c["esi_list_sha256"]),
           $(c["esi_list_id"])}' "$INDEX" > "$TEMP/index_normalized.csv"
{
    head -1 "$TEMP/verified_index.csv"
    tail -n +2 "$TEMP/verified_index.csv" | LC_ALL=C sort -t, -k1,1n -k2,2n
} > "$TEMP/verified_sorted.csv"
{
    echo "f,sample,esi_count,honest_set_seed,esi_list_sha256,esi_list_id"
    LC_ALL=C sort -t, -k1,1n -k2,2n "$TEMP/index_normalized.csv"
} > "$TEMP/index_sorted.csv"
cmp "$TEMP/verified_sorted.csv" "$TEMP/index_sorted.csv"
test "$(($(wc -l < "$INDEX") - 1))" = 5000

# Build the exact post-dedup instance reference relation from all instance rows.
echo "dataset,ensemble,point_id,field,f,Delta,K,sample,esi_list_id,esi_list_sha256" \
    > "$TEMP/instances.csv"
find "$EMPIRICAL_DIR/raw" -type f -name instances.csv | LC_ALL=C sort |
    while IFS= read -r file; do
        relative=${file#"$EMPIRICAL_DIR/raw/"}
        dataset=${relative%%/*}
        remainder=${relative#*/}
        ensemble=${remainder%%/*}
        point=${relative%/instances.csv}
        point=${point##*/}
        awk -F, -v dataset="$dataset" -v ensemble="$ensemble" -v point="$point" '
            BEGIN { OFS="," }
            NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
            {
                if (!("esi_list_id" in c) || !("esi_list_sha256" in c)) exit 2
                print dataset,ensemble,point,$(c["field"]),$(c["f"]),
                      $(c["Delta"]),$(c["K"]),$(c["sample"]),
                      $(c["esi_list_id"]),$(c["esi_list_sha256"])
            }
        ' "$file" >> "$TEMP/instances.csv"
    done

gzip -dc "$REFERENCES" > "$TEMP/references.csv"
test "$(($(wc -l < "$TEMP/instances.csv") - 1))" = 451400
test "$(($(wc -l < "$TEMP/references.csv") - 1))" = 451400
{
    head -1 "$TEMP/instances.csv"
    tail -n +2 "$TEMP/instances.csv" | LC_ALL=C sort
} > "$TEMP/instances_sorted.csv"
{
    head -1 "$TEMP/references.csv"
    tail -n +2 "$TEMP/references.csv" | LC_ALL=C sort
} > "$TEMP/references_sorted.csv"
cmp "$TEMP/instances_sorted.csv" "$TEMP/references_sorted.csv"

# Cardinality, resolution, repeated-reference consistency, and orphan audit.
awk -F, -v index_file="$INDEX" '
    BEGIN {
        if ((getline line < index_file) <= 0) exit 2
        n=split(line,h,FS); for(i=1;i<=n;i++)c[h[i]]=i
        while((getline line < index_file)>0){
            split(line,v,FS); key=v[c["f"]] SUBSEP v[c["sample"]]
            if(key in id || v[c["esi_list_id"]] in seen_id) bad=1
            id[key]=v[c["esi_list_id"]]; hash[key]=v[c["esi_list_sha256"]]
            count[key]=v[c["esi_count"]]; ++canonical
            seen_id[v[c["esi_list_id"]]]=key
        }
        close(index_file)
    }
    NR==1 {for(i=1;i<=NF;i++)r[$i]=i; next}
    {
        key=$(r["f"]) SUBSEP $(r["sample"])
        if (!(key in id) || $(r["esi_list_id"]) != id[key] ||
            $(r["esi_list_sha256"]) != hash[key] || count[key] != 2*$(r["f"])+1)
            bad=1
        used[key]=1; ++rows
    }
    END {
        for(key in id) if(!(key in used)) bad=1
        if(bad || rows!=451400 || canonical!=5000) exit 2
    }
' "$TEMP/references.csv"

test -z "$(find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv -print -quit)"
echo "ESI DEDUP AUDIT PASS: 451400 instance references, 5000 canonical ordered lists, no unresolved references or orphans"
