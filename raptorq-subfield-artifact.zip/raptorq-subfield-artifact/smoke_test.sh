#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TEMP=$(mktemp -d /tmp/rq-slim-smoke-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
cp -R "$HERE" "$TEMP/artifact"
rm -rf "$TEMP/artifact/build"
(
    cd "$TEMP/artifact"
    env JOBS_OVERRIDE=2 ./reproduce_all.sh --smoke
)
echo "SLIM ARTIFACT SMOKE TEST PASS"
