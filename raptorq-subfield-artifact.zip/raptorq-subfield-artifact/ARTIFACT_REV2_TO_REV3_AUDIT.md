# Revision 2 to revision 3 integration audit

## Result

Revision 3 is an integration/portability revision built strictly from the
immutable revision-2 Appendix A artifact and completed ESI-profile campaign.
No new scientific experiment was run. All scientific preservation, workload,
baseline-mapping, exact-certificate, deterministic-analysis, and independent
witness checks pass.

Input hashes checked before extraction:

- revision 2: `bf2c03393ebfcc6203557bba8f6eb022a782e29eaea03acfd0c38cac8699091b`;
- completed profile: `fc1db8a7ab1197fffe5643fb1e6169f65658efda611859da48449da27ce35f15`;
- historical GF(4): `4205cbb083f2a5d36569b727275b0049226f69b6cc49b0c68cb0483594039a19`.

## Revision-2 preservation

Every path in revision 2's authoritative checksum universe was compared with
the revision-3 staging tree. Eight pre-existing files have wrapper or
documentation byte changes, three obsolete `imports/` paths are removed, and
`CHECKSUMS.txt` is regenerated. The exact 12-path list is in
`ARTIFACT_REV2_TO_REV3_CHANGED_FILES.txt`.

No pre-existing scientific path is modified. The unchanged revision-2
scientific-content digest and retained-core digest are both
`8632080212e7cc92ef35ab4a21416150efd0f22581b939c76fb20c51bf72e249`.

Changed wrapper purposes:

- `verify_artifact.sh`: invokes all native components, uses temporary oracle
  builds, accepts compiler warnings, and guards the checksum universe/archives;
- `analyze_existing.sh`: checks both empirical components from saved data and
  uses a temporary oracle checkout;
- `reproduce_all.sh`: includes GF(4), GF(16), Delsarte, main empirical, and
  ESI-profile full reproduction in the two-worker contract;
- `package.sh`: emits the revision-3 filename and rejects nested ZIP/TAR files.

The four Markdown changes describe the unified artifact and provenance. The
removed `imports/` files are superseded by native materialization and the
frozen manifest.

## ESI-profile import

The complete standalone checksum universe has 20,129 paths. The import audit
classifies each one. It retains 20,112 scientific files by exact original hash,
modifies only three component documents and eight integration wrappers, and
omits one standalone package metadata file. The scientific preservation digest
is `4c644eea57a088626b05a7dfa662acc04f6c30a619e0ff09bca14b3f5f6a0f70`
for both the standalone and integrated representations.

Full byte comparison justified omission of 132 identical duplicates totaling
10,058,705 bytes: the 122-file `nanorq` tree, four Appendix source snapshots,
five full-domain baseline summaries, and one shared `rq_tables.h`. Every
omitted-source/retained-target pair and both hashes are in
`provenance/ESI_PROFILE_IMPORT_AUDIT.csv`.

The 47,500 profile instance records and 1,900,000 paths remain unchanged. The
component verifier checks 4,100 masks, all instance and structural records,
sampler means, witness decompositions, GF(256) identities, diagnostics,
summaries, eight paper tables, and 11 independent selected witnesses.

## Full-domain baseline relation

`esi_profiles/audit/full_domain_baseline_mapping.csv` contains 238 exact
published-row mappings. Its verifier checks field, `f`, Delta, successes, and
sample count against the retained `empirical/summaries/` row. No neighboring
point substitution is possible.

## Historical GF(4) replacement

The complete dependency audit classified all 282 members of the historical
ZIP. The 26 revision-2 materializations were rechecked against their exact
members. A locked fresh Rust replay required 37 additional Cargo/module/vendor
and license files, which were copied in exact original bytes. The resulting 63
materialized files total 668,821 bytes and are listed in
`provenance/gf4_historical_import_manifest.csv`.

The other 219 members (64,455,676 bytes) are classified individually in
`provenance/GF4_HISTORICAL_IMPORT_AUDIT.csv` and omitted because they are not
needed for current dimension or Delsarte claims. Native verification reproduces
all 477 full GF(4) endpoints and 477 band minima byte-for-byte and verifies all
nine exact-rational Delsarte certificates. The old ZIP is neither packaged nor
referenced by an execution path.

## Mechanical counts and digests

- main empirical: 451,400 instances / 18,017,000 paths;
- profile empirical: 47,500 instances / 1,900,000 paths;
- combined: 498,900 instances / 19,917,000 paths;
- unified scientific digest:
  `a32268ad5e5de3713da2e9acd06605f851f9a5cef96eba16230e7b4b1641b3f4`.

These values are recomputed from the retained records and digest definitions by
scripts under `provenance/`; they are not trusted from prose.

## Compiler portability and final verification

All artifact-controlled active C compile paths use `${CC:-cc}`. Active wrappers
contain no `-Werror`, no warning-file-empty assertion, no broad `-w`, and no
compiler-specific suppression added for the known profile warning. Warnings are
displayed and recorded; compile failure is fatal. The actual fresh-extraction
compiler commands, version strings, warning counts, and results are recorded in
`logs/REV3_COMPILER_VERIFICATION.md` and the delivered
`FINAL_VERIFICATION_REV3.log`.

The package and saved verifier recursively reject nested `*.zip`, `*.tar`,
`*.tar.gz`, and `*.tgz` files. `CHECKSUMS.txt` covers every packaged file except
itself and is rechecked at both the start and end of saved verification.
