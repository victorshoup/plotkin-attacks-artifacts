#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PARENT=$(dirname "$HERE")
NAME=$(basename "$HERE")
OUT=${1:-"$PARENT/${NAME}.zip"}
rm -f "$OUT"
(
    cd "$PARENT"
    find "$NAME" -type f ! -path "$NAME/build/*" -print | LC_ALL=C sort > /tmp/rq-slim-package-files.$$
    zip -X -q "$OUT" -@ < /tmp/rq-slim-package-files.$$
    rm -f /tmp/rq-slim-package-files.$$
)
shasum -a 256 "$OUT"
