# Exhaustive finite GF(16) dimension certificate

This directory certifies the GF(16) dimension of the standardized RaptorQ
intermediate-difference subcode for every RFC-valid source dimension (K).  It is an
exact finite computation, separate from the empirical low-weight search.

Let (K') be the RFC 6330 extended source-block size, and let (S), (H), and
(L=K'+S+H) have their RFC meanings.  Intersecting the valid intermediate-difference
space with GF(16) gives the kernel over GF(16) of the following rows:

1. the (S) binary LDPC rows;
2. two GF(16)-coordinate equations for each of the (H) GF(256) HDPC rows, using the
   basis (1,\alpha) of GF(256) over its GF(16) subfield;
3. the (K'-K) binary padding-symbol encoding rows.

Thus the constraint count is (S+2H+(K'-K)), and full row rank gives

\[
L-[S+2H+(K'-K)]=K-H.
\]

The exact result is

\[
\boxed{\kappa_{16}=\max(0,K-H_{\mathrm{HDPC}})}
\]

for every RFC-valid (K), with no exceptions.

## Why the endpoint checks cover every source dimension

RFC Table 2 partitions the source dimensions into 477 bands with fixed (K'), (S),
(H), (W), and (L).  Within a band, the padding rows are nested: increasing (K)
deletes an initial padding constraint, while decreasing (K) adds one.

For (K>H), full row rank at the maximum-padding endpoint propagates throughout the
band when padding rows are deleted.  For (K\le H), full column rank at the full-size
endpoint propagates downward when padding rows are added.  The only band meeting the
boundary is (K'=10), (H=10), containing (K=1,\ldots,10); all ten values are also
checked directly.  Consequently the two endpoint tables plus that direct band check
cover every RFC-valid (K).  Six direct interior checks in widely separated bands guard
against an implementation error in the propagation bookkeeping.

## Files and replay

- `gf16_kprime_dimensions.csv`: exact ranks at all 477 full-size (K=K') endpoints.
- `gf16_band_min_dimensions.csv`: exact ranks at all 477 maximum-padding endpoints.
- `gf16_direct_checks.csv`: the ten boundary-band values and six interior spot checks.
- `verification.log`: recorded warning-clean replay and timing output.
- `source/gf16_dimension_cert.c`: rank-only C implementation based on the trusted
  empirical RFC/field construction.

The certifier reduces the binary LDPC/padding subsystem first over GF(2), then reduces
the two coordinate rows of each HDPC row over GF(16).  Row reordering does not change
rank.  This avoids constructing either the full (L\times L) RFC matrix or the enormous
nullspace basis at the RFC maximum.

The top-level `verify_artifact.sh` recompiles and reruns this certificate and compares
the resulting deterministic tables byte-for-byte.
