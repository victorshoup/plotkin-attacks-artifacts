#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/../.." && pwd)
BUILD="$ARTIFACT/build"
SOURCE="$HERE/source/gf16_dimension_cert.c"
TMP=$(mktemp -d /tmp/rq-gf16-certificate-XXXXXX)
trap 'rm -rf "$TMP"' EXIT
CC=${CC:-cc}
export CC

export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1

mkdir -p "$BUILD"
"$CC" -O3 -std=c11 -Wall -Wextra -Wpedantic \
    "$SOURCE" -o "$BUILD/gf16_dimension_cert"
"$BUILD/gf16_dimension_cert" "$TMP" > "$TMP/verification.log" 2>&1

for file in gf16_kprime_dimensions.csv gf16_band_min_dimensions.csv \
            gf16_direct_checks.csv; do
    cmp "$HERE/$file" "$TMP/$file"
done
grep -q '^failures: 0$' "$TMP/verification.log"
grep -q '^RESULT: kappa16=max(0,K-H_HDPC) FOR EVERY RFC-VALID K$' \
    "$TMP/verification.log"

# Independent guard over every K used by the empirical grid: construct the
# empirical kernel basis directly and compare its dimension with the exact formula.
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    "$ARTIFACT/source/current_empirical/dimension_inventory.c" \
    -o "$BUILD/dimension_inventory"
for K in $(seq 10 97); do
    row=$("$BUILD/dimension_inventory" 16 $((K - 1)) 0)
    observed=${row##*,}
    H=$(awk -F, -v K="$K" '
        NR > 1 && K <= $1 { print $3; exit }
    ' "$HERE/gf16_kprime_dimensions.csv")
    expected=$((K > H ? K - H : 0))
    test "$observed" = "$expected"
done

echo "GF(16) FAST CERTIFICATE VERIFICATION PASS: 477 full endpoints, 477 band minima, 10 boundary values, 6 interior spots, 88 empirical-K cross-checks"
