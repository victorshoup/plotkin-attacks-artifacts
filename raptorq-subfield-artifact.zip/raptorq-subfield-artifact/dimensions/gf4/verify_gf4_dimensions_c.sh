#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/../.." && pwd)
BUILD="$ARTIFACT/build"
SOURCE="$HERE/source/gf4_dimension_cert.c"
TMP=$(mktemp -d /tmp/rq-gf4-certificate-XXXXXX)
trap 'rm -rf "$TMP"' EXIT
CC=${CC:-cc}
export CC

export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1

mkdir -p "$BUILD"
"$CC" -O3 -std=c11 -Wall -Wextra -Wpedantic \
    "$SOURCE" -o "$BUILD/gf4_dimension_cert"
"$BUILD/gf4_dimension_cert" "$TMP" > "$TMP/verification.log" 2>&1

# The historical filenames are retained to preserve byte-level identity with
# the independently generated Rust certificate shipped in revision 3.
cmp "$HERE/gf4_kprime_dimensions_rust.csv" \
    "$TMP/gf4_kprime_dimensions_rust.csv"
cmp "$HERE/gf4_band_min_dimensions_rust.csv" \
    "$TMP/gf4_band_min_dimensions_rust.csv"
grep -q '^failures: 0$' "$TMP/verification.log"
grep -q '^direct Kprime=30 exception-band checks: 4$' "$TMP/verification.log"
grep -q '^RESULT: kappa4=1 AT K=30 AND max(0,K-3H_HDPC) OTHERWISE FOR EVERY RFC-VALID K$' \
    "$TMP/verification.log"

# Independent guard on the small-K region used by the empirical campaigns.
# This constructs the full subfield-constraint matrix via the generic empirical
# implementation rather than the bit-sliced rank-only certifier above.
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    "$ARTIFACT/source/current_empirical/dimension_inventory.c" \
    -o "$BUILD/dimension_inventory"
for K in $(seq 1 97); do
    row=$("$BUILD/dimension_inventory" 4 $((K - 1)) 0)
    observed=${row##*,}
    H=$(awk -F, -v K="$K" '
        NR > 1 && K <= $1 { print $3; exit }
    ' "$HERE/gf4_kprime_dimensions_rust.csv")
    if test "$K" = 30; then
        expected=1
    elif test "$K" -gt $((3 * H)); then
        expected=$((K - 3 * H))
    else
        expected=0
    fi
    test "$observed" = "$expected"
done

echo "GF(4) C CERTIFICATE VERIFICATION PASS: 477 full endpoints, 477 band minima, 4 exception-band values, 97 independent small-K cross-checks"
