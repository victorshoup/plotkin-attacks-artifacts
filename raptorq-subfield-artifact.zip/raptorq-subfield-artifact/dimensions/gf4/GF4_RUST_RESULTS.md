# Native Rust GF(4) investigation results

**Investigation date:** 29 August 2026. **Exact-bound consolidation:** 30 August 2026.

This is the running report for the native GF(4) extension. It does not edit or replace the
Plotkin paper. The vendored `raptorq` 2.0.1 implementation is authoritative for HDPC
coefficients, transmitted encoding rows, encoder behavior, and decoder behavior. The
corrected Python material is used only as a differential oracle.

## Implementation and trust boundary

The new Rust modules are:

- `rq-attack/src/gf4.rs`: compact two-bit GF(4), with octet embedding
  `{00,01,d6,d7}`;
- `rq-attack/src/gf4la.rs`: bit-sliced GF(4) rank, RREF, kernels, and linear combinations;
- `rq-attack/src/gf4matrix.rs`: native construction of `Z4`, its basis, source differences,
  and the induced honest-row matrix `B4`;
- `rq-attack/src/gf4search.rs`: projective normalization, greedy quotient closure,
  randomized seeded restarts, and exact enumeration of small residual spaces;
- `rq-attack/src/gf4cli.rs`: certificates, f=64 reproduction, end-to-end validation, and
  the original `K=f+1` machine-readable scans;
- `rq-attack/src/gf4overhead.rs`: fixed-f source-dimension/overhead scans, native binary
  comparison flags, exact whole-space enumeration at small `kappa4`, detailed timing, and
  per-instance plus aggregate CSV/JSON output;
- `rq-attack/src/gf4randomnull.rs`: deterministic full-rank random GF(4) matrices, the
  random-code first moment, and a null-model driver using the unchanged practical search.

HDPC rows come from the vendored `generate_hdpc_rows`. Padding, source, repair, and honest
rows come from the vendored `generate_encoding_rows`, with the same ESI-to-ISI map used by
the decoder. The existing RFC LDPC constructor is reused; its pre-existing test compares it
byte-for-byte against the vendored full constraint matrix. No new vendor patch was needed,
and encoder/decoder semantics were not changed.

GF(256) coefficients are decomposed in the explicit basis
`(1, alpha, alpha^2, alpha^3)` over GF(4). Exhaustively constructing the 256 coordinate
tuples verifies that this is a basis. Each HDPC equation therefore becomes four native
GF(4) equations.

## Baseline and discrepancies

Before GF(4) changes:

- `cargo build --release --workspace`: passed;
- `cargo test --release`: 5/5 existing tests passed;
- the explicit `rq-attack certify` binary: 477/477 GF(2) full sizes, zero failures;
- the corrected hard-coded f=64 checker: encoder agreement on 70 zero ESIs, decoder `None`
  on both the bad 65 and all 70, systematic control successful;
- a two-repetition GF(2) end-to-end run passed all four existing parameter shapes.

One baseline command discrepancy was found. Once the hard-coded GF(4) checker existed,
Cargo could not choose between two binaries for the documented command
`cargo run -p rq-attack --release -- certify`. Adding `default-run = "rq-attack"` to the
package manifest restores the documented command without changing program behavior.

The supplied Python f=64 verifier could not run in this environment because the installed
Python lacks `numba`. This is an environment dependency failure, not a mathematical
discrepancy. The native differential test reconstructs the recorded shortening, exact
minimum word, zero ESI set, and source difference. In addition, the precomputed corrected
Python and native Rust dimension CSVs agree at all 477 full sizes and all 477 band minima.
The exact rational Delsarte verifier runs without `numba` and passed.

## GF(4) arithmetic and linear algebra tests

Tests cover the full addition and multiplication closure, nonzero inverses,
`w^2=w+1`, byte conversion, agreement with vendored GF(256) multiplication, rank,
nullity, kernel membership, and independence. Native ambiguity bases are also checked
against every native constraint at selected sizes.

The current release suite has 27 passing tests and zero failures.

## Exhaustive standardized dimension result

`gf4-certify` checks all 477 standardized full `K'` values and the minimum reachable `K`
in every one of the 477 bands. It also checks every `K=27,28,29,30` directly because the
exceptional band meets the `3H=30` boundary.

The result is:

```text
kappa4 = 1                         for K = 30,
kappa4 = max(0, K - 3 H_HDPC)     for every other RFC-valid K.
```

At full size, the sole deviation from the lower-bound floor is `(K,H,kappa4)=(30,10,1)`.
There were zero failures among the 477 full-size and 477 band-minimum checks. Runtime was
5.46 seconds in the recorded run.

Why endpoints cover all reachable `K`: within a fixed `K'` band, padding-row sets are
nested. Above `3H`, full row rank at the maximum-padding endpoint propagates when padding
rows are deleted. Below `3H`, full column rank at the full-size endpoint is preserved when
padding rows are added. The only exceptional crossing is the `K'=30` band, which is why all
four of its source dimensions were checked directly. This is an exhaustive finite statement
about RFC-valid parameters, not a parameter-free symbolic theorem.

Machine-readable outputs:

- `results/gf4_kprime_dimensions_rust.csv`;
- `results/gf4_band_min_dimensions_rust.csv`.

## Corrected f=64 reconstruction and improvement

For the recorded 129-row honest set at `f=64, K=65`:

- `K'=69, S=13, H=10, L=92`;
- `kappa2=0`, `kappa4=35`, and `rank(B4)=35`;
- the recorded 51-row shortening has native rank 33 and residual dimension 2;
- exact enumeration of all 15 nonzero residual words gives minimum weight 59 and exactly
  the recorded 70 zero ESIs;
- the reconstructed source difference exactly matches the 65 recorded GF(4) codes.

The seeded search does not receive the recorded shortening. With seed `20260829` and 200
restarts it found:

- a 54-row rank-33 shortening, saving 21 ranks and leaving dimension 2;
- shortened length 75 and quaternary Plotkin size bound `260/35 = 7.428571`, below `4^2`;
- separately, exact enumeration in a greedily selected residual dimension-8 space found a
  weight-53 word with 76 zero honest ESIs.

The source difference from that weight-53 word changes 31 of 65 source symbols. The real
encoder confirms equality on all 76 zero ESIs. The real decoder returns `None` on the
selected bad 65 and on all 76 zero ESIs. The 65-systematic-packet control recovers the
original source. This is an explicit end-to-end instance, not a universal result.

The exact residual enumeration is an improvement over merely stopping at a Plotkin
contradiction: it directly searches the small subcode exposed by the greedy closure and
extracts an explicit minimum word whenever the residual dimension is at most eight.

## Honest-set experiments

Sampling uses a deterministic partial Fisher-Yates sample of `2f+1` ESIs from `0..3f+1`,
with every seed recorded. The heuristic is randomized greedy projective closure with 40
restarts, followed by exact residual enumeration when dimension is at most eight. Every
produced witness is replayed through the real encoder and decoder. A heuristic failure is
not treated as a negative code result.

### Broad scan

The main scan contains 510 independently seeded honest sets: ten for every `f=40..90`, with
`K=f+1`.

| f range | honest sets | Plotkin shortening found | explicit E2E witness found |
|---:|---:|---:|---:|
| 40–49 | 100 | 2 | 52 |
| 50–59 | 100 | 26 | 68 |
| 60–69 | 100 | 100 | 100 |
| 70–79 | 100 | 100 | 100 |
| 80–90 | 110 | 110 | 110 |
| **total** | **510** | **338** | **430** |

All 430 generated witnesses passed encoder equality, bad-subset decoder failure,
all-zero-set decoder failure, and systematic control. The binary ambiguity dimension is
zero through `f=69` at these shapes. Thus the many successes in that range are genuinely
outside the existing binary construction.

The binary universal theorem begins at `f=77` for `K=f+1,H=10`. Exact GF(4) Delsarte
certificates now cover `f=72..76`; the historical scan files retain the
`floating_point_lp_only` label that was accurate when those experiments were generated.
Future scans label all five points `exact_universal_certificate`. All low-rank scan outcomes
remain experimental instance results.

### Focused f=64 scan

A separate campaign sampled 200 honest sets at `f=64,K=65`, using seed `16420260829` and
40 restarts per set.

- Plotkin shortening found: 200/200;
- explicit real-encoder/decoder witness found: 200/200;
- shortening rank: 33 in every sample;
- shortening cardinality: 49–54, median 50;
- rank saving: 16–21, median 17;
- residual dimension: 2 in every sample;
- exact minimum weight: 52–63, median 59.

This is strong evidence that the phenomenon is common, and plausibly high-frequency, for
uniformly sampled honest ESI sets at this shape under this search. It does not prove success
for every set, probability one, or a protocol-level high-probability theorem. Distinguishing
very high probability from universality remains open.

Machine-readable scan files:

- `results/gf4_scan_f40_90_s10_r40_seed20260829.csv` and `.json`;
- `results/gf4_scan_f64_64_s200_r40_seed16420260829.csv` and `.json`.

## Dense f=64 source-dimension/overhead sweep

The fixed-f scanner makes `K` and `Delta=65-K` first-class axes while leaving the original
`K=f+1` scanner intact. For every `K`, it obtains `K'`, `S`, `H_HDPC`, `L`, transmitted
rows, encoding behavior, and decoding behavior from the vendored implementation. It computes
`kappa2` and `kappa4` natively. Every random choice has a recorded derived seed.

The initial campaign used master seed `640020260829`, 20 independently sampled 129-ESI
honest sets at every RFC-valid `K=65..30`, and 40 shortening restarts per set. No `K` was
skipped and the scan did not stop on failures. All three binary comparison flags were false
at every point:

- `binary_universal`: false because the first satisfying integer is `K=78`;
- `binary_plotkin_actual_kappa2`: false because native `kappa2=0` throughout;
- `binary_randomized`: false because the first satisfying integer is `K=79`.

`H_HDPC=10` throughout. The standardized parameter bands were:

| K range | K' | S | L | kappa4 |
|---:|---:|---:|---:|---:|
| 65–63 | 69 | 13 | 92 | K-30 |
| 62–61 | 62 | 13 | 85 | K-30 |
| 60–56 | 60 | 13 | 83 | K-30 |
| 55–50 | 55 | 13 | 78 | K-30 |
| 49 | 49 | 13 | 72 | 19 |
| 48–47 | 48 | 13 | 71 | K-30 |
| 46–43 | 46 | 13 | 69 | K-30 |
| 42–37 | 42 | 11 | 63 | K-30 |
| 36–33 | 36 | 11 | 57 | K-30 |
| 32–31 | 32 | 11 | 53 | K-30 |
| 30 | 30 | 11 | 51 | 1 (the certified exception) |

Initial explicit end-to-end success counts were:

| K | Delta | E2E / 20 | K | Delta | E2E / 20 |
|---:|---:|---:|---:|---:|---:|
| 65 | 0 | 20 | 47 | 18 | 2 |
| 64 | 1 | 20 | 46 | 19 | 0 |
| 63 | 2 | 20 | 45 | 20 | 0 |
| 62 | 3 | 20 | 44 | 21 | 1 |
| 61 | 4 | 20 | 43 | 22 | 0 |
| 60 | 5 | 20 | 42 | 23 | 0 |
| 59 | 6 | 20 | 41 | 24 | 0 |
| 58 | 7 | 20 | 40 | 25 | 0 |
| 57 | 8 | 20 | 39 | 26 | 0 |
| 56 | 9 | 20 | 38 | 27 | 0 |
| 55 | 10 | 17 | 37 | 28 | 0 |
| 54 | 11 | 16 | 36 | 29 | 0 |
| 53 | 12 | 11 | 35 | 30 | 0 |
| 52 | 13 | 7 | 34 | 31 | 0 |
| 51 | 14 | 2 | 33 | 32 | 0 |
| 50 | 15 | 2 | 32 | 33 | 0 |
| 49 | 16 | 0 | 31 | 34 | 0 |
| 48 | 17 | 1 | 30 | 35 | 0 |

The 259 claimed initial witnesses all had honest-row weight at most 64 and at least 65 zero
honest ESIs. Each reconstructed a nonzero source difference and passed distinct-source,
real-encoder equality on the entire zero set and selected bad 65-set, real-decoder `None`
on both sets, and a 65-packet recovery control. For `K<65`, only the first `K` packets can be
systematic; the control therefore uses ESIs `0..64`, namely all `K` systematic packets and
`65-K` repair packets.

At `K=38..30`, where `kappa4<=8`, the scanner enumerated every nonzero ambiguity vector.
Across the 20 sampled honest sets at each of those nine values, the exact minimum honest-row
weights were respectively 72–78, 75–80, 77–82, 79–84, 79–87, 81–91, 86–94, 95–101, and
89–102. Thus those 180 individual sampled codes exactly have no weight-at-most-64 word in
`Z4`; this is not a claim about every possible honest set. For `K>=39`, enumeration is exact
only within each selected residual subspace, so a failed search remains a heuristic failure.

### Transition refinement

The transition campaign used seed `640200260829`, 200 honest sets per `K`, and 40 restarts
at every neighboring `K=56..44`. Intervals below are ordinary two-sided 95% Wilson score
intervals and describe only this sampling/search procedure. Weight summaries include
successful explicit witnesses only.

| K | Delta | E2E / 200 | Wilson 95% | witness weight min/median/max |
|---:|---:|---:|:---:|:---:|
| 56 | 9 | 193 | [0.930, 0.983] | 57 / 62 / 64 |
| 55 | 10 | 176 | [0.828, 0.918] | 57 / 63 / 64 |
| 54 | 11 | 145 | [0.659, 0.782] | 59 / 63 / 64 |
| 53 | 12 | 113 | [0.496, 0.632] | 59 / 63 / 64 |
| 52 | 13 | 74 | [0.306, 0.439] | 60 / 64 / 64 |
| 51 | 14 | 64 | [0.259, 0.388] | 59 / 64 / 64 |
| 50 | 15 | 36 | [0.133, 0.239] | 59 / 63 / 64 |
| 49 | 16 | 17 | [0.054, 0.132] | 62 / 64 / 64 |
| 48 | 17 | 10 | [0.027, 0.090] | 62 / 64 / 64 |
| 47 | 18 | 5 | [0.011, 0.057] | 64 / 64 / 64 |
| 46 | 19 | 1 | [0.001, 0.028] | 64 / 64 / 64 |
| 45 | 20 | 2 | [0.003, 0.036] | 61 / 61.5 / 62 |
| 44 | 21 | 2 | [0.003, 0.036] | 60 / 60.5 / 61 |

The transition is broad rather than a sharp threshold. Under a declared convention that
"high empirical frequency" means a point estimate at least 0.8 with this 40-restart budget,
the largest observed overhead meeting that convention is `Delta=10` (`K=55`, 176/200).
This is 23 source symbols below the first binary-universal integer (`K=78`) and 24 below the
first binary-randomized integer (`K=79`). It is not a mathematical `Delta_max`. Sparse
successes continue through `Delta=21`. The small reversal from 1/200 at `K=46` to 2/200 at
both `K=45` and `K=44` is the observed non-monotonicity; it may be sampling noise, an RFC-row
effect, or heuristic behavior.

Plotkin shortening and explicit search separate sharply in this region. In the initial
campaign Plotkin contradictions occurred in all samples at `K=65..63`, 12/20 at `K=62`,
2/20 at each of `K=61,60`, 1/20 at `K=59`, and none below, while explicit witnesses remained
common much farther down. None of the 2,600 refined `K=56..44` instances produced a Plotkin
contradiction, but 838 produced an explicit E2E witness.

### Restart-budget sensitivity and timing

The same 200 honest sets at representative high, partial, and low transition points were
rerun sequentially with restart budgets 1, 2, 5, 10, 20, 40, and 80. Entries are
`E2E successes / median shortening-search milliseconds`.

| restarts | K=56, Delta=9 | K=53, Delta=12 | K=50, Delta=15 |
|---:|:---:|:---:|:---:|
| 1 | 15 / 0.502 | 5 / 0.430 | 0 / 0.375 |
| 2 | 30 / 0.977 | 8 / 0.864 | 1 / 0.743 |
| 5 | 68 / 2.453 | 21 / 2.162 | 2 / 1.874 |
| 10 | 103 / 4.863 | 37 / 4.293 | 10 / 3.705 |
| 20 | 155 / 9.657 | 72 / 8.553 | 14 / 7.417 |
| 40 | 193 / 19.330 | 113 / 17.320 | 36 / 15.049 |
| 80 | 200 / 39.024 | 169 / 34.411 | 61 / 29.922 |

The success curve remains strongly budget-sensitive: at `K=56`, 80 restarts reached 200/200;
at `K=53`, it raised success from 113/200 to 169/200; and at `K=50`, from 36/200 to 61/200.
This reinforces that misses outside exact whole-space enumeration are search failures only.

Across the 2,600-instance 40-restart transition campaign, median/p95/maximum times were
14.946/19.237/26.516 ms for shortening search and 16.705/22.012/30.350 ms total attributable
per instance. Median component times were 0.042 ms for native binary dimension, 0.017 ms for
GF(4) constraint construction, 0.090 ms for the `Z4` basis, 0.008 ms for source rows,
0.115 ms for `B4`, and 1.401 ms for residual enumeration. Among the 838 successful instances,
source-difference construction was 0.0016 ms median and real encoder/decoder replay was
0.346 ms median. Detailed per-stage p95 and maxima are retained in the individual outputs.

Machine-readable outputs:

- dense initial instances and aggregate:
  `results/gf4_overhead_f64_k30_65_s20_r40_seed640020260829[_aggregate].{csv,json}`;
- focused transition instances and aggregate:
  `results/gf4_overhead_f64_k44_56_s200_r40_seed640200260829[_aggregate].{csv,json}`;
- restart study: single-K files matching
  `results/gf4_overhead_f64_k{50,53,56}_{same}_s200_r{1,2,5,10,20,40,80}_seed640200260829[_aggregate].{csv,json}`.

## Exact Delsarte boundary and universal consequences

Scaled floating-point LP solutions were used only to locate candidate supports and active
constraints. The consolidated certificates are rational, and the verifier recomputes every
normalized Krawtchouk coefficient and every distance inequality with exact arithmetic. No
floating objective or rounded logarithm licenses a claim.

| f | `(n_h,d)` | K | K' | H | kappa4 | exact U4 | margin | certificate |
|---:|:---:|---:|---:|---:|---:|---:|---:|:---|
| 72 | (145,73) | 73 | 75 | 10 | 43 | 42 | 1 | `f72_n145_d73_delsarte_exact.txt` |
| 73 | (147,74) | 74 | 75 | 10 | 44 | 43 | 1 | `f73_n147_d74_delsarte_exact.txt` |
| 74 | (149,75) | 75 | 75 | 10 | 45 | 43 | 2 | `f74_n149_d75_delsarte_exact.txt` |
| 75 | (151,76) | 76 | 84 | 10 | 46 | 44 | 2 | `f75_n151_d76_delsarte_exact.txt` |
| 76 | (153,77) | 77 | 84 | 10 | 47 | 44 | 3 | `f76_n153_d77_delsarte_exact.txt` |

For each row the exact certificate proves `A_4(n_h,d) <= M_f=1/y0` and checks
`4^U4 <= M_f < 4^(U4+1)`. The full rational values are in
`../../gf4/DELSARTE_BOUNDARY_SUMMARY.md` and in the certificates. Since native standardized
RaptorQ gives `kappa4>U4`, every honest row set at each point contains a bad `f+1` subset.

The local study also produced exact rational feasible certificates at `f=68..71`. Scaled
numerical candidate optima do not cross the RaptorQ dimensions there; at `f=70,71`, the
exact integer bounds equal `kappa4` rather than falling below it. The first exact universal
contradiction certified in the examined neighborhood is therefore `f=72`. The GF(4) chain
`f=72..76` joins the existing binary universal theorem at `f=77`, giving continuous
universal coverage at every RFC-valid `K=f+1` point from `f=72` onward.

The same bounds give a small universal overhead range essentially for free. Because
`kappa4(K)=K-30` here, `K_min=U4+31`: the largest exact universal `Delta=f+1-K` is 0, 0, 1,
1, and 2 at `f=72,73,74,75,76`, respectively.

Certificate verifier commands (run from the bundle root) are:

```bash
python3 gf4/verify_delsarte_certificates.py gf4/delsarte_exact_certificates/f72_n145_d73_delsarte_exact.txt
python3 gf4/verify_delsarte_certificates.py gf4/delsarte_exact_certificates/f73_n147_d74_delsarte_exact.txt
python3 gf4/verify_delsarte_certificates.py gf4/delsarte_exact_certificates/f74_n149_d75_delsarte_exact.txt
python3 gf4/verify_delsarte_certificates.py gf4/delsarte_exact_certificates/f75_n151_d76_delsarte_exact.txt
python3 gf4/verify_delsarte_certificates.py gf4/delsarte_exact_certificates/f76_n153_d77_delsarte_exact.txt
```

Running the verifier without filenames checks all nine local certificates. The original
`f72_delsarte_exact_certificate.txt` and its original verifier are preserved unchanged.

## Practical algorithm and complexity

The effective practical procedure is GF(4) low-rank shortening followed by explicit
low-weight search in the residual ambiguity space. It constructs `Z4` and `B4`, follows
randomized greedy projective-closure paths, computes the kernel of each selected low-rank
row set, and enumerates all `4^r-1` nonzero residual vectors when `r<=8`. A minimum word in
that selected subspace is then mapped to a source difference and replayed through the real
encoder and decoder. Closure selection is heuristic; residual enumeration is exact after
the subspace is selected. A miss outside whole-space enumeration is only a search failure.

Let `m=S+4H+(K'-K)`, `h=2f+1`, `kappa=kappa4`, `R` be the restart count, `r` the residual
dimension, and `w` the bit-slice word size. Conservative costs are:

- `Z4` construction by row reduction: `O(m L^2 / w)` word operations;
- `B4` construction: `O(h kappa L / w)`;
- projective grouping and quotient row updates: `O(h kappa^2)` per greedy path and
  `O(R h kappa^2)` over restarts, plus key hashing/comparison;
- a residual kernel: `O(|T| kappa^2)` dense GF(4) work;
- exact residual enumeration: after evaluating the residual basis, the implementation walks
  the same base-4 coefficient order with bit-sliced incremental updates, costing
  `O(4^r (h+kappa)/w)` amortized word operations rather than recomputing every dot product;
- source-difference recovery: `O(kappa L / w + K L / w)`.

Encoder/decoder replay is a separate validation cost inherited from the vendored codec.
Because enumeration is exponential in `r`, this is not an unrestricted provably
polynomial-time algorithm. It is practical on the measured path because `r` is capped at
eight. Across the 2,600 refined 40-restart instances, shortening search took
14.946/19.237/26.516 ms median/p95/maximum; total attributable time was
16.705/22.012/30.350 ms. This supports the description “practical heuristic attack” while
keeping asymptotic and empirical claims separate.

Standalone prose prepared for later manuscript integration is in
`../../GF4_APPENDIX_DRAFT.md`; two shorter candidate fragments are in
`../../GF4_MAIN_TEXT_SUMMARY.md`.

## Full-domain ESI-assignment sensitivity experiment

### Actual standardized domain and samplers

RFC 6330 defines the ESI as a 24-bit unsigned integer. Vendored `raptorq` 2.0.1 enforces
`encoding_symbol_id < 16777216` in `PayloadId::new`. The actual external ESI domain is
therefore exactly `0..=16,777,215`, of size `2^24`. For a block with `K` source symbols,
`0..K-1` are systematic ESIs and `K..=16,777,215` are repair ESIs. The encoder accepts a
repair ESI `X` by calling `repair_packets(X-K,1)`; the decoder and native row bridge apply
the vendored `K'-K` ESI-to-ISI shift.

The legacy `consecutive` sampler is unchanged: at fixed `f`, it samples `h=2f+1` ESIs
uniformly without replacement from `0..=3f`. The new primary `random-esi` sampler uses
Floyd sampling with rejection-sampled RNG draws to select a uniform `h`-subset directly
from the full `2^24` domain in `O(h)` memory, then puts the set in the same canonical
ascending order used by the legacy path.

Direct `H` sampling has the same marginal law as first sampling a uniform outer assignment
`U` of size `u=3f+1` from a domain of size `D`, then sampling a uniform `h`-subset of `U`:

```text
Pr[H] = C(D-h,u-h) / (C(D,u) C(u,h)) = 1/C(D,h).
```

The direct sampler therefore avoids constructing an unused outer set without changing the
honest-set distribution.

Tests independently compare native `B4` row functionals with actual encoder differences at
systematic ESIs, low repair ESIs, ESI 193, 1,000,000, 8,388,608, and the maximum ESI
16,777,215. Fresh decoders recover from low-, medium-, high-repair, and mixed packet sets.
All tests pass. An 80-instance before/after differential comparison of the enumeration
optimization checked 57 scientific fields per record and found zero mismatches; only timing
fields changed.

### Primary 40-restart results

The primary campaign uses `f=64`, `h=129`, seed `640300260830`, 200 independently sampled
sets per `K`, and all 40 restarts. Success requires an explicit word of weight at most 64
and a complete passing encoder/decoder replay. Ordinary two-sided 95% Wilson intervals are
shown.

| K | Delta | E2E successes | Wilson 95% | median first success | median selected weight |
|---:|---:|---:|:---:|---:|---:|
| 65 | 0 | 200/200 | [0.981,1.000] | 1 | 54 |
| 56 | 9 | 200/200 | [0.981,1.000] | 1 | 60 |
| 55 | 10 | 200/200 | [0.981,1.000] | 2 | 61 |
| 54 | 11 | 200/200 | [0.981,1.000] | 2 | 61 |
| 53 | 12 | 200/200 | [0.981,1.000] | 4 | 62 |
| 52 | 13 | 198/200 | [0.964,0.997] | 6 | 62 |
| 51 | 14 | 189/200 | [0.904,0.969] | 11 | 63 |
| 50 | 15 | 129/200 | [0.577,0.708] | 13 | 64 |
| 49 | 16 | 101/200 | [0.436,0.574] | 14 | 64 |
| 48 | 17 | 64/200 | [0.259,0.388] | 25 | 65 |
| 47 | 18 | 34/200 | [0.124,0.228] | 15.5 | 66 |
| 46 | 19 | 28/200 | [0.099,0.195] | 23 | 66 |
| 45 | 20 | 10/200 | [0.027,0.090] | 24.5 | 67 |
| 44 | 21 | 5/200 | [0.011,0.057] | 16 | 68 |

The full-domain campaign produced 1,558 E2E witnesses in the 2,600-set `K=56..44`
transition, compared with 838 under the archived consecutive baseline. Under the existing
descriptive convention “observed fraction at least 0.8,” the primary full-domain boundary
is `K=51`, `Delta=14` (189/200), compared with `K=55`, `Delta=10` for the consecutive
baseline. These are sampler- and budget-specific empirical frequencies, not universal or
protocol-level probability statements.

The primary sets were almost purely repair symbols, as the full-domain law predicts: among
all 2,800 primary sets, 2,799 contained zero systematic ESIs and one set contained one;
none contained ESI 0. Nevertheless, every `B4` had full column rank, so the immediate-kernel
frequency was 0/2,800. Median minimum/maximum ESIs were about 85,000--92,000 and
16.68--16.71 million across the displayed `K` values.

### Restart sensitivity and composition diagnostic

The same 200 `H` sets and deterministic restart prefixes give:

| K | r=1 | 2 | 5 | 10 | 20 | 40 | 80 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 56 | 133 | 183 | 200 | 200 | 200 | 200 | 200 |
| 53 | 25 | 68 | 118 | 172 | 196 | 200 | 200 |
| 50 | 4 | 11 | 28 | 53 | 98 | 129 | 185 |

Each entry is a success count out of 200. The 80-restart reruns preserve the exact sampled
sets and first 40 deterministic restarts.

Because the primary distribution materially changed the systematic/repair composition, a
50-set `stratified-random-esi` diagnostic at `K=65,56,53,50` paired each set with the
systematic count drawn by the legacy sampler, sampled that many ESIs uniformly from
`0..K-1`, and sampled the remainder uniformly from the full repair stratum. At 40 restarts
it observed 50/50, 50/50, 50/50, and 41/50 E2E successes, respectively. The corresponding
median systematic counts were 44, 36, 36, and 34. Thus removing systematic symbols is not a
necessary explanation for the improvement; spreading repair identifiers across the actual
domain remains the salient changed factor. The diagnostic is small and does not establish
causality or a protocol distribution theorem.

### Structural comparison and timings

The consecutive baseline selected very large low-rank closures: at `K=56,53,50,44`, median
rank savings were 39, 42, 44, and 46. Full-domain random ESIs instead had median selected
rank saving 0 or 1 throughout; their selected residual dimensions ranged from 1 to 8 and
were most often 8. Despite losing the conspicuous large flats, the full-domain campaign
found lower-weight words more often. The operative mechanism in this distribution is
therefore not explained by the large consecutive-range flats alone, motivating the generic
random-code comparison below.

With the semantics-preserving bit-sliced enumerator, median total time was approximately
36--45 ms over `K=44..56` and 52 ms at `K=65`. The entire 2,600-set transition campaign ran
single-threaded in 105.9 seconds; the separate 200-set `K=65` campaign took 10.4 seconds.

Primary per-instance CSV/JSON, aggregate CSV/JSON, restart files, the stratified diagnostic,
and consolidated summaries are under `results/` with the unambiguous prefix
`gf4_esi_sensitivity_*_full_24bit_full_budget_*`. Every per-instance file preserves the
complete actual `H` list.

## Generic random-code null comparison

The final exploratory experiment removes all RaptorQ-specific row structure while matching
the full-domain code length, alphabet, and dimension. For each `K=44..56` and `K=65`, it
samples every entry of a `129 x kappa` matrix independently and uniformly from GF(4), where
`kappa=K-30`, and rejects the complete matrix unless it has full column rank. Conditioning
the iid law on full rank is uniform over full-rank matrices. Since every `kappa`-dimensional
subspace has exactly `|GL(kappa,4)|` ordered generator bases, the induced code is uniform
over `kappa`-dimensional subspaces of `GF(4)^129`.

For comparison with search frequency, the exact random-code first moment is

```text
E[N_<=64] = (4^kappa-1) sum_{w=1}^{64} C(129,w)3^w / (4^129-1),
E[L_<=64] = E[N_<=64]/3.
```

`N` counts nonzero codewords and `L` counts projective classes. These expectations are not
existence probabilities. The analyzer retains their exact integer ratios and reports
high-precision decimal evaluations.

The campaign used seed `640400260830`, 500 independently generated matrices per `K`, and
the identical projective-closure/exact-residual search used on `B4`. Primary results use 40
restarts; the same streams continue to 80 at `K=56,53,50`. Every claimed low-weight word was
independently recomputed as `B_rand x`, including a nonzero coefficient-vector check.

| K | 44 | 45 | 46 | 47 | 48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 56 | 65 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| random code / 500 | 9 | 24 | 52 | 95 | 170 | 248 | 372 | 460 | 497 | 500 | 500 | 500 | 500 | 500 |
| full-domain RaptorQ / 200 | 5 | 10 | 28 | 34 | 64 | 101 | 129 | 189 | 198 | 200 | 200 | 200 | 200 | 200 |

The restart-prefix counts are:

| K | population | 1 | 2 | 5 | 10 | 20 | 40 | 80 |
|---:|:---|---:|---:|---:|---:|---:|---:|---:|
| 56 | random / 500 | 327 | 450 | 499 | 500 | 500 | 500 | 500 |
| 56 | RaptorQ / 200 | 133 | 183 | 200 | 200 | 200 | 200 | 200 |
| 53 | random / 500 | 84 | 176 | 311 | 440 | 495 | 500 | 500 |
| 53 | RaptorQ / 200 | 25 | 68 | 118 | 172 | 196 | 200 | 200 |
| 50 | random / 500 | 13 | 32 | 79 | 142 | 268 | 372 | 458 |
| 50 | RaptorQ / 200 | 4 | 11 | 28 | 53 | 98 | 129 | 185 |

All 7,000 random matrices and all 2,800 primary full-domain RaptorQ matrices had full column
rank, so neither population produced an immediate kernel. Random-code median selected rank
saving was one throughout; full-domain RaptorQ was usually zero or one. Median residual
dimension was eight at nearly every point, and median selected weights agreed exactly at
12 of 14 displayed `K` values and differed by one at the rest. Closure sizes and
ranks likewise tracked closely.

The optional row-order diagnostic permuted each of 20 `K=50` random matrices five times
with independently seeded Fisher-Yates permutations. Under the same 40-restart stream, all
100 permutations reproduced the unpermuted selected coefficient vector, weight, residual
basis, and first-success restart. No gross row-order artifact was observed.

The clearest finite-budget difference is `K=50`: random codes reached 372/500 (0.744) at 40
restarts versus 129/200 (0.645) for RaptorQ. At 80 restarts the rates reconverged to 458/500
(0.916) and 185/200 (0.925). Thus the measured outcome is Case A: for this low-weight search,
full-domain RaptorQ behaves approximately like the generic quaternary null. This is an
empirical comparison, not a theorem that the RaptorQ induced-code distribution is uniform.
The consecutive-ESI large low-rank flats are special structure, but are not needed to
explain the full-domain low-weight phenomenon.

The single-process campaign took 349.266 seconds; summed per-instance wall time was 349.227
seconds. The machine-readable comparison, exact first moments, restart curves, full raw
records, and complete report are under `results/gf4_random_code_null_*` and
`results/GF4_RANDOM_CODE_NULL_SUMMARY_2026-08-30.md`.

## Failed ideas and limitations

- A 10-restart pilot failed on one sampled `f=62` set, while the 40-restart main campaign
  succeeded on all ten independently sampled `f=62` sets. This demonstrates search-budget
  sensitivity, not a contradiction and not evidence of nonexistence.
- Randomized greedy closure is not an optimizer. No optimality claim is made for `|T|`, rank
  saving, residual dimension, or minimum weight outside exact enumeration of a selected
  small residual space.
- The consecutive-sampler and full-domain 200/200 results are empirical. No invariant has
  been proved that forces the consecutive rank-33 flats or the full-domain weight behavior
  for every honest-row set.
- The random-code first moment is not an existence probability, and agreement with the null
  does not prove that full-domain RaptorQ codes are uniformly random subspaces.
- The dense overhead scans are limited to `f=64`, `H=10`, and their explicitly stated ESI
  distributions. No additional broad `f=40..90` campaign was launched.
- The exact Delsarte certificates settle the local contradiction boundary, but most are
  feasibility certificates rather than proofs that the displayed rational objective is the
  optimal Delsarte objective. Optimality is unnecessary for their integer dimension bounds.
- Numerical evidence below `f=72` does not establish that no stronger coding bound could
  prove a contradiction there.

## Reproduction commands

Run from this directory:

```bash
cargo build --release --workspace
cargo test --release
cargo run -p rq-attack --release -- certify
cargo run -p rq-attack --release --bin gf4_f64_real_decoder
cargo run -p rq-attack --release -- gf4-certify
cargo run -p rq-attack --release -- gf4-f64 --seed 20260829 --restarts 200
cargo run -p rq-attack --release -- gf4-scan --f-min 40 --f-max 90 --samples 10 --restarts 40 --seed 20260829
cargo run -p rq-attack --release -- gf4-scan --f-min 64 --f-max 64 --samples 200 --restarts 40 --seed 16420260829
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 30 --k-max 65 --samples 20 --restarts 40 --seed 640020260829
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 44 --k-max 56 --samples 200 --restarts 40 --seed 640200260829
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 65 --k-max 65 --samples 200 --restarts 40 --seed 640300260830 --sampler random-esi
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 44 --k-max 56 --samples 200 --restarts 40 --seed 640300260830 --sampler random-esi
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 56 --k-max 56 --samples 200 --restarts 80 --seed 640300260830 --sampler random-esi
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 53 --k-max 53 --samples 200 --restarts 80 --seed 640300260830 --sampler random-esi
cargo run -p rq-attack --release -- gf4-overhead-scan --f 64 --k-min 50 --k-max 50 --samples 200 --restarts 80 --seed 640300260830 --sampler random-esi
python3 results/analyze_esi_sensitivity.py
cargo run -p rq-attack --release -- gf4-random-code-null --k-min 44 --k-max 56 --samples 500 --restarts 40 --nested-restarts 80 --seed 640400260830
python3 results/analyze_random_code_null.py
python3 ../../gf4/verify_exact_delsarte.py
python3 ../../gf4/verify_delsarte_certificates.py
```

The corrected Python f=64 verifier additionally requires `numpy` and `numba`; it was not
runnable in the recorded environment because `numba` was absent.
