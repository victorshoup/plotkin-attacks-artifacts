#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE="$HERE/source"
TEMP=$(mktemp -d /tmp/rq-gf4-dimension-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT

export CARGO_BUILD_JOBS=2
export RAYON_NUM_THREADS=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 BLIS_NUM_THREADS=1 GOTO_NUM_THREADS=1

command -v cargo >/dev/null 2>&1 || {
    echo "cargo is required to reproduce the frozen GF(4) dimension tables" >&2
    exit 2
}
cp -R "$SOURCE" "$TEMP/source"
mkdir -p "$TEMP/source/results"
(
    cd "$TEMP/source"
    cargo run --locked -j 2 --release -p rq-attack -- gf4-certify
) > "$TEMP/gf4_dimension_replay.log" 2>&1

cmp "$HERE/gf4_kprime_dimensions_rust.csv" \
    "$TEMP/source/results/gf4_kprime_dimensions_rust.csv"
cmp "$HERE/gf4_band_min_dimensions_rust.csv" \
    "$TEMP/source/results/gf4_band_min_dimensions_rust.csv"
grep -q '^RESULT: NATIVE GF(4) RFC DIMENSION CERTIFICATE PASSED$' \
    "$TEMP/gf4_dimension_replay.log"
echo "GF(4) DIMENSION VERIFICATION PASS: 477 full endpoints and 477 band minima reproduced byte-for-byte"
