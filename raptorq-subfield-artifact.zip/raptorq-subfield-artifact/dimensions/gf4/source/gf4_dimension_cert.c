#define _POSIX_C_SOURCE 200809L
#define main rq_empirical_program_main
#include "../../../source/current_empirical/rq_empirical.c"
#undef main

#include <errno.h>
#include <limits.h>

/*
 * Exact GF(4) rank-only certificate.  This deliberately reuses the trusted
 * RFC parameter, field, HDPC, and LT-row construction from rq_empirical.c,
 * but does not construct a nullspace basis.  Binary LDPC/padding rows are
 * reduced first over GF(2); the two GF(4) coordinate rows of each HDPC row
 * are then reduced over GF(4).  Reordering rows cannot change rank and keeps
 * the full RFC domain practical without allocating an L-by-L matrix.
 */

typedef struct {
    uint64_t *rows;
    int *pivot_row;
    int nrows;
    int ncols;
    int words;
    int rank;
} binary_basis;

typedef struct {
    rq_params p;
    int rank;
    int rows;
    int kappa;
} certificate_result;

static subfield sf4;
static uint8_t gf4_code[256];
static uint8_t gf4_value[4];
static uint8_t gf4_product[4][4];
static uint8_t gf4_inverse[4];
static uint8_t multiplication_mask[4][2];

static void checked_path(char *out, size_t size, const char *directory,
                         const char *name)
{
    int n = snprintf(out, size, "%s/%s", directory, name);
    if (n < 0 || (size_t)n >= size) die("certificate output path too long");
}

static FILE *open_certificate_output(const char *directory, const char *name)
{
    char path[PATH_MAX];
    checked_path(path, sizeof(path), directory, name);
    FILE *file = fopen(path, "w");
    if (file == NULL) {
        fprintf(stderr, "cannot open %s: %s\n", path, strerror(errno));
        exit(2);
    }
    return file;
}

static void initialize_gf4_tables(void)
{
    memset(gf4_code, 0xff, sizeof(gf4_code));
    /* A polynomial-basis code is required: its bitwise XOR is field addition. */
    const uint8_t beta = gf_exp[85]; /* generator of GF(4)^* inside GF(256) */
    uint8_t basis[2] = {1, beta};
    for (int code = 0; code < 4; ++code) {
        uint8_t value = 0;
        for (int bit = 0; bit < 2; ++bit) {
            if ((code >> bit) & 1) value ^= basis[bit];
        }
        if (gf4_code[value] != 0xff) die("GF(4) polynomial basis collision");
        gf4_code[value] = (uint8_t)code;
        gf4_value[code] = value;
    }
    for (int i = 0; i < 4; ++i) {
        if (gf4_code[sf4.elems[i]] == 0xff) die("GF(4) basis misses subfield element");
    }
    for (int a = 0; a < 4; ++a) {
        for (int b = 0; b < 4; ++b) {
            uint8_t product = gf_mul(gf4_value[a], gf4_value[b]);
            if (gf4_code[product] == 0xff) die("GF(4) product escaped subfield");
            gf4_product[a][b] = gf4_code[product];
        }
    }
    gf4_inverse[0] = 0;
    for (int a = 1; a < 4; ++a) {
        for (int b = 1; b < 4; ++b) {
            if (gf4_product[a][b] == 1) gf4_inverse[a] = (uint8_t)b;
        }
        if (gf4_inverse[a] == 0) die("missing GF(4) inverse");
    }
    for (int scalar = 0; scalar < 4; ++scalar) {
        for (int input_bit = 0; input_bit < 2; ++input_bit) {
            uint8_t output = gf4_product[scalar][1 << input_bit];
            for (int output_bit = 0; output_bit < 2; ++output_bit) {
                if ((output >> output_bit) & 1u) {
                    multiplication_mask[scalar][output_bit] |=
                        (uint8_t)(1u << input_bit);
                }
            }
        }
    }
}

static inline void bit_set(uint64_t *row, int column)
{
    row[column >> 6] |= UINT64_C(1) << (column & 63);
}

static int first_binary_one(const uint64_t *row, int words, int ncols)
{
    for (int w = 0; w < words; ++w) {
        if (row[w] != 0) {
            int column = 64 * w + __builtin_ctzll(row[w]);
            return column < ncols ? column : -1;
        }
    }
    return -1;
}

static binary_basis build_binary_basis(const rq_params *p)
{
    binary_basis basis;
    basis.nrows = p->S + (p->Kp - p->K);
    basis.ncols = p->L;
    basis.words = (p->L + 63) / 64;
    basis.rank = 0;
    basis.rows = xcalloc((size_t)basis.nrows * basis.words,
                         sizeof(*basis.rows));
    basis.pivot_row = xmalloc((size_t)p->L * sizeof(*basis.pivot_row));
    for (int column = 0; column < p->L; ++column) basis.pivot_row[column] = -1;

    int B = p->W - p->S;
    for (int i = 0; i < B; ++i) {
        int a = 1 + i / p->S;
        int b = i % p->S;
        bit_set(basis.rows + (size_t)b * basis.words, i);
        b = (b + a) % p->S;
        bit_set(basis.rows + (size_t)b * basis.words, i);
        b = (b + a) % p->S;
        bit_set(basis.rows + (size_t)b * basis.words, i);
    }
    for (int i = 0; i < p->S; ++i) {
        uint64_t *row = basis.rows + (size_t)i * basis.words;
        bit_set(row, i + B);
        bit_set(row, (i % p->P) + p->W);
        bit_set(row, ((i + 1) % p->P) + p->W);
    }

    int row_index = p->S;
    for (int isi = p->K; isi < p->Kp; ++isi) {
        int indices[MAX_DEG];
        int count = encoding_indices((uint32_t)isi, p, indices);
        uint64_t *row = basis.rows + (size_t)row_index * basis.words;
        for (int i = 0; i < count; ++i) bit_set(row, indices[i]);
        ++row_index;
    }
    if (row_index != basis.nrows) die("binary constraint row count mismatch");

    for (int r = 0; r < basis.nrows; ++r) {
        uint64_t *row = basis.rows + (size_t)r * basis.words;
        int reductions = 0;
        for (;;) {
            if (++reductions > basis.ncols + 1) die("binary rank reduction did not advance");
            int pivot = first_binary_one(row, basis.words, basis.ncols);
            if (pivot < 0) break;
            int existing = basis.pivot_row[pivot];
            if (existing < 0) {
                basis.pivot_row[pivot] = r;
                ++basis.rank;
                break;
            }
            const uint64_t *source =
                basis.rows + (size_t)existing * basis.words;
            for (int w = pivot >> 6; w < basis.words; ++w) row[w] ^= source[w];
        }
    }
    return basis;
}

static void free_binary_basis(binary_basis *basis)
{
    free(basis->rows);
    free(basis->pivot_row);
    memset(basis, 0, sizeof(*basis));
}

static int gf4_row_first(const uint64_t *row, int words, int ncols)
{
    for (int w = 0; w < words; ++w) {
        uint64_t combined = row[w] | row[words + w];
        if (combined != 0) {
            int column = 64 * w + __builtin_ctzll(combined);
            return column < ncols ? column : -1;
        }
    }
    return -1;
}

static uint8_t gf4_row_coefficient(const uint64_t *row, int words, int column)
{
    uint64_t bit = UINT64_C(1) << (column & 63);
    int word = column >> 6;
    uint8_t code = 0;
    for (int plane = 0; plane < 2; ++plane) {
        if (row[(size_t)plane * words + word] & bit) code |= (uint8_t)(1u << plane);
    }
    return code;
}

static void gf4_row_set(uint64_t *row, int words, int column, uint8_t code)
{
    uint64_t bit = UINT64_C(1) << (column & 63);
    int word = column >> 6;
    for (int plane = 0; plane < 2; ++plane) {
        if ((code >> plane) & 1u) row[(size_t)plane * words + word] |= bit;
    }
}

static void gf4_add_scaled_binary(uint64_t *target, const uint64_t *binary,
                                   int words, uint8_t scalar, int first_word)
{
    for (int plane = 0; plane < 2; ++plane) {
        if (!((scalar >> plane) & 1u)) continue;
        uint64_t *output = target + (size_t)plane * words;
        for (int w = first_word; w < words; ++w) output[w] ^= binary[w];
    }
}

static uint64_t selected_xor(const uint64_t input[2], uint8_t mask)
{
    uint64_t result = 0;
    for (int bit = 0; bit < 2; ++bit) if ((mask >> bit) & 1u) result ^= input[bit];
    return result;
}

static void gf4_add_scaled(uint64_t *target, const uint64_t *source,
                            int words, uint8_t scalar, int first_word)
{
    for (int w = first_word; w < words; ++w) {
        uint64_t input[2];
        for (int plane = 0; plane < 2; ++plane) {
            input[plane] = source[(size_t)plane * words + w];
        }
        for (int plane = 0; plane < 2; ++plane) {
            target[(size_t)plane * words + w] ^=
                selected_xor(input, multiplication_mask[scalar][plane]);
        }
    }
}

static void gf4_scale(uint64_t *row, int words, uint8_t scalar)
{
    for (int w = 0; w < words; ++w) {
        uint64_t input[2];
        for (int plane = 0; plane < 2; ++plane) input[plane] = row[(size_t)plane * words + w];
        for (int plane = 0; plane < 2; ++plane) {
            row[(size_t)plane * words + w] =
                selected_xor(input, multiplication_mask[scalar][plane]);
        }
    }
}

static uint8_t *generate_hdpc_dense(const rq_params *p)
{
    int width = p->Kp + p->S;
    uint8_t *hdpc = xcalloc((size_t)p->H * width, 1);
#define HDPC(r, c) hdpc[(size_t)(r) * width + (c)]
    for (int i = 0; i < p->H; ++i) HDPC(i, width - 1) = gf_exp[i];
    for (int j = width - 2; j >= 0; --j) {
        for (int i = 0; i < p->H; ++i) HDPC(i, j) = gf_mul(2, HDPC(i, j + 1));
        int first = (int)rq_rand((uint32_t)j + 1u, 6, (uint32_t)p->H);
        int offset = (int)rq_rand((uint32_t)j + 1u, 7, (uint32_t)p->H - 1u);
        HDPC(first, j) ^= 1;
        HDPC((first + offset + 1) % p->H, j) ^= 1;
    }
#undef HDPC
    return hdpc;
}

static certificate_result certify_k(int K)
{
    certificate_result result;
    result.p = get_params(K);
    binary_basis binary = build_binary_basis(&result.p);
    int words = binary.words;
    int hdpc_rows = 4 * result.p.H;
    uint64_t *gf_rows = xcalloc((size_t)hdpc_rows * 2 * words,
                                sizeof(*gf_rows));
    int *gf_pivot = xmalloc((size_t)result.p.L * sizeof(*gf_pivot));
    for (int column = 0; column < result.p.L; ++column) gf_pivot[column] = -1;
    uint8_t *hdpc = generate_hdpc_dense(&result.p);
    int hdpc_width = result.p.Kp + result.p.S;
    int gf_rank = 0;

    for (int h = 0; h < result.p.H; ++h) {
        for (int coordinate = 0; coordinate < 4; ++coordinate) {
            uint64_t *row = gf_rows + (size_t)gf_rank * 2 * words;
            memset(row, 0, (size_t)2 * words * sizeof(*row));
            for (int column = 0; column < result.p.L; ++column) {
                uint8_t coefficient = 0;
                if (column < hdpc_width) {
                    coefficient = hdpc[(size_t)h * hdpc_width + column];
                } else if (column == hdpc_width + h) {
                    coefficient = 1;
                }
                uint8_t subfield_element = sf4.decomp[coefficient][coordinate];
                uint8_t code = gf4_code[subfield_element];
                if (code == 0xff) die("invalid GF(4) coordinate");
                if (code != 0) gf4_row_set(row, words, column, code);
            }

            int reductions = 0;
            for (;;) {
                if (++reductions > result.p.L + 1) {
                    fprintf(stderr, "stuck K=%d h=%d coordinate=%d pivot=%d coefficient=%u binary=%d gf=%d\n",
                            K, h, coordinate,
                            gf4_row_first(row, words, result.p.L),
                            gf4_row_coefficient(row, words,
                                gf4_row_first(row, words, result.p.L)),
                            binary.pivot_row[gf4_row_first(row, words, result.p.L)],
                            gf_pivot[gf4_row_first(row, words, result.p.L)]);
                    die("GF(4) rank reduction did not advance");
                }
                int pivot = gf4_row_first(row, words, result.p.L);
                if (pivot < 0) break;
                uint8_t coefficient = gf4_row_coefficient(row, words, pivot);
                int binary_row = binary.pivot_row[pivot];
                if (binary_row >= 0) {
                    gf4_add_scaled_binary(row,
                        binary.rows + (size_t)binary_row * words,
                        words, coefficient, pivot >> 6);
                    continue;
                }
                int previous = gf_pivot[pivot];
                if (previous >= 0) {
                    uint8_t previous_coefficient = gf4_row_coefficient(
                        gf_rows + (size_t)previous * 2 * words, words, pivot);
                    if (previous_coefficient != 1) {
                        fprintf(stderr, "unnormalized pivot K=%d pivot=%d code=%u\n",
                                K, pivot, previous_coefficient);
                        die("GF(4) pivot normalization failure");
                    }
                    gf4_add_scaled(row,
                        gf_rows + (size_t)previous * 2 * words,
                        words, coefficient, pivot >> 6);
                    continue;
                }
                gf4_scale(row, words, gf4_inverse[coefficient]);
                gf_pivot[pivot] = gf_rank;
                ++gf_rank;
                break;
            }
        }
    }
    free(hdpc);
    free(gf_pivot);
    result.rank = binary.rank + gf_rank;
    result.rows = binary.nrows + hdpc_rows;
    result.kappa = result.p.L - result.rank;
    free(gf_rows);
    free_binary_basis(&binary);
    return result;
}

static int floor_kappa4(int K, int H)
{
    return K > 3 * H ? K - 3 * H : 0;
}

static int expected_kappa4(int K, int H)
{
    return K == 30 ? 1 : floor_kappa4(K, H);
}

static void emit_result(FILE *file, int index, int kprime, int kmin,
                        certificate_result r, int is_band)
{
    int expected = expected_kappa4(r.p.K, r.p.H);
    if (is_band) {
        fprintf(file, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                index, kprime, kmin, r.p.S, r.p.H, r.p.L, r.kappa,
                expected, r.rank, r.rows, kprime - kmin,
                r.kappa == expected);
    } else {
        fprintf(file, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                kprime, r.p.S, r.p.H, r.p.L, r.kappa, expected,
                r.rank, r.rows, r.kappa - floor_kappa4(r.p.K, r.p.H), r.kappa == expected);
    }
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s OUTPUT_DIRECTORY\n", argv[0]);
        return 2;
    }
    gf256_init();
    subfield_init(&sf4, 4);
    initialize_gf4_tables();

    FILE *full = open_certificate_output(argv[1], "gf4_kprime_dimensions_rust.csv");
    FILE *bands = open_certificate_output(argv[1], "gf4_band_min_dimensions_rust.csv");
    FILE *direct = open_certificate_output(argv[1], "gf4_direct_checks.csv");
    setvbuf(full, NULL, _IOLBF, 0);
    setvbuf(bands, NULL, _IOLBF, 0);
    setvbuf(direct, NULL, _IOLBF, 0);
    fputs("Kprime,S,H,L,kappa4,expected,rank4,constraint_rows,delta,ok\n", full);
    fputs("index,Kprime,Kmin,S,H,L,kappa4,expected,rank4,constraint_rows,padding,ok\n", bands);
    fputs("check_type,index,Kprime,K,H,kappa4,expected,rank4,constraint_rows,ok\n", direct);

    int failures = 0;
    int boundary_checks = 0;
    int spot_checks = 0;
    const int spot_indices[] = {1, 10, 50, 100, 200, 300, 400, 476};
    for (int index = 0; index < 477; ++index) {
        if (index % 25 == 0) {
            fprintf(stderr, "GF4_CERT_PROGRESS index=%d/477 Kprime=%u\n",
                    index, RQ_PARAMS[index].kp);
            fflush(stderr);
        }
        int kprime = (int)RQ_PARAMS[index].kp;
        int kmin = index == 0 ? 1 : (int)RQ_PARAMS[index - 1].kp + 1;
        certificate_result full_result = certify_k(kprime);
        certificate_result band_result = certify_k(kmin);
        if (full_result.p.Kp != kprime || band_result.p.Kp != kprime)
            die("RFC band mapping mismatch");
        emit_result(full, index, kprime, kmin, full_result, 0);
        emit_result(bands, index, kprime, kmin, band_result, 1);
        failures += full_result.kappa != expected_kappa4(kprime, full_result.p.H);
        failures += band_result.kappa != expected_kappa4(kmin, band_result.p.H);

        if (kprime == 30) {
            for (int K = kmin; K <= kprime; ++K) {
                certificate_result r = certify_k(K);
                int expected = expected_kappa4(K, r.p.H);
                int ok = r.kappa == expected;
                fprintf(direct, "exception_band,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                        index, kprime, K, r.p.H, r.kappa, expected,
                        r.rank, r.rows, ok);
                failures += !ok;
                ++boundary_checks;
            }
        }

        bool selected = false;
        for (size_t s = 0; s < sizeof(spot_indices) / sizeof(spot_indices[0]); ++s)
            selected |= index == spot_indices[s];
        if (selected && kprime - kmin >= 2) {
            int K = kmin + (kprime - kmin) / 2;
            certificate_result r = certify_k(K);
            int expected = expected_kappa4(K, r.p.H);
            int ok = r.kappa == expected;
            fprintf(direct, "interior_spot,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                    index, kprime, K, r.p.H, r.kappa, expected,
                    r.rank, r.rows, ok);
            failures += !ok;
            ++spot_checks;
        }
    }
    if (fclose(full) != 0 || fclose(bands) != 0 || fclose(direct) != 0)
        die("cannot close certificate output");

    printf("GF(4) exact finite dimension certificate\n");
    printf("full RFC Kprime endpoints: 477\n");
    printf("maximum-padding band endpoints: 477\n");
    printf("direct Kprime=30 exception-band checks: %d\n", boundary_checks);
    printf("independent interior spot checks: %d\n", spot_checks);
    printf("failures: %d\n", failures);
    if (failures != 0) {
        puts("RESULT: GF(4) DIMENSION CERTIFICATE FAILED");
        return 1;
    }
    puts("RESULT: kappa4=1 AT K=30 AND max(0,K-3H_HDPC) OTHERWISE FOR EVERY RFC-VALID K");
    return 0;
}
