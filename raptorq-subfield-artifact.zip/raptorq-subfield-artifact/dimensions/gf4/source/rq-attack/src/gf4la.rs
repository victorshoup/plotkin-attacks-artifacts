//! Bit-sliced linear algebra over GF(4).

use crate::gf2la::{self, BitVec};
use crate::gf4::Gf4;

/// A GF(4) row. The low/high coefficient bits are independently bit-packed.
#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct Row {
    pub lo: BitVec,
    pub hi: BitVec,
    pub ncols: usize,
}

impl Row {
    pub fn zero(ncols: usize) -> Self {
        Self {
            lo: gf2la::zeros(ncols),
            hi: gf2la::zeros(ncols),
            ncols,
        }
    }

    pub fn from_binary(bits: BitVec, ncols: usize) -> Self {
        Self {
            lo: bits,
            hi: gf2la::zeros(ncols),
            ncols,
        }
    }

    #[inline]
    pub fn coeff(&self, col: usize) -> Gf4 {
        Gf4::from_code(
            gf2la::get_bit(&self.lo, col) as u8 | ((gf2la::get_bit(&self.hi, col) as u8) << 1),
        )
    }

    #[inline]
    pub fn set(&mut self, col: usize, value: Gf4) {
        gf2la::set_bit(&mut self.lo, col, value.code() & 1 != 0);
        gf2la::set_bit(&mut self.hi, col, value.code() & 2 != 0);
    }

    pub fn is_zero(&self) -> bool {
        self.lo.iter().chain(self.hi.iter()).all(|&word| word == 0)
    }

    pub fn first_nonzero(&self) -> Option<usize> {
        for (word_index, (&a, &b)) in self.lo.iter().zip(&self.hi).enumerate() {
            let word = a | b;
            if word != 0 {
                let col = word_index * 64 + word.trailing_zeros() as usize;
                if col < self.ncols {
                    return Some(col);
                }
            }
        }
        None
    }

    #[inline]
    pub fn add_assign(&mut self, rhs: &Self) {
        debug_assert_eq!(self.ncols, rhs.ncols);
        gf2la::xor_into(&mut self.lo, &rhs.lo);
        gf2la::xor_into(&mut self.hi, &rhs.hi);
    }

    pub fn scaled(&self, scalar: Gf4) -> Self {
        let mut out = Self::zero(self.ncols);
        match scalar.code() {
            0 => {}
            1 => {
                out.lo.clone_from(&self.lo);
                out.hi.clone_from(&self.hi);
            }
            // w(A + Bw) = B + (A+B)w
            2 => {
                out.lo.clone_from(&self.hi);
                out.hi.clone_from(&self.lo);
                gf2la::xor_into(&mut out.hi, &self.hi);
            }
            // w^2(A + Bw) = (A+B) + Aw
            3 => {
                out.lo.clone_from(&self.lo);
                gf2la::xor_into(&mut out.lo, &self.hi);
                out.hi.clone_from(&self.lo);
            }
            _ => unreachable!(),
        }
        out
    }

    #[inline]
    pub fn add_scaled(&mut self, scalar: Gf4, rhs: &Self) {
        debug_assert_eq!(self.ncols, rhs.ncols);
        match scalar.code() {
            0 => {}
            1 => self.add_assign(rhs),
            2 => {
                for ((out_lo, out_hi), (&rhs_lo, &rhs_hi)) in self
                    .lo
                    .iter_mut()
                    .zip(&mut self.hi)
                    .zip(rhs.lo.iter().zip(&rhs.hi))
                {
                    *out_lo ^= rhs_hi;
                    *out_hi ^= rhs_lo ^ rhs_hi;
                }
            }
            3 => {
                for ((out_lo, out_hi), (&rhs_lo, &rhs_hi)) in self
                    .lo
                    .iter_mut()
                    .zip(&mut self.hi)
                    .zip(rhs.lo.iter().zip(&rhs.hi))
                {
                    *out_lo ^= rhs_lo ^ rhs_hi;
                    *out_hi ^= rhs_lo;
                }
            }
            _ => unreachable!(),
        }
    }

    /// Standard GF(4) dot product (no conjugation).
    pub fn dot(&self, rhs: &Self) -> Gf4 {
        debug_assert_eq!(self.ncols, rhs.ncols);
        let ac = gf2la::dot(&self.lo, &rhs.lo) as u8;
        let bd = gf2la::dot(&self.hi, &rhs.hi) as u8;
        let ad = gf2la::dot(&self.lo, &rhs.hi) as u8;
        let bc = gf2la::dot(&self.hi, &rhs.lo) as u8;
        Gf4::from_code((ac ^ bd) | ((ad ^ bc ^ bd) << 1))
    }

    pub fn coefficients(&self) -> Vec<Gf4> {
        (0..self.ncols).map(|c| self.coeff(c)).collect()
    }
}

/// Reduced row echelon form as sorted `(pivot_column, normalized_row)` pairs.
pub fn rref(rows: &[Row], ncols: usize) -> Vec<(usize, Row)> {
    let mut pivots: Vec<(usize, Row)> = Vec::new();
    for original in rows {
        let mut row = original.clone();
        for (col, pivot) in &pivots {
            let q = row.coeff(*col);
            row.add_scaled(q, pivot);
        }
        let Some(col) = row.first_nonzero() else {
            continue;
        };
        let q = row.coeff(col);
        row = row.scaled(q.inverse());
        for (_, pivot) in &mut pivots {
            let q = pivot.coeff(col);
            pivot.add_scaled(q, &row);
        }
        pivots.push((col, row));
        pivots.sort_by_key(|(c, _)| *c);
    }
    debug_assert!(pivots.iter().all(|(_, row)| row.ncols == ncols));
    pivots
}

pub fn rank(rows: &[Row], ncols: usize) -> usize {
    // Echelon insertion is cheaper than full RREF and sufficient for rank.
    let mut pivots: Vec<Option<Row>> = vec![None; ncols];
    let mut result = 0;
    for original in rows {
        let mut row = original.clone();
        loop {
            let Some(col) = row.first_nonzero() else {
                break;
            };
            let q = row.coeff(col);
            if let Some(pivot) = &pivots[col] {
                row.add_scaled(q, pivot);
            } else {
                row = row.scaled(q.inverse());
                pivots[col] = Some(row);
                result += 1;
                break;
            }
        }
    }
    result
}

pub fn kernel_basis(rows: &[Row], ncols: usize) -> Vec<Row> {
    let pivots = rref(rows, ncols);
    let mut is_pivot = vec![false; ncols];
    for (col, _) in &pivots {
        is_pivot[*col] = true;
    }
    let mut basis = Vec::new();
    for free in 0..ncols {
        if is_pivot[free] {
            continue;
        }
        let mut vector = Row::zero(ncols);
        vector.set(free, Gf4::ONE);
        for (pivot_col, pivot) in &pivots {
            vector.set(*pivot_col, pivot.coeff(free));
        }
        basis.push(vector);
    }
    basis
}

pub fn linear_combination(basis: &[Row], coefficients: &[Gf4], ncols: usize) -> Row {
    assert_eq!(basis.len(), coefficients.len());
    let mut out = Row::zero(ncols);
    for (row, &q) in basis.iter().zip(coefficients) {
        out.add_scaled(q, row);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn row(values: &[u8]) -> Row {
        let mut r = Row::zero(values.len());
        for (i, &q) in values.iter().enumerate() {
            r.set(i, Gf4::from_code(q));
        }
        r
    }

    fn check_kernel(rows: &[Row], ncols: usize) {
        let basis = kernel_basis(rows, ncols);
        assert_eq!(basis.len(), ncols - rank(rows, ncols));
        assert_eq!(rank(&basis, ncols), basis.len());
        for b in &basis {
            for r in rows {
                assert_eq!(r.dot(b), Gf4::ZERO);
            }
        }
    }

    #[test]
    fn rank_and_kernel_small_examples() {
        let rows = vec![row(&[1, 2, 0, 3]), row(&[0, 1, 1, 2])];
        assert_eq!(rank(&rows, 4), 2);
        check_kernel(&rows, 4);

        let mut dependent = rows.clone();
        let mut sum = rows[0].scaled(Gf4::W);
        sum.add_assign(&rows[1].scaled(Gf4::W2));
        dependent.push(sum);
        assert_eq!(rank(&dependent, 4), 2);
        check_kernel(&dependent, 4);
    }

    #[test]
    fn full_rank_and_zero_matrix() {
        let identity = vec![row(&[1, 0]), row(&[0, 1])];
        assert!(kernel_basis(&identity, 2).is_empty());
        assert_eq!(kernel_basis(&[Row::zero(3)], 3).len(), 3);
    }
}
