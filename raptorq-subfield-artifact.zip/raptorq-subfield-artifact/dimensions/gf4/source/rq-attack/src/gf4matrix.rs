//! Native construction of Z4 = W intersect GF(4)^L from exact RaptorQ structures.

use raptorq::{generate_hdpc_rows, Octet};

use crate::gf2la::BitVec;
use crate::gf4::Gf4;
use crate::gf4la::{self, Row};
use crate::rqmatrix::{self, Params};

pub struct Construction {
    pub params: Params,
    pub z_basis: Vec<Row>,
    pub gsrc: Vec<BitVec>,
}

impl Construction {
    pub fn kappa(&self) -> usize {
        self.z_basis.len()
    }
}

/// Coordinates of each GF(256) octet in the basis (1, alpha, alpha^2, alpha^3)
/// over the embedded GF(4). The exhaustive construction also proves this is a basis.
fn decomposition_table() -> [[Gf4; 4]; 256] {
    let basis = [
        Octet::alpha(0),
        Octet::alpha(1),
        Octet::alpha(2),
        Octet::alpha(3),
    ];
    let mut result = [[Gf4::ZERO; 4]; 256];
    let mut seen = [false; 256];
    for q0 in Gf4::ALL {
        for q1 in Gf4::ALL {
            for q2 in Gf4::ALL {
                for q3 in Gf4::ALL {
                    let qs = [q0, q1, q2, q3];
                    let mut value = 0u8;
                    for (&q, alpha) in qs.iter().zip(&basis) {
                        debug_assert_eq!(Gf4::from_byte(q.to_byte()), Some(q));
                        value ^= (Octet::new(q.to_byte()) * alpha.clone()).byte();
                    }
                    assert!(!seen[value as usize], "GF(256)/GF(4) basis collision");
                    seen[value as usize] = true;
                    result[value as usize] = qs;
                }
            }
        }
    }
    assert!(seen.iter().all(|&x| x));
    result
}

/// [LDPC ; four GF(4) coordinate equations per HDPC row], without padding.
pub fn core_constraints(k: usize) -> (Params, Vec<Row>) {
    let (p, ldpc) = rqmatrix::ldpc_rows(k);
    let mut rows: Vec<Row> = ldpc.into_iter().map(|r| Row::from_binary(r, p.l)).collect();
    let decomp = decomposition_table();
    let hdpc = generate_hdpc_rows(p.kprime, p.s, p.h);
    for i in 0..p.h {
        let mut four = [
            Row::zero(p.l),
            Row::zero(p.l),
            Row::zero(p.l),
            Row::zero(p.l),
        ];
        for j in 0..p.l {
            let coordinates = decomp[hdpc.get(i, j).byte() as usize];
            for t in 0..4 {
                if !coordinates[t].is_zero() {
                    four[t].set(j, coordinates[t]);
                }
            }
        }
        rows.extend(four);
    }
    (p, rows)
}

pub fn constraints(k: usize) -> (Params, Vec<Row>) {
    let (p, mut rows) = core_constraints(k);
    let padding_isis: Vec<u32> = (k as u32..p.kprime as u32).collect();
    rows.extend(
        rqmatrix::encoding_rows_for_isis(k, &padding_isis)
            .into_iter()
            .map(|r| Row::from_binary(r, p.l)),
    );
    (p, rows)
}

pub fn ambiguity_dim(k: usize) -> (Params, usize, usize, usize) {
    let (p, rows) = constraints(k);
    let rank = gf4la::rank(&rows, p.l);
    (p, p.l - rank, rank, rows.len())
}

pub fn construct(k: usize) -> Construction {
    let (p, rows) = constraints(k);
    let z_basis = gf4la::kernel_basis(&rows, p.l);
    let source_esis: Vec<u32> = (0..k as u32).collect();
    let gsrc = rqmatrix::honest_rows(k, &source_esis);
    Construction {
        params: p,
        z_basis,
        gsrc,
    }
}

pub fn induced_matrix(k: usize, honest_esis: &[u32], z_basis: &[Row]) -> Vec<Row> {
    let honest = rqmatrix::honest_rows(k, honest_esis);
    let kappa = z_basis.len();
    honest
        .iter()
        .map(|g| {
            let mut out = Row::zero(kappa);
            for (t, z) in z_basis.iter().enumerate() {
                let q = Gf4::from_code(
                    crate::gf2la::dot(g, &z.lo) as u8 | ((crate::gf2la::dot(g, &z.hi) as u8) << 1),
                );
                out.set(t, q);
            }
            out
        })
        .collect()
}

pub fn combine_ambiguity(basis: &[Row], coefficients: &[Gf4], l: usize) -> Row {
    gf4la::linear_combination(basis, coefficients, l)
}

pub fn source_difference(gsrc: &[BitVec], z: &Row) -> Vec<Gf4> {
    gsrc.iter()
        .map(|row| {
            Gf4::from_code(
                crate::gf2la::dot(row, &z.lo) as u8 | ((crate::gf2la::dot(row, &z.hi) as u8) << 1),
            )
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn selected_dimensions_match_corrected_oracle() {
        let cases = [
            (10, 0),
            (30, 1),
            (31, 1),
            (32, 2),
            (65, 35),
            (73, 43),
            (100, 70),
            (1050, 1017),
        ];
        for (k, expected) in cases {
            let (_, dim, _, _) = ambiguity_dim(k);
            assert_eq!(dim, expected, "K={k}");
        }
    }

    #[test]
    fn basis_satisfies_every_native_constraint() {
        for k in [30usize, 65, 73] {
            let (p, rows) = constraints(k);
            let basis = gf4la::kernel_basis(&rows, p.l);
            for z in &basis {
                for constraint in &rows {
                    assert_eq!(constraint.dot(z), Gf4::ZERO, "K={k}");
                }
            }
        }
    }
}
