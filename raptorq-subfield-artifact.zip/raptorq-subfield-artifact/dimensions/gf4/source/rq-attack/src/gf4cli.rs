//! CLI entry points for native GF(4) certification and experiments.

use std::fmt::Write as _;
use std::path::PathBuf;
use std::time::Instant;

use raptorq::{
    EncodingPacket, ObjectTransmissionInformation, SourceBlockDecoder, SourceBlockEncoder,
};

use crate::gf4la;
use crate::gf4matrix;
use crate::gf4search::{self, F64_HONEST_ESIS, F64_SHORTENING_ESIS};

const KPRIMES: &str = include_str!("../kprimes.txt");

fn standardized_kprimes() -> Vec<usize> {
    KPRIMES
        .split_whitespace()
        .map(|x| x.parse().unwrap())
        .collect()
}

fn expected_kappa4(k: usize, h: usize) -> usize {
    if k == 30 {
        1
    } else {
        k.saturating_sub(3 * h)
    }
}

fn results_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../results")
}

pub fn certify() {
    let start = Instant::now();
    let kprimes = standardized_kprimes();
    assert_eq!(kprimes.len(), 477);
    println!("=== Native GF(4) certificate over RFC 6330 parameters ===");
    println!("constraints: exact RFC LDPC rows + vendored HDPC rows expanded over GF(4) + vendored padding rows");

    let mut full_csv =
        String::from("Kprime,S,H,L,kappa4,expected,rank4,constraint_rows,delta,ok\n");
    let mut band_csv =
        String::from("index,Kprime,Kmin,S,H,L,kappa4,expected,rank4,constraint_rows,padding,ok\n");
    let mut full_failures = 0usize;
    let mut band_failures = 0usize;
    let mut exceptions = Vec::new();

    for (index, &kprime) in kprimes.iter().enumerate() {
        let (p, kappa, rank, rows) = gf4matrix::ambiguity_dim(kprime);
        let expected = expected_kappa4(kprime, p.h);
        let ok = kappa == expected;
        if !ok {
            full_failures += 1;
            println!(
                "  FAIL full K'={kprime} H={} L={}: kappa4={kappa}, expected={expected}, rank={rank}/{rows}",
                p.h, p.l
            );
        }
        let floor = kprime.saturating_sub(3 * p.h);
        if kappa != floor {
            exceptions.push((kprime, p.h, kappa, floor));
        }
        writeln!(
            full_csv,
            "{},{},{},{},{},{},{},{},{},{}",
            kprime,
            p.s,
            p.h,
            p.l,
            kappa,
            expected,
            rank,
            rows,
            kappa as isize - floor as isize,
            ok as u8
        )
        .unwrap();

        let previous = if index == 0 { 0 } else { kprimes[index - 1] };
        let kmin = previous + 1;
        let (bp, band_kappa, band_rank, band_rows) = gf4matrix::ambiguity_dim(kmin);
        assert_eq!(bp.kprime, kprime);
        let band_expected = expected_kappa4(kmin, bp.h);
        let band_ok = band_kappa == band_expected;
        if !band_ok {
            band_failures += 1;
            println!(
                "  FAIL band K'={kprime}, Kmin={kmin}: kappa4={band_kappa}, expected={band_expected}"
            );
        }
        writeln!(
            band_csv,
            "{},{},{},{},{},{},{},{},{},{},{},{}",
            index,
            kprime,
            kmin,
            bp.s,
            bp.h,
            bp.l,
            band_kappa,
            band_expected,
            band_rank,
            band_rows,
            kprime - kmin,
            band_ok as u8
        )
        .unwrap();
    }

    // K'=30 is the only band where the exceptional boundary needs more than the two
    // endpoint monotonicity checks. Check every K in that band directly.
    let mut exception_band_ok = true;
    println!("K'=30 exception band (checked directly):");
    for k in 27..=30 {
        let (p, kappa, rank, rows) = gf4matrix::ambiguity_dim(k);
        let expected = expected_kappa4(k, p.h);
        let ok = kappa == expected;
        exception_band_ok &= ok;
        println!(
            "  K={k}: H={} L={} rank={rank}/{rows} kappa4={kappa} expected={expected} {}",
            p.h,
            p.l,
            if ok { "PASS" } else { "FAIL" }
        );
    }

    let out_dir = results_dir();
    std::fs::create_dir_all(&out_dir).expect("create results directory");
    let full_path = out_dir.join("gf4_kprime_dimensions_rust.csv");
    let band_path = out_dir.join("gf4_band_min_dimensions_rust.csv");
    std::fs::write(&full_path, full_csv).expect("write full-size CSV");
    std::fs::write(&band_path, band_csv).expect("write band CSV");

    println!(
        "checked {} full K' values and {} minimum-band endpoints; failures={}",
        kprimes.len(),
        kprimes.len(),
        full_failures + band_failures + (!exception_band_ok) as usize
    );
    println!("deviations from max(0,K'-3H): {exceptions:?}");
    println!("machine-readable full results: {}", full_path.display());
    println!("machine-readable band results: {}", band_path.display());
    println!("elapsed: {:.3}s", start.elapsed().as_secs_f64());

    if full_failures == 0
        && band_failures == 0
        && exception_band_ok
        && exceptions == vec![(30, 10, 1, 0)]
    {
        println!("RESULT: NATIVE GF(4) RFC DIMENSION CERTIFICATE PASSED");
    } else {
        eprintln!("RESULT: NATIVE GF(4) RFC DIMENSION CERTIFICATE FAILED");
        std::process::exit(1);
    }
}

fn packet_for(enc: &SourceBlockEncoder, esi: u32, k: usize) -> EncodingPacket {
    if (esi as usize) < k {
        enc.source_packets()[esi as usize].clone()
    } else {
        enc.repair_packets(esi - k as u32, 1).pop().unwrap()
    }
}

fn packets_for(enc: &SourceBlockEncoder, esis: &[u32], k: usize) -> Vec<EncodingPacket> {
    esis.iter().map(|&esi| packet_for(enc, esi, k)).collect()
}

#[derive(Clone, Copy, Default)]
struct EndToEnd {
    encoder_equal: bool,
    decoder_none: bool,
    all_zero_decoder_none: bool,
    control: bool,
}

fn validate_end_to_end(
    k: usize,
    bad_esis: &[u32],
    zero_esis: &[u32],
    source_diff: &[crate::gf4::Gf4],
) -> EndToEnd {
    const SYMBOL_BYTES: usize = 8;
    let config =
        ObjectTransmissionInformation::new((k * SYMBOL_BYTES) as u64, SYMBOL_BYTES as u16, 1, 1, 1);
    let mut source = vec![0u8; k * SYMBOL_BYTES];
    for (i, byte) in source.iter_mut().enumerate() {
        *byte = ((i as u64 * 131 + 17) & 0xff) as u8;
    }
    let mut source2 = source.clone();
    for (i, q) in source_diff.iter().enumerate() {
        source2[i * SYMBOL_BYTES] ^= q.to_byte();
    }
    assert_ne!(source, source2);
    let encoder = SourceBlockEncoder::new(0, &config, &source);
    let encoder2 = SourceBlockEncoder::new(0, &config, &source2);
    let encoder_equal = zero_esis
        .iter()
        .all(|&esi| packet_for(&encoder, esi, k).data() == packet_for(&encoder2, esi, k).data());
    let decoder_none = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, bad_esis, k))
        .is_none();
    let all_zero_decoder_none = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, zero_esis, k))
        .is_none();
    let systematic: Vec<u32> = (0..k as u32).collect();
    let control = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, &systematic, k))
        .as_deref()
        == Some(source.as_slice());
    EndToEnd {
        encoder_equal,
        decoder_none,
        all_zero_decoder_none,
        control,
    }
}

pub fn f64(seed: u64, restarts: usize) {
    const F: usize = 64;
    const K: usize = 65;
    let started = Instant::now();
    let construction = gf4matrix::construct(K);
    let p = construction.params;
    let b = gf4matrix::induced_matrix(K, F64_HONEST_ESIS, &construction.z_basis);
    let full_rank = gf4la::rank(&b, construction.kappa());
    assert_eq!(construction.kappa(), 35);
    assert_eq!(full_rank, 35);

    // Differential check of the recorded shortening, reconstructed from the native B4.
    let positions: std::collections::HashMap<u32, usize> = F64_HONEST_ESIS
        .iter()
        .enumerate()
        .map(|(i, &esi)| (esi, i))
        .collect();
    let recorded_rows: Vec<_> = F64_SHORTENING_ESIS
        .iter()
        .map(|esi| b[*positions.get(esi).unwrap()].clone())
        .collect();
    let recorded_rank = gf4la::rank(&recorded_rows, construction.kappa());
    let recorded_residual = gf4la::kernel_basis(&recorded_rows, construction.kappa());
    let mut enumeration_rng = gf4search::Rng::new(seed);
    let recorded_word = gf4search::minimum_word(&b, &recorded_residual, 15, &mut enumeration_rng)
        .expect("recorded residual space is nonzero");
    assert_eq!(
        (recorded_rank, recorded_residual.len(), recorded_word.weight),
        (33, 2, 59)
    );

    // Independent algorithmic search: the recorded shortening is not supplied to this path.
    let search_started = Instant::now();
    let plotkin = gf4search::search_plotkin(&b, F, restarts, seed)
        .expect("greedy Plotkin-shortening search produced no candidate");
    let result = gf4search::search_explicit_word(&b, F, restarts, seed, 8)
        .expect("greedy shortening search produced no candidate");
    let search_seconds = search_started.elapsed().as_secs_f64();
    if result.word.weight > F {
        eprintln!(
            "heuristic search failed to find weight <= {F} after {restarts} restarts (best={})",
            result.word.weight
        );
        std::process::exit(1);
    }

    let zero_esis: Vec<u32> = result
        .word
        .values
        .iter()
        .enumerate()
        .filter_map(|(i, q)| q.is_zero().then_some(F64_HONEST_ESIS[i]))
        .collect();
    assert!(zero_esis.len() >= F + 1);
    let bad_esis = zero_esis[..F + 1].to_vec();
    let coefficients = result.word.coefficient_vector.coefficients();
    let z = gf4matrix::combine_ambiguity(&construction.z_basis, &coefficients, p.l);
    let source_diff = gf4matrix::source_difference(&construction.gsrc, &z);
    let source_nonzero = source_diff.iter().filter(|q| !q.is_zero()).count();
    assert!(source_nonzero > 0);

    // End-to-end checks through the ordinary vendored encoder and decoder.
    let e2e = validate_end_to_end(K, &bad_esis, &zero_esis, &source_diff);

    let shortening_esis: Vec<u32> = result
        .shortening
        .iter()
        .map(|&i| F64_HONEST_ESIS[i])
        .collect();
    println!("=== Native algorithmic GF(4) f=64 reproduction ===");
    println!(
        "f={F} K={K} n={} honest_rows={} K'={} S={} H={} L={} kappa2={} kappa4={} rank(B4)={full_rank}",
        3 * F + 1,
        F64_HONEST_ESIS.len(),
        p.kprime,
        p.s,
        p.h,
        p.l,
        K.saturating_sub(7 * p.h),
        construction.kappa()
    );
    println!(
        "recorded differential: |T|={} rho={} residual_dim={} exact_min_weight={} zeros={}",
        F64_SHORTENING_ESIS.len(),
        recorded_rank,
        recorded_residual.len(),
        recorded_word.weight,
        recorded_word.values.iter().filter(|q| q.is_zero()).count()
    );
    println!(
        "algorithmic low-rank search: winning_restart={} |T|={} rho={} rank_deficiency={} residual_dim={} N={} Plotkin_bound={}/{}={:.6} contradiction={}",
        plotkin.restart,
        plotkin.shortening.len(),
        plotkin.rank,
        plotkin.shortening.len().saturating_sub(plotkin.rank),
        plotkin.residual_dimension,
        plotkin.shortened_length,
        plotkin.bound_numerator,
        plotkin.bound_denominator,
        plotkin.bound_numerator as f64 / plotkin.bound_denominator as f64,
        plotkin.contradiction,
    );
    println!(
        "algorithmic search: seed={seed} restarts={restarts} winning_restart={} |T|={} rho={} rank_deficiency={} residual_dim={} exact={} enumerated={} min_weight={} zeros={} time={search_seconds:.6}s",
        result.restart,
        result.shortening.len(),
        result.rank,
        result.shortening.len().saturating_sub(result.rank),
        result.residual_basis.len(),
        result.word.exact,
        result.word.enumerated,
        result.word.weight,
        zero_esis.len(),
    );
    println!("honest_ESIs={F64_HONEST_ESIS:?}");
    println!("shortening_ESIs={shortening_esis:?}");
    println!("zero_ESIs={zero_esis:?}");
    println!("bad_fplus1_ESIs={bad_esis:?}");
    println!(
        "source_difference_GF4_codes={:?}",
        source_diff.iter().map(|q| q.code()).collect::<Vec<_>>()
    );
    println!(
        "source_difference_bytes={:?}",
        source_diff.iter().map(|q| q.to_byte()).collect::<Vec<_>>()
    );
    println!("source difference nonzero coordinates: {source_nonzero}/{K}");
    println!(
        "two encodings agree on bad {} ESIs: {}",
        bad_esis.len(),
        e2e.encoder_equal
    );
    println!(
        "two encodings agree on all {} zero ESIs: {}",
        zero_esis.len(),
        e2e.encoder_equal
    );
    println!("decoder on bad set returned None: {}", e2e.decoder_none);
    println!(
        "decoder on all zero ESIs returned None: {}",
        e2e.all_zero_decoder_none
    );
    println!("systematic control succeeds: {}", e2e.control);
    println!("total elapsed: {:.6}s", started.elapsed().as_secs_f64());
    if e2e.encoder_equal && e2e.decoder_none && e2e.all_zero_decoder_none && e2e.control {
        println!("RESULT: NATIVE GF(4) SHORTENING WITNESS CONFIRMED BY REAL DECODER");
    } else {
        eprintln!("RESULT: NATIVE GF(4) F64 CHECK FAILED");
        std::process::exit(1);
    }
}

fn floor_log2(x: usize) -> usize {
    (usize::BITS - 1 - x.leading_zeros()) as usize
}

fn delsarte_status(f: usize, k: usize) -> &'static str {
    if (72..=76).contains(&f) && k == f + 1 {
        "exact_universal_certificate"
    } else {
        "none_recorded"
    }
}

pub fn scan(f_min: usize, f_max: usize, samples: usize, restarts: usize, seed: u64) {
    assert!(f_min <= f_max);
    assert!(samples > 0 && restarts > 0);
    let scan_started = Instant::now();
    let mut csv = String::from(
        "f,K,Kprime,S,H,L,kappa2,kappa4,honest_rows,binary_theorem,delsarte_status,sample,seed,best_T,rho,rank_saving,residual_dimension,shortened_length,plotkin_numerator,plotkin_denominator,plotkin_contradiction,min_weight,exact_enumeration,bad_subset_obtained,encoder_equal,decoder_none,all_zero_decoder_none,control,runtime_seconds,heuristic,honest_ESIs\n",
    );
    let mut json_records = Vec::new();
    let mut total = 0usize;
    let mut plotkin_successes = 0usize;
    let mut explicit_successes = 0usize;

    println!("=== Native GF(4) honest-set scan: f={f_min}..{f_max}, samples={samples}, restarts={restarts}, seed={seed} ===");
    for f in f_min..=f_max {
        let k = f + 1;
        let n = 3 * f + 1;
        let hrows = 2 * f + 1;
        let construction = gf4matrix::construct(k);
        let p = construction.params;
        let kappa4 = construction.kappa();
        let kappa2 = k.saturating_sub(7 * p.h);
        let binary_theorem = k > 7 * p.h + floor_log2(2 * f + 2);
        let mut f_plotkin = 0usize;
        let mut f_explicit = 0usize;
        for sample in 0..samples {
            total += 1;
            let record_seed = seed
                ^ (f as u64).wrapping_mul(0x9e37_79b9)
                ^ (sample as u64).wrapping_mul(0x85eb_ca6b);
            let mut honest_rng = gf4search::Rng::new(record_seed);
            let honest = gf4search::random_subset(&mut honest_rng, n, hrows);
            let b = gf4matrix::induced_matrix(k, &honest, &construction.z_basis);
            let record_started = Instant::now();
            let plotkin = gf4search::search_plotkin(&b, f, restarts, record_seed);

            let mut minimum_weight: Option<usize> = None;
            let mut exact_enumeration = false;
            let mut bad_esis = Vec::new();
            let mut e2e = EndToEnd::default();
            if let Some(candidate) = &plotkin {
                if candidate.contradiction {
                    plotkin_successes += 1;
                    f_plotkin += 1;
                }
                if candidate.residual_dimension <= 8 && candidate.residual_dimension > 0 {
                    let shortening_rows: Vec<_> =
                        candidate.shortening.iter().map(|&i| b[i].clone()).collect();
                    let residual = gf4la::kernel_basis(&shortening_rows, kappa4);
                    let limit = 4usize.pow(residual.len() as u32).saturating_sub(1);
                    let mut enum_rng = gf4search::Rng::new(record_seed ^ 0xa5a5_a5a5);
                    if let Some(word) = gf4search::minimum_word(&b, &residual, limit, &mut enum_rng)
                    {
                        minimum_weight = Some(word.weight);
                        exact_enumeration = word.exact;
                        if word.weight <= f {
                            let zero_esis: Vec<u32> = word
                                .values
                                .iter()
                                .enumerate()
                                .filter_map(|(i, q)| q.is_zero().then_some(honest[i]))
                                .collect();
                            bad_esis = zero_esis[..f + 1].to_vec();
                            let z = gf4matrix::combine_ambiguity(
                                &construction.z_basis,
                                &word.coefficient_vector.coefficients(),
                                p.l,
                            );
                            let source_diff = gf4matrix::source_difference(&construction.gsrc, &z);
                            e2e = validate_end_to_end(k, &bad_esis, &zero_esis, &source_diff);
                            assert!(e2e.encoder_equal && e2e.decoder_none && e2e.control);
                            explicit_successes += 1;
                            f_explicit += 1;
                        }
                    }
                }
            }
            let runtime = record_started.elapsed().as_secs_f64();
            let (
                best_t,
                rho,
                rank_saving,
                residual_dimension,
                shortened_length,
                numerator,
                denominator,
                contradiction,
            ) = plotkin
                .as_ref()
                .map_or((0, 0, 0, 0, hrows, 0, 0, false), |r| {
                    (
                        r.shortening.len(),
                        r.rank,
                        r.shortening.len().saturating_sub(r.rank),
                        r.residual_dimension,
                        r.shortened_length,
                        r.bound_numerator,
                        r.bound_denominator,
                        r.contradiction,
                    )
                });
            let min_weight_csv = minimum_weight.map_or(String::new(), |x| x.to_string());
            let honest_field = honest
                .iter()
                .map(u32::to_string)
                .collect::<Vec<_>>()
                .join(";");
            writeln!(
                csv,
                "{f},{k},{},{},{},{},{kappa2},{kappa4},{hrows},{},{},{sample},{record_seed},{best_t},{rho},{rank_saving},{residual_dimension},{shortened_length},{numerator},{denominator},{},{},{},{},{},{},{},{},{runtime:.9},randomized_greedy_projective_closure+exact_residual_enumeration,\"{}\"",
                p.kprime,
                p.s,
                p.h,
                p.l,
                binary_theorem as u8,
                delsarte_status(f,k),
                contradiction as u8,
                min_weight_csv,
                exact_enumeration as u8,
                (!bad_esis.is_empty()) as u8,
                e2e.encoder_equal as u8,
                e2e.decoder_none as u8,
                e2e.all_zero_decoder_none as u8,
                e2e.control as u8,
                honest_field,
            ).unwrap();
            json_records.push(format!(
                "{{\"f\":{f},\"K\":{k},\"Kprime\":{},\"S\":{},\"H\":{},\"L\":{},\"kappa2\":{kappa2},\"kappa4\":{kappa4},\"honest_rows\":{hrows},\"binary_theorem\":{},\"delsarte_status\":\"{}\",\"sample\":{sample},\"seed\":{record_seed},\"best_T\":{best_t},\"rho\":{rho},\"rank_saving\":{rank_saving},\"residual_dimension\":{residual_dimension},\"shortened_length\":{shortened_length},\"plotkin_numerator\":{numerator},\"plotkin_denominator\":{denominator},\"plotkin_contradiction\":{},\"min_weight\":{},\"exact_enumeration\":{},\"bad_subset_obtained\":{},\"encoder_equal\":{},\"decoder_none\":{},\"all_zero_decoder_none\":{},\"control\":{},\"runtime_seconds\":{runtime:.9},\"heuristic\":\"randomized_greedy_projective_closure+exact_residual_enumeration\",\"honest_ESIs\":{:?}}}",
                p.kprime,p.s,p.h,p.l,binary_theorem,delsarte_status(f,k),contradiction,
                minimum_weight.map_or("null".to_string(), |x| x.to_string()),exact_enumeration,
                !bad_esis.is_empty(),e2e.encoder_equal,e2e.decoder_none,e2e.all_zero_decoder_none,e2e.control,honest
            ));
        }
        println!(
            "f={f:>2} K={k:>2} K'={:>3} H={} kappa2={kappa2:>2} kappa4={kappa4:>2}: Plotkin {f_plotkin}/{samples}, explicit+E2E {f_explicit}/{samples}",
            p.kprime, p.h
        );
    }

    let out_dir = results_dir();
    std::fs::create_dir_all(&out_dir).expect("create results directory");
    let stem = format!("gf4_scan_f{f_min}_{f_max}_s{samples}_r{restarts}_seed{seed}");
    let csv_path = out_dir.join(format!("{stem}.csv"));
    let json_path = out_dir.join(format!("{stem}.json"));
    std::fs::write(&csv_path, csv).expect("write scan CSV");
    std::fs::write(&json_path, format!("[\n{}\n]\n", json_records.join(",\n")))
        .expect("write scan JSON");
    println!("scan records={total}; Plotkin successes={plotkin_successes}; explicit end-to-end successes={explicit_successes}");
    println!("CSV: {}", csv_path.display());
    println!("JSON: {}", json_path.display());
    println!("elapsed: {:.3}s", scan_started.elapsed().as_secs_f64());
    println!("RESULT: GF(4) HEURISTIC SCAN COMPLETE (failures are not nonexistence results)");
}
