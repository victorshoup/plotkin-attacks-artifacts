//! Dense fixed-f source-dimension/overhead experiments.
//!
//! This keeps the original K=f+1 scanner unchanged while making K and Delta first-class
//! axes, computing both ambiguity dimensions natively, and recording per-stage timings.

use std::collections::BTreeMap;
use std::fmt::Write as _;
use std::path::PathBuf;
use std::time::Instant;

use raptorq::{
    EncodingPacket, ObjectTransmissionInformation, SourceBlockDecoder, SourceBlockEncoder,
};

use crate::gf4::Gf4;
use crate::gf4la::{self, Row};
use crate::gf4matrix::{self, Construction};
use crate::gf4search::{self, MinimumWord, PlotkinResult, Rng, SearchResult};
use crate::rqmatrix;

const SYMBOL_BYTES: usize = 8;
const EXACT_DIMENSION_LIMIT: usize = 8;
const WILSON_Z_95: f64 = 1.959_963_984_540_054;
pub const RAPTORQ_ESI_DOMAIN_SIZE: u32 = 1 << 24;
pub const RAPTORQ_MAX_ESI: u32 = RAPTORQ_ESI_DOMAIN_SIZE - 1;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EsiSampler {
    Consecutive,
    RandomEsi,
    StratifiedRandomEsi,
}

impl EsiSampler {
    pub fn parse(value: &str) -> Self {
        match value {
            "consecutive" => Self::Consecutive,
            "random-esi" => Self::RandomEsi,
            "stratified-random-esi" => Self::StratifiedRandomEsi,
            _ => panic!(
                "unknown --sampler {value:?}; expected consecutive, random-esi, or stratified-random-esi"
            ),
        }
    }

    fn name(self) -> &'static str {
        match self {
            Self::Consecutive => "consecutive",
            Self::RandomEsi => "random-esi",
            Self::StratifiedRandomEsi => "stratified-random-esi",
        }
    }

    fn file_tag(self) -> &'static str {
        match self {
            Self::Consecutive => "consecutive",
            Self::RandomEsi => "random_esi_full_24bit",
            Self::StratifiedRandomEsi => "stratified_random_esi_full_24bit",
        }
    }
}

#[derive(Clone, Copy, Default)]
struct EndToEnd {
    source_distinct: bool,
    encoder_equal_bad: bool,
    encoder_equal_all_zero: bool,
    decoder_none_bad: bool,
    decoder_none_all_zero: bool,
    control: bool,
}

impl EndToEnd {
    fn passed(self) -> bool {
        self.source_distinct
            && self.encoder_equal_bad
            && self.encoder_equal_all_zero
            && self.decoder_none_bad
            && self.decoder_none_all_zero
            && self.control
    }
}

#[derive(Clone, Copy)]
struct ConstructionTimes {
    binary_dimension: f64,
    constraints: f64,
    basis: f64,
    source_rows: f64,
}

impl ConstructionTimes {
    fn matrix(self) -> f64 {
        self.constraints + self.basis + self.source_rows
    }
}

struct BuiltK {
    construction: Construction,
    kappa2: usize,
    times: ConstructionTimes,
}

#[derive(Clone)]
struct InstanceResult {
    f: usize,
    n: usize,
    h: usize,
    k: usize,
    delta: usize,
    kprime: usize,
    s: usize,
    hdpc: usize,
    l: usize,
    kappa2: usize,
    kappa4: usize,
    binary_universal: bool,
    binary_plotkin_actual_kappa2: bool,
    binary_randomized: bool,
    exact_gf4_bound_status: &'static str,
    sampler: &'static str,
    esi_domain_size: u32,
    esi_domain_min: u32,
    esi_domain_max: u32,
    honest_esi_min: u32,
    honest_esi_max: u32,
    honest_esi_median: u32,
    systematic_count: usize,
    repair_count: usize,
    contains_esi0: bool,
    contains_any_systematic: bool,
    sample: usize,
    honest_set_seed: u64,
    search_seed: u64,
    restart_budget: usize,
    restarts_executed: usize,
    early_stop_on_explicit_witness: bool,
    first_plotkin_restart: Option<usize>,
    first_explicit_restart: Option<usize>,
    selected_restart: Option<usize>,
    rank_b4: usize,
    shortening_cardinality: usize,
    shortening_rank: usize,
    rank_saving: usize,
    residual_dimension: usize,
    shortened_length: usize,
    plotkin_contradiction: bool,
    selected_plotkin_contradiction: bool,
    exact_enumeration_performed: bool,
    minimum_word_weight: Option<usize>,
    number_zero_esis: Option<usize>,
    source_difference_weight: Option<usize>,
    explicit_witness: bool,
    e2e: EndToEnd,
    binary_dimension_time: f64,
    constraint_time: f64,
    basis_time: f64,
    source_rows_time: f64,
    matrix_time: f64,
    b4_time: f64,
    search_time: f64,
    enumeration_time: f64,
    source_difference_time: f64,
    replay_time: f64,
    total_time: f64,
    algorithm: &'static str,
    honest_esis: Vec<u32>,
    shortening_esis: Vec<u32>,
    zero_esis: Vec<u32>,
    bad_esis: Vec<u32>,
}

fn results_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../results")
}

fn floor_log2(x: usize) -> usize {
    (usize::BITS - 1 - x.leading_zeros()) as usize
}

fn ceil_log2(x: usize) -> usize {
    if x <= 1 {
        0
    } else {
        (usize::BITS - (x - 1).leading_zeros()) as usize
    }
}

fn build_k(k: usize) -> BuiltK {
    let binary_started = Instant::now();
    let (binary_params, kappa2, _, _) = rqmatrix::ambiguity_dim(k);
    let binary_dimension = binary_started.elapsed().as_secs_f64();

    let constraints_started = Instant::now();
    let (params, constraints) = gf4matrix::constraints(k);
    let constraints_time = constraints_started.elapsed().as_secs_f64();
    assert_eq!(params.kprime, binary_params.kprime);
    assert_eq!(params.h, binary_params.h);

    let basis_started = Instant::now();
    let z_basis = gf4la::kernel_basis(&constraints, params.l);
    let basis_time = basis_started.elapsed().as_secs_f64();

    let source_rows_started = Instant::now();
    let source_esis: Vec<u32> = (0..k as u32).collect();
    let gsrc = rqmatrix::honest_rows(k, &source_esis);
    let source_rows_time = source_rows_started.elapsed().as_secs_f64();

    BuiltK {
        construction: Construction {
            params,
            z_basis,
            gsrc,
        },
        kappa2,
        times: ConstructionTimes {
            binary_dimension,
            constraints: constraints_time,
            basis: basis_time,
            source_rows: source_rows_time,
        },
    }
}

fn identity_basis(n: usize) -> Vec<Row> {
    (0..n)
        .map(|i| {
            let mut row = Row::zero(n);
            row.set(i, Gf4::ONE);
            row
        })
        .collect()
}

fn plotkin_score(r: &PlotkinResult) -> (bool, usize, usize, usize, std::cmp::Reverse<usize>) {
    (
        r.contradiction,
        r.shortening.len().saturating_sub(r.rank),
        r.residual_dimension,
        r.shortening.len(),
        std::cmp::Reverse(r.rank),
    )
}

fn word_score(
    candidate: &SearchResult,
    target_weight: usize,
) -> (
    bool,
    std::cmp::Reverse<usize>,
    usize,
    std::cmp::Reverse<usize>,
) {
    (
        candidate.word.weight <= target_weight,
        std::cmp::Reverse(candidate.word.weight),
        candidate.shortening.len().saturating_sub(candidate.rank),
        std::cmp::Reverse(candidate.rank),
    )
}

fn packet_for(enc: &SourceBlockEncoder, esi: u32, k: usize) -> EncodingPacket {
    if (esi as usize) < k {
        enc.source_packets()[esi as usize].clone()
    } else {
        enc.repair_packets(esi - k as u32, 1).pop().unwrap()
    }
}

fn packets_for(enc: &SourceBlockEncoder, esis: &[u32], k: usize) -> Vec<EncodingPacket> {
    esis.iter().map(|&esi| packet_for(enc, esi, k)).collect()
}

fn validate_end_to_end(
    k: usize,
    required_subset_size: usize,
    bad_esis: &[u32],
    zero_esis: &[u32],
    source_diff: &[Gf4],
) -> EndToEnd {
    let config =
        ObjectTransmissionInformation::new((k * SYMBOL_BYTES) as u64, SYMBOL_BYTES as u16, 1, 1, 1);
    let mut source = vec![0u8; k * SYMBOL_BYTES];
    for (i, byte) in source.iter_mut().enumerate() {
        *byte = ((i as u64 * 131 + 17) & 0xff) as u8;
    }
    let mut source2 = source.clone();
    for (i, q) in source_diff.iter().enumerate() {
        source2[i * SYMBOL_BYTES] ^= q.to_byte();
    }
    let source_distinct = source != source2;
    let encoder = SourceBlockEncoder::new(0, &config, &source);
    let encoder2 = SourceBlockEncoder::new(0, &config, &source2);
    let encoder_equal_bad = bad_esis
        .iter()
        .all(|&esi| packet_for(&encoder, esi, k).data() == packet_for(&encoder2, esi, k).data());
    let encoder_equal_all_zero = zero_esis
        .iter()
        .all(|&esi| packet_for(&encoder, esi, k).data() == packet_for(&encoder2, esi, k).data());
    let decoder_none_bad = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, bad_esis, k))
        .is_none();
    let decoder_none_all_zero = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, zero_esis, k))
        .is_none();

    // For K<required_subset_size, only ESIs 0..K-1 are systematic. The control therefore
    // uses `required_subset_size` packets beginning at ESI 0: all K systematic packets plus
    // the required number of repair packets. This is the meaningful 65-packet control.
    let control_esis: Vec<u32> = (0..required_subset_size as u32).collect();
    let control = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
        .decode(packets_for(&encoder, &control_esis, k))
        .as_deref()
        == Some(source.as_slice());
    EndToEnd {
        source_distinct,
        encoder_equal_bad,
        encoder_equal_all_zero,
        decoder_none_bad,
        decoder_none_all_zero,
        control,
    }
}

fn run_instance(
    f: usize,
    k: usize,
    sample: usize,
    restarts: usize,
    master_seed: u64,
    built: &BuiltK,
    sampler: EsiSampler,
    stop_after_first_witness: bool,
) -> InstanceResult {
    let operational_started = Instant::now();
    let n = 3 * f + 1;
    let h = 2 * f + 1;
    let required_subset_size = f + 1;
    let delta = required_subset_size - k;
    let p = built.construction.params;
    let kappa4 = built.construction.kappa();
    let binary_floor = floor_log2(2 * f + 2);
    let binary_randomized_bits = ceil_log2(4 * f + 4);
    let binary_universal = k > 7 * p.h + binary_floor;
    let binary_plotkin_actual_kappa2 = built.kappa2 > binary_floor;
    let binary_randomized = k >= 7 * p.h + binary_randomized_bits;
    let honest_set_seed = master_seed
        ^ (k as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15)
        ^ (sample as u64).wrapping_mul(0x85eb_ca6b_27d4_eb2f);
    let search_seed = master_seed.rotate_left(17)
        ^ (k as u64).wrapping_mul(0xc2b2_ae35_87b7_3a21)
        ^ (sample as u64).wrapping_mul(0x1656_67b1_9e37_79f9);
    let mut honest_rng = Rng::new(honest_set_seed);
    // Keep the original sampler and its RNG behavior unchanged. The full-domain mode uses
    // an O(h)-memory uniform sampler and canonicalizes the set in ascending ESI order before
    // matrix construction, exactly as the original path does.
    let honest_esis = match sampler {
        EsiSampler::Consecutive => gf4search::random_subset(&mut honest_rng, n, h),
        EsiSampler::RandomEsi => {
            gf4search::random_subset_u32(&mut honest_rng, RAPTORQ_ESI_DOMAIN_SIZE, h)
        }
        EsiSampler::StratifiedRandomEsi => {
            // Pair each set with the systematic count produced by the legacy sampler, then
            // sample uniformly within the systematic and repair strata of the full domain.
            let baseline = gf4search::random_subset(&mut honest_rng, n, h);
            let systematic = baseline.iter().filter(|&&esi| esi < k as u32).count();
            let mut esis = gf4search::random_subset_u32(&mut honest_rng, k as u32, systematic);
            esis.extend(
                gf4search::random_subset_u32(
                    &mut honest_rng,
                    RAPTORQ_ESI_DOMAIN_SIZE - k as u32,
                    h - systematic,
                )
                .into_iter()
                .map(|relative| relative + k as u32),
            );
            esis.sort_unstable();
            esis
        }
    };
    assert_eq!(honest_esis.len(), h);
    assert!(honest_esis.windows(2).all(|pair| pair[0] < pair[1]));
    let esi_domain_size = match sampler {
        EsiSampler::Consecutive => n as u32,
        EsiSampler::RandomEsi => RAPTORQ_ESI_DOMAIN_SIZE,
        EsiSampler::StratifiedRandomEsi => RAPTORQ_ESI_DOMAIN_SIZE,
    };
    let systematic_count = honest_esis.iter().filter(|&&esi| esi < k as u32).count();
    let honest_esi_min = honest_esis[0];
    let honest_esi_max = *honest_esis.last().unwrap();
    let honest_esi_median = honest_esis[h / 2];

    let b4_started = Instant::now();
    let b4 = gf4matrix::induced_matrix(k, &honest_esis, &built.construction.z_basis);
    let rank_b4 = gf4la::rank(&b4, kappa4);
    let b4_time = b4_started.elapsed().as_secs_f64();

    let mut search_time = 0.0;
    let mut enumeration_time = 0.0;
    let mut first_plotkin_restart = None;
    let mut first_explicit_restart = None;
    let mut best_plotkin: Option<PlotkinResult> = None;
    let mut best_word: Option<SearchResult> = None;
    let mut direct_word: Option<MinimumWord> = None;
    let mut plotkin_contradiction = false;
    let mut restarts_executed = 0;
    let algorithm;

    if kappa4 > 0 && kappa4 <= EXACT_DIMENSION_LIMIT {
        algorithm = "direct_full_space_exact_enumeration";
        let enumeration_started = Instant::now();
        let basis = identity_basis(kappa4);
        let mut rng = Rng::new(search_seed);
        let limit = 4usize.pow(kappa4 as u32).saturating_sub(1);
        direct_word = gf4search::minimum_word(&b4, &basis, limit, &mut rng);
        enumeration_time += enumeration_started.elapsed().as_secs_f64();
        if direct_word.as_ref().is_some_and(|word| word.weight <= f) {
            first_explicit_restart = Some(0);
        }
    } else if kappa4 > 0 {
        algorithm = "randomized_greedy_projective_closure+exact_residual_enumeration";
        for restart in 0..restarts {
            restarts_executed = restart + 1;
            let search_started = Instant::now();
            let mut rng = Rng::new(search_seed.wrapping_add(restart as u64));
            let stages =
                gf4search::greedy_path(&b4, kappa4.saturating_sub(1), &mut rng, restart != 0);
            let plotkin_candidate =
                gf4search::best_plotkin_for_stages(&b4, f, stages.clone(), restart);
            search_time += search_started.elapsed().as_secs_f64();
            if let Some(candidate) = plotkin_candidate {
                if candidate.contradiction {
                    plotkin_contradiction = true;
                    first_plotkin_restart.get_or_insert(restart + 1);
                }
                if best_plotkin
                    .as_ref()
                    .is_none_or(|old| plotkin_score(&candidate) > plotkin_score(old))
                {
                    best_plotkin = Some(candidate);
                }
            }

            let enumeration_started = Instant::now();
            let word_candidate = gf4search::best_explicit_for_stages(
                &b4,
                f,
                stages,
                restart,
                EXACT_DIMENSION_LIMIT,
                &mut rng,
            );
            enumeration_time += enumeration_started.elapsed().as_secs_f64();
            if let Some(candidate) = word_candidate {
                if candidate.word.weight <= f {
                    first_explicit_restart.get_or_insert(restart + 1);
                }
                if best_word
                    .as_ref()
                    .is_none_or(|old| word_score(&candidate, f) > word_score(old, f))
                {
                    best_word = Some(candidate);
                }
            }
            if stop_after_first_witness && first_explicit_restart.is_some() {
                break;
            }
        }
    } else {
        algorithm = "kappa4_zero";
    }

    let selected_explicit = best_word.as_ref();
    let selected_plotkin = best_plotkin.clone();
    let selected_word = selected_explicit
        .map(|candidate| candidate.word.clone())
        .or(direct_word);
    let minimum_word_weight = selected_word.as_ref().map(|word| word.weight);
    let explicit_witness = minimum_word_weight.is_some_and(|weight| weight <= f);
    let zero_esis: Vec<u32> = if explicit_witness {
        selected_word
            .as_ref()
            .unwrap()
            .values
            .iter()
            .enumerate()
            .filter_map(|(i, q)| q.is_zero().then_some(honest_esis[i]))
            .collect()
    } else {
        Vec::new()
    };
    let bad_esis = if explicit_witness {
        zero_esis[..required_subset_size].to_vec()
    } else {
        Vec::new()
    };
    let shortening_indices = selected_explicit
        .map(|candidate| candidate.shortening.clone())
        .or_else(|| {
            selected_plotkin
                .as_ref()
                .map(|candidate| candidate.shortening.clone())
        })
        .unwrap_or_default();
    let shortening_esis: Vec<u32> = shortening_indices
        .iter()
        .map(|&index| honest_esis[index])
        .collect();
    let shortening_cardinality = shortening_indices.len();
    let shortening_rank = selected_explicit
        .map(|candidate| candidate.rank)
        .or_else(|| selected_plotkin.as_ref().map(|candidate| candidate.rank))
        .unwrap_or(0);
    let residual_dimension = selected_explicit
        .map(|candidate| candidate.residual_basis.len())
        .or_else(|| {
            selected_plotkin
                .as_ref()
                .map(|candidate| candidate.residual_dimension)
        })
        .unwrap_or(kappa4);
    let shortened_length = selected_explicit
        .map(|candidate| h - candidate.shortening.len())
        .or_else(|| {
            selected_plotkin
                .as_ref()
                .map(|candidate| candidate.shortened_length)
        })
        .unwrap_or(h);
    let selected_shortening_plotkin_contradiction = selected_explicit.map_or_else(
        || {
            selected_plotkin
                .as_ref()
                .is_some_and(|candidate| candidate.contradiction)
        },
        |candidate| {
            let denominator = 4 * (f + 1) as isize - 3 * shortened_length as isize;
            denominator > 0
                && 4u128.pow(candidate.residual_basis.len() as u32) * denominator as u128
                    > (4 * (f + 1)) as u128
        },
    );

    let mut source_difference_time = 0.0;
    let mut replay_time = 0.0;
    let mut source_difference_weight = None;
    let mut e2e = EndToEnd::default();
    if explicit_witness {
        let source_started = Instant::now();
        let coefficient_vector = &selected_word.as_ref().unwrap().coefficient_vector;
        let z = gf4matrix::combine_ambiguity(
            &built.construction.z_basis,
            &coefficient_vector.coefficients(),
            p.l,
        );
        let source_diff = gf4matrix::source_difference(&built.construction.gsrc, &z);
        source_difference_weight = Some(source_diff.iter().filter(|q| !q.is_zero()).count());
        source_difference_time = source_started.elapsed().as_secs_f64();
        assert!(source_difference_weight.unwrap() > 0);

        let replay_started = Instant::now();
        e2e = validate_end_to_end(k, required_subset_size, &bad_esis, &zero_esis, &source_diff);
        replay_time = replay_started.elapsed().as_secs_f64();
        assert!(
            e2e.passed(),
            "end-to-end check failed for f={f}, K={k}, sample={sample}"
        );
    }

    let operational_time = operational_started.elapsed().as_secs_f64();
    let total_time = built.times.binary_dimension + built.times.matrix() + operational_time;
    InstanceResult {
        f,
        n,
        h,
        k,
        delta,
        kprime: p.kprime,
        s: p.s,
        hdpc: p.h,
        l: p.l,
        kappa2: built.kappa2,
        kappa4,
        binary_universal,
        binary_plotkin_actual_kappa2,
        binary_randomized,
        exact_gf4_bound_status: "none_available_for_f64",
        sampler: sampler.name(),
        esi_domain_size,
        esi_domain_min: 0,
        esi_domain_max: match sampler {
            EsiSampler::Consecutive => esi_domain_size - 1,
            EsiSampler::RandomEsi => RAPTORQ_MAX_ESI,
            EsiSampler::StratifiedRandomEsi => RAPTORQ_MAX_ESI,
        },
        honest_esi_min,
        honest_esi_max,
        honest_esi_median,
        systematic_count,
        repair_count: h - systematic_count,
        contains_esi0: honest_esis.binary_search(&0).is_ok(),
        contains_any_systematic: systematic_count > 0,
        sample,
        honest_set_seed,
        search_seed,
        restart_budget: restarts,
        restarts_executed,
        early_stop_on_explicit_witness: stop_after_first_witness,
        first_plotkin_restart,
        first_explicit_restart,
        selected_restart: selected_explicit
            .map(|candidate| candidate.restart + 1)
            .or_else(|| {
                selected_plotkin
                    .as_ref()
                    .map(|candidate| candidate.restart + 1)
            }),
        rank_b4,
        shortening_cardinality,
        shortening_rank,
        rank_saving: shortening_cardinality.saturating_sub(shortening_rank),
        residual_dimension,
        shortened_length,
        plotkin_contradiction,
        selected_plotkin_contradiction: selected_shortening_plotkin_contradiction,
        exact_enumeration_performed: selected_word.as_ref().is_some_and(|word| word.exact),
        minimum_word_weight,
        number_zero_esis: explicit_witness.then_some(zero_esis.len()),
        source_difference_weight,
        explicit_witness,
        e2e,
        binary_dimension_time: built.times.binary_dimension,
        constraint_time: built.times.constraints,
        basis_time: built.times.basis,
        source_rows_time: built.times.source_rows,
        matrix_time: built.times.matrix(),
        b4_time,
        search_time,
        enumeration_time,
        source_difference_time,
        replay_time,
        total_time,
        algorithm,
        honest_esis,
        shortening_esis,
        zero_esis,
        bad_esis,
    }
}

fn csv_opt(value: Option<usize>) -> String {
    value.map_or(String::new(), |value| value.to_string())
}

fn json_opt(value: Option<usize>) -> String {
    value.map_or("null".to_string(), |value| value.to_string())
}

fn semicolon(values: &[u32]) -> String {
    values
        .iter()
        .map(u32::to_string)
        .collect::<Vec<_>>()
        .join(";")
}

fn write_instance_outputs(path_stem: &PathBuf, records: &[InstanceResult]) {
    let mut csv = String::from(
        "f,n,h,K,Delta,Kprime,S,H_HDPC,L,kappa2,kappa4,binary_universal,binary_plotkin_actual_kappa2,binary_randomized,exact_gf4_bound_status,sampler,esi_domain_size,esi_domain_min,esi_domain_max,honest_esi_min,honest_esi_max,honest_esi_median,systematic_count,repair_count,contains_ESI_0,contains_any_systematic,sample,honest_set_seed,search_seed,restart_budget,restarts_executed,early_stop_on_explicit_witness,first_plotkin_restart,first_explicit_witness_restart,selected_restart,rank_B4,shortening_cardinality,shortening_rank,rank_saving,residual_dimension,shortened_length,plotkin_contradiction,selected_shortening_plotkin_contradiction,exact_enumeration_performed,minimum_word_weight,number_of_zero_honest_ESIs,source_difference_weight,explicit_witness,source_blocks_distinct,encoder_equality_bad_subset,encoder_equality_all_zero,bad_subset_decoder_none,full_zero_set_decoder_none,systematic_control_check,binary_dimension_time,constraint_construction_time,basis_construction_time,source_rows_construction_time,matrix_construction_time,B4_construction_time,shortening_search_time,residual_enumeration_time,source_difference_time,encoder_decoder_replay_time,total_wall_clock_time,algorithm,honest_ESIs,shortening_ESIs,zero_ESIs,bad_ESIs\n",
    );
    let mut json = Vec::new();
    for r in records {
        writeln!(
            csv,
            "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9},{},\"{}\",\"{}\",\"{}\",\"{}\"",
            r.f,r.n,r.h,r.k,r.delta,r.kprime,r.s,r.hdpc,r.l,r.kappa2,r.kappa4,
            r.binary_universal as u8,r.binary_plotkin_actual_kappa2 as u8,r.binary_randomized as u8,
            r.exact_gf4_bound_status,r.sampler,r.esi_domain_size,r.esi_domain_min,r.esi_domain_max,
            r.honest_esi_min,r.honest_esi_max,r.honest_esi_median,r.systematic_count,r.repair_count,
            r.contains_esi0 as u8,r.contains_any_systematic as u8,r.sample,r.honest_set_seed,r.search_seed,r.restart_budget,
            r.restarts_executed,r.early_stop_on_explicit_witness as u8,
            csv_opt(r.first_plotkin_restart),csv_opt(r.first_explicit_restart),csv_opt(r.selected_restart),
            r.rank_b4,r.shortening_cardinality,r.shortening_rank,r.rank_saving,r.residual_dimension,
            r.shortened_length,r.plotkin_contradiction as u8,r.selected_plotkin_contradiction as u8,
            r.exact_enumeration_performed as u8,csv_opt(r.minimum_word_weight),csv_opt(r.number_zero_esis),
            csv_opt(r.source_difference_weight),r.explicit_witness as u8,r.e2e.source_distinct as u8,
            r.e2e.encoder_equal_bad as u8,r.e2e.encoder_equal_all_zero as u8,
            r.e2e.decoder_none_bad as u8,r.e2e.decoder_none_all_zero as u8,r.e2e.control as u8,
            r.binary_dimension_time,r.constraint_time,r.basis_time,r.source_rows_time,r.matrix_time,
            r.b4_time,r.search_time,r.enumeration_time,r.source_difference_time,r.replay_time,r.total_time,
            r.algorithm,semicolon(&r.honest_esis),semicolon(&r.shortening_esis),semicolon(&r.zero_esis),
            semicolon(&r.bad_esis),
        ).unwrap();
        json.push(format!(
            "{{\"f\":{},\"n\":{},\"h\":{},\"K\":{},\"Delta\":{},\"Kprime\":{},\"S\":{},\"H_HDPC\":{},\"L\":{},\"kappa2\":{},\"kappa4\":{},\"binary_universal\":{},\"binary_plotkin_actual_kappa2\":{},\"binary_randomized\":{},\"exact_gf4_bound_status\":\"{}\",\"sampler\":\"{}\",\"esi_domain_size\":{},\"esi_domain_min\":{},\"esi_domain_max\":{},\"honest_esi_min\":{},\"honest_esi_max\":{},\"honest_esi_median\":{},\"systematic_count\":{},\"repair_count\":{},\"contains_ESI_0\":{},\"contains_any_systematic\":{},\"sample\":{},\"honest_set_seed\":{},\"search_seed\":{},\"restart_budget\":{},\"restarts_executed\":{},\"early_stop_on_explicit_witness\":{},\"first_plotkin_restart\":{},\"first_explicit_witness_restart\":{},\"selected_restart\":{},\"rank_B4\":{},\"shortening_cardinality\":{},\"shortening_rank\":{},\"rank_saving\":{},\"residual_dimension\":{},\"shortened_length\":{},\"plotkin_contradiction\":{},\"selected_shortening_plotkin_contradiction\":{},\"exact_enumeration_performed\":{},\"minimum_word_weight\":{},\"number_of_zero_honest_ESIs\":{},\"source_difference_weight\":{},\"explicit_witness\":{},\"source_blocks_distinct\":{},\"encoder_equality_bad_subset\":{},\"encoder_equality_all_zero\":{},\"bad_subset_decoder_none\":{},\"full_zero_set_decoder_none\":{},\"systematic_control_check\":{},\"binary_dimension_time\":{:.9},\"constraint_construction_time\":{:.9},\"basis_construction_time\":{:.9},\"source_rows_construction_time\":{:.9},\"matrix_construction_time\":{:.9},\"B4_construction_time\":{:.9},\"shortening_search_time\":{:.9},\"residual_enumeration_time\":{:.9},\"source_difference_time\":{:.9},\"encoder_decoder_replay_time\":{:.9},\"total_wall_clock_time\":{:.9},\"algorithm\":\"{}\",\"honest_ESIs\":{:?},\"shortening_ESIs\":{:?},\"zero_ESIs\":{:?},\"bad_ESIs\":{:?}}}",
            r.f,r.n,r.h,r.k,r.delta,r.kprime,r.s,r.hdpc,r.l,r.kappa2,r.kappa4,
            r.binary_universal,r.binary_plotkin_actual_kappa2,r.binary_randomized,
            r.exact_gf4_bound_status,r.sampler,r.esi_domain_size,r.esi_domain_min,r.esi_domain_max,
            r.honest_esi_min,r.honest_esi_max,r.honest_esi_median,r.systematic_count,r.repair_count,
            r.contains_esi0,r.contains_any_systematic,r.sample,r.honest_set_seed,r.search_seed,r.restart_budget,
            r.restarts_executed,r.early_stop_on_explicit_witness,
            json_opt(r.first_plotkin_restart),json_opt(r.first_explicit_restart),json_opt(r.selected_restart),
            r.rank_b4,r.shortening_cardinality,r.shortening_rank,r.rank_saving,r.residual_dimension,
            r.shortened_length,r.plotkin_contradiction,r.selected_plotkin_contradiction,
            r.exact_enumeration_performed,json_opt(r.minimum_word_weight),json_opt(r.number_zero_esis),
            json_opt(r.source_difference_weight),r.explicit_witness,r.e2e.source_distinct,
            r.e2e.encoder_equal_bad,r.e2e.encoder_equal_all_zero,r.e2e.decoder_none_bad,
            r.e2e.decoder_none_all_zero,r.e2e.control,r.binary_dimension_time,r.constraint_time,
            r.basis_time,r.source_rows_time,r.matrix_time,r.b4_time,r.search_time,r.enumeration_time,
            r.source_difference_time,r.replay_time,r.total_time,r.algorithm,r.honest_esis,
            r.shortening_esis,r.zero_esis,r.bad_esis,
        ));
    }
    std::fs::write(path_stem.with_extension("csv"), csv).expect("write overhead instance CSV");
    std::fs::write(
        path_stem.with_extension("json"),
        format!("[\n{}\n]\n", json.join(",\n")),
    )
    .expect("write overhead instance JSON");
}

fn wilson(successes: usize, samples: usize) -> (f64, f64) {
    if samples == 0 {
        return (f64::NAN, f64::NAN);
    }
    let n = samples as f64;
    let p = successes as f64 / n;
    let z2 = WILSON_Z_95 * WILSON_Z_95;
    let denominator = 1.0 + z2 / n;
    let center = (p + z2 / (2.0 * n)) / denominator;
    let half = WILSON_Z_95 * (p * (1.0 - p) / n + z2 / (4.0 * n * n)).sqrt() / denominator;
    ((center - half).max(0.0), (center + half).min(1.0))
}

fn median_usize(values: &[usize]) -> Option<f64> {
    if values.is_empty() {
        return None;
    }
    let mut sorted = values.to_vec();
    sorted.sort_unstable();
    let middle = sorted.len() / 2;
    Some(if sorted.len() % 2 == 1 {
        sorted[middle] as f64
    } else {
        (sorted[middle - 1] + sorted[middle]) as f64 / 2.0
    })
}

fn median_f64(values: &[f64]) -> f64 {
    let mut sorted = values.to_vec();
    sorted.sort_by(|a, b| a.total_cmp(b));
    let middle = sorted.len() / 2;
    if sorted.len() % 2 == 1 {
        sorted[middle]
    } else {
        (sorted[middle - 1] + sorted[middle]) / 2.0
    }
}

fn p95(values: &[f64]) -> f64 {
    let mut sorted = values.to_vec();
    sorted.sort_by(|a, b| a.total_cmp(b));
    let index = ((0.95 * sorted.len() as f64).ceil() as usize).saturating_sub(1);
    sorted[index]
}

fn distribution(values: &[usize]) -> String {
    let mut counts = BTreeMap::new();
    for &value in values {
        *counts.entry(value).or_insert(0usize) += 1;
    }
    counts
        .into_iter()
        .map(|(value, count)| format!("{value}:{count}"))
        .collect::<Vec<_>>()
        .join(";")
}

fn range(values: &[usize]) -> (Option<usize>, Option<usize>) {
    (values.iter().min().copied(), values.iter().max().copied())
}

fn write_aggregate_outputs(path_stem: &PathBuf, records: &[InstanceResult]) {
    let mut groups: BTreeMap<(usize, usize), Vec<&InstanceResult>> = BTreeMap::new();
    for record in records {
        groups.entry((record.f, record.k)).or_default().push(record);
    }
    let mut csv = String::from(
        "f,K,Delta,Kprime,S,H_HDPC,L,kappa2,kappa4,binary_universal,binary_plotkin_actual_kappa2,binary_randomized,exact_gf4_bound_status,samples,plotkin_successes,plotkin_fraction,plotkin_wilson95_low,plotkin_wilson95_high,explicit_successes,explicit_fraction,explicit_wilson95_low,explicit_wilson95_high,e2e_successes,e2e_fraction,e2e_wilson95_low,e2e_wilson95_high,T_median,T_min,T_max,rho_median,rho_min,rho_max,rank_saving_median,rank_saving_min,rank_saving_max,residual_dimension_distribution,minimum_weight_distribution,minimum_weight_median,minimum_weight_min,minimum_weight_max,zero_coordinate_distribution,zero_median,zero_min,zero_max,search_time_median,search_time_p95,search_time_max,total_time_median,total_time_p95,total_time_max\n",
    );
    let mut json = Vec::new();
    println!("K  Delta K' S  H k2 k4  Plotkin   explicit   E2E     Wilson95(E2E)");
    for ((_f, _k), group) in groups.iter().rev() {
        let first = group[0];
        let samples = group.len();
        let plotkin = group
            .iter()
            .filter(|record| record.plotkin_contradiction)
            .count();
        let explicit = group
            .iter()
            .filter(|record| record.explicit_witness)
            .count();
        let e2e = group.iter().filter(|record| record.e2e.passed()).count();
        let plotkin_ci = wilson(plotkin, samples);
        let explicit_ci = wilson(explicit, samples);
        let e2e_ci = wilson(e2e, samples);
        let ts: Vec<usize> = group
            .iter()
            .map(|record| record.shortening_cardinality)
            .collect();
        let rhos: Vec<usize> = group.iter().map(|record| record.shortening_rank).collect();
        let savings: Vec<usize> = group.iter().map(|record| record.rank_saving).collect();
        let residuals: Vec<usize> = group
            .iter()
            .map(|record| record.residual_dimension)
            .collect();
        let weights: Vec<usize> = group
            .iter()
            .filter_map(|record| record.minimum_word_weight)
            .collect();
        let zeros: Vec<usize> = group
            .iter()
            .filter_map(|record| record.number_zero_esis)
            .collect();
        let search_times: Vec<f64> = group.iter().map(|record| record.search_time).collect();
        let total_times: Vec<f64> = group.iter().map(|record| record.total_time).collect();
        let (tmin, tmax) = range(&ts);
        let (rhomin, rhomax) = range(&rhos);
        let (saving_min, saving_max) = range(&savings);
        let (weight_min, weight_max) = range(&weights);
        let (zero_min, zero_max) = range(&zeros);
        println!(
            "{:>2} {:>5} {:>3} {:>2} {:>2} {:>2} {:>2}  {:>3}/{:<3}   {:>3}/{:<3}   {:>3}/{:<3}  [{:.3},{:.3}]",
            first.k,first.delta,first.kprime,first.s,first.hdpc,first.kappa2,first.kappa4,
            plotkin,samples,explicit,samples,e2e,samples,e2e_ci.0,e2e_ci.1
        );
        writeln!(
            csv,
            "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{:.9},{:.9},{:.9},{},{:.9},{:.9},{:.9},{},{:.9},{:.9},{:.9},{},{},{},{},{},{},{},{},{},\"{}\",\"{}\",{},{},{},\"{}\",{},{},{},{:.9},{:.9},{:.9},{:.9},{:.9},{:.9}",
            first.f,first.k,first.delta,first.kprime,first.s,first.hdpc,first.l,first.kappa2,
            first.kappa4,first.binary_universal as u8,first.binary_plotkin_actual_kappa2 as u8,
            first.binary_randomized as u8,first.exact_gf4_bound_status,samples,plotkin,
            plotkin as f64/samples as f64,plotkin_ci.0,plotkin_ci.1,explicit,
            explicit as f64/samples as f64,explicit_ci.0,explicit_ci.1,e2e,
            e2e as f64/samples as f64,e2e_ci.0,e2e_ci.1,
            median_usize(&ts).map_or(String::new(), |v| format!("{v:.3}")),csv_opt(tmin),csv_opt(tmax),
            median_usize(&rhos).map_or(String::new(), |v| format!("{v:.3}")),csv_opt(rhomin),csv_opt(rhomax),
            median_usize(&savings).map_or(String::new(), |v| format!("{v:.3}")),csv_opt(saving_min),csv_opt(saving_max),
            distribution(&residuals),distribution(&weights),
            median_usize(&weights).map_or(String::new(), |v| format!("{v:.3}")),csv_opt(weight_min),csv_opt(weight_max),
            distribution(&zeros),median_usize(&zeros).map_or(String::new(), |v| format!("{v:.3}")),csv_opt(zero_min),csv_opt(zero_max),
            median_f64(&search_times),p95(&search_times),search_times.iter().copied().fold(0.0,f64::max),
            median_f64(&total_times),p95(&total_times),total_times.iter().copied().fold(0.0,f64::max),
        ).unwrap();
        json.push(format!(
            "{{\"f\":{},\"K\":{},\"Delta\":{},\"Kprime\":{},\"S\":{},\"H_HDPC\":{},\"L\":{},\"kappa2\":{},\"kappa4\":{},\"binary_universal\":{},\"binary_plotkin_actual_kappa2\":{},\"binary_randomized\":{},\"exact_gf4_bound_status\":\"{}\",\"samples\":{},\"plotkin_successes\":{},\"plotkin_fraction\":{:.9},\"plotkin_wilson95\":[{:.9},{:.9}],\"explicit_successes\":{},\"explicit_fraction\":{:.9},\"explicit_wilson95\":[{:.9},{:.9}],\"e2e_successes\":{},\"e2e_fraction\":{:.9},\"e2e_wilson95\":[{:.9},{:.9}],\"T_median\":{},\"T_min\":{},\"T_max\":{},\"rho_median\":{},\"rho_min\":{},\"rho_max\":{},\"rank_saving_median\":{},\"rank_saving_min\":{},\"rank_saving_max\":{},\"residual_dimension_distribution\":\"{}\",\"minimum_weight_distribution\":\"{}\",\"minimum_weight_median\":{},\"minimum_weight_min\":{},\"minimum_weight_max\":{},\"zero_coordinate_distribution\":\"{}\",\"zero_median\":{},\"zero_min\":{},\"zero_max\":{},\"search_time_median\":{:.9},\"search_time_p95\":{:.9},\"search_time_max\":{:.9},\"total_time_median\":{:.9},\"total_time_p95\":{:.9},\"total_time_max\":{:.9}}}",
            first.f,first.k,first.delta,first.kprime,first.s,first.hdpc,first.l,first.kappa2,
            first.kappa4,first.binary_universal,first.binary_plotkin_actual_kappa2,
            first.binary_randomized,first.exact_gf4_bound_status,samples,plotkin,
            plotkin as f64/samples as f64,plotkin_ci.0,plotkin_ci.1,explicit,
            explicit as f64/samples as f64,explicit_ci.0,explicit_ci.1,e2e,
            e2e as f64/samples as f64,e2e_ci.0,e2e_ci.1,
            median_usize(&ts).map_or("null".to_string(), |v| format!("{v:.3}")),json_opt(tmin),json_opt(tmax),
            median_usize(&rhos).map_or("null".to_string(), |v| format!("{v:.3}")),json_opt(rhomin),json_opt(rhomax),
            median_usize(&savings).map_or("null".to_string(), |v| format!("{v:.3}")),json_opt(saving_min),json_opt(saving_max),
            distribution(&residuals),distribution(&weights),
            median_usize(&weights).map_or("null".to_string(), |v| format!("{v:.3}")),json_opt(weight_min),json_opt(weight_max),
            distribution(&zeros),median_usize(&zeros).map_or("null".to_string(), |v| format!("{v:.3}")),json_opt(zero_min),json_opt(zero_max),
            median_f64(&search_times),p95(&search_times),search_times.iter().copied().fold(0.0,f64::max),
            median_f64(&total_times),p95(&total_times),total_times.iter().copied().fold(0.0,f64::max),
        ));
    }
    std::fs::write(path_stem.with_extension("csv"), csv).expect("write aggregate CSV");
    std::fs::write(
        path_stem.with_extension("json"),
        format!("[\n{}\n]\n", json.join(",\n")),
    )
    .expect("write aggregate JSON");
}

pub fn scan_overhead(
    f: usize,
    k_min: usize,
    k_max: usize,
    samples: usize,
    restarts: usize,
    seed: u64,
    sampler: EsiSampler,
    stop_after_first_witness: bool,
) {
    assert!(k_min <= k_max);
    assert!(k_max <= f + 1);
    assert!(samples > 0 && restarts > 0);
    let campaign_started = Instant::now();
    let mut records = Vec::with_capacity((k_max - k_min + 1) * samples);
    println!(
        "=== GF(4) overhead scan: f={f}, K={k_max}..{k_min}, samples={samples}, restarts={restarts}, seed={seed}, sampler={} ===",
        sampler.name()
    );
    for k in (k_min..=k_max).rev() {
        let built = build_k(k);
        let p = built.construction.params;
        let expected_kappa4 = if k == 30 {
            1
        } else {
            k.saturating_sub(3 * p.h)
        };
        assert_eq!(built.construction.kappa(), expected_kappa4);
        println!(
            "K={k:>2} Delta={:>2} K'={:>2} S={:>2} H={} L={:>2} kappa2={:>2} kappa4={:>2}",
            f + 1 - k,
            p.kprime,
            p.s,
            p.h,
            p.l,
            built.kappa2,
            built.construction.kappa()
        );
        for sample in 0..samples {
            records.push(run_instance(
                f,
                k,
                sample,
                restarts,
                seed,
                &built,
                sampler,
                stop_after_first_witness,
            ));
        }
    }

    let out_dir = results_dir();
    std::fs::create_dir_all(&out_dir).expect("create results directory");
    let stem = match sampler {
        EsiSampler::Consecutive => {
            // Compatibility promise: the legacy/default mode retains its exact filenames.
            format!("gf4_overhead_f{f}_k{k_min}_{k_max}_s{samples}_r{restarts}_seed{seed}")
        }
        EsiSampler::RandomEsi | EsiSampler::StratifiedRandomEsi => {
            let search_tag = if stop_after_first_witness {
                "success_first"
            } else {
                "full_budget"
            };
            format!(
                "gf4_esi_sensitivity_{}_{}_f{f}_k{k_min}_{k_max}_s{samples}_r{restarts}_seed{seed}",
                sampler.file_tag(),
                search_tag
            )
        }
    };
    let instance_stem = out_dir.join(&stem);
    let aggregate_stem = out_dir.join(format!("{stem}_aggregate"));
    write_instance_outputs(&instance_stem, &records);
    write_aggregate_outputs(&aggregate_stem, &records);
    println!(
        "instances: {}",
        instance_stem.with_extension("csv").display()
    );
    println!(
        "instances JSON: {}",
        instance_stem.with_extension("json").display()
    );
    println!(
        "aggregate: {}",
        aggregate_stem.with_extension("csv").display()
    );
    println!(
        "aggregate JSON: {}",
        aggregate_stem.with_extension("json").display()
    );
    println!("Wilson intervals: ordinary two-sided 95% Wilson score intervals");
    println!(
        "campaign elapsed: {:.3}s",
        campaign_started.elapsed().as_secs_f64()
    );
    println!("RESULT: GF(4) FIXED-f OVERHEAD SCAN COMPLETE (search failures are not nonexistence results)");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_source(k: usize) -> Vec<u8> {
        (0..k * SYMBOL_BYTES)
            .map(|i| ((i * 131 + 17) & 0xff) as u8)
            .collect()
    }

    #[test]
    fn logarithms_and_wilson_interval_are_sane() {
        assert_eq!(floor_log2(130), 7);
        assert_eq!(ceil_log2(260), 9);
        let (low, high) = wilson(20, 20);
        assert!(low > 0.83 && low < 0.84);
        assert_eq!(high, 1.0);
        let (low_zero, high_zero) = wilson(0, 20);
        assert_eq!(low_zero, 0.0);
        assert!(high_zero > 0.16 && high_zero < 0.17);
    }

    #[test]
    fn direct_enumeration_basis_is_identity() {
        let basis = identity_basis(4);
        assert_eq!(gf4la::rank(&basis, 4), 4);
        for (i, row) in basis.iter().enumerate() {
            for j in 0..4 {
                assert_eq!(row.coeff(j), if i == j { Gf4::ONE } else { Gf4::ZERO });
            }
        }
    }

    #[test]
    fn full_domain_sampler_is_deterministic_distinct_and_in_range() {
        let mut rng1 = Rng::new(0x4553_4924);
        let mut rng2 = Rng::new(0x4553_4924);
        let a = gf4search::random_subset_u32(&mut rng1, RAPTORQ_ESI_DOMAIN_SIZE, 129);
        let b = gf4search::random_subset_u32(&mut rng2, RAPTORQ_ESI_DOMAIN_SIZE, 129);
        assert_eq!(a, b);
        assert_eq!(a.len(), 129);
        assert!(a.windows(2).all(|pair| pair[0] < pair[1]));
        assert!(a.iter().all(|&esi| esi <= RAPTORQ_MAX_ESI));
    }

    #[test]
    fn legacy_consecutive_sampler_regression_is_unchanged() {
        let expected = vec![
            1, 3, 7, 10, 11, 13, 14, 15, 20, 21, 23, 24, 25, 26, 29, 30, 31, 33, 36, 37,
            38, 39, 40, 42, 43, 46, 47, 48, 50, 51, 52, 53, 54, 55, 56, 58, 59, 64, 65, 66,
            67, 68, 69, 70, 71, 72, 73, 74, 75, 77, 78, 79, 82, 83, 84, 85, 90, 91, 94, 95,
            96, 97, 98, 100, 104, 106, 107, 108, 109, 110, 111, 112, 113, 115, 117, 118,
            120, 121, 122, 127, 128, 129, 131, 132, 133, 134, 135, 136, 138, 140, 141, 142,
            144, 146, 147, 148, 149, 152, 154, 155, 157, 158, 159, 160, 162, 163, 164, 165,
            167, 168, 169, 170, 171, 172, 173, 174, 176, 177, 179, 180, 182, 183, 184, 186,
            187, 188, 190, 191, 192,
        ];
        let mut rng = Rng::new(16_633_419_257_214_173_383);
        assert_eq!(gf4search::random_subset(&mut rng, 193, 129), expected);
    }

    #[test]
    fn arbitrary_esi_b4_rows_match_actual_encoder_differences() {
        let k = 65;
        let built = build_k(k);
        let esis = [
            0,
            31,
            64,
            65,
            193,
            1_000_000,
            8_388_608,
            RAPTORQ_MAX_ESI,
        ];
        let b4 = gf4matrix::induced_matrix(k, &esis, &built.construction.z_basis);
        let mut coefficients = Row::zero(built.construction.kappa());
        for i in 0..built.construction.kappa() {
            coefficients.set(i, Gf4::from_code(((i * 3 + 1) % 4) as u8));
        }
        let z = gf4matrix::combine_ambiguity(
            &built.construction.z_basis,
            &coefficients.coefficients(),
            built.construction.params.l,
        );
        let source_diff = gf4matrix::source_difference(&built.construction.gsrc, &z);
        assert!(source_diff.iter().any(|q| !q.is_zero()));

        let config = ObjectTransmissionInformation::new(
            (k * SYMBOL_BYTES) as u64,
            SYMBOL_BYTES as u16,
            1,
            1,
            1,
        );
        let source = vec![0u8; k * SYMBOL_BYTES];
        let mut source2 = source.clone();
        for (i, q) in source_diff.iter().enumerate() {
            source2[i * SYMBOL_BYTES] = q.to_byte();
        }
        let encoder = SourceBlockEncoder::new(0, &config, &source);
        let encoder2 = SourceBlockEncoder::new(0, &config, &source2);
        for (i, &esi) in esis.iter().enumerate() {
            let packet = packet_for(&encoder, esi, k);
            let packet2 = packet_for(&encoder2, esi, k);
            assert_eq!(packet.payload_id().encoding_symbol_id(), esi);
            let predicted = b4[i].dot(&coefficients).to_byte();
            assert_eq!(packet.data()[0] ^ packet2.data()[0], predicted, "ESI={esi}");
            assert!(packet.data()[1..]
                .iter()
                .zip(&packet2.data()[1..])
                .all(|(a, b)| a == b));
        }
    }

    #[test]
    fn decoder_accepts_systematic_and_low_medium_high_repairs() {
        let k = 65;
        let config = ObjectTransmissionInformation::new(
            (k * SYMBOL_BYTES) as u64,
            SYMBOL_BYTES as u16,
            1,
            1,
            1,
        );
        let source = test_source(k);
        let encoder = SourceBlockEncoder::new(0, &config, &source);
        let cases = [k as u32, 1_000_000, RAPTORQ_MAX_ESI - 9];
        for start in cases {
            let mut esis: Vec<u32> = (0..64).collect();
            esis.extend(start..start + 10);
            let decoded = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
                .decode(packets_for(&encoder, &esis, k));
            assert_eq!(decoded.as_deref(), Some(source.as_slice()), "start ESI={start}");
        }

        let mut mixed: Vec<u32> = (0..60).collect();
        mixed.extend(k as u32..k as u32 + 5);
        mixed.extend(1_000_000..1_000_005);
        mixed.extend(RAPTORQ_MAX_ESI - 4..=RAPTORQ_MAX_ESI);
        let decoded = SourceBlockDecoder::new(0, &config, (k * SYMBOL_BYTES) as u64)
            .decode(packets_for(&encoder, &mixed, k));
        assert_eq!(decoded.as_deref(), Some(source.as_slice()));
    }
}
