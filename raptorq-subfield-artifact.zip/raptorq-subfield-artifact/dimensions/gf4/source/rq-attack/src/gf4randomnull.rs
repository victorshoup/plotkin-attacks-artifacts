//! Generic random-quaternary-code null model for the fixed-f=64 search.
//!
//! Each matrix has 129 rows and `kappa = K - 30` columns. Entries are sampled
//! independently and uniformly in GF(4), and the complete matrix is rejected unless it has
//! full column rank. Conditioning this iid-uniform distribution on full rank is uniform over
//! full-rank matrices. Every `kappa`-dimensional subspace has exactly `|GL(kappa, 4)|`
//! ordered generator bases, so the induced code is uniform over `kappa`-dimensional linear
//! subspaces of GF(4)^129.

use std::fmt::Write as _;
use std::path::PathBuf;
use std::time::Instant;

use crate::gf4::Gf4;
use crate::gf4la::{self, Row};
use crate::gf4search::{self, Rng, SearchResult};

const F: usize = 64;
const H: usize = 2 * F + 1;
const EXACT_DIMENSION_LIMIT: usize = 8;

#[derive(Clone)]
struct InstanceResult {
    k: usize,
    kappa: usize,
    sample: usize,
    master_seed: u64,
    matrix_seed: u64,
    search_seed: u64,
    matrix_attempts: usize,
    rank: usize,
    primary_restart_budget: usize,
    restart_stream_budget: usize,
    first_success_restart: Option<usize>,
    success_at_primary_budget: bool,
    selected_restart: usize,
    shortening_cardinality: usize,
    shortening_rank: usize,
    rank_saving: usize,
    residual_dimension: usize,
    minimum_selected_weight: usize,
    zero_coordinates: usize,
    algebraically_verified: bool,
    matrix_generation_time: f64,
    search_time_primary: f64,
    search_time_total: f64,
    total_wall_clock_time: f64,
    shortening_indices: Vec<usize>,
    coefficient_codes: Vec<u8>,
}

fn results_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../results")
}

fn matrix_seed(master_seed: u64, k: usize, sample: usize) -> u64 {
    master_seed
        ^ (k as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15)
        ^ (sample as u64).wrapping_mul(0x85eb_ca6b_27d4_eb2f)
        ^ 0x5241_4e44_4746_3421
}

fn search_seed(master_seed: u64, k: usize, sample: usize) -> u64 {
    master_seed.rotate_left(17)
        ^ (k as u64).wrapping_mul(0xc2b2_ae35_87b7_3a21)
        ^ (sample as u64).wrapping_mul(0x1656_67b1_9e37_79f9)
        ^ 0x4e55_4c4c_5345_4152
}

fn iid_matrix(rng: &mut Rng, nrows: usize, ncols: usize) -> Vec<Row> {
    (0..nrows)
        .map(|_| {
            let mut row = Row::zero(ncols);
            for col in 0..ncols {
                row.set(col, Gf4::from_code(rng.below_uniform(4) as u8));
            }
            row
        })
        .collect()
}

/// Generate an iid-uniform GF(4) matrix conditioned on full column rank.
pub(crate) fn random_full_rank_matrix(nrows: usize, ncols: usize, seed: u64) -> (Vec<Row>, usize) {
    assert!(ncols > 0 && ncols <= nrows);
    let mut rng = Rng::new(seed);
    for attempt in 1.. {
        let matrix = iid_matrix(&mut rng, nrows, ncols);
        if gf4la::rank(&matrix, ncols) == ncols {
            return (matrix, attempt);
        }
    }
    unreachable!()
}

/// High-precision-enough floating evaluation of the exact first-moment rational.
/// The final analysis also evaluates the same rational with Python arbitrary-precision
/// integers and Decimal arithmetic.
pub(crate) fn expected_nonzero_low_weight_words(kappa: usize) -> f64 {
    let mut term = 1.0f64;
    let mut volume = 0.0f64;
    for weight in 1..=F {
        term *= ((H + 1 - weight) as f64 / weight as f64) * 3.0;
        volume += term;
    }
    (4.0f64.powi(kappa as i32) - 1.0) * volume / (4.0f64.powi(H as i32) - 1.0)
}

fn explicit_score(
    result: &SearchResult,
) -> (
    bool,
    std::cmp::Reverse<usize>,
    usize,
    std::cmp::Reverse<usize>,
) {
    (
        result.word.weight <= F,
        std::cmp::Reverse(result.word.weight),
        result.shortening.len().saturating_sub(result.rank),
        std::cmp::Reverse(result.rank),
    )
}

struct SearchTrace {
    selected_primary: SearchResult,
    first_success_restart: Option<usize>,
    search_time_primary: f64,
    search_time_total: f64,
}

/// Run the same restart/path/residual-enumeration heuristic used for RaptorQ B4 matrices.
fn search_with_primary_snapshot(
    matrix: &[Row],
    primary_restarts: usize,
    stream_restarts: usize,
    seed: u64,
) -> SearchTrace {
    assert!(primary_restarts > 0 && stream_restarts >= primary_restarts);
    let kappa = matrix[0].ncols;
    let started = Instant::now();
    let mut best: Option<SearchResult> = None;
    let mut selected_primary = None;
    let mut first_success_restart = None;
    let mut search_time_primary = 0.0;
    for restart in 0..stream_restarts {
        let mut rng = Rng::new(seed.wrapping_add(restart as u64));
        let stages =
            gf4search::greedy_path(matrix, kappa.saturating_sub(1), &mut rng, restart != 0);
        if let Some(candidate) = gf4search::best_explicit_for_stages(
            matrix,
            F,
            stages,
            restart,
            EXACT_DIMENSION_LIMIT,
            &mut rng,
        ) {
            if candidate.word.weight <= F {
                first_success_restart.get_or_insert(restart + 1);
            }
            if best
                .as_ref()
                .is_none_or(|old| explicit_score(&candidate) > explicit_score(old))
            {
                best = Some(candidate);
            }
        }
        if restart + 1 == primary_restarts {
            search_time_primary = started.elapsed().as_secs_f64();
            selected_primary = best.clone();
        }
    }
    SearchTrace {
        selected_primary: selected_primary.expect("search produced no primary candidate"),
        first_success_restart,
        search_time_primary,
        search_time_total: started.elapsed().as_secs_f64(),
    }
}

fn independently_verify(matrix: &[Row], selected: &SearchResult) -> (usize, usize) {
    assert!(!selected.word.coefficient_vector.is_zero());
    let values: Vec<Gf4> = matrix
        .iter()
        .map(|row| row.dot(&selected.word.coefficient_vector))
        .collect();
    let weight = values.iter().filter(|value| !value.is_zero()).count();
    assert_eq!(values, selected.word.values);
    assert_eq!(weight, selected.word.weight);
    (weight, values.len() - weight)
}

fn run_instance(
    k: usize,
    sample: usize,
    primary_restarts: usize,
    stream_restarts: usize,
    master_seed: u64,
) -> InstanceResult {
    let total_started = Instant::now();
    let kappa = k - 30;
    let matrix_seed = matrix_seed(master_seed, k, sample);
    let search_seed = search_seed(master_seed, k, sample);
    let matrix_started = Instant::now();
    let (matrix, matrix_attempts) = random_full_rank_matrix(H, kappa, matrix_seed);
    let matrix_generation_time = matrix_started.elapsed().as_secs_f64();
    let rank = gf4la::rank(&matrix, kappa);
    assert_eq!(rank, kappa);
    let trace =
        search_with_primary_snapshot(&matrix, primary_restarts, stream_restarts, search_seed);
    let selected = trace.selected_primary;
    let (minimum_selected_weight, zero_coordinates) = independently_verify(&matrix, &selected);
    let success_at_primary_budget = trace
        .first_success_restart
        .is_some_and(|restart| restart <= primary_restarts);
    assert_eq!(success_at_primary_budget, minimum_selected_weight <= F);
    InstanceResult {
        k,
        kappa,
        sample,
        master_seed,
        matrix_seed,
        search_seed,
        matrix_attempts,
        rank,
        primary_restart_budget: primary_restarts,
        restart_stream_budget: stream_restarts,
        first_success_restart: trace.first_success_restart,
        success_at_primary_budget,
        selected_restart: selected.restart + 1,
        shortening_cardinality: selected.shortening.len(),
        shortening_rank: selected.rank,
        rank_saving: selected.shortening.len().saturating_sub(selected.rank),
        residual_dimension: selected.residual_basis.len(),
        minimum_selected_weight,
        zero_coordinates,
        algebraically_verified: true,
        matrix_generation_time,
        search_time_primary: trace.search_time_primary,
        search_time_total: trace.search_time_total,
        total_wall_clock_time: total_started.elapsed().as_secs_f64(),
        shortening_indices: selected.shortening,
        coefficient_codes: selected
            .word
            .coefficient_vector
            .coefficients()
            .into_iter()
            .map(Gf4::code)
            .collect(),
    }
}

fn optional_usize(value: Option<usize>) -> String {
    value.map_or(String::new(), |value| value.to_string())
}

fn semicolon_usize(values: &[usize]) -> String {
    values
        .iter()
        .map(usize::to_string)
        .collect::<Vec<_>>()
        .join(";")
}

fn semicolon_u8(values: &[u8]) -> String {
    values
        .iter()
        .map(u8::to_string)
        .collect::<Vec<_>>()
        .join(";")
}

fn write_outputs(stem: &PathBuf, records: &[InstanceResult]) {
    let mut csv = String::from(
        "f,h,K,kappa,sample,master_seed,matrix_seed,search_seed,matrix_generation,matrix_attempts,rank,primary_restart_budget,restart_stream_budget,first_success_restart,success_at_primary_budget,selected_restart,shortening_cardinality,shortening_rank,rank_saving,residual_dimension,minimum_selected_weight,zero_coordinates,algebraically_verified,matrix_generation_time,search_time_primary,search_time_total,total_wall_clock_time,search_algorithm,shortening_indices,coefficient_codes\n",
    );
    let mut json = Vec::with_capacity(records.len());
    for r in records {
        writeln!(
            csv,
            "{F},{H},{},{},{},{},{},{},iid_uniform_gf4_conditioned_full_column_rank,{},{},{},{},{},{},{},{},{},{},{},{},{},{},{:.9},{:.9},{:.9},{:.9},randomized_greedy_projective_closure+exact_residual_enumeration,\"{}\",\"{}\"",
            r.k,
            r.kappa,
            r.sample,
            r.master_seed,
            r.matrix_seed,
            r.search_seed,
            r.matrix_attempts,
            r.rank,
            r.primary_restart_budget,
            r.restart_stream_budget,
            optional_usize(r.first_success_restart),
            r.success_at_primary_budget as u8,
            r.selected_restart,
            r.shortening_cardinality,
            r.shortening_rank,
            r.rank_saving,
            r.residual_dimension,
            r.minimum_selected_weight,
            r.zero_coordinates,
            r.algebraically_verified as u8,
            r.matrix_generation_time,
            r.search_time_primary,
            r.search_time_total,
            r.total_wall_clock_time,
            semicolon_usize(&r.shortening_indices),
            semicolon_u8(&r.coefficient_codes),
        )
        .unwrap();
        json.push(format!(
            "{{\"f\":{F},\"h\":{H},\"K\":{},\"kappa\":{},\"sample\":{},\"master_seed\":{},\"matrix_seed\":{},\"search_seed\":{},\"matrix_generation\":\"iid_uniform_gf4_conditioned_full_column_rank\",\"matrix_attempts\":{},\"rank\":{},\"primary_restart_budget\":{},\"restart_stream_budget\":{},\"first_success_restart\":{},\"success_at_primary_budget\":{},\"selected_restart\":{},\"shortening_cardinality\":{},\"shortening_rank\":{},\"rank_saving\":{},\"residual_dimension\":{},\"minimum_selected_weight\":{},\"zero_coordinates\":{},\"algebraically_verified\":{},\"matrix_generation_time\":{:.9},\"search_time_primary\":{:.9},\"search_time_total\":{:.9},\"total_wall_clock_time\":{:.9},\"search_algorithm\":\"randomized_greedy_projective_closure+exact_residual_enumeration\",\"shortening_indices\":{:?},\"coefficient_codes\":{:?}}}",
            r.k,
            r.kappa,
            r.sample,
            r.master_seed,
            r.matrix_seed,
            r.search_seed,
            r.matrix_attempts,
            r.rank,
            r.primary_restart_budget,
            r.restart_stream_budget,
            r.first_success_restart.map_or("null".to_string(), |value| value.to_string()),
            r.success_at_primary_budget,
            r.selected_restart,
            r.shortening_cardinality,
            r.shortening_rank,
            r.rank_saving,
            r.residual_dimension,
            r.minimum_selected_weight,
            r.zero_coordinates,
            r.algebraically_verified,
            r.matrix_generation_time,
            r.search_time_primary,
            r.search_time_total,
            r.total_wall_clock_time,
            r.shortening_indices,
            r.coefficient_codes,
        ));
    }
    std::fs::write(stem.with_extension("csv"), csv).expect("write random-code CSV");
    std::fs::write(
        stem.with_extension("json"),
        format!("[\n{}\n]\n", json.join(",\n")),
    )
    .expect("write random-code JSON");
}

pub fn scan(
    k_min: usize,
    k_max: usize,
    include_k65: bool,
    samples: usize,
    primary_restarts: usize,
    nested_restarts: usize,
    seed: u64,
) {
    assert!(44 <= k_min && k_min <= k_max && k_max <= 56);
    assert!(samples > 0 && primary_restarts > 0 && nested_restarts >= primary_restarts);
    let campaign_started = Instant::now();
    let mut k_values: Vec<usize> = (k_min..=k_max).collect();
    if include_k65 {
        k_values.push(65);
    }
    let mut records = Vec::with_capacity(k_values.len() * samples);
    println!(
        "=== GF(4) random-code null: K={k_min}..{k_max}{}, samples={samples}, primary={primary_restarts}, nested={nested_restarts}, seed={seed} ===",
        if include_k65 { " plus 65" } else { "" }
    );
    for k in k_values.into_iter().rev() {
        let kappa = k - 30;
        let stream_restarts = if matches!(k, 50 | 53 | 56) {
            nested_restarts
        } else {
            primary_restarts
        };
        println!(
            "K={k} kappa={kappa} E[N_<=64]={:.12e} restarts={stream_restarts}",
            expected_nonzero_low_weight_words(kappa)
        );
        for sample in 0..samples {
            records.push(run_instance(
                k,
                sample,
                primary_restarts,
                stream_restarts,
                seed,
            ));
            if (sample + 1) % 100 == 0 || sample + 1 == samples {
                println!("  completed {}/{}", sample + 1, samples);
            }
        }
    }
    let out_dir = results_dir();
    std::fs::create_dir_all(&out_dir).expect("create results directory");
    let plus65 = if include_k65 { "_plus65" } else { "" };
    let stem = out_dir.join(format!(
        "gf4_random_code_null_f64_k{k_min}_{k_max}{plus65}_s{samples}_r{primary_restarts}_nested{nested_restarts}_seed{seed}"
    ));
    write_outputs(&stem, &records);
    println!("instances: {}", stem.with_extension("csv").display());
    println!("instances JSON: {}", stem.with_extension("json").display());
    println!(
        "campaign elapsed: {:.3}s",
        campaign_started.elapsed().as_secs_f64()
    );
    println!("RESULT: GF(4) RANDOM-CODE NULL COMPLETE");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn random_matrix_generation_is_deterministic_and_full_rank() {
        let (a, attempts_a) = random_full_rank_matrix(129, 20, 0x5241_4e44);
        let (b, attempts_b) = random_full_rank_matrix(129, 20, 0x5241_4e44);
        assert_eq!(a, b);
        assert_eq!(attempts_a, attempts_b);
        assert_eq!(gf4la::rank(&a, 20), 20);
    }

    #[test]
    fn deficient_draw_is_rejected() {
        let seed = (0..10_000)
            .find(|&seed| random_full_rank_matrix(1, 1, seed).1 > 1)
            .expect("find deterministic seed with a rejected 1x1 zero draw");
        let (matrix, attempts) = random_full_rank_matrix(1, 1, seed);
        assert!(attempts > 1);
        assert_eq!(gf4la::rank(&matrix, 1), 1);
    }

    #[test]
    fn first_moment_matches_regression_anchors() {
        let anchors = [
            (14, 0.138_862_084_788_155_48),
            (15, 0.555_448_340_704_526_6),
            (16, 2.221_793_364_370_011_4),
            (17, 8.887_173_459_031_95),
            (18, 35.548_693_837_679_71),
            (19, 142.194_775_352_270_74),
            (20, 568.779_101_410_634_8),
            (21, 2_275.116_405_644_091),
        ];
        for (kappa, expected) in anchors {
            let actual = expected_nonzero_low_weight_words(kappa);
            assert!((actual / expected - 1.0).abs() < 2e-15);
        }
    }

    #[test]
    fn every_claimed_word_is_recomputed_algebraically() {
        let (matrix, _) = random_full_rank_matrix(129, 20, 0x5645_5249_4659);
        let trace = search_with_primary_snapshot(&matrix, 2, 2, 0x5345_4152_4348);
        let (weight, zeros) = independently_verify(&matrix, &trace.selected_primary);
        assert_eq!(weight, trace.selected_primary.word.weight);
        assert_eq!(weight + zeros, 129);
    }

    #[test]
    fn null_driver_uses_the_existing_search_result_exactly() {
        let (matrix, _) = random_full_rank_matrix(129, 20, 0x5341_4d45);
        let seed = 0x4845_5552_4953_5449;
        let trace = search_with_primary_snapshot(&matrix, 1, 1, seed);
        let existing = gf4search::search_explicit_word(&matrix, F, 1, seed, 8).unwrap();
        assert_eq!(trace.selected_primary.shortening, existing.shortening);
        assert_eq!(trace.selected_primary.rank, existing.rank);
        assert_eq!(
            trace.selected_primary.residual_basis,
            existing.residual_basis
        );
        assert_eq!(trace.selected_primary.word.weight, existing.word.weight);
        assert_eq!(
            trace.selected_primary.word.coefficient_vector,
            existing.word.coefficient_vector
        );
        assert_eq!(trace.selected_primary.word.values, existing.word.values);
    }

    #[test]
    fn k50_row_permutation_diagnostic_has_no_gross_artifact() {
        for sample in 0..20u64 {
            let (matrix, _) = random_full_rank_matrix(129, 20, 0x524f_574d_4154_0000 ^ sample);
            let search_seed = 0x524f_5753_4541_0000 ^ sample;
            let baseline = search_with_primary_snapshot(&matrix, 40, 40, search_seed);
            for permutation in 0..5u64 {
                let mut permuted = matrix.clone();
                let mut rng = Rng::new(
                    0x5045_524d_5554_0000 ^ sample.wrapping_mul(0x9e37_79b9) ^ permutation,
                );
                for index in (1..permuted.len()).rev() {
                    let other = rng.below_uniform(index + 1);
                    permuted.swap(index, other);
                }
                let result = search_with_primary_snapshot(&permuted, 40, 40, search_seed);
                assert_eq!(
                    result.selected_primary.word.weight,
                    baseline.selected_primary.word.weight
                );
                assert_eq!(
                    result.selected_primary.word.coefficient_vector,
                    baseline.selected_primary.word.coefficient_vector
                );
                assert_eq!(
                    result.selected_primary.residual_basis,
                    baseline.selected_primary.residual_basis
                );
                assert_eq!(result.first_success_restart, baseline.first_success_restart);
            }
        }
    }
}
