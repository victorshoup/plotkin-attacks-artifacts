//! Reproducible low-rank-shortening search over rows of a GF(4) matrix.

use std::collections::{BTreeSet, HashMap};

use crate::gf4::Gf4;
use crate::gf4la::{self, Row};

#[derive(Clone)]
pub struct Rng(u64);

impl Rng {
    pub fn new(seed: u64) -> Self {
        Self(seed ^ 0x9e37_79b9_7f4a_7c15)
    }

    pub fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_f491_4f6c_dd1d)
    }

    pub fn below(&mut self, n: usize) -> usize {
        (self.next_u64() % n as u64) as usize
    }

    /// Exactly uniform draw from `[0, n)` using rejection sampling.
    pub fn below_uniform(&mut self, n: usize) -> usize {
        assert!(n > 0);
        let n = n as u64;
        let rejection_threshold = n.wrapping_neg() % n;
        loop {
            let value = self.next_u64();
            if value >= rejection_threshold {
                return (value % n) as usize;
            }
        }
    }
}

pub fn random_subset(rng: &mut Rng, n: usize, size: usize) -> Vec<u32> {
    assert!(size <= n);
    let mut pool: Vec<u32> = (0..n as u32).collect();
    for i in 0..size {
        let j = i + rng.below(n - i);
        pool.swap(i, j);
    }
    let mut result = pool[..size].to_vec();
    result.sort_unstable();
    result
}

/// A uniform subset of `[0, domain_size)` without allocating the whole domain.
///
/// Floyd's algorithm uses O(size) memory, which matters for the 2^24-element RaptorQ ESI
/// domain. The returned ordering is the same canonical ascending ordering used by the
/// pre-existing consecutive-range sampler.
pub fn random_subset_u32(rng: &mut Rng, domain_size: u32, size: usize) -> Vec<u32> {
    assert!(size <= domain_size as usize);
    let mut selected = BTreeSet::new();
    for j in domain_size - size as u32..domain_size {
        let candidate = rng.below_uniform(j as usize + 1) as u32;
        if !selected.insert(candidate) {
            assert!(selected.insert(j));
        }
    }
    selected.into_iter().collect()
}

pub fn canonical_projective(row: &Row) -> Row {
    let Some(col) = row.first_nonzero() else {
        return row.clone();
    };
    row.scaled(row.coeff(col).inverse())
}

#[derive(Clone, Debug)]
pub struct Stage {
    pub rank: usize,
    pub closure: Vec<usize>,
}

/// Greedy quotient search. At each rank, choose the largest projective class of residual
/// rows, which maximizes the exact one-step closure gain. Randomness only breaks ties.
pub fn greedy_path(rows: &[Row], max_rank: usize, rng: &mut Rng, random_ties: bool) -> Vec<Stage> {
    let mut residual = rows.to_vec();
    let mut closure: Vec<usize> = residual
        .iter()
        .enumerate()
        .filter_map(|(i, row)| row.is_zero().then_some(i))
        .collect();
    let mut stages = vec![Stage {
        rank: 0,
        closure: closure.clone(),
    }];
    let mut rank = 0;
    while rank < max_rank {
        let mut groups: HashMap<Row, Vec<usize>> = HashMap::new();
        for (i, row) in residual.iter().enumerate() {
            if !row.is_zero() {
                groups.entry(canonical_projective(row)).or_default().push(i);
            }
        }
        if groups.is_empty() {
            break;
        }
        let best_size = groups.values().map(Vec::len).max().unwrap();
        let mut keys: Vec<Row> = groups
            .into_iter()
            .filter_map(|(key, members)| (members.len() == best_size).then_some(key))
            .collect();
        // HashMap order is deliberately removed from the reproducibility boundary.
        keys.sort_by(|a, b| a.lo.cmp(&b.lo).then(a.hi.cmp(&b.hi)));
        let selected = if random_ties && keys.len() > 1 {
            keys.swap_remove(rng.below(keys.len()))
        } else {
            keys.swap_remove(0)
        };
        let pivot_col = selected.first_nonzero().unwrap();
        for row in &mut residual {
            if !row.is_zero() {
                let q = row.coeff(pivot_col);
                row.add_scaled(q, &selected);
            }
        }
        rank += 1;
        closure = residual
            .iter()
            .enumerate()
            .filter_map(|(i, row)| row.is_zero().then_some(i))
            .collect();
        stages.push(Stage {
            rank,
            closure: closure.clone(),
        });
    }
    stages
}

#[derive(Clone, Debug)]
pub struct MinimumWord {
    pub weight: usize,
    pub coefficient_vector: Row,
    pub values: Vec<Gf4>,
    pub enumerated: usize,
    pub exact: bool,
}

pub fn minimum_word(
    transmitted_rows: &[Row],
    subspace_basis: &[Row],
    enumeration_limit: usize,
    rng: &mut Rng,
) -> Option<MinimumWord> {
    let dimension = subspace_basis.len();
    if dimension == 0 {
        return None;
    }
    let total = 4usize.checked_pow(dimension as u32);
    let exact = total.is_some_and(|n| n - 1 <= enumeration_limit);
    let iterations = if exact { total.unwrap() - 1 } else { enumeration_limit };
    let ncols = subspace_basis[0].ncols;
    let mut best: Option<MinimumWord> = None;

    // Exact mode visits the identical base-4 coefficient sequence as the original direct
    // implementation, but updates the ambiguity vector and its transmitted values across
    // the odometer carry instead of recomputing every dot product from scratch.
    if exact {
        let basis_values: Vec<Row> = subspace_basis
            .iter()
            .map(|basis_vector| {
                let mut values = Row::zero(transmitted_rows.len());
                for (i, row) in transmitted_rows.iter().enumerate() {
                    values.set(i, row.dot(basis_vector));
                }
                values
            })
            .collect();
        let mut coefficients = vec![Gf4::ZERO; dimension];
        let mut x = Row::zero(ncols);
        let mut values = Row::zero(transmitted_rows.len());
        for _ in 0..iterations {
            let mut digit = 0;
            loop {
                let old = coefficients[digit];
                let new = Gf4::from_code((old.code() + 1) & 3);
                let delta = old + new;
                coefficients[digit] = new;
                x.add_scaled(delta, &subspace_basis[digit]);
                values.add_scaled(delta, &basis_values[digit]);
                digit += 1;
                if !new.is_zero() || digit == dimension {
                    break;
                }
            }
            let weight = values
                .lo
                .iter()
                .zip(&values.hi)
                .map(|(&lo, &hi)| (lo | hi).count_ones() as usize)
                .sum();
            if best.as_ref().is_none_or(|old| weight < old.weight) {
                best = Some(MinimumWord {
                    weight,
                    coefficient_vector: x.clone(),
                    values: values.coefficients(),
                    enumerated: iterations,
                    exact: true,
                });
            }
        }
        return best;
    }

    for index in 0..iterations {
        let _ = index;
        let coefficients: Vec<Gf4> = loop {
            let qs: Vec<Gf4> = (0..dimension)
                .map(|_| Gf4::from_code(rng.below(4) as u8))
                .collect();
            if qs.iter().any(|q| !q.is_zero()) {
                break qs;
            }
        };
        let x = gf4la::linear_combination(subspace_basis, &coefficients, ncols);
        let values: Vec<Gf4> = transmitted_rows.iter().map(|row| row.dot(&x)).collect();
        let weight = values.iter().filter(|q| !q.is_zero()).count();
        if best.as_ref().is_none_or(|old| weight < old.weight) {
            best = Some(MinimumWord {
                weight,
                coefficient_vector: x,
                values,
                enumerated: 0,
                exact: false,
            });
        }
    }
    if let Some(word) = &mut best {
        word.enumerated = iterations;
    }
    best
}

#[derive(Clone, Debug)]
pub struct SearchResult {
    pub shortening: Vec<usize>,
    pub rank: usize,
    pub residual_basis: Vec<Row>,
    pub word: MinimumWord,
    pub restart: usize,
}

#[derive(Clone, Debug)]
pub struct PlotkinResult {
    pub shortening: Vec<usize>,
    pub rank: usize,
    pub residual_dimension: usize,
    pub restart: usize,
    pub shortened_length: usize,
    pub bound_numerator: usize,
    pub bound_denominator: usize,
    pub contradiction: bool,
}

fn plotkin_score(r: &PlotkinResult) -> (bool, usize, usize, usize, std::cmp::Reverse<usize>) {
    (
        r.contradiction,
        r.shortening.len().saturating_sub(r.rank),
        r.residual_dimension,
        r.shortening.len(),
        std::cmp::Reverse(r.rank),
    )
}

/// Select the best auditable Plotkin-shortening candidate along one already-generated
/// greedy path. Keeping path generation separate lets callers measure each restart and
/// identify the first successful restart without changing the baseline heuristic.
pub fn best_plotkin_for_stages(
    rows: &[Row],
    f: usize,
    stages: Vec<Stage>,
    restart: usize,
) -> Option<PlotkinResult> {
    let kappa = rows.first()?.ncols;
    let h = rows.len();
    let d = f + 1;
    let mut best: Option<PlotkinResult> = None;
    for stage in stages {
        let tau = stage.closure.len().min(f);
        let shortened_length = h - tau;
        let signed_denominator = 4 * d as isize - 3 * shortened_length as isize;
        if signed_denominator <= 0 {
            continue;
        }
        let shortening: Vec<usize> = stage.closure.into_iter().take(tau).collect();
        let selected_rows: Vec<Row> = shortening.iter().map(|&i| rows[i].clone()).collect();
        let actual_rank = gf4la::rank(&selected_rows, kappa);
        let residual_dimension = kappa - actual_rank;
        let denominator = signed_denominator as usize;
        let code_size = 4u128.pow(residual_dimension as u32);
        let contradiction = code_size * denominator as u128 > (4 * d) as u128;
        let candidate = PlotkinResult {
            shortening,
            rank: actual_rank,
            residual_dimension,
            restart,
            shortened_length,
            bound_numerator: 4 * d,
            bound_denominator: denominator,
            contradiction,
        };
        if best
            .as_ref()
            .is_none_or(|old| plotkin_score(&candidate) > plotkin_score(old))
        {
            best = Some(candidate);
        }
    }
    best
}

pub fn search_plotkin(rows: &[Row], f: usize, restarts: usize, seed: u64) -> Option<PlotkinResult> {
    let kappa = rows.first()?.ncols;
    let mut best: Option<PlotkinResult> = None;
    for restart in 0..restarts {
        let mut rng = Rng::new(seed.wrapping_add(restart as u64));
        let stages = greedy_path(rows, kappa.saturating_sub(1), &mut rng, restart != 0);
        if let Some(candidate) = best_plotkin_for_stages(rows, f, stages, restart) {
            if best
                .as_ref()
                .is_none_or(|old| plotkin_score(&candidate) > plotkin_score(old))
            {
                best = Some(candidate);
            }
        }
    }
    best
}

/// Repeated randomized greedy paths, with exact word enumeration whenever the residual
/// dimension is small. This is a heuristic: failure means only that this search failed.
pub fn search_explicit_word(
    rows: &[Row],
    target_weight: usize,
    restarts: usize,
    seed: u64,
    max_residual_dimension: usize,
) -> Option<SearchResult> {
    let kappa = rows.first()?.ncols;
    let mut best: Option<SearchResult> = None;
    for restart in 0..restarts {
        let mut rng = Rng::new(seed.wrapping_add(restart as u64));
        let stages = greedy_path(rows, kappa.saturating_sub(1), &mut rng, restart != 0);
        if let Some(candidate) = best_explicit_for_stages(
            rows,
            target_weight,
            stages,
            restart,
            max_residual_dimension,
            &mut rng,
        ) {
            if best.as_ref().is_none_or(|old| {
                explicit_score(&candidate, target_weight) > explicit_score(old, target_weight)
            }) {
                best = Some(candidate);
            }
        }
    }
    best
}

fn explicit_score(
    result: &SearchResult,
    target_weight: usize,
) -> (
    bool,
    std::cmp::Reverse<usize>,
    usize,
    std::cmp::Reverse<usize>,
) {
    (
        result.word.weight <= target_weight,
        std::cmp::Reverse(result.word.weight),
        result.shortening.len().saturating_sub(result.rank),
        std::cmp::Reverse(result.rank),
    )
}

/// Evaluate every exactly enumerable residual stage along one already-generated greedy path.
/// This is the per-restart primitive used by the original explicit-word search; exposing it
/// lets experiment drivers record first-success restarts without changing the baseline.
pub fn best_explicit_for_stages(
    rows: &[Row],
    target_weight: usize,
    stages: Vec<Stage>,
    restart: usize,
    max_residual_dimension: usize,
    rng: &mut Rng,
) -> Option<SearchResult> {
    let kappa = rows.first()?.ncols;
    let mut best: Option<SearchResult> = None;
    for stage in stages {
        let residual_dimension = kappa - stage.rank;
        if residual_dimension == 0 || residual_dimension > max_residual_dimension {
            continue;
        }
        let shortening_rows: Vec<Row> = stage.closure.iter().map(|&i| rows[i].clone()).collect();
        let basis = gf4la::kernel_basis(&shortening_rows, kappa);
        debug_assert_eq!(basis.len(), residual_dimension);
        let limit = 4usize.pow(residual_dimension as u32).saturating_sub(1);
        let Some(word) = minimum_word(rows, &basis, limit, rng) else {
            continue;
        };
        let candidate = SearchResult {
            shortening: stage.closure,
            rank: stage.rank,
            residual_basis: basis,
            word,
            restart,
        };
        if best.as_ref().is_none_or(|old| {
            explicit_score(&candidate, target_weight) > explicit_score(old, target_weight)
        }) {
            best = Some(candidate);
        }
    }
    best
}

pub const F64_HONEST_ESIS: &[u32] = &[
    0, 1, 2, 3, 4, 6, 7, 8, 10, 13, 14, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 33,
    34, 35, 36, 37, 38, 40, 41, 42, 43, 45, 46, 48, 49, 52, 53, 55, 56, 57, 58, 60, 61, 62, 63, 65,
    66, 67, 68, 69, 71, 74, 75, 77, 78, 79, 80, 81, 82, 84, 86, 87, 88, 89, 90, 91, 93, 95, 96, 99,
    101, 105, 106, 107, 108, 109, 111, 112, 114, 115, 116, 119, 120, 122, 123, 126, 129, 130, 135,
    136, 138, 139, 141, 142, 144, 145, 148, 149, 151, 152, 153, 154, 159, 160, 164, 166, 167, 168,
    169, 172, 173, 174, 176, 177, 178, 179, 181, 182, 183, 184, 186, 187, 188, 191, 192,
];

pub const F64_SHORTENING_ESIS: &[u32] = &[
    1, 3, 6, 10, 13, 14, 17, 21, 27, 30, 34, 37, 38, 41, 42, 43, 45, 46, 55, 65, 68, 75, 78, 79,
    81, 86, 90, 91, 95, 99, 105, 106, 108, 114, 116, 123, 138, 145, 149, 152, 160, 166, 167, 169,
    172, 174, 183, 184, 188, 191, 192,
];

#[cfg(test)]
pub const F64_ZERO_ESIS: &[u32] = &[
    1, 3, 4, 6, 10, 13, 14, 17, 21, 22, 25, 27, 30, 34, 35, 37, 38, 41, 42, 43, 45, 46, 55, 56, 60,
    65, 68, 71, 75, 77, 78, 79, 81, 82, 86, 90, 91, 93, 95, 99, 105, 106, 108, 111, 114, 115, 116,
    123, 138, 139, 142, 145, 149, 152, 154, 160, 164, 166, 167, 169, 172, 174, 176, 179, 183, 184,
    186, 188, 191, 192,
];

#[cfg(test)]
pub const F64_SOURCE_DIFF_CODES: &[u8] = &[
    1, 0, 1, 0, 0, 0, 0, 2, 2, 3, 0, 0, 2, 0, 0, 3, 2, 0, 3, 1, 1, 0, 0, 1, 2, 0, 1, 0, 2, 3, 0, 3,
    3, 2, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 1, 3, 3, 0, 3, 3, 3, 1, 0, 0, 1, 1, 2, 0, 3, 2, 1,
    3,
];

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gf4matrix;

    #[test]
    fn corrected_f64_shortening_differential() {
        let construction = gf4matrix::construct(65);
        assert_eq!(construction.kappa(), 35);
        let b = gf4matrix::induced_matrix(65, F64_HONEST_ESIS, &construction.z_basis);
        assert_eq!(gf4la::rank(&b, 35), 35);
        let positions: HashMap<u32, usize> = F64_HONEST_ESIS
            .iter()
            .enumerate()
            .map(|(i, &esi)| (esi, i))
            .collect();
        let shortening: Vec<Row> = F64_SHORTENING_ESIS
            .iter()
            .map(|esi| b[*positions.get(esi).unwrap()].clone())
            .collect();
        assert_eq!(gf4la::rank(&shortening, 35), 33);
        let residual = gf4la::kernel_basis(&shortening, 35);
        assert_eq!(residual.len(), 2);
        let mut rng = Rng::new(20260829);
        let word = minimum_word(&b, &residual, 15, &mut rng).unwrap();
        assert!(word.exact);
        assert_eq!(word.enumerated, 15);
        assert_eq!(word.weight, 59);
        let zeros: Vec<u32> = word
            .values
            .iter()
            .enumerate()
            .filter_map(|(i, q)| q.is_zero().then_some(F64_HONEST_ESIS[i]))
            .collect();
        assert_eq!(zeros, F64_ZERO_ESIS);
        let z = gf4matrix::combine_ambiguity(
            &construction.z_basis,
            &word.coefficient_vector.coefficients(),
            construction.params.l,
        );
        let source = gf4matrix::source_difference(&construction.gsrc, &z);
        assert_eq!(
            source.iter().map(|q| q.code()).collect::<Vec<_>>(),
            F64_SOURCE_DIFF_CODES
        );
    }

    #[test]
    fn split_path_plotkin_search_matches_one_restart_wrapper() {
        let construction = gf4matrix::construct(65);
        let b = gf4matrix::induced_matrix(65, F64_HONEST_ESIS, &construction.z_basis);
        let mut rng = Rng::new(20260829);
        let stages = greedy_path(&b, construction.kappa() - 1, &mut rng, false);
        let split = best_plotkin_for_stages(&b, 64, stages, 0).unwrap();
        let wrapped = search_plotkin(&b, 64, 1, 20260829).unwrap();
        assert_eq!(split.shortening, wrapped.shortening);
        assert_eq!(split.rank, wrapped.rank);
        assert_eq!(split.residual_dimension, wrapped.residual_dimension);
        assert_eq!(split.contradiction, wrapped.contradiction);
    }

    #[test]
    fn split_path_explicit_search_matches_one_restart_wrapper() {
        let construction = gf4matrix::construct(65);
        let b = gf4matrix::induced_matrix(65, F64_HONEST_ESIS, &construction.z_basis);
        let mut rng = Rng::new(20260829);
        let stages = greedy_path(&b, construction.kappa() - 1, &mut rng, false);
        let split = best_explicit_for_stages(&b, 64, stages, 0, 8, &mut rng).unwrap();
        let wrapped = search_explicit_word(&b, 64, 1, 20260829, 8).unwrap();
        assert_eq!(split.shortening, wrapped.shortening);
        assert_eq!(split.rank, wrapped.rank);
        assert_eq!(split.residual_basis.len(), wrapped.residual_basis.len());
        assert_eq!(split.word.weight, wrapped.word.weight);
        assert_eq!(split.word.values, wrapped.word.values);
    }
}
