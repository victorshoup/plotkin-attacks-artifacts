//! Arithmetic in the unique GF(4) subfield of RaptorQ's GF(256).
//!
//! Internally an element `a + b*w` is the two-bit value `a | (b << 1)`, where
//! `w^2 = w + 1`.  The corresponding RFC-6330 octets are 00, 01, d6, d7.

use std::fmt;
use std::ops::{Add, AddAssign, Mul};

#[derive(Clone, Copy, Default, Eq, PartialEq, Hash, Ord, PartialOrd)]
pub struct Gf4(u8);

impl Gf4 {
    pub const ZERO: Self = Self(0);
    pub const ONE: Self = Self(1);
    pub const W: Self = Self(2);
    pub const W2: Self = Self(3);
    pub const ALL: [Self; 4] = [Self::ZERO, Self::ONE, Self::W, Self::W2];
    pub const BYTES: [u8; 4] = [0x00, 0x01, 0xd6, 0xd7];

    #[inline]
    pub const fn from_code(code: u8) -> Self {
        assert!(code < 4);
        Self(code)
    }

    #[inline]
    pub const fn code(self) -> u8 {
        self.0
    }

    #[inline]
    pub const fn to_byte(self) -> u8 {
        Self::BYTES[self.0 as usize]
    }

    pub const fn from_byte(byte: u8) -> Option<Self> {
        match byte {
            0x00 => Some(Self::ZERO),
            0x01 => Some(Self::ONE),
            0xd6 => Some(Self::W),
            0xd7 => Some(Self::W2),
            _ => None,
        }
    }

    #[inline]
    pub const fn inverse(self) -> Self {
        match self.0 {
            1 => Self::ONE,
            2 => Self::W2,
            3 => Self::W,
            _ => panic!("zero has no multiplicative inverse"),
        }
    }

    #[inline]
    pub const fn is_zero(self) -> bool {
        self.0 == 0
    }
}

impl Add for Gf4 {
    type Output = Self;
    #[inline]
    fn add(self, rhs: Self) -> Self {
        // Addition in characteristic two is coefficient-wise XOR.
        Self(self.0 ^ rhs.0)
    }
}

impl AddAssign for Gf4 {
    #[inline]
    fn add_assign(&mut self, rhs: Self) {
        self.0 ^= rhs.0;
    }
}

impl Mul for Gf4 {
    type Output = Self;
    #[inline]
    fn mul(self, rhs: Self) -> Self {
        let a = self.0 & 1;
        let b = (self.0 >> 1) & 1;
        let c = rhs.0 & 1;
        let d = (rhs.0 >> 1) & 1;
        // (a+bw)(c+dw) = (ac+bd) + (ad+bc+bd)w, since w^2=w+1.
        let lo = (a & c) ^ (b & d);
        let hi = (a & d) ^ (b & c) ^ (b & d);
        Self(lo | (hi << 1))
    }
}

impl fmt::Debug for Gf4 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl fmt::Display for Gf4 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.0 {
            0 => write!(f, "0"),
            1 => write!(f, "1"),
            2 => write!(f, "w"),
            3 => write!(f, "w^2"),
            _ => unreachable!(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use raptorq::Octet;

    #[test]
    fn addition_table_and_characteristic_two() {
        for a in Gf4::ALL {
            assert_eq!(a + Gf4::ZERO, a);
            assert_eq!(a + a, Gf4::ZERO);
        }
        assert_eq!(Gf4::W + Gf4::ONE, Gf4::W2);
    }

    #[test]
    fn multiplication_inverses_and_defining_polynomial() {
        assert_eq!(Gf4::W * Gf4::W, Gf4::W + Gf4::ONE);
        for a in [Gf4::ONE, Gf4::W, Gf4::W2] {
            assert_eq!(a * a.inverse(), Gf4::ONE);
        }
    }

    #[test]
    fn embedding_is_closed_and_matches_vendored_gf256() {
        for a in Gf4::ALL {
            assert_eq!(Gf4::from_byte(a.to_byte()), Some(a));
            for b in Gf4::ALL {
                let sum = a + b;
                let product = a * b;
                assert!(Gf4::from_byte(sum.to_byte()).is_some());
                assert!(Gf4::from_byte(product.to_byte()).is_some());
                let octet_product = Octet::new(a.to_byte()) * Octet::new(b.to_byte());
                assert_eq!(octet_product.byte(), product.to_byte());
                assert_eq!(a.to_byte() ^ b.to_byte(), sum.to_byte());
            }
        }
        assert_eq!(Octet::alpha(85).byte(), Gf4::W.to_byte());
    }
}
