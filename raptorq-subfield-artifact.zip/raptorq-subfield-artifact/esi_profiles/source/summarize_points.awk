BEGIN { FS=OFS="," }
NR==1 {for(i=1;i<=NF;i++)c[$i]=i;next}
{
    key=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP \
        $(c["f"]) SUBSEP $(c["Delta"])
    campaign[key]=$(c["campaign"]); profile[key]=$(c["profile"])
    field[key]=$(c["field"]); f[key]=$(c["f"]); delta[key]=$(c["Delta"])
    K[key]=$(c["K"]); kappa[key]=$(c["kappa"])
    sys=$(c["systematic_count"])+0
    if(!(key in minsys)||sys<minsys[key])minsys[key]=sys
    if(sys>maxsys[key])maxsys[key]=sys
    sysval[key SUBSEP (++n[key])]=sys; sumsys[key]+=sys
    success[key]+=$(c["success"])
    zero[key]+=$(c["initial_zero_rows"])
    classes[key]+=$(c["initial_nonzero_projective_classes"])
    largest[key]+=$(c["initial_largest_projective_class"])
    class2[key]+=$(c["initial_projective_classes_at_least_two"])
    rows2[key]+=$(c["initial_rows_in_nontrivial_projective_classes"])
    searchms[key]+=$(c["search_ms"])
}
END {
    print "campaign,profile,field,f,Delta,K,kappa,samples,successes,success_fraction,systematic_min,systematic_mean,systematic_median,systematic_max,hypergeometric_expectation,hypergeometric_sd,mean_standard_error,mean_minus_expectation,z_score,initial_zero_rows_mean,initial_nonzero_projective_classes_mean,initial_largest_projective_class_mean,initial_projective_classes_at_least_two_mean,initial_rows_in_nontrivial_projective_classes_mean,mean_search_ms,total_search_ms"
    for(key in n){
        for(i=2;i<=n[key];i++){
            v=sysval[key SUBSEP i];j=i-1
            while(j>=1&&sysval[key SUBSEP j]>v){sysval[key SUBSEP (j+1)]=sysval[key SUBSEP j];j--}
            sysval[key SUBSEP (j+1)]=v
        }
        if(n[key]%2)median=sysval[key SUBSEP ((n[key]+1)/2)]
        else median=(sysval[key SUBSEP (n[key]/2)]+sysval[key SUBSEP (n[key]/2+1)])/2
        N=3*f[key]+1; draws=2*f[key]+1
        expectation=profile[key]=="canonical" ? draws*K[key]/N : 0
        variance=profile[key]=="canonical" ? draws*(K[key]/N)*(1-K[key]/N)*((N-draws)/(N-1)) : 0
        sd=sqrt(variance); se=sd/sqrt(n[key]); diff=sumsys[key]/n[key]-expectation
        z=se>0?diff/se:0
        printf "%s,%s,%d,%d,%d,%d,%d,%d,%d,%.6f,%d,%.6f,%.3f,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.3f\n",
            campaign[key],profile[key],field[key],f[key],delta[key],K[key],kappa[key],n[key],success[key],success[key]/n[key],minsys[key],sumsys[key]/n[key],median,maxsys[key],expectation,sd,se,diff,z,zero[key]/n[key],classes[key]/n[key],largest[key]/n[key],class2[key]/n[key],rows2[key]/n[key],searchms[key]/n[key],searchms[key]
    }
}

