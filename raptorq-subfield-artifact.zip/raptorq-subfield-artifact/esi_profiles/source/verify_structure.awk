BEGIN{FS=OFS=","}
FILENAME==instances{
 if(FNR==1){delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
 key=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["sample"])
 if($(c["minimum_word_weight"])>=0){valid[key]=1;expected_zero[key]=$(c["number_of_zero_honest_ESIs"]);expected_success[key]=$(c["success"])}
 if($(c["success"])==1)must[key]=1
 next
}
FNR==1{delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
{
 key=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["sample"])
 if(!(key in valid)||seen[key]++||$(c["zero_count"])!=expected_zero[key]||
    $(c["success"])!=expected_success[key]||
    $(c["zero_count"])-$(c["rank_B_Z"])!=$(c["total_saving"])||
    $(c["zero_count"])-$(c["rank_G_Z"])!=$(c["raw_LT_saving"])||
    $(c["rank_G_Z"])-$(c["rank_B_Z"])!=$(c["restriction_loss"])||
    $(c["total_saving"])!=$(c["raw_LT_saving"])+$(c["restriction_loss"]))exit 2
 if($(c["field"])==256){
  if($(c["restricted_rank_identity_ok"])!=1||$(c["intersection_identity_ok"])!=1||
     $(c["intersection_dimension"])!=$(c["restriction_loss"]))exit 2
 }else if($(c["restricted_rank_identity_ok"])!=-1||$(c["intersection_identity_ok"])!=-1)exit 2
 ++rows
}
END{
 for(key in valid)if(!seen[key])exit 2
 for(key in must)if(!seen[key])exit 2
 print "STRUCTURE VERIFICATION PASS: rows=" rows > "/dev/stderr"
}

