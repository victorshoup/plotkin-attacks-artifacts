BEGIN{FS=OFS=","}
NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
$(c["campaign"])=="delta0"{
 q=$(c["field"]);f=$(c["f"])
 val[q SUBSEP "full-domain" SUBSEP f]=$(c["full_domain_successes"])
 val[q SUBSEP "canonical" SUBSEP f]=$(c["canonical_successes"])
 val[q SUBSEP "low-repair" SUBSEP f]=$(c["low_repair_successes"])
 if(!(q in minf)||f<minf[q])minf[q]=f;if(f>maxf[q])maxf[q]=f
}
END{
 print "field,profile,sampled_f_min,sampled_f_max,first_any_success_f,first_at_least_5_f,first_at_least_10_f"
 split("full-domain canonical low-repair",p," ")
 for(q in minf)for(i=1;i<=3;i++){
  any=five=ten=""
  for(f=minf[q];f<=maxf[q];f++){
   s=val[q SUBSEP p[i] SUBSEP f]
   if(any==""&&s>=1)any=f;if(five==""&&s>=5)five=f;if(ten==""&&s>=10)ten=f
  }
  print q,p[i],minf[q],maxf[q],any,five,ten
 }
}

