BEGIN { FS=OFS="," }
NR==1 {
    for (i=1;i<=NF;i++) c[$i]=i
    next
}
$(c["profile"])=="canonical" || $(c["profile"])=="low-repair" {
    instance=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP \
        $(c["Delta"]) SUBSEP $(c["sample"])
    point=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP \
        $(c["Delta"]) SUBSEP $(c["K"])
    profile=$(c["profile"])
    result[instance SUBSEP profile]=$(c["success"])+0
    point_for[instance]=point
    if (!(instance in seen_instance)) {
        seen_instance[instance]=1
        instances[++instance_count]=instance
    }
    if (!(point in seen_point)) {
        seen_point[point]=1
        points[++point_count]=point
    }
}
END {
    for (i=1;i<=instance_count;i++) {
        instance=instances[i]
        point=point_for[instance]
        cval=result[instance SUBSEP "canonical"]
        lval=result[instance SUBSEP "low-repair"]
        if ((instance SUBSEP "canonical") in result &&
            (instance SUBSEP "low-repair") in result) {
            samples[point]++
            canonical[point]+=cval
            low[point]+=lval
            if (cval && lval) both[point]++
            else if (cval) conly[point]++
            else if (lval) lonly[point]++
            else neither[point]++
        }
    }
    print "campaign","field","f","Delta","K","paired_samples", \
        "both_success","canonical_only","low_repair_only","both_failure", \
        "canonical_successes","low_repair_successes","canonical_minus_low_repair"
    for (i=1;i<=point_count;i++) {
        point=points[i]
        split(point,a,SUBSEP)
        if (samples[point])
            print a[1],a[2],a[3],a[4],a[5],samples[point],both[point]+0, \
                conly[point]+0,lonly[point]+0,neither[point]+0, \
                canonical[point]+0,low[point]+0,canonical[point]-low[point]
    }
}
