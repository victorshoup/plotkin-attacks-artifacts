#define main rq_profile_campaign_program_main
#include "rq_profile_campaign.c"
#undef main

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: %s F SAMPLES MASTER_SEED\n", argv[0]);
        return 2;
    }
    int f = parse_int(argv[1]);
    int samples = parse_int(argv[2]);
    uint64_t master_seed = parse_u64(argv[3]);
    int n = 3 * f + 1;
    int h = 2 * f + 1;
    for (int sample = 0; sample < samples; ++sample) {
        uint64_t seed = master_seed
            ^ (uint64_t)f * UINT64_C(0x9e3779b97f4a7c15)
            ^ (uint64_t)sample * UINT64_C(0x85ebca6b27d4eb2f);
        rng64 rng;
        rng_init(&rng, seed);
        uint32_t *positions = xmalloc((size_t)h * sizeof(uint32_t));
        sample_consecutive(positions, (uint32_t)n, h, &rng);
        printf("%d,%d,%" PRIu64 ",%d,", f, sample, seed, h);
        for (int i = 0; i < h; ++i) {
            printf("%s%u", i == 0 ? "" : " ", positions[i]);
        }
        putchar('\n');
        free(positions);
    }
    return 0;
}

