BEGIN{FS=OFS=","}
NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
{
 base=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 add(base SUBSEP "all"); add(base SUBSEP ($(c["success"])?"success":"failure"))
}
function add(key){
 split(key,a,SUBSEP);campaign[key]=a[1];profile[key]=a[2];field[key]=a[3];f[key]=a[4];delta[key]=a[5];group[key]=a[6];K[key]=$(c["K"])
 n[key]++;zero[key]+=$(c["initial_zero_rows"]);classes[key]+=$(c["initial_nonzero_projective_classes"])
 largest[key]+=$(c["initial_largest_projective_class"]);class2[key]+=$(c["initial_projective_classes_at_least_two"])
 rows2[key]+=$(c["initial_rows_in_nontrivial_projective_classes"])
 if($(c["initial_largest_projective_class"])>maxlargest[key])maxlargest[key]=$(c["initial_largest_projective_class"])
}
END{
 print "campaign,profile,field,f,Delta,K,outcome_group,instances,mean_initial_zero_rows,mean_initial_nonzero_projective_classes,mean_initial_largest_projective_class,max_initial_largest_projective_class,mean_initial_projective_classes_at_least_two,mean_initial_rows_in_nontrivial_projective_classes"
 for(key in n)printf "%s,%s,%d,%d,%d,%d,%s,%d,%.6f,%.6f,%.6f,%d,%.6f,%.6f\n",campaign[key],profile[key],field[key],f[key],delta[key],K[key],group[key],n[key],zero[key]/n[key],classes[key]/n[key],largest[key]/n[key],maxlargest[key],class2[key]/n[key],rows2[key]/n[key]
}

