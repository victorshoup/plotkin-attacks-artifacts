#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#include "rq_tables.h"

#define RQ_ESI_DOMAIN (1u << 24)
#define MAX_DEG 40
#define MAX_EXTENSION_DEGREE 4
#define DEGREE_TABLE_COUNT 31

typedef struct {
    int K;
    int Kp;
    int J;
    int S;
    int H;
    int W;
    int L;
    int P;
    int P1;
} rq_params;

typedef struct {
    int q;
    int degree;
    uint8_t elems[256];
    uint8_t decomp[256][MAX_EXTENSION_DEGREE];
} subfield;

typedef struct {
    uint64_t state;
} rng64;

typedef struct {
    uint8_t *rows;
    int nrows;
    int ncols;
} matrix_u8;

typedef struct {
    int rank;
    uint8_t *row_by_pivot;
    uint8_t *has_pivot;
} linear_basis;

typedef struct {
    bool valid;
    bool success;
    int weight;
    int zeros;
    int restart;
    int rank;
    int closure;
    int rank_saving;
    int residual_dimension;
    uint64_t directions_enumerated;
    uint8_t *coefficient_vector;
} candidate;

typedef struct {
    candidate best;
    int first_success_restart;
    int restarts_executed;
    int successful_paths;
    uint64_t projective_steps;
    uint64_t nontrivial_projective_steps;
    uint64_t largest_class_sum;
    uint64_t chosen_class_sum;
    uint64_t projective_saving_sum;
    int largest_class_max;
    int projective_saving_max;
    int canonical_success;
    int canonical_weight;
    int canonical_zero_count;
    int canonical_residual_dimension;
    uint64_t canonical_directions_enumerated;
} search_result;

typedef struct {
    int residual_dimension;
    int rows_represented;
    int rows_already_zero;
    int largest_class_size;
    int maximum_class_count;
    int chosen_class_size;
    int rank_before;
    int rank_after;
    int rows_imposed;
    int rank_consumed;
    int projective_saving;
} path_step;

typedef struct {
    FILE *summary_stream;
    FILE *full_stream;
    bool write_full;
    const char *ensemble;
    int field;
    int f;
    int delta;
    int sample;
    uint64_t instance_seed;
} trace_context;

typedef struct {
    int count;
    int nontrivial_count;
    int *largest;
    int *chosen;
    int *saving;
    int *maximum_class_count;
} dimension_bucket;

typedef struct {
    dimension_bucket all;
    dimension_bucket success;
    dimension_bucket failure;
} dimension_summary;

typedef struct {
    int minimum;
    int median;
    int maximum;
    double mean;
} integer_summary;

static uint8_t gf_exp[512];
static uint8_t gf_log[256];
static uint8_t gf_inv[256];
static uint8_t gf_mul_table[256][256];

static const uint32_t DEGREE_F[DEGREE_TABLE_COUNT] = {
    0, 5243, 529531, 704294, 791675, 844104, 879057, 904023,
    922747, 937311, 948962, 958494, 966438, 973160, 978921,
    983914, 988283, 992138, 995565, 998631, 1001391, 1003887,
    1006157, 1008229, 1010129, 1011876, 1013490, 1014983,
    1016370, 1017662, 1048576
};

static void die(const char *message)
{
    fprintf(stderr, "fatal: %s\n", message);
    exit(2);
}

static void *xmalloc(size_t size)
{
    void *p = malloc(size ? size : 1);
    if (p == NULL) {
        die("out of memory");
    }
    return p;
}

static void *xcalloc(size_t count, size_t size)
{
    void *p = calloc(count ? count : 1, size ? size : 1);
    if (p == NULL) {
        die("out of memory");
    }
    return p;
}

static uint64_t now_ns(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        die("clock_gettime failed");
    }
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}

static void gf256_init(void)
{
    uint16_t x = 1;
    memset(gf_exp, 0, sizeof(gf_exp));
    memset(gf_log, 0, sizeof(gf_log));
    for (int i = 0; i < 255; ++i) {
        gf_exp[i] = (uint8_t)x;
        gf_log[(uint8_t)x] = (uint8_t)i;
        x <<= 1;
        if ((x & 0x100) != 0) {
            x ^= 0x11d;
        }
    }
    for (int i = 255; i < 512; ++i) {
        gf_exp[i] = gf_exp[i - 255];
    }
    gf_inv[0] = 0;
    for (int a = 1; a < 256; ++a) {
        gf_inv[a] = gf_exp[255 - gf_log[a]];
    }
    for (int a = 0; a < 256; ++a) {
        for (int b = 0; b < 256; ++b) {
            gf_mul_table[a][b] = (a == 0 || b == 0)
                ? 0
                : gf_exp[(int)gf_log[a] + (int)gf_log[b]];
        }
    }
}

static inline uint8_t gf_mul(uint8_t a, uint8_t b)
{
    return gf_mul_table[a][b];
}

static bool is_prime(int n)
{
    if (n < 2) {
        return false;
    }
    if ((n & 1) == 0) {
        return n == 2;
    }
    for (int d = 3; (int64_t)d * d <= n; d += 2) {
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

static rq_params get_params(int K)
{
    if (K <= 0 || K > 56403) {
        die("K outside RFC 6330 range");
    }
    for (size_t i = 0; i < RQ_PARAMS_COUNT; ++i) {
        if ((int)RQ_PARAMS[i].kp >= K) {
            rq_params p;
            memset(&p, 0, sizeof(p));
            p.K = K;
            p.Kp = (int)RQ_PARAMS[i].kp;
            p.J = (int)RQ_PARAMS[i].J;
            p.S = (int)RQ_PARAMS[i].S;
            p.H = (int)RQ_PARAMS[i].H;
            p.W = (int)RQ_PARAMS[i].W;
            p.L = p.Kp + p.S + p.H;
            p.P = p.L - p.W;
            p.P1 = p.P;
            while (!is_prime(p.P1)) {
                ++p.P1;
            }
            return p;
        }
    }
    die("no RFC systematic parameter row");
    rq_params zero;
    memset(&zero, 0, sizeof(zero));
    return zero;
}

static uint32_t rq_rand(uint32_t y, uint32_t i, uint32_t m)
{
    if (m == 0) {
        die("RFC Rand modulus is zero");
    }
    uint32_t x0 = (y + i) & 255u;
    uint32_t x1 = ((y >> 8) + i) & 255u;
    uint32_t x2 = ((y >> 16) + i) & 255u;
    uint32_t x3 = ((y >> 24) + i) & 255u;
    return (V0[x0] ^ V1[x1] ^ V2[x2] ^ V3[x3]) % m;
}

static int rq_degree(uint32_t v, int W)
{
    for (int d = 1; d < DEGREE_TABLE_COUNT; ++d) {
        if (v < DEGREE_F[d]) {
            int cap = W - 2;
            return d < cap ? d : cap;
        }
    }
    die("degree lookup failed");
    return 0;
}

static int encoding_indices(uint32_t internal_symbol_id,
                            const rq_params *p,
                            int out[MAX_DEG])
{
    uint32_t A = 53591u + (uint32_t)p->J * 997u;
    if ((A & 1u) == 0) {
        ++A;
    }
    uint32_t B = 10267u * ((uint32_t)p->J + 1u);
    uint32_t y = B + internal_symbol_id * A;
    int d = rq_degree(rq_rand(y, 0, 1048576u), p->W);
    uint32_t a = 1u + rq_rand(y, 1, (uint32_t)p->W - 1u);
    uint32_t b = rq_rand(y, 2, (uint32_t)p->W);
    int d1 = d < 4 ? 2 + (int)rq_rand(internal_symbol_id, 3, 2) : 2;
    uint32_t a1 = 1u + rq_rand(internal_symbol_id, 4, (uint32_t)p->P1 - 1u);
    uint32_t b1 = rq_rand(internal_symbol_id, 5, (uint32_t)p->P1);

    int n = 0;
    out[n++] = (int)b;
    for (int j = 1; j < d; ++j) {
        b = (b + a) % (uint32_t)p->W;
        out[n++] = (int)b;
    }
    while ((int)b1 >= p->P) {
        b1 = (b1 + a1) % (uint32_t)p->P1;
    }
    out[n++] = p->W + (int)b1;
    for (int j = 1; j < d1; ++j) {
        b1 = (b1 + a1) % (uint32_t)p->P1;
        while ((int)b1 >= p->P) {
            b1 = (b1 + a1) % (uint32_t)p->P1;
        }
        out[n++] = p->W + (int)b1;
    }
    if (n > MAX_DEG) {
        die("encoding degree overflow");
    }
    return n;
}

static void encoding_row_dense(uint32_t internal_symbol_id,
                               const rq_params *p,
                               uint8_t *row)
{
    int indices[MAX_DEG];
    memset(row, 0, (size_t)p->L);
    int count = encoding_indices(internal_symbol_id, p, indices);
    for (int i = 0; i < count; ++i) {
        row[indices[i]] = 1;
    }
}

static uint32_t esi_to_isi(uint32_t esi, const rq_params *p)
{
    return esi < (uint32_t)p->K
        ? esi
        : esi + (uint32_t)(p->Kp - p->K);
}

static uint8_t *build_constraint_matrix(const rq_params *p)
{
    int L = p->L;
    int S = p->S;
    int H = p->H;
    int W = p->W;
    int P = p->P;
    int Kp = p->Kp;
    int B = W - S;
    uint8_t *A = xcalloc((size_t)L * L, 1);
#define AAT(r, c) A[(size_t)(r) * L + (c)]

    for (int i = 0; i < B; ++i) {
        int a = 1 + i / S;
        int b = i % S;
        AAT(b, i) = 1;
        b = (b + a) % S;
        AAT(b, i) = 1;
        b = (b + a) % S;
        AAT(b, i) = 1;
    }
    for (int i = 0; i < S; ++i) {
        AAT(i, i + B) = 1;
    }
    for (int i = 0; i < S; ++i) {
        AAT(i, (i % P) + W) = 1;
        AAT(i, ((i + 1) % P) + W) = 1;
    }

    uint8_t *hdpc = xcalloc((size_t)H * (Kp + S), 1);
#define HD(r, c) hdpc[(size_t)(r) * (Kp + S) + (c)]
    for (int i = 0; i < H; ++i) {
        HD(i, Kp + S - 1) = gf_exp[i];
    }
    for (int j = Kp + S - 2; j >= 0; --j) {
        for (int i = 0; i < H; ++i) {
            HD(i, j) = gf_mul(2, HD(i, j + 1));
        }
        int rand6 = (int)rq_rand((uint32_t)j + 1u, 6, (uint32_t)H);
        int rand7 = (int)rq_rand((uint32_t)j + 1u, 7, (uint32_t)H - 1u);
        int i1 = rand6;
        int i2 = (rand6 + rand7 + 1) % H;
        HD(i1, j) ^= 1;
        HD(i2, j) ^= 1;
    }
    for (int i = 0; i < H; ++i) {
        memcpy(&AAT(S + i, 0), &HD(i, 0), (size_t)(Kp + S));
        AAT(S + i, Kp + S + i) = 1;
    }
    free(hdpc);

    uint8_t *row = xmalloc((size_t)L);
    for (int x = 0; x < Kp; ++x) {
        encoding_row_dense((uint32_t)x, p, row);
        memcpy(&AAT(S + H + x, 0), row, (size_t)L);
    }
    free(row);
#undef HD
#undef AAT
    return A;
}

static int log2_exact_q(int q)
{
    if (q == 4) {
        return 2;
    }
    if (q == 16) {
        return 4;
    }
    if (q == 256) {
        return 8;
    }
    die("field must be 4, 16, or 256");
    return 0;
}

static void subfield_init(subfield *sf, int q)
{
    memset(sf, 0, sizeof(*sf));
    sf->q = q;
    int bits = log2_exact_q(q);
    sf->degree = 8 / bits;
    sf->elems[0] = 0;
    int step = 255 / (q - 1);
    for (int i = 0; i < q - 1; ++i) {
        sf->elems[i + 1] = gf_exp[i * step];
    }

    bool seen[256];
    memset(seen, 0, sizeof(seen));
    uint64_t combinations = 1;
    for (int t = 0; t < sf->degree; ++t) {
        combinations *= (uint64_t)q;
    }
    if (combinations != 256) {
        die("subfield decomposition does not have 256 tuples");
    }
    for (uint64_t code = 0; code < combinations; ++code) {
        uint64_t z = code;
        uint8_t value = 0;
        uint8_t coords[MAX_EXTENSION_DEGREE] = {0, 0, 0, 0};
        for (int t = 0; t < sf->degree; ++t) {
            int digit = (int)(z % (uint64_t)q);
            z /= (uint64_t)q;
            coords[t] = sf->elems[digit];
            uint8_t basis_element = gf_exp[t];
            value ^= gf_mul(coords[t], basis_element);
        }
        if (seen[value]) {
            die("subfield basis is not independent");
        }
        seen[value] = true;
        memcpy(sf->decomp[value], coords, (size_t)sf->degree);
    }
    for (int value = 0; value < 256; ++value) {
        if (!seen[value]) {
            die("subfield decomposition does not span GF(256)");
        }
        uint8_t reconstructed = 0;
        for (int t = 0; t < sf->degree; ++t) {
            reconstructed ^= gf_mul(sf->decomp[value][t], gf_exp[t]);
        }
        if (reconstructed != (uint8_t)value) {
            die("subfield decomposition reconstruction failed");
        }
    }

    for (int i = 0; i < q; ++i) {
        for (int j = 0; j < q; ++j) {
            uint8_t a = sf->elems[i];
            uint8_t b = sf->elems[j];
            uint8_t sum = a ^ b;
            uint8_t product = gf_mul(a, b);
            bool sum_ok = false;
            bool product_ok = false;
            for (int k = 0; k < q; ++k) {
                sum_ok |= sf->elems[k] == sum;
                product_ok |= sf->elems[k] == product;
            }
            if (!sum_ok || !product_ok) {
                die("subfield closure failure");
            }
        }
    }
}

static void basis_init(linear_basis *basis, int ncols)
{
    basis->rank = 0;
    basis->row_by_pivot = xcalloc((size_t)ncols * ncols, 1);
    basis->has_pivot = xcalloc((size_t)ncols, 1);
}

static void basis_free(linear_basis *basis)
{
    free(basis->row_by_pivot);
    free(basis->has_pivot);
    memset(basis, 0, sizeof(*basis));
}

static int basis_add(linear_basis *basis, const uint8_t *row, int ncols)
{
    uint8_t *v = xmalloc((size_t)ncols);
    memcpy(v, row, (size_t)ncols);

    for (int pivot = 0; pivot < ncols; ++pivot) {
        if (basis->has_pivot[pivot] && v[pivot] != 0) {
            uint8_t scale = v[pivot];
            const uint8_t *basis_row =
                basis->row_by_pivot + (size_t)pivot * ncols;
            for (int j = pivot; j < ncols; ++j) {
                v[j] ^= gf_mul(scale, basis_row[j]);
            }
        }
    }

    int pivot_col = -1;
    for (int j = 0; j < ncols; ++j) {
        if (v[j] != 0) {
            pivot_col = j;
            break;
        }
    }
    if (pivot_col < 0) {
        free(v);
        return 0;
    }

    uint8_t inverse = gf_inv[v[pivot_col]];
    for (int j = pivot_col; j < ncols; ++j) {
        v[j] = gf_mul(v[j], inverse);
    }

    for (int pivot = 0; pivot < ncols; ++pivot) {
        if (!basis->has_pivot[pivot]) {
            continue;
        }
        uint8_t *basis_row =
            basis->row_by_pivot + (size_t)pivot * ncols;
        uint8_t scale = basis_row[pivot_col];
        if (scale == 0) {
            continue;
        }
        basis_row[pivot_col] = 0;
        for (int j = pivot_col + 1; j < ncols; ++j) {
            basis_row[j] ^= gf_mul(scale, v[j]);
        }
    }

    memcpy(basis->row_by_pivot + (size_t)pivot_col * ncols,
           v,
           (size_t)ncols);
    basis->has_pivot[pivot_col] = 1;
    ++basis->rank;
    free(v);
    return 1;
}

static uint8_t *basis_kernel(const linear_basis *basis,
                             int ncols,
                             int *dimension_out)
{
    int dimension = ncols - basis->rank;
    uint8_t *kernel = xcalloc((size_t)dimension * ncols, 1);
    int index = 0;
    for (int free_col = 0; free_col < ncols; ++free_col) {
        if (basis->has_pivot[free_col]) {
            continue;
        }
        uint8_t *x = kernel + (size_t)index * ncols;
        x[free_col] = 1;
        for (int pivot = 0; pivot < ncols; ++pivot) {
            if (basis->has_pivot[pivot]) {
                x[pivot] = basis->row_by_pivot[(size_t)pivot * ncols + free_col];
            }
        }
        ++index;
    }
    if (index != dimension) {
        die("kernel dimension mismatch");
    }
    *dimension_out = dimension;
    return kernel;
}

static int matrix_rank(const matrix_u8 *matrix)
{
    linear_basis basis;
    basis_init(&basis, matrix->ncols);
    for (int i = 0; i < matrix->nrows; ++i) {
        basis_add(&basis,
                  matrix->rows + (size_t)i * matrix->ncols,
                  matrix->ncols);
    }
    int rank = basis.rank;
    basis_free(&basis);
    return rank;
}

static uint8_t dot_product(const uint8_t *a, const uint8_t *b, int n)
{
    uint8_t sum = 0;
    for (int i = 0; i < n; ++i) {
        if (a[i] != 0 && b[i] != 0) {
            sum ^= gf_mul(a[i], b[i]);
        }
    }
    return sum;
}

static matrix_u8 build_subfield_constraints(const rq_params *p,
                                             const subfield *sf)
{
    uint8_t *full = build_constraint_matrix(p);
    int rows = p->S + sf->degree * p->H + (p->Kp - p->K);
    matrix_u8 constraints;
    constraints.nrows = rows;
    constraints.ncols = p->L;
    constraints.rows = xcalloc((size_t)rows * p->L, 1);
    int out = 0;

    for (int r = 0; r < p->S; ++r) {
        memcpy(constraints.rows + (size_t)out * p->L,
               full + (size_t)r * p->L,
               (size_t)p->L);
        ++out;
    }

    for (int h = 0; h < p->H; ++h) {
        const uint8_t *hdpc = full + (size_t)(p->S + h) * p->L;
        for (int coordinate = 0; coordinate < sf->degree; ++coordinate) {
            uint8_t *target = constraints.rows + (size_t)out * p->L;
            for (int j = 0; j < p->L; ++j) {
                target[j] = sf->decomp[hdpc[j]][coordinate];
            }
            ++out;
        }
    }

    for (int isi = p->K; isi < p->Kp; ++isi) {
        const uint8_t *padding =
            full + (size_t)(p->S + p->H + isi) * p->L;
        memcpy(constraints.rows + (size_t)out * p->L,
               padding,
               (size_t)p->L);
        ++out;
    }

    free(full);
    if (out != rows) {
        die("subfield constraint row count mismatch");
    }
    return constraints;
}

static uint8_t *kernel_basis_of_matrix(const matrix_u8 *matrix,
                                       int *dimension_out)
{
    linear_basis basis;
    basis_init(&basis, matrix->ncols);
    for (int r = 0; r < matrix->nrows; ++r) {
        basis_add(&basis,
                  matrix->rows + (size_t)r * matrix->ncols,
                  matrix->ncols);
    }
    uint8_t *kernel = basis_kernel(&basis, matrix->ncols, dimension_out);
    basis_free(&basis);
    return kernel;
}

static uint8_t *kernel_basis_with_expected_dimension(const matrix_u8 *matrix,
                                                     int expected_dimension)
{
    linear_basis basis;
    basis_init(&basis, matrix->ncols);
    for (int r = 0; r < matrix->nrows; ++r) {
        basis_add(&basis,
                  matrix->rows + (size_t)r * matrix->ncols,
                  matrix->ncols);
    }
    if (matrix->ncols - basis.rank != expected_dimension) {
        die("intermediate-code basis dimension check failed");
    }
    int basis_dimension = 0;
    uint8_t *kernel = basis_kernel(&basis,
                                   matrix->ncols,
                                   &basis_dimension);
    if (basis_dimension != expected_dimension) {
        die("intermediate-code basis construction failed");
    }
    basis_free(&basis);
    return kernel;
}

static matrix_u8 build_induced_rows(const rq_params *p,
                                    const uint8_t *ambiguity_basis,
                                    int kappa,
                                    const uint32_t *esis,
                                    int count)
{
    matrix_u8 matrix;
    matrix.nrows = count;
    matrix.ncols = kappa;
    matrix.rows = xcalloc((size_t)count * kappa, 1);
    int indices[MAX_DEG];

    for (int r = 0; r < count; ++r) {
        uint32_t isi = esi_to_isi(esis[r], p);
        int degree = encoding_indices(isi, p, indices);
        uint8_t *target = matrix.rows + (size_t)r * kappa;
        for (int b = 0; b < kappa; ++b) {
            const uint8_t *z = ambiguity_basis + (size_t)b * p->L;
            uint8_t value = 0;
            for (int t = 0; t < degree; ++t) {
                value ^= z[indices[t]];
            }
            target[b] = value;
        }
    }
    return matrix;
}

static matrix_u8 build_source_projection(const rq_params *p,
                                         const uint8_t *ambiguity_basis,
                                         int kappa)
{
    uint32_t *source_esis = xmalloc((size_t)p->K * sizeof(uint32_t));
    for (int i = 0; i < p->K; ++i) {
        source_esis[i] = (uint32_t)i;
    }
    matrix_u8 source = build_induced_rows(p,
                                          ambiguity_basis,
                                          kappa,
                                          source_esis,
                                          p->K);
    free(source_esis);
    return source;
}

static void free_matrix(matrix_u8 *matrix)
{
    free(matrix->rows);
    matrix->rows = NULL;
    matrix->nrows = 0;
    matrix->ncols = 0;
}

/* Exact RNG used by the Rust GF(4) campaign. */
static void rng_init(rng64 *rng, uint64_t seed)
{
    rng->state = seed ^ UINT64_C(0x9e3779b97f4a7c15);
}

static uint64_t rng_next(rng64 *rng)
{
    uint64_t x = rng->state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    rng->state = x;
    return x * UINT64_C(0x2545f4914f6cdd1d);
}

static size_t rng_below(rng64 *rng, size_t n)
{
    if (n == 0) {
        die("rng_below n=0");
    }
    return (size_t)(rng_next(rng) % (uint64_t)n);
}

static size_t rng_below_uniform(rng64 *rng, size_t n)
{
    if (n == 0) {
        die("rng_below_uniform n=0");
    }
    uint64_t nn = (uint64_t)n;
    uint64_t threshold = (uint64_t)(0 - nn) % nn;
    for (;;) {
        uint64_t value = rng_next(rng);
        if (value >= threshold) {
            return (size_t)(value % nn);
        }
    }
}

static int compare_u32(const void *aa, const void *bb)
{
    uint32_t a = *(const uint32_t *)aa;
    uint32_t b = *(const uint32_t *)bb;
    return (a > b) - (a < b);
}

/* Partial Fisher-Yates with rejection sampling for exact uniformity. */
static void sample_consecutive(uint32_t *out,
                               uint32_t domain_size,
                               int size,
                               rng64 *rng)
{
    if (size < 0 || (uint32_t)size > domain_size) {
        die("invalid consecutive sample size");
    }
    uint32_t *pool = xmalloc((size_t)domain_size * sizeof(uint32_t));
    for (uint32_t i = 0; i < domain_size; ++i) {
        pool[i] = i;
    }
    for (int i = 0; i < size; ++i) {
        int j = i + (int)rng_below_uniform(rng,
                                           (size_t)domain_size - (size_t)i);
        uint32_t tmp = pool[i];
        pool[i] = pool[j];
        pool[j] = tmp;
    }
    memcpy(out, pool, (size_t)size * sizeof(uint32_t));
    qsort(out, (size_t)size, sizeof(uint32_t), compare_u32);
    free(pool);
}

static void canonical_projective(uint8_t *row, int ncols)
{
    int first = -1;
    for (int j = 0; j < ncols; ++j) {
        if (row[j] != 0) {
            first = j;
            break;
        }
    }
    if (first < 0) {
        return;
    }
    uint8_t inverse = gf_inv[row[first]];
    for (int j = first; j < ncols; ++j) {
        row[j] = gf_mul(row[j], inverse);
    }
}

static bool row_is_zero(const uint8_t *row, int ncols)
{
    for (int j = 0; j < ncols; ++j) {
        if (row[j] != 0) {
            return false;
        }
    }
    return true;
}

static int row_first_nonzero(const uint8_t *row, int ncols)
{
    for (int j = 0; j < ncols; ++j) {
        if (row[j] != 0) {
            return j;
        }
    }
    return -1;
}

static int lexicographic_compare(const uint8_t *a, const uint8_t *b, int ncols)
{
    for (int j = 0; j < ncols; ++j) {
        if (a[j] < b[j]) {
            return -1;
        }
        if (a[j] > b[j]) {
            return 1;
        }
    }
    return 0;
}

typedef struct {
    uint8_t *key;
    int *members;
    int member_count;
    int member_capacity;
} projective_group;

static void group_add_member(projective_group *group, int member)
{
    if (group->member_count == group->member_capacity) {
        int new_capacity = group->member_capacity == 0 ? 4 : 2 * group->member_capacity;
        int *new_members = realloc(group->members,
                                   (size_t)new_capacity * sizeof(int));
        if (new_members == NULL) {
            die("out of memory growing projective group");
        }
        group->members = new_members;
        group->member_capacity = new_capacity;
    }
    group->members[group->member_count++] = member;
}

static void free_groups(projective_group *groups, int count)
{
    for (int i = 0; i < count; ++i) {
        free(groups[i].key);
        free(groups[i].members);
    }
    free(groups);
}

static projective_group *build_projective_groups(const uint8_t *residual,
                                                  int nrows,
                                                  int ncols,
                                                  int *count_out)
{
    projective_group *groups = xcalloc((size_t)nrows, sizeof(projective_group));
    int group_count = 0;
    for (int i = 0; i < nrows; ++i) {
        const uint8_t *row = residual + (size_t)i * ncols;
        if (row_is_zero(row, ncols)) {
            continue;
        }
        uint8_t *key = xmalloc((size_t)ncols);
        memcpy(key, row, (size_t)ncols);
        canonical_projective(key, ncols);
        int found = -1;
        for (int g = 0; g < group_count; ++g) {
            if (memcmp(groups[g].key, key, (size_t)ncols) == 0) {
                found = g;
                break;
            }
        }
        if (found < 0) {
            found = group_count++;
            groups[found].key = key;
            key = NULL;
        }
        free(key);
        group_add_member(&groups[found], i);
    }
    *count_out = group_count;
    return groups;
}

typedef struct {
    int zero_rows;
    int nonzero_classes;
    int largest_class;
    int classes_at_least_two;
    int rows_in_nontrivial_classes;
} initial_projective_stats;

static initial_projective_stats describe_initial_projective_structure(
    const matrix_u8 *matrix)
{
    initial_projective_stats stats;
    memset(&stats, 0, sizeof(stats));
    int group_count = 0;
    projective_group *groups = build_projective_groups(matrix->rows,
                                                       matrix->nrows,
                                                       matrix->ncols,
                                                       &group_count);
    stats.nonzero_classes = group_count;
    for (int r = 0; r < matrix->nrows; ++r) {
        stats.zero_rows += row_is_zero(matrix->rows +
                                           (size_t)r * matrix->ncols,
                                       matrix->ncols);
    }
    for (int g = 0; g < group_count; ++g) {
        int size = groups[g].member_count;
        if (size > stats.largest_class) stats.largest_class = size;
        if (size >= 2) {
            ++stats.classes_at_least_two;
            stats.rows_in_nontrivial_classes += size;
        }
    }
    free_groups(groups, group_count);
    return stats;
}

static int choose_best_group(const projective_group *groups,
                             int group_count,
                             int ncols,
                             rng64 *rng,
                             bool random_ties)
{
    int best_size = 0;
    for (int g = 0; g < group_count; ++g) {
        if (groups[g].member_count > best_size) {
            best_size = groups[g].member_count;
        }
    }
    if (best_size == 0) {
        return -1;
    }

    int *ties = xmalloc((size_t)group_count * sizeof(int));
    int tie_count = 0;
    for (int g = 0; g < group_count; ++g) {
        if (groups[g].member_count == best_size) {
            ties[tie_count++] = g;
        }
    }

    /* Rust sorts projective keys before choosing the first or a random tie. */
    for (int i = 1; i < tie_count; ++i) {
        int g = ties[i];
        int j = i - 1;
        while (j >= 0 &&
               lexicographic_compare(groups[g].key,
                                     groups[ties[j]].key,
                                     ncols) < 0) {
            ties[j + 1] = ties[j];
            --j;
        }
        ties[j + 1] = g;
    }

    int selected = random_ties
        ? ties[rng_below(rng, (size_t)tie_count)]
        : ties[0];
    free(ties);
    return selected;
}

static int closure_indices(const uint8_t *residual,
                           int nrows,
                           int ncols,
                           int *indices)
{
    int count = 0;
    for (int i = 0; i < nrows; ++i) {
        if (row_is_zero(residual + (size_t)i * ncols, ncols)) {
            indices[count++] = i;
        }
    }
    return count;
}

static uint8_t *kernel_from_closure(const matrix_u8 *original,
                                    const int *closure,
                                    int closure_count,
                                    int *dimension_out,
                                    int *rank_out)
{
    linear_basis basis;
    basis_init(&basis, original->ncols);
    for (int i = 0; i < closure_count; ++i) {
        basis_add(&basis,
                  original->rows + (size_t)closure[i] * original->ncols,
                  original->ncols);
    }
    int dimension = 0;
    uint8_t *kernel = basis_kernel(&basis, original->ncols, &dimension);
    if (rank_out != NULL) {
        *rank_out = basis.rank;
    }
    *dimension_out = dimension;
    basis_free(&basis);
    return kernel;
}

static uint64_t checked_power_u64(uint64_t base, int exponent, bool *ok)
{
    uint64_t value = 1;
    *ok = true;
    for (int i = 0; i < exponent; ++i) {
        if (base != 0 && value > UINT64_MAX / base) {
            *ok = false;
            return 0;
        }
        value *= base;
    }
    return value;
}

static uint64_t projective_direction_count(int q, int dimension, bool *ok)
{
    uint64_t power = checked_power_u64((uint64_t)q, dimension, ok);
    if (!*ok || power == 0) {
        return 0;
    }
    return (power - 1) / (uint64_t)(q - 1);
}

static bool candidate_better(const candidate *new_candidate,
                             const candidate *old_candidate,
                             int target_weight)
{
    if (!old_candidate->valid) {
        return true;
    }
    bool new_success = new_candidate->weight <= target_weight;
    bool old_success = old_candidate->weight <= target_weight;
    if (new_success != old_success) {
        return new_success;
    }
    if (new_candidate->weight != old_candidate->weight) {
        return new_candidate->weight < old_candidate->weight;
    }
    if (new_candidate->rank_saving != old_candidate->rank_saving) {
        return new_candidate->rank_saving > old_candidate->rank_saving;
    }
    return new_candidate->rank < old_candidate->rank;
}

static candidate enumerate_stage(const matrix_u8 *original,
                                 const subfield *sf,
                                 const int *closure,
                                 int closure_count,
                                 int restart,
                                 uint64_t max_directions)
{
    candidate result;
    memset(&result, 0, sizeof(result));
    result.weight = original->nrows + 1;
    result.restart = restart;

    int residual_dimension = 0;
    int shortening_rank = 0;
    uint8_t *kernel = kernel_from_closure(original,
                                          closure,
                                          closure_count,
                                          &residual_dimension,
                                          &shortening_rank);
    if (residual_dimension <= 0) {
        free(kernel);
        return result;
    }

    bool count_ok = false;
    uint64_t directions = projective_direction_count(sf->q,
                                                      residual_dimension,
                                                      &count_ok);
    if (!count_ok || directions > max_directions) {
        free(kernel);
        return result;
    }

    uint8_t *restricted = xcalloc((size_t)original->nrows * residual_dimension, 1);
    for (int i = 0; i < original->nrows; ++i) {
        const uint8_t *row = original->rows + (size_t)i * original->ncols;
        for (int t = 0; t < residual_dimension; ++t) {
            restricted[(size_t)i * residual_dimension + t] =
                dot_product(row,
                            kernel + (size_t)t * original->ncols,
                            original->ncols);
        }
    }

    uint8_t *best_coefficients = xcalloc((size_t)residual_dimension, 1);
    uint8_t *values = xmalloc((size_t)original->nrows);
    int *digits = xcalloc((size_t)residual_dimension, sizeof(int));
    int best_weight = original->nrows + 1;
    uint64_t enumerated = 0;

    /*
     * Enumerate one representative of every projective direction.
     * For a fixed first nonzero coordinate, that coordinate is 1 and the tail runs
     * through a base-q odometer.  Update the transmitted values incrementally when an
     * odometer digit changes, rather than recomputing every dot product from scratch.
     */
    for (int first = 0; first < residual_dimension; ++first) {
        memset(digits, 0, (size_t)residual_dimension * sizeof(int));
        int weight = 0;
        for (int i = 0; i < original->nrows; ++i) {
            values[i] = restricted[(size_t)i * residual_dimension + first];
            weight += values[i] != 0;
        }

        int tail = residual_dimension - first - 1;
        bool tail_ok = false;
        uint64_t tail_count = checked_power_u64((uint64_t)sf->q, tail, &tail_ok);
        if (!tail_ok) {
            die("projective tail count overflow");
        }

        for (uint64_t iteration = 0; iteration < tail_count; ++iteration) {
            ++enumerated;
            if (weight < best_weight) {
                best_weight = weight;
                memset(best_coefficients, 0, (size_t)residual_dimension);
                best_coefficients[first] = 1;
                for (int j = first + 1; j < residual_dimension; ++j) {
                    best_coefficients[j] = sf->elems[digits[j]];
                }
            }
            if (iteration + 1 == tail_count) {
                break;
            }

            int position = first + 1;
            for (;;) {
                int old_index = digits[position];
                int new_index = old_index + 1;
                if (new_index == sf->q) {
                    new_index = 0;
                }
                digits[position] = new_index;
                uint8_t delta = sf->elems[old_index] ^ sf->elems[new_index];
                if (delta != 0) {
                    for (int i = 0; i < original->nrows; ++i) {
                        uint8_t old_value = values[i];
                        uint8_t new_value = old_value ^
                            gf_mul(delta,
                                   restricted[(size_t)i * residual_dimension + position]);
                        weight += (new_value != 0) - (old_value != 0);
                        values[i] = new_value;
                    }
                }
                if (new_index != 0) {
                    break;
                }
                ++position;
                if (position >= residual_dimension) {
                    die("projective odometer overflow");
                }
            }
        }
    }

    if (enumerated != directions) {
        die("projective enumeration count mismatch");
    }

    uint8_t *coefficient_vector = xcalloc((size_t)original->ncols, 1);
    for (int t = 0; t < residual_dimension; ++t) {
        if (best_coefficients[t] == 0) {
            continue;
        }
        const uint8_t *basis_vector = kernel + (size_t)t * original->ncols;
        for (int j = 0; j < original->ncols; ++j) {
            coefficient_vector[j] ^=
                gf_mul(best_coefficients[t], basis_vector[j]);
        }
    }

    result.valid = true;
    result.weight = best_weight;
    result.zeros = original->nrows - best_weight;
    result.rank = shortening_rank;
    result.closure = closure_count;
    result.rank_saving = closure_count - shortening_rank;
    result.residual_dimension = residual_dimension;
    result.directions_enumerated = enumerated;
    result.coefficient_vector = coefficient_vector;

    free(best_coefficients);
    free(values);
    free(digits);
    free(restricted);
    free(kernel);
    return result;
}
static void free_candidate(candidate *value)
{
    free(value->coefficient_vector);
    value->coefficient_vector = NULL;
    value->valid = false;
}

static int compare_ints(const void *left, const void *right)
{
    int a = *(const int *)left;
    int b = *(const int *)right;
    return (a > b) - (a < b);
}

static integer_summary summarize_integers(const int *values, int count)
{
    integer_summary summary = {-1, -1, -1, 0.0};
    if (count == 0) {
        return summary;
    }
    int *copy = xmalloc((size_t)count * sizeof(int));
    uint64_t sum = 0;
    for (int i = 0; i < count; ++i) {
        copy[i] = values[i];
        sum += (uint64_t)values[i];
    }
    qsort(copy, (size_t)count, sizeof(int), compare_ints);
    summary.minimum = copy[0];
    summary.median = copy[(count - 1) / 2];
    summary.maximum = copy[count - 1];
    summary.mean = (double)sum / (double)count;
    free(copy);
    return summary;
}

static void add_dimension_observation(dimension_bucket *bucket,
                                      int capacity,
                                      const path_step *step)
{
    if (bucket->largest == NULL) {
        bucket->largest = xmalloc((size_t)capacity * sizeof(int));
        bucket->chosen = xmalloc((size_t)capacity * sizeof(int));
        bucket->saving = xmalloc((size_t)capacity * sizeof(int));
        bucket->maximum_class_count =
            xmalloc((size_t)capacity * sizeof(int));
    }
    if (bucket->count >= capacity) {
        die("dimension-summary capacity exceeded");
    }
    int slot = bucket->count++;
    bucket->largest[slot] = step->largest_class_size;
    bucket->chosen[slot] = step->chosen_class_size;
    bucket->saving[slot] = step->projective_saving;
    bucket->maximum_class_count[slot] = step->maximum_class_count;
    bucket->nontrivial_count += step->largest_class_size > 1;
}

static void free_dimension_bucket(dimension_bucket *bucket)
{
    free(bucket->largest);
    free(bucket->chosen);
    free(bucket->saving);
    free(bucket->maximum_class_count);
    memset(bucket, 0, sizeof(*bucket));
}

static void emit_bucket_summary(FILE *stream, const dimension_bucket *bucket)
{
    integer_summary largest = summarize_integers(bucket->largest, bucket->count);
    integer_summary chosen = summarize_integers(bucket->chosen, bucket->count);
    integer_summary saving = summarize_integers(bucket->saving, bucket->count);
    integer_summary maximum_classes =
        summarize_integers(bucket->maximum_class_count, bucket->count);
    double nontrivial_fraction = bucket->count == 0
        ? 0.0
        : (double)bucket->nontrivial_count / (double)bucket->count;
    fprintf(stream,
            ",%d,%d,%.6f,%d,%d,%.3f,%d,%d,%d,%.3f,%d,%d,%d,%.3f,%d,%d,%d,%.3f,%d",
            bucket->count,
            bucket->nontrivial_count,
            nontrivial_fraction,
            largest.minimum,
            largest.median,
            largest.mean,
            largest.maximum,
            chosen.minimum,
            chosen.median,
            chosen.mean,
            chosen.maximum,
            saving.minimum,
            saving.median,
            saving.mean,
            saving.maximum,
            maximum_classes.minimum,
            maximum_classes.median,
            maximum_classes.mean,
            maximum_classes.maximum);
}

static void emit_outcome_bucket_summary(FILE *stream,
                                        const dimension_bucket *bucket)
{
    integer_summary largest = summarize_integers(bucket->largest, bucket->count);
    integer_summary saving = summarize_integers(bucket->saving, bucket->count);
    double nontrivial_fraction = bucket->count == 0
        ? 0.0
        : (double)bucket->nontrivial_count / (double)bucket->count;
    fprintf(stream,
            ",%d,%d,%.6f,%d,%d,%.3f,%d,%d,%d,%.3f,%d",
            bucket->count,
            bucket->nontrivial_count,
            nontrivial_fraction,
            largest.minimum,
            largest.median,
            largest.mean,
            largest.maximum,
            saving.minimum,
            saving.median,
            saving.mean,
            saving.maximum);
}

static void emit_dimension_summaries(const trace_context *trace,
                                     dimension_summary *summaries,
                                     int ncols)
{
    if (trace == NULL || trace->summary_stream == NULL || summaries == NULL) {
        return;
    }
    for (int dimension = ncols; dimension >= 1; --dimension) {
        dimension_summary *summary = &summaries[dimension];
        if (summary->all.count == 0) {
            continue;
        }
        fprintf(trace->summary_stream,
                "%s,%d,%d,%d,%d,%d",
                trace->ensemble,
                trace->field,
                trace->f,
                trace->delta,
                trace->sample,
                dimension);
        emit_bucket_summary(trace->summary_stream, &summary->all);
        emit_outcome_bucket_summary(trace->summary_stream, &summary->success);
        emit_outcome_bucket_summary(trace->summary_stream, &summary->failure);
        fputc('\n', trace->summary_stream);
    }
    fflush(trace->summary_stream);
}

static search_result search_explicit_word(const matrix_u8 *original,
                                          const subfield *sf,
                                          int target_weight,
                                          int restarts,
                                          uint64_t search_seed,
                                          int max_residual_dimension,
                                          uint64_t max_directions,
                                          const trace_context *trace)
{
    search_result result;
    memset(&result, 0, sizeof(result));
    result.first_success_restart = -1;
    result.best.weight = original->nrows + 1;
    result.canonical_weight = -1;
    result.canonical_zero_count = -1;
    result.canonical_residual_dimension = -1;

    int nrows = original->nrows;
    int ncols = original->ncols;
    if (ncols == 0) {
        result.restarts_executed = restarts;
        return result;
    }
    int *closure = xmalloc((size_t)nrows * sizeof(int));
    dimension_summary *summaries = NULL;
    if (trace != NULL && trace->summary_stream != NULL) {
        summaries = xcalloc((size_t)(ncols + 1), sizeof(*summaries));
    }

    for (int restart = 0; restart < restarts; ++restart) {
        rng64 rng;
        rng_init(&rng, search_seed + (uint64_t)restart);
        uint8_t *residual = xmalloc((size_t)nrows * ncols);
        memcpy(residual,
               original->rows,
               (size_t)nrows * ncols);
        int rank = 0;
        bool random_ties = restart != 0;
        path_step *steps = xcalloc((size_t)(ncols + 1), sizeof(path_step));
        int step_count = 0;
        candidate path_candidate;
        memset(&path_candidate, 0, sizeof(path_candidate));
        path_candidate.weight = nrows + 1;
        path_candidate.restart = restart;
        bool path_success = false;
        int final_weight = -1;
        int final_zeros = -1;

        for (;;) {
            int closure_count = closure_indices(residual,
                                                nrows,
                                                ncols,
                                                closure);
            int residual_dimension = ncols - rank;

            if (residual_dimension > 0 &&
                residual_dimension <= max_residual_dimension) {
                path_candidate = enumerate_stage(original,
                                                 sf,
                                                 closure,
                                                 closure_count,
                                                 restart,
                                                 max_directions);
                if (!path_candidate.valid) {
                    die("configured exact-enumeration threshold exceeds direction cap");
                }
                path_candidate.success = path_candidate.weight <= target_weight;
                path_success = path_candidate.success;
                final_weight = path_candidate.weight;
                final_zeros = path_candidate.zeros;
                if (restart == 0) {
                    result.canonical_success = path_candidate.success;
                    result.canonical_weight = path_candidate.weight;
                    result.canonical_zero_count = path_candidate.zeros;
                    result.canonical_residual_dimension =
                        path_candidate.residual_dimension;
                    result.canonical_directions_enumerated =
                        path_candidate.directions_enumerated;
                }
                if (path_candidate.success && result.first_success_restart < 0) {
                    result.first_success_restart = restart;
                }
                if (candidate_better(&path_candidate,
                                     &result.best,
                                     target_weight)) {
                        free_candidate(&result.best);
                    result.best = path_candidate;
                    memset(&path_candidate, 0, sizeof(path_candidate));
                }
                /* Clean semantics: one exact enumeration terminates this path. */
                break;
            }

            if (residual_dimension <= 0 || rank >= ncols) {
                die("greedy path exhausted before exact enumeration");
            }

            int group_count = 0;
            projective_group *groups = build_projective_groups(residual,
                                                               nrows,
                                                               ncols,
                                                               &group_count);
            if (group_count == 0) {
                free_groups(groups, group_count);
                break;
            }
            int selected_index = choose_best_group(groups,
                                                   group_count,
                                                   ncols,
                                                   &rng,
                                                   random_ties);
            if (selected_index < 0) {
                free_groups(groups, group_count);
                die("no nonzero projective class before exact enumeration");
            }
            int largest_size = groups[selected_index].member_count;
            int maximum_count = 0;
            for (int g = 0; g < group_count; ++g) {
                maximum_count += groups[g].member_count == largest_size;
            }
            if (step_count >= ncols + 1) {
                die("path trace overflow");
            }
            path_step *step = &steps[step_count++];
            step->residual_dimension = residual_dimension;
            step->rows_represented = nrows - closure_count;
            step->rows_already_zero = closure_count;
            step->largest_class_size = largest_size;
            step->maximum_class_count = maximum_count;
            step->chosen_class_size = groups[selected_index].member_count;
            step->rank_before = rank;
            const uint8_t *selected = groups[selected_index].key;
            int pivot_col = row_first_nonzero(selected, ncols);
            if (pivot_col < 0) {
                die("selected projective row is zero");
            }
            for (int i = 0; i < nrows; ++i) {
                uint8_t *row = residual + (size_t)i * ncols;
                if (row_is_zero(row, ncols)) {
                    continue;
                }
                uint8_t scale = row[pivot_col];
                if (scale == 0) {
                    continue;
                }
                for (int j = pivot_col; j < ncols; ++j) {
                    row[j] ^= gf_mul(scale, selected[j]);
                }
            }
            ++rank;
            step->rank_after = rank;
            step->rows_imposed = closure_indices(residual,
                                                 nrows,
                                                 ncols,
                                                 closure);
            step->rank_consumed = rank;
            step->projective_saving = step->rows_imposed - rank;
            free_groups(groups, group_count);
        }

        result.successful_paths += path_success;
        for (int i = 0; i < step_count; ++i) {
            const path_step *step = &steps[i];
            ++result.projective_steps;
            result.nontrivial_projective_steps += step->largest_class_size > 1;
            result.largest_class_sum += (uint64_t)step->largest_class_size;
            result.chosen_class_sum += (uint64_t)step->chosen_class_size;
            result.projective_saving_sum += (uint64_t)step->projective_saving;
            if (step->largest_class_size > result.largest_class_max) {
                result.largest_class_max = step->largest_class_size;
            }
            if (step->projective_saving > result.projective_saving_max) {
                result.projective_saving_max = step->projective_saving;
            }
            if (summaries != NULL) {
                dimension_summary *summary =
                    &summaries[step->residual_dimension];
                add_dimension_observation(&summary->all, restarts, step);
                add_dimension_observation(path_success
                                              ? &summary->success
                                              : &summary->failure,
                                          restarts,
                                          step);
            }
        }

        if (trace != NULL && trace->full_stream != NULL && trace->write_full) {
            for (int i = 0; i < step_count; ++i) {
                const path_step *step = &steps[i];
                fprintf(trace->full_stream,
                        "%s,%d,%d,%d,%d,%" PRIu64 ",%" PRIu64 ",%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                        trace->ensemble,
                        trace->field,
                        trace->f,
                        trace->delta,
                        trace->sample,
                        trace->instance_seed,
                        search_seed,
                        restart,
                        step->residual_dimension,
                        step->rows_represented,
                        step->rows_already_zero,
                        step->largest_class_size,
                        step->maximum_class_count,
                        step->chosen_class_size,
                        step->rank_before,
                        step->rank_after,
                        step->rows_imposed,
                        step->rank_consumed,
                        step->projective_saving,
                        path_success ? 1 : 0,
                        final_weight,
                        final_zeros);
            }
            fflush(trace->full_stream);
        }
        free_candidate(&path_candidate);
        free(steps);
        free(residual);
        result.restarts_executed = restart + 1;
    }

    emit_dimension_summaries(trace, summaries, ncols);
    if (summaries != NULL) {
        for (int dimension = 1; dimension <= ncols; ++dimension) {
            free_dimension_bucket(&summaries[dimension].all);
            free_dimension_bucket(&summaries[dimension].success);
            free_dimension_bucket(&summaries[dimension].failure);
        }
        free(summaries);
    }
    free(closure);
    result.best.success = result.best.valid && result.best.weight <= target_weight;
    return result;
}

static uint8_t *source_difference_from_coefficients(const matrix_u8 *source_projection,
                                                    const uint8_t *coefficients)
{
    uint8_t *source = xcalloc((size_t)source_projection->nrows, 1);
    for (int i = 0; i < source_projection->nrows; ++i) {
        source[i] = dot_product(source_projection->rows +
                                    (size_t)i * source_projection->ncols,
                                coefficients,
                                source_projection->ncols);
    }
    return source;
}

static bool solve_full_column_rank(const matrix_u8 *matrix,
                                   const uint8_t *rhs,
                                   uint8_t *solution)
{
    int m = matrix->nrows;
    int n = matrix->ncols;
    int width = n + 1;
    uint8_t *augmented = xcalloc((size_t)m * width, 1);
    for (int r = 0; r < m; ++r) {
        memcpy(augmented + (size_t)r * width,
               matrix->rows + (size_t)r * n,
               (size_t)n);
        augmented[(size_t)r * width + n] = rhs[r];
    }

    int pivot_row = 0;
    int *pivot_for_column = xmalloc((size_t)n * sizeof(int));
    for (int c = 0; c < n; ++c) {
        pivot_for_column[c] = -1;
    }
    for (int c = 0; c < n && pivot_row < m; ++c) {
        int selected = -1;
        for (int r = pivot_row; r < m; ++r) {
            if (augmented[(size_t)r * width + c] != 0) {
                selected = r;
                break;
            }
        }
        if (selected < 0) {
            continue;
        }
        if (selected != pivot_row) {
            for (int j = c; j < width; ++j) {
                uint8_t tmp = augmented[(size_t)pivot_row * width + j];
                augmented[(size_t)pivot_row * width + j] =
                    augmented[(size_t)selected * width + j];
                augmented[(size_t)selected * width + j] = tmp;
            }
        }
        uint8_t inverse = gf_inv[augmented[(size_t)pivot_row * width + c]];
        for (int j = c; j < width; ++j) {
            augmented[(size_t)pivot_row * width + j] =
                gf_mul(augmented[(size_t)pivot_row * width + j], inverse);
        }
        for (int r = 0; r < m; ++r) {
            if (r == pivot_row) {
                continue;
            }
            uint8_t scale = augmented[(size_t)r * width + c];
            if (scale == 0) {
                continue;
            }
            for (int j = c; j < width; ++j) {
                augmented[(size_t)r * width + j] ^=
                    gf_mul(scale,
                           augmented[(size_t)pivot_row * width + j]);
            }
        }
        pivot_for_column[c] = pivot_row;
        ++pivot_row;
    }

    for (int r = 0; r < m; ++r) {
        bool zero = true;
        for (int c = 0; c < n; ++c) {
            zero &= augmented[(size_t)r * width + c] == 0;
        }
        if (zero && augmented[(size_t)r * width + n] != 0) {
            free(pivot_for_column);
            free(augmented);
            return false;
        }
    }

    memset(solution, 0, (size_t)n);
    int rank = 0;
    for (int c = 0; c < n; ++c) {
        if (pivot_for_column[c] >= 0) {
            solution[c] = augmented[(size_t)pivot_for_column[c] * width + n];
            ++rank;
        }
    }
    free(pivot_for_column);
    free(augmented);
    return rank == n;
}

static void ensure_directory(const char *path)
{
    if (path == NULL) {
        return;
    }
    if (mkdir(path, 0777) != 0 && errno != EEXIST) {
        die("cannot create witness directory");
    }
}

static void write_witness(const char *directory,
                          const char *profile,
                          int field_q,
                          int f,
                          int delta,
                          int sample,
                          uint64_t honest_seed,
                          uint64_t search_seed,
                          const rq_params *p,
                          const uint32_t *esis,
                          int h,
                          const uint8_t *ambiguity_basis,
                          const matrix_u8 *honest_matrix,
                          const matrix_u8 *source_projection,
                          const search_result *search)
{
    if (directory == NULL || !search->best.success ||
        search->best.coefficient_vector == NULL) {
        return;
    }
    ensure_directory(directory);
    uint8_t *source = source_difference_from_coefficients(source_projection,
                                                          search->best.coefficient_vector);
    uint8_t *intermediate = xcalloc((size_t)p->L, 1);
    for (int b = 0; b < honest_matrix->ncols; ++b) {
        uint8_t scale = search->best.coefficient_vector[b];
        if (scale == 0) continue;
        for (int j = 0; j < p->L; ++j) {
            intermediate[j] ^=
                gf_mul(scale, ambiguity_basis[(size_t)b * p->L + j]);
        }
    }
    char path[1024];
    snprintf(path,
             sizeof(path),
             "%s/witness_q%d_f%d_delta%d_sample%d.txt",
             directory,
             field_q,
             f,
             delta,
             sample);
    FILE *fp = fopen(path, "w");
    if (fp == NULL) {
        free(intermediate);
        free(source);
        die("cannot write witness file");
    }
    fprintf(fp, "profile=%s\n", profile);
    fprintf(fp, "field=%d\n", field_q);
    fprintf(fp, "f=%d\nDelta=%d\nK=%d\n", f, delta, p->K);
    fprintf(fp,
            "Kprime=%d\nS=%d\nH=%d\nL=%d\n",
            p->Kp,
            p->S,
            p->H,
            p->L);
    fprintf(fp, "honest_set_seed=%" PRIu64 "\n", honest_seed);
    fprintf(fp, "search_seed=%" PRIu64 "\n", search_seed);
    fprintf(fp,
            "weight=%d\nzeros=%d\nrestart=%d\nrank=%d\nclosure=%d\nrank_saving=%d\nresidual_dimension=%d\ndirections_enumerated=%" PRIu64 "\n",
            search->best.weight,
            search->best.zeros,
            search->best.restart,
            search->best.rank,
            search->best.closure,
            search->best.rank_saving,
            search->best.residual_dimension,
            search->best.directions_enumerated);
    fprintf(fp, "source_difference_hex=");
    for (int i = 0; i < p->K; ++i) {
        fprintf(fp, "%02x", source[i]);
    }
    fprintf(fp, "\nintermediate_difference_hex=");
    for (int i = 0; i < p->L; ++i) {
        fprintf(fp, "%02x", intermediate[i]);
    }
    fprintf(fp, "\nhonest_ESIs=");
    for (int i = 0; i < h; ++i) {
        fprintf(fp, "%s%u", i == 0 ? "" : " ", esis[i]);
    }
    fprintf(fp, "\nzero_ESIs=");
    int zeros = 0;
    for (int i = 0; i < h; ++i) {
        uint8_t value = dot_product(honest_matrix->rows +
                                        (size_t)i * honest_matrix->ncols,
                                    search->best.coefficient_vector,
                                    honest_matrix->ncols);
        if (value == 0) {
            fprintf(fp, "%s%u", zeros == 0 ? "" : " ", esis[i]);
            ++zeros;
        }
    }
    fprintf(fp, "\n");
    fclose(fp);
    if (zeros != search->best.zeros) {
        die("witness zero-count mismatch");
    }
    free(intermediate);
    free(source);
}

static void write_zero_set_structure(FILE *stream,
                                     const char *profile,
                                     int field_q,
                                     int f,
                                     int delta,
                                     int sample,
                                     const rq_params *p,
                                     const uint32_t *esis,
                                     const matrix_u8 *honest,
                                     const matrix_u8 *constraints,
                                     const candidate *witness)
{
    if (stream == NULL || !witness->valid ||
        witness->coefficient_vector == NULL) {
        return;
    }
    int *zero_rows = xmalloc((size_t)honest->nrows * sizeof(int));
    int zero_count = 0;
    for (int r = 0; r < honest->nrows; ++r) {
        if (dot_product(honest->rows + (size_t)r * honest->ncols,
                        witness->coefficient_vector,
                        honest->ncols) == 0) {
            zero_rows[zero_count++] = r;
        }
    }
    if (zero_count != witness->zeros) {
        die("complete zero set differs from search candidate");
    }

    matrix_u8 restricted = {
        .rows = xcalloc((size_t)zero_count * honest->ncols, 1),
        .nrows = zero_count,
        .ncols = honest->ncols
    };
    matrix_u8 raw = {
        .rows = xcalloc((size_t)zero_count * p->L, 1),
        .nrows = zero_count,
        .ncols = p->L
    };
    for (int z = 0; z < zero_count; ++z) {
        int r = zero_rows[z];
        memcpy(restricted.rows + (size_t)z * restricted.ncols,
               honest->rows + (size_t)r * honest->ncols,
               (size_t)restricted.ncols);
        encoding_row_dense(esi_to_isi(esis[r], p),
                           p,
                           raw.rows + (size_t)z * p->L);
    }
    int rank_B_Z = matrix_rank(&restricted);
    int rank_G_Z = matrix_rank(&raw);
    int total_saving = zero_count - rank_B_Z;
    int raw_saving = zero_count - rank_G_Z;
    int restriction_loss = rank_G_Z - rank_B_Z;
    if (total_saving != raw_saving + restriction_loss) {
        die("zero-set rank decomposition failed");
    }

    int rank_precode = -1;
    int rank_stacked = -1;
    int intersection_dimension = -1;
    int restricted_identity_ok = -1;
    int intersection_identity_ok = -1;
    if (field_q == 256) {
        rank_precode = matrix_rank(constraints);
        matrix_u8 stacked = {
            .rows = xcalloc((size_t)(constraints->nrows + raw.nrows) * p->L, 1),
            .nrows = constraints->nrows + raw.nrows,
            .ncols = p->L
        };
        memcpy(stacked.rows,
               constraints->rows,
               (size_t)constraints->nrows * p->L);
        memcpy(stacked.rows + (size_t)constraints->nrows * p->L,
               raw.rows,
               (size_t)raw.nrows * p->L);
        rank_stacked = matrix_rank(&stacked);
        intersection_dimension = rank_G_Z + rank_precode - rank_stacked;
        restricted_identity_ok =
            rank_B_Z == rank_stacked - rank_precode;
        intersection_identity_ok =
            restriction_loss == intersection_dimension;
        if (!restricted_identity_ok || !intersection_identity_ok) {
            die("GF(256) precode-row-space intersection identity failed");
        }
        free_matrix(&stacked);
    }

    fprintf(stream,
            "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
            profile, field_q, f, delta, p->K, sample,
            witness->success ? 1 : 0, zero_count, rank_B_Z,
            rank_G_Z, total_saving, raw_saving, restriction_loss,
            rank_precode, rank_stacked, intersection_dimension,
            restricted_identity_ok, intersection_identity_ok);
    fflush(stream);
    free_matrix(&raw);
    free_matrix(&restricted);
    free(zero_rows);
}

static int selftest_one_field(int q, int K, int expected_kappa)
{
    subfield sf;
    subfield_init(&sf, q);
    rq_params p = get_params(K);
    matrix_u8 constraints = build_subfield_constraints(&p, &sf);
    int kappa = q == 256 ? K : 0;
    uint8_t *ambiguity = q == 256
        ? kernel_basis_with_expected_dimension(&constraints, K)
        : kernel_basis_of_matrix(&constraints, &kappa);
    if (kappa != expected_kappa) {
        fprintf(stderr,
                "selftest q=%d K=%d kappa=%d expected=%d\n",
                q,
                K,
                kappa,
                expected_kappa);
        free(ambiguity);
        free_matrix(&constraints);
        return 0;
    }
    matrix_u8 source = build_source_projection(&p, ambiguity, kappa);
    int source_rank = matrix_rank(&source);
    if (source_rank != kappa) {
        fprintf(stderr,
                "selftest source projection q=%d K=%d rank=%d kappa=%d\n",
                q,
                K,
                source_rank,
                kappa);
        free_matrix(&source);
        free(ambiguity);
        free_matrix(&constraints);
        return 0;
    }
    free_matrix(&source);
    free(ambiguity);
    free_matrix(&constraints);
    return 1;
}

static int selftest(void)
{
    gf256_init();
    for (int a = 1; a < 256; ++a) {
        if (gf_mul((uint8_t)a, gf_inv[a]) != 1) {
            fprintf(stderr, "GF(256) inverse failure at %d\n", a);
            return 0;
        }
    }
    rq_params p = get_params(65);
    if (!(p.Kp == 69 && p.J == 157 && p.S == 13 && p.H == 10 &&
          p.W == 79 && p.L == 92 && p.P == 13 && p.P1 == 13)) {
        fprintf(stderr, "K=65 RFC parameter mismatch\n");
        return 0;
    }

    if (!selftest_one_field(4, 65, 35) ||
        !selftest_one_field(4, 44, 14) ||
        !selftest_one_field(4, 30, 1) ||
        !selftest_one_field(16, 65, 55) ||
        !selftest_one_field(256, 65, 65)) {
        return 0;
    }

    /* Recover the existing Rust-validated GF(4) source difference from Z4. */
    subfield sf4;
    subfield_init(&sf4, 4);
    matrix_u8 constraints = build_subfield_constraints(&p, &sf4);
    int kappa4 = 0;
    uint8_t *ambiguity = kernel_basis_of_matrix(&constraints, &kappa4);
    matrix_u8 source = build_source_projection(&p, ambiguity, kappa4);
    static const uint8_t source_codes[65] = {
        1,0,1,0,0,0,0,2,2,3,0,0,2,0,0,3,2,0,3,1,1,0,0,1,2,0,1,0,2,3,0,3,3,
        2,0,0,2,0,0,0,2,0,0,0,2,0,0,1,3,3,0,3,3,3,1,0,0,1,1,2,0,3,2,1,3
    };
    static const uint32_t zero_esis[70] = {
        1,3,4,6,10,13,14,17,21,22,25,27,30,34,35,37,38,41,42,43,45,46,55,56,60,
        65,68,71,75,77,78,79,81,82,86,90,91,93,95,99,105,106,108,111,114,115,116,
        123,138,139,142,145,149,152,154,160,164,166,167,169,172,174,176,179,183,184,
        186,188,191,192
    };
    uint8_t embedded_source[65];
    for (int i = 0; i < 65; ++i) {
        static const uint8_t embed[4] = {0x00, 0x01, 0xd6, 0xd7};
        embedded_source[i] = embed[source_codes[i]];
    }
    uint8_t *coefficients = xcalloc((size_t)kappa4, 1);
    if (!solve_full_column_rank(&source, embedded_source, coefficients)) {
        fprintf(stderr, "GF(4) source-difference solve failed\n");
        free(coefficients);
        free_matrix(&source);
        free(ambiguity);
        free_matrix(&constraints);
        return 0;
    }
    matrix_u8 known_rows = build_induced_rows(&p,
                                              ambiguity,
                                              kappa4,
                                              zero_esis,
                                              70);
    for (int i = 0; i < 70; ++i) {
        if (dot_product(known_rows.rows + (size_t)i * kappa4,
                        coefficients,
                        kappa4) != 0) {
            fprintf(stderr,
                    "Rust-validated GF(4) witness mismatch at ESI %u\n",
                    zero_esis[i]);
            free_matrix(&known_rows);
            free(coefficients);
            free_matrix(&source);
            free(ambiguity);
            free_matrix(&constraints);
            return 0;
        }
    }
    free_matrix(&known_rows);
    free(coefficients);
    free_matrix(&source);
    free(ambiguity);
    free_matrix(&constraints);

    fprintf(stderr,
            "SELFTEST PASS: RFC construction; GF(4)/GF(16)/GF(256) dimensions; "
            "source-projection injectivity; Rust-validated GF(4) witness zeros\n");
    return 1;
}

typedef enum {
    PROFILE_CANONICAL,
    PROFILE_LOW_REPAIR,
    PROFILE_SHIFTED_REPAIR
} profile_kind;

typedef enum {
    TRACE_MODE_SUMMARY,
    TRACE_MODE_DIAGNOSTIC,
    TRACE_MODE_FULL
} trace_mode_kind;

typedef struct {
    int field_q;
    int f_min;
    int f_max;
    int delta_min;
    int delta_max;
    int samples;
    int sample_start;
    int restarts;
    int max_residual_dimension;
    uint64_t max_directions;
    uint64_t master_seed;
    int honest_seed_schema;
    profile_kind profile;
    bool early_stop;
    const char *output_path;
    const char *witness_directory;
    trace_mode_kind trace_mode;
    const char *trace_summary_path;
    const char *trace_path;
    int diagnostic_sample;
    const char *esi_path;
    const char *structure_path;
} options;

static uint64_t rotate_left_u64(uint64_t value, unsigned count)
{
    count &= 63u;
    return (value << count) | (value >> ((64u - count) & 63u));
}

static int parse_int(const char *text)
{
    char *end = NULL;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (errno != 0 || end == NULL || *end != '\0' ||
        value < 0 || value > 1000000) {
        die("invalid integer option");
    }
    return (int)value;
}

static uint64_t parse_u64(const char *text)
{
    char *end = NULL;
    errno = 0;
    unsigned long long value = strtoull(text, &end, 0);
    if (errno != 0 || end == NULL || *end != '\0') {
        die("invalid uint64 option");
    }
    return (uint64_t)value;
}

static void usage(const char *program)
{
    fprintf(stderr,
            "usage: %s [--selftest] --field 4|16|256 "
            "[--f N | --f-min N --f-max N] "
            "[--delta N | --delta-min N --delta-max N] "
            "[--samples N] [--sample-start N] [--restarts N] "
            "[--max-residual-d N] [--max-directions N] "
            "[--profile canonical|low-repair|shifted-repair] "
            "[--seed U64] [--seed-schema 4] "
            "[--out FILE] [--witness-dir DIR] "
            "[--trace-mode summary|diagnostic|full] "
            "[--trace-summary-out FILE] [--trace-out FILE] "
            "[--diagnostic-sample N] "
            "[--esi-out FILE] [--structure-out FILE]\n",
            program);
}

static const char *profile_name(profile_kind profile)
{
    if (profile == PROFILE_CANONICAL) return "canonical";
    if (profile == PROFILE_LOW_REPAIR) return "low-repair";
    return "shifted-repair";
}

static const char *trace_mode_name(trace_mode_kind mode)
{
    if (mode == TRACE_MODE_FULL) return "full";
    if (mode == TRACE_MODE_DIAGNOSTIC) return "diagnostic";
    return "summary";
}

static trace_mode_kind parse_trace_mode(const char *name)
{
    if (strcmp(name, "summary") == 0) return TRACE_MODE_SUMMARY;
    if (strcmp(name, "diagnostic") == 0) return TRACE_MODE_DIAGNOSTIC;
    if (strcmp(name, "full") == 0) return TRACE_MODE_FULL;
    die("trace mode must be summary, diagnostic, or full");
    return TRACE_MODE_SUMMARY;
}

static void set_field_defaults(options *opts)
{
    if (opts->max_residual_dimension != 0) {
        return;
    }
    if (opts->field_q == 4) {
        opts->max_residual_dimension = 8;
    } else if (opts->field_q == 16) {
        opts->max_residual_dimension = 5;
    } else if (opts->field_q == 256) {
        opts->max_residual_dimension = 3;
    }
}

int main(int argc, char **argv)
{
    gf256_init();
    options opts;
    memset(&opts, 0, sizeof(opts));
    opts.field_q = 256;
    opts.f_min = 64;
    opts.f_max = 64;
    opts.delta_min = 0;
    opts.delta_max = 0;
    opts.samples = 20;
    opts.sample_start = 0;
    opts.restarts = 40;
    opts.max_residual_dimension = 0;
    opts.max_directions = UINT64_C(1000000);
    opts.master_seed = UINT64_C(64025620260903);
    opts.honest_seed_schema = 4;
    opts.profile = PROFILE_CANONICAL;
    opts.early_stop = false;
    opts.output_path = "rq_subfield_results.csv";
    opts.witness_directory = NULL;
    opts.trace_mode = TRACE_MODE_SUMMARY;
    opts.trace_summary_path = NULL;
    opts.trace_path = NULL;
    opts.diagnostic_sample = -1;
    opts.esi_path = NULL;
    opts.structure_path = NULL;
    bool run_selftest = false;

    for (int i = 1; i < argc; ++i) {
#define REQUIRE_VALUE() do { if (i + 1 >= argc) die("missing option value"); } while (0)
        if (strcmp(argv[i], "--selftest") == 0) {
            run_selftest = true;
        } else if (strcmp(argv[i], "--field") == 0) {
            REQUIRE_VALUE();
            opts.field_q = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--f") == 0) {
            REQUIRE_VALUE();
            opts.f_min = opts.f_max = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--f-min") == 0) {
            REQUIRE_VALUE();
            opts.f_min = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--f-max") == 0) {
            REQUIRE_VALUE();
            opts.f_max = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--delta") == 0) {
            REQUIRE_VALUE();
            opts.delta_min = opts.delta_max = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--delta-min") == 0) {
            REQUIRE_VALUE();
            opts.delta_min = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--delta-max") == 0) {
            REQUIRE_VALUE();
            opts.delta_max = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--samples") == 0) {
            REQUIRE_VALUE();
            opts.samples = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--sample-start") == 0) {
            REQUIRE_VALUE();
            opts.sample_start = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--restarts") == 0) {
            REQUIRE_VALUE();
            opts.restarts = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--max-residual-d") == 0) {
            REQUIRE_VALUE();
            opts.max_residual_dimension = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--max-directions") == 0) {
            REQUIRE_VALUE();
            opts.max_directions = parse_u64(argv[++i]);
        } else if (strcmp(argv[i], "--profile") == 0) {
            REQUIRE_VALUE();
            const char *name = argv[++i];
            if (strcmp(name, "canonical") == 0) {
                opts.profile = PROFILE_CANONICAL;
            } else if (strcmp(name, "low-repair") == 0) {
                opts.profile = PROFILE_LOW_REPAIR;
            } else if (strcmp(name, "shifted-repair") == 0) {
                opts.profile = PROFILE_SHIFTED_REPAIR;
            } else {
                die("profile must be canonical, low-repair, or shifted-repair");
            }
        } else if (strcmp(argv[i], "--seed") == 0) {
            REQUIRE_VALUE();
            opts.master_seed = parse_u64(argv[++i]);
        } else if (strcmp(argv[i], "--seed-schema") == 0) {
            REQUIRE_VALUE();
            opts.honest_seed_schema = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--early-stop") == 0) {
            REQUIRE_VALUE();
            opts.early_stop = parse_int(argv[++i]) != 0;
        } else if (strcmp(argv[i], "--out") == 0) {
            REQUIRE_VALUE();
            opts.output_path = argv[++i];
        } else if (strcmp(argv[i], "--witness-dir") == 0) {
            REQUIRE_VALUE();
            opts.witness_directory = argv[++i];
        } else if (strcmp(argv[i], "--trace-mode") == 0) {
            REQUIRE_VALUE();
            opts.trace_mode = parse_trace_mode(argv[++i]);
        } else if (strcmp(argv[i], "--trace-summary-out") == 0) {
            REQUIRE_VALUE();
            opts.trace_summary_path = argv[++i];
        } else if (strcmp(argv[i], "--trace-out") == 0) {
            REQUIRE_VALUE();
            opts.trace_path = argv[++i];
        } else if (strcmp(argv[i], "--diagnostic-sample") == 0) {
            REQUIRE_VALUE();
            opts.diagnostic_sample = parse_int(argv[++i]);
        } else if (strcmp(argv[i], "--esi-out") == 0) {
            REQUIRE_VALUE();
            opts.esi_path = argv[++i];
        } else if (strcmp(argv[i], "--structure-out") == 0) {
            REQUIRE_VALUE();
            opts.structure_path = argv[++i];
        } else if (strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else {
            usage(argv[0]);
            die("unknown option");
        }
#undef REQUIRE_VALUE
    }

    if (run_selftest) {
        return selftest() ? 0 : 1;
    }

    log2_exact_q(opts.field_q);
    set_field_defaults(&opts);
    if (opts.f_min > opts.f_max ||
        opts.delta_min > opts.delta_max ||
        opts.samples <= 0 ||
        opts.restarts <= 0 ||
        opts.max_residual_dimension <= 0 ||
        opts.max_directions == 0 || opts.early_stop ||
        opts.honest_seed_schema != 4) {
        die("invalid campaign options");
    }
    if (opts.trace_mode == TRACE_MODE_SUMMARY && opts.trace_path != NULL) {
        die("summary trace mode cannot write full path traces");
    }
    if (opts.trace_mode == TRACE_MODE_DIAGNOSTIC &&
        (opts.trace_path == NULL || opts.diagnostic_sample < 0)) {
        die("diagnostic trace mode requires --trace-out and --diagnostic-sample");
    }

    subfield sf;
    subfield_init(&sf, opts.field_q);
    bool directions_ok = false;
    uint64_t nominal_directions = projective_direction_count(opts.field_q,
                                                              opts.max_residual_dimension,
                                                              &directions_ok);
    fprintf(stderr,
            "CAMPAIGN q=%d degree=%d f=%d..%d Delta=%d..%d samples=%d sample_start=%d restarts=%d "
            "profile=%s trace_mode=%s max_residual_d=%d directions_at_max=%s%" PRIu64 " cap=%" PRIu64 " seed=%" PRIu64 " seed_schema=%d\n",
            opts.field_q,
            sf.degree,
            opts.f_min,
            opts.f_max,
            opts.delta_min,
            opts.delta_max,
            opts.samples,
            opts.sample_start,
            opts.restarts,
            profile_name(opts.profile),
            trace_mode_name(opts.trace_mode),
            opts.max_residual_dimension,
            directions_ok ? "" : ">",
            nominal_directions,
            opts.max_directions,
            opts.master_seed,
            opts.honest_seed_schema);

    FILE *csv = fopen(opts.output_path, "w");
    if (csv == NULL) {
        die("cannot open output CSV");
    }
    fprintf(csv,
            "field,relative_extension_degree,f,n,h,K,Delta,Kprime,S,H_HDPC,L,kappa,profile,sample,"
            "honest_set_seed,search_seed,systematic_count,repair_count,honest_esi_min,honest_esi_max,"
            "rank_B,initial_zero_rows,initial_nonzero_projective_classes,initial_largest_projective_class,"
            "initial_projective_classes_at_least_two,initial_rows_in_nontrivial_projective_classes,"
            "restart_budget,restarts_executed,max_residual_dimension,max_directions,"
            "success,minimum_word_weight,number_of_zero_honest_ESIs,first_success_restart,selected_restart,"
            "shortening_cardinality,shortening_rank,rank_saving,residual_dimension,directions_enumerated,"
            "successful_paths,projective_steps,nontrivial_projective_steps,nontrivial_projective_fraction,"
            "largest_projective_class_max,largest_projective_class_mean,chosen_projective_class_mean,"
            "projective_saving_max,projective_saving_mean,"
            "construction_ms,matrix_ms,search_ms,canonical_success,canonical_weight,"
            "canonical_zero_count,canonical_residual_dimension,"
            "canonical_directions_enumerated\n");
    FILE *trace_summary_csv = NULL;
    if (opts.trace_summary_path != NULL) {
        trace_summary_csv = fopen(opts.trace_summary_path, "w");
        if (trace_summary_csv == NULL) die("cannot open path-summary CSV");
        fprintf(trace_summary_csv,
                "ensemble,field,f,Delta,sample,residual_dimension,"
                "all_paths,all_nontrivial_paths,all_nontrivial_fraction,"
                "all_largest_min,all_largest_median,all_largest_mean,all_largest_max,"
                "all_chosen_min,all_chosen_median,all_chosen_mean,all_chosen_max,"
                "all_saving_min,all_saving_median,all_saving_mean,all_saving_max,"
                "all_maximum_class_count_min,all_maximum_class_count_median,all_maximum_class_count_mean,all_maximum_class_count_max,"
                "success_paths,success_nontrivial_paths,success_nontrivial_fraction,"
                "success_largest_min,success_largest_median,success_largest_mean,success_largest_max,"
                "success_saving_min,success_saving_median,success_saving_mean,success_saving_max,"
                "failure_paths,failure_nontrivial_paths,failure_nontrivial_fraction,"
                "failure_largest_min,failure_largest_median,failure_largest_mean,failure_largest_max,"
                "failure_saving_min,failure_saving_median,failure_saving_mean,failure_saving_max\n");
    }
    FILE *trace_csv = NULL;
    if (opts.trace_path != NULL && opts.trace_mode != TRACE_MODE_SUMMARY) {
        trace_csv = fopen(opts.trace_path, "w");
        if (trace_csv == NULL) die("cannot open path trace CSV");
        fprintf(trace_csv,
                "ensemble,field,f,Delta,sample,instance_seed,search_seed,path,residual_dimension,rows_represented,rows_already_zero,largest_class_size,maximum_class_count,chosen_class_size,rank_before,rank_after,cumulative_rows_imposed,cumulative_rank_consumed,cumulative_projective_saving,path_success,final_weight,final_zero_count\n");
    }
    FILE *esi_csv = NULL;
    if (opts.esi_path != NULL) {
        esi_csv = fopen(opts.esi_path, "w");
        if (esi_csv == NULL) die("cannot open ESI CSV");
        fprintf(esi_csv,
                "ensemble,profile,field,f,Delta,K,sample,honest_set_seed,h,position_mask,honest_ESIs\n");
    }
    FILE *structure_csv = NULL;
    if (opts.structure_path != NULL) {
        structure_csv = fopen(opts.structure_path, "w");
        if (structure_csv == NULL) die("cannot open structure CSV");
        fprintf(structure_csv,
                "profile,field,f,Delta,K,sample,success,zero_count,rank_B_Z,rank_G_Z,total_saving,raw_LT_saving,restriction_loss,rank_precode,rank_stacked,intersection_dimension,restricted_rank_identity_ok,intersection_identity_ok\n");
    }

    int total_instances = 0;
    int total_successes = 0;
    for (int f = opts.f_min; f <= opts.f_max; ++f) {
        int n = 3 * f + 1;
        int h = 2 * f + 1;
        for (int delta = opts.delta_min; delta <= opts.delta_max; ++delta) {
            int K = f + 1 - delta;
            if (K <= 0 || K > 56403) {
                continue;
            }

            uint64_t construction_start = now_ns();
            rq_params p = get_params(K);
            matrix_u8 constraints = build_subfield_constraints(&p, &sf);
            int kappa = K;
            uint8_t *ambiguity_basis = NULL;
            if (opts.field_q == 256) {
                ambiguity_basis =
                    kernel_basis_with_expected_dimension(&constraints, K);
            } else {
                ambiguity_basis =
                    kernel_basis_of_matrix(&constraints, &kappa);
            }
            matrix_u8 source_projection = build_source_projection(&p,
                                                                   ambiguity_basis,
                                                                   kappa);
            if (matrix_rank(&source_projection) != kappa) {
                die("source projection is not injective");
            }
            double construction_ms = (double)(now_ns() - construction_start) / 1e6;
            int point_successes = 0;
            uint64_t point_start = now_ns();

            for (int sample_offset = 0; sample_offset < opts.samples; ++sample_offset) {
                int sample = opts.sample_start + sample_offset;
                uint64_t seed_parameter = (uint64_t)f;
                uint64_t honest_seed = opts.master_seed
                    ^ seed_parameter * UINT64_C(0x9e3779b97f4a7c15)
                    ^ (uint64_t)sample * UINT64_C(0x85ebca6b27d4eb2f);
                uint64_t search_seed = rotate_left_u64(opts.master_seed, 17)
                    ^ (uint64_t)K * UINT64_C(0xc2b2ae3587b73a21)
                    ^ (uint64_t)sample * UINT64_C(0x165667b19e3779f9);
                rng64 honest_rng;
                rng_init(&honest_rng, honest_seed);
                uint32_t *positions = xmalloc((size_t)h * sizeof(uint32_t));
                uint32_t *esis = xmalloc((size_t)h * sizeof(uint32_t));
                sample_consecutive(positions, (uint32_t)n, h, &honest_rng);
                uint32_t offset = 0;
                if (opts.profile == PROFILE_LOW_REPAIR) {
                    offset = (uint32_t)K;
                } else if (opts.profile == PROFILE_SHIFTED_REPAIR) {
                    offset = UINT32_C(1) << 23;
                }
                if (offset + (uint32_t)(n - 1) >= RQ_ESI_DOMAIN) {
                    die("profile exceeds the 24-bit ESI domain");
                }
                for (int i = 0; i < h; ++i) {
                    esis[i] = offset + positions[i];
                }
                int systematic_count = 0;
                for (int i = 0; i < h; ++i) {
                    systematic_count += esis[i] < (uint32_t)K;
                }
                if (esi_csv != NULL) {
                    fprintf(esi_csv,
                            "rq,%s,%d,%d,%d,%d,%d,%" PRIu64 ",%d,",
                            profile_name(opts.profile), opts.field_q, f, delta,
                            K, sample, honest_seed, h);
                    for (int i = 0; i < h; ++i) {
                        fprintf(esi_csv, "%s%u", i == 0 ? "" : " ", positions[i]);
                    }
                    fputc(',', esi_csv);
                    for (int i = 0; i < h; ++i) {
                        fprintf(esi_csv, "%s%u", i == 0 ? "" : " ", esis[i]);
                    }
                    fputc('\n', esi_csv);
                    fflush(esi_csv);
                }

                uint64_t matrix_start = now_ns();
                matrix_u8 honest = build_induced_rows(&p,
                                                       ambiguity_basis,
                                                       kappa,
                                                       esis,
                                                       h);
                int rank_B = matrix_rank(&honest);
                initial_projective_stats initial =
                    describe_initial_projective_structure(&honest);
                double matrix_ms = (double)(now_ns() - matrix_start) / 1e6;

                uint64_t search_start = now_ns();
                trace_context trace = {
                    .summary_stream = trace_summary_csv,
                    .full_stream = trace_csv,
                    .write_full = opts.trace_mode == TRACE_MODE_FULL ||
                                  (opts.trace_mode == TRACE_MODE_DIAGNOSTIC &&
                                   sample == opts.diagnostic_sample),
                    .ensemble = profile_name(opts.profile),
                    .field = opts.field_q,
                    .f = f,
                    .delta = delta,
                    .sample = sample,
                    .instance_seed = honest_seed
                };
                search_result search = search_explicit_word(&honest,
                                                            &sf,
                                                            f,
                                                            opts.restarts,
                                                            search_seed,
                                                            opts.max_residual_dimension,
                                                            opts.max_directions,
                                                            &trace);
                double search_ms = (double)(now_ns() - search_start) / 1e6;

                if (search.best.success) {
                    ++point_successes;
                    ++total_successes;
                    write_witness(opts.witness_directory,
                                  profile_name(opts.profile),
                                  opts.field_q,
                                  f,
                                  delta,
                                  sample,
                                  honest_seed,
                                  search_seed,
                                  &p,
                                  esis,
                                  h,
                                  ambiguity_basis,
                                  &honest,
                                  &source_projection,
                                  &search);
                }
                write_zero_set_structure(structure_csv,
                                         profile_name(opts.profile),
                                         opts.field_q,
                                         f,
                                         delta,
                                         sample,
                                         &p,
                                         esis,
                                         &honest,
                                         &constraints,
                                         &search.best);
                ++total_instances;

                fprintf(csv,
                        "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%d,%" PRIu64 ",%" PRIu64 ",%d,%d,%u,%u,%d,%d,%d,%d,%d,%d,%d,%d,%d,%" PRIu64 ",%d,%d,%d,%d,%d,%d,%d,%d,%d,%" PRIu64 ",%d,%" PRIu64 ",%" PRIu64 ",%.6f,%d,%.3f,%.3f,%d,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d,%" PRIu64 "\n",
                        opts.field_q,
                        sf.degree,
                        f,
                        n,
                        h,
                        K,
                        delta,
                        p.Kp,
                        p.S,
                        p.H,
                        p.L,
                        kappa,
                        profile_name(opts.profile),
                        sample,
                        honest_seed,
                        search_seed,
                        systematic_count,
                        h - systematic_count,
                        esis[0],
                        esis[h - 1],
                        rank_B,
                        initial.zero_rows,
                        initial.nonzero_classes,
                        initial.largest_class,
                        initial.classes_at_least_two,
                        initial.rows_in_nontrivial_classes,
                        opts.restarts,
                        search.restarts_executed,
                        opts.max_residual_dimension,
                        opts.max_directions,
                        search.best.success ? 1 : 0,
                        search.best.valid ? search.best.weight : -1,
                        search.best.valid ? search.best.zeros : -1,
                        search.first_success_restart,
                        search.best.valid ? search.best.restart : -1,
                        search.best.valid ? search.best.closure : -1,
                        search.best.valid ? search.best.rank : -1,
                        search.best.valid ? search.best.rank_saving : -1,
                        search.best.valid ? search.best.residual_dimension : -1,
                        search.best.valid ? search.best.directions_enumerated : 0,
                        search.successful_paths,
                        search.projective_steps,
                        search.nontrivial_projective_steps,
                        search.projective_steps == 0 ? 0.0 :
                            (double)search.nontrivial_projective_steps /
                            (double)search.projective_steps,
                        search.largest_class_max,
                        search.projective_steps == 0 ? 0.0 :
                            (double)search.largest_class_sum /
                            (double)search.projective_steps,
                        search.projective_steps == 0 ? 0.0 :
                            (double)search.chosen_class_sum /
                            (double)search.projective_steps,
                        search.projective_saving_max,
                        search.projective_steps == 0 ? 0.0 :
                            (double)search.projective_saving_sum /
                            (double)search.projective_steps,
                        construction_ms,
                        matrix_ms,
                        search_ms,
                        search.canonical_success,
                        search.canonical_weight,
                        search.canonical_zero_count,
                        search.canonical_residual_dimension,
                        search.canonical_directions_enumerated);
                fflush(csv);

                free_candidate(&search.best);
                free_matrix(&honest);
                free(esis);
                free(positions);
            }

            double point_ms = (double)(now_ns() - point_start) / 1e6;
            fprintf(stderr,
                    "POINT q=%d f=%d Delta=%d K=%d kappa=%d profile=%s "
                    "success=%d/%d construction_ms=%.3f point_ms=%.1f\n",
                    opts.field_q,
                    f,
                    delta,
                    K,
                    kappa,
                    profile_name(opts.profile),
                    point_successes,
                    opts.samples,
                    construction_ms,
                    point_ms);

            free_matrix(&source_projection);
            free(ambiguity_basis);
            free_matrix(&constraints);
        }
    }

    if (fclose(csv) != 0) die("cannot close output CSV");
    if (trace_summary_csv != NULL && fclose(trace_summary_csv) != 0) {
        die("cannot close path-summary CSV");
    }
    if (trace_csv != NULL && fclose(trace_csv) != 0) {
        die("cannot close path trace CSV");
    }
    if (esi_csv != NULL && fclose(esi_csv) != 0) {
        die("cannot close ESI CSV");
    }
    if (structure_csv != NULL && fclose(structure_csv) != 0) {
        die("cannot close structure CSV");
    }
    fprintf(stderr,
            "CAMPAIGN DONE q=%d success=%d/%d output=%s\n",
            opts.field_q,
            total_successes,
            total_instances,
            opts.output_path);
    return 0;
}
