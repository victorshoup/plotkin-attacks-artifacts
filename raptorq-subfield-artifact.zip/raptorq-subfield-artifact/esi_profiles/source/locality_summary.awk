BEGIN{FS=OFS=","}
NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
{
 key=$(c["f"]) SUBSEP $(c["K"]);seen[key]=1;f[key]=$(c["f"]);K[key]=$(c["K"]);kind=$(c["window_kind"])
 if(kind=="low-repair"||kind=="shifted-repair"){
  rank[key SUBSEP kind]=$(c["raw_binary_rank"]);dup[key SUBSEP kind]=$(c["duplicate_pairs"]);drows[key SUBSEP kind]=$(c["duplicate_rows"]);degree[key SUBSEP kind]=$(c["mean_degree"])
 }else{
  i=++nr[key];rr[key SUBSEP i]=$(c["raw_binary_rank"]);rd[key SUBSEP i]=$(c["duplicate_pairs"]);rdr[key SUBSEP i]=$(c["duplicate_rows"]);rg[key SUBSEP i]=$(c["mean_degree"])
 }
}
END{
 print "f,K,low_rank,shifted_rank,random_rank_min,random_rank_median,random_rank_max,low_rank_ecdf,shifted_rank_ecdf,low_duplicate_pairs,shifted_duplicate_pairs,random_duplicate_pairs_min,random_duplicate_pairs_median,random_duplicate_pairs_max,low_duplicate_pairs_ecdf,shifted_duplicate_pairs_ecdf,low_duplicate_rows,shifted_duplicate_rows,low_mean_degree,shifted_mean_degree,random_mean_degree_min,random_mean_degree_median,random_mean_degree_max,low_mean_degree_ecdf,shifted_mean_degree_ecdf,random_windows"
 for(key in seen){
  if(nr[key]!=16)exit 2
  sortmetric(key,rr,"rank");rmin=sorted[1];rmed=(sorted[8]+sorted[9])/2;rmax=sorted[16];lr=rank[key SUBSEP "low-repair"];sr=rank[key SUBSEP "shifted-repair"];lrec=ecdf(lr);srec=ecdf(sr)
  sortmetric(key,rd,"dup");dmin=sorted[1];dmed=(sorted[8]+sorted[9])/2;dmax=sorted[16];ld=dup[key SUBSEP "low-repair"];sd=dup[key SUBSEP "shifted-repair"];ldec=ecdf(ld);sdec=ecdf(sd)
  sortmetric(key,rg,"degree");gmin=sorted[1];gmed=(sorted[8]+sorted[9])/2;gmax=sorted[16];lg=degree[key SUBSEP "low-repair"];sg=degree[key SUBSEP "shifted-repair"];lgec=ecdf(lg);sgec=ecdf(sg)
  printf "%d,%d,%d,%d,%d,%.3f,%d,%.6f,%.6f,%d,%d,%d,%.3f,%d,%.6f,%.6f,%d,%d,%.9f,%.9f,%.9f,%.9f,%.9f,%.6f,%.6f,16\n",f[key],K[key],lr,sr,rmin,rmed,rmax,lrec,srec,ld,sd,dmin,dmed,dmax,ldec,sdec,drows[key SUBSEP "low-repair"],drows[key SUBSEP "shifted-repair"],lg,sg,gmin,gmed,gmax,lgec,sgec
 }
}
function sortmetric(key,array,label, i,j,v){
 delete sorted
 for(i=1;i<=16;i++)sorted[i]=array[key SUBSEP i]
 for(i=2;i<=16;i++){v=sorted[i];j=i-1;while(j>=1&&sorted[j]>v){sorted[j+1]=sorted[j];j--}sorted[j+1]=v}
}
function ecdf(value, i,n){n=0;for(i=1;i<=16;i++)if(sorted[i]<=value)n++;return n/16}

