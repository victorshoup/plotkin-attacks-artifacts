BEGIN {FS=OFS=","}
NR==1 {for(i=1;i<=NF;i++)c[$i]=i;next}
$(c["profile"])=="canonical" {
    key=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
    campaign[key]=$(c["campaign"]);field[key]=$(c["field"]);f[key]=$(c["f"])
    delta[key]=$(c["Delta"]);K[key]=$(c["K"])
    v=$(c["systematic_count"])+0;s=$(c["success"])+0
    count[key SUBSEP v]++;wins[key SUBSEP v]+=s;total[key]++;success[key]+=s
    if(!(key in minv)||v<minv[key])minv[key]=v;if(v>maxv[key])maxv[key]=v
}
END {
    print "campaign,field,f,Delta,K,grouping,group,systematic_min,systematic_max,samples,successes,success_fraction"
    for(key in total){
        if(success[key]==0||success[key]==total[key])continue
        distinct=0
        for(v=minv[key];v<=maxv[key];v++)if(count[key SUBSEP v])distinct++
        if(distinct<=3){
            for(v=minv[key];v<=maxv[key];v++)if(count[key SUBSEP v])
                emit(key,"exact","exact_" v,v,v,count[key SUBSEP v],wins[key SUBSEP v])
            continue
        }
        cumulative=0;t1=minv[key];t2=maxv[key];got1=0
        for(v=minv[key];v<=maxv[key];v++){
            cumulative+=count[key SUBSEP v]
            if(cumulative*3>=total[key]&&!got1){t1=v;got1=1}
            if(cumulative*3>=2*total[key]){t2=v;break}
        }
        delete gn;delete gw;delete gmin;delete gmax
        for(v=minv[key];v<=maxv[key];v++)if(count[key SUBSEP v]){
            g=v<=t1?1:(v<=t2?2:3);gn[g]+=count[key SUBSEP v];gw[g]+=wins[key SUBSEP v]
            if(!(g in gmin))gmin[g]=v;gmax[g]=v
        }
        name[1]="low";name[2]="middle";name[3]="high"
        for(g=1;g<=3;g++)if(gn[g])emit(key,"tertile",name[g],gmin[g],gmax[g],gn[g],gw[g])
    }
}
function emit(key,grouping,group,lo,hi,n,w){
    printf "%s,%d,%d,%d,%d,%s,%s,%d,%d,%d,%d,%.6f\n",campaign[key],field[key],f[key],delta[key],K[key],grouping,group,lo,hi,n,w,w/n
}
