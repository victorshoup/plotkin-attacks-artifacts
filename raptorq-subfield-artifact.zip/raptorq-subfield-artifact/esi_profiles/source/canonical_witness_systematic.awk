BEGIN { FS=OFS="," }
NR==1 {
    for (i=1;i<=NF;i++) c[$i]=i
    next
}
$(c["profile"])=="canonical" {
    key=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP \
        $(c["Delta"]) SUBSEP $(c["K"])
    if (!(key in seen)) { seen[key]=1; keys[++key_count]=key }
    z=$(c["zero_systematic"])+0
    n=++count[key]
    values[key SUBSEP n]=z
    sum[key]+=z
    honest_sum[key]+=$(c["honest_systematic"])+0
    if (n==1 || z<minimum[key]) minimum[key]=z
    if (n==1 || z>maximum[key]) maximum[key]=z
}
END {
    print "campaign","field","f","Delta","K","successful_witnesses", \
        "zero_systematic_min","zero_systematic_mean","zero_systematic_median", \
        "zero_systematic_max","honest_systematic_mean","zero_systematic_fraction"
    for (ki=1;ki<=key_count;ki++) {
        key=keys[ki]
        n=count[key]
        for (i=1;i<=n;i++) sorted[i]=values[key SUBSEP i]
        for (i=2;i<=n;i++) {
            v=sorted[i]; j=i-1
            while (j>=1 && sorted[j]>v) { sorted[j+1]=sorted[j]; j-- }
            sorted[j+1]=v
        }
        if (n%2) median=sorted[(n+1)/2]
        else median=(sorted[n/2]+sorted[n/2+1])/2
        split(key,a,SUBSEP)
        printf "%s,%s,%s,%s,%s,%d,%d,%.6f,%.3f,%d,%.6f,%.6f\n", \
            a[1],a[2],a[3],a[4],a[5],n,minimum[key],sum[key]/n,median, \
            maximum[key],honest_sum[key]/n,sum[key]/honest_sum[key]
        for (i=1;i<=n;i++) delete sorted[i]
    }
}
