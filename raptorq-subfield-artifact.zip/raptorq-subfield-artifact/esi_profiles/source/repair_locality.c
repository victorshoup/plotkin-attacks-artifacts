#define main rq_profile_campaign_program_main
#include "rq_profile_campaign.c"
#undef main

typedef struct {
    int f;
    int K;
} locality_point;

static void emit_window(int f, int K, const char *kind, int index,
                        uint32_t start)
{
    rq_params p = get_params(K);
    int rows = 3 * f + 1;
    matrix_u8 raw = {
        .rows = xcalloc((size_t)rows * p.L, 1),
        .nrows = rows,
        .ncols = p.L
    };
    int degree_counts[MAX_DEG + 1];
    memset(degree_counts, 0, sizeof(degree_counts));
    int indices[MAX_DEG];
    int degree_sum = 0;
    for (int r = 0; r < rows; ++r) {
        uint32_t esi = start + (uint32_t)r;
        uint32_t isi = esi_to_isi(esi, &p);
        int degree = encoding_indices(isi, &p, indices);
        ++degree_counts[degree];
        degree_sum += degree;
        encoding_row_dense(isi, &p, raw.rows + (size_t)r * p.L);
    }
    int duplicate_pairs = 0;
    bool *duplicated = xcalloc((size_t)rows, sizeof(bool));
    for (int i = 0; i < rows; ++i) {
        for (int j = i + 1; j < rows; ++j) {
            if (memcmp(raw.rows + (size_t)i * p.L,
                       raw.rows + (size_t)j * p.L,
                       (size_t)p.L) == 0) {
                ++duplicate_pairs;
                duplicated[i] = duplicated[j] = true;
            }
        }
    }
    int duplicate_rows = 0;
    for (int i = 0; i < rows; ++i) duplicate_rows += duplicated[i];
    printf("%d,%d,%s,%d,%u,%d,%d,%d,%.9f,\"",
           f, K, kind, index, start, rows, matrix_rank(&raw),
           duplicate_pairs, (double)degree_sum / rows);
    bool first = true;
    for (int degree = 0; degree <= MAX_DEG; ++degree) {
        if (degree_counts[degree] == 0) continue;
        printf("%s%d:%d", first ? "" : ";", degree,
               degree_counts[degree]);
        first = false;
    }
    printf("\",%d\n", duplicate_rows);
    free(duplicated);
    free_matrix(&raw);
}

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: %s JOBS.csv OUTPUT.csv MASTER_SEED\n", argv[0]);
        return 2;
    }
    gf256_init();
    uint64_t master_seed = parse_u64(argv[3]);
    FILE *input = fopen(argv[1], "r");
    if (input == NULL) die("cannot open locality input");
    locality_point points[512];
    int point_count = 0;
    char line[2048];
    if (fgets(line, sizeof(line), input) == NULL) die("empty jobs file");
    while (fgets(line, sizeof(line), input) != NULL) {
        char campaign[32], profile[32], point_id[256];
        int field, f, delta, K, exact_d, samples;
        if (sscanf(line, "%31[^,],%31[^,],%d,%d,%d,%d,%d,%d,%255[^\n]",
                   campaign, profile, &field, &f, &delta, &K, &exact_d,
                   &samples, point_id) != 9) die("invalid jobs row");
        if (strcmp(campaign, "delta0") == 0) continue;
        bool seen = false;
        for (int i = 0; i < point_count; ++i) {
            seen |= points[i].f == f && points[i].K == K;
        }
        if (!seen) {
            if (point_count == 512) die("too many locality points");
            points[point_count++] = (locality_point){.f=f, .K=K};
        }
    }
    fclose(input);
    FILE *output = freopen(argv[2], "w", stdout);
    if (output == NULL) die("cannot open locality output");
    puts("f,K,window_kind,window_index,start_esi,row_count,raw_binary_rank,duplicate_pairs,mean_degree,degree_histogram,duplicate_rows");
    uint32_t max_esi = RQ_ESI_DOMAIN - 1;
    for (int pidx = 0; pidx < point_count; ++pidx) {
        int f = points[pidx].f;
        int K = points[pidx].K;
        uint32_t width_minus_one = (uint32_t)(3 * f);
        uint32_t max_start = max_esi - width_minus_one;
        emit_window(f, K, "low-repair", -1, (uint32_t)K);
        emit_window(f, K, "shifted-repair", -1, UINT32_C(1) << 23);
        uint64_t span = (uint64_t)max_start - (uint64_t)K + 1;
        for (int index = 0; index < 16; ++index) {
            uint64_t lo = (uint64_t)K + span * (uint64_t)index / 16;
            uint64_t hi = (uint64_t)K + span * (uint64_t)(index + 1) / 16 - 1;
            rng64 rng;
            uint64_t seed = master_seed
                ^ (uint64_t)f * UINT64_C(0x9e3779b97f4a7c15)
                ^ (uint64_t)K * UINT64_C(0xc2b2ae3587b73a21)
                ^ (uint64_t)index * UINT64_C(0x165667b19e3779f9);
            rng_init(&rng, seed);
            uint64_t selected = lo + rng_below_uniform(&rng,
                                                        (size_t)(hi-lo+1));
            if (selected == (uint64_t)K && selected < hi) ++selected;
            if (selected == (UINT32_C(1) << 23)) {
                selected = selected < hi ? selected + 1 : selected - 1;
            }
            emit_window(f, K, "random-control", index,
                        (uint32_t)selected);
        }
    }
    if (fclose(output) != 0) die("cannot close locality output");
    return 0;
}

