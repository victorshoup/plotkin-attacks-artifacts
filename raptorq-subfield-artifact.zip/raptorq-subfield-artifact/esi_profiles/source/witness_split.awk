BEGIN{FS="=";OFS=",";have=0}
FNR==1{
    if(have)emit()
    have=1;path=FILENAME
    profile=field=f=delta=K=weight=zeros=source_weight=0
    sample=path;sub(/^.*_sample/,"",sample);sub(/\.txt$/, "", sample);sample+=0
    campaign=path
    if(campaign~/\/raw\/primary\/delta0_/)campaign="delta0"
    else if(campaign~/\/raw\/primary\/positive_/)campaign="positive"
    else if(campaign~/\/raw\/primary\/deep_/)campaign="deep"
    else if(campaign~/\/raw\/headline\//)campaign="headline"
    else if(campaign~/\/raw\/sentinel\//)campaign="sentinel"
    else exit 2
}
$1=="profile"{profile=$2}
$1=="field"{field=$2+0}
$1=="f"{f=$2+0}
$1=="Delta"{delta=$2+0}
$1=="K"{K=$2+0}
$1=="weight"{weight=$2+0}
$1=="zeros"{zeros=$2+0}
$1=="source_difference_hex"{
 source_weight=0;for(i=1;i<length($2);i+=2)if(substr($2,i,2)!="00")source_weight++
}
$1=="honest_ESIs"{
 honest_systematic=0;n=split($2,v," ");for(i=1;i<=n;i++)if(v[i]<K)honest_systematic++
 honest_repair=n-honest_systematic
}
$1=="zero_ESIs"{
 zero_systematic=0;nzero=split($2,v," ");for(i=1;i<=nzero;i++)if(v[i]<K)zero_systematic++
 zero_repair=nzero-zero_systematic
}
END{if(have)emit()}
function emit(){
 weight_systematic=honest_systematic-zero_systematic
 weight_repair=honest_repair-zero_repair
 if(weight_systematic+weight_repair!=weight||nzero!=zeros||sample<0||sample>=100)exit 2
 relative_path=path
 if(artifact_prefix!=""&&index(relative_path,artifact_prefix)==1)
     relative_path=substr(relative_path,length(artifact_prefix)+1)
 print campaign,profile,field,f,delta,K,sample,honest_systematic,honest_repair,weight,weight_systematic,weight_repair,zero_systematic,zero_repair,source_weight,relative_path
}
