BEGIN{FS=OFS=","}
FILENAME==masks{
 if(FNR==1)next
 key=$1 SUBSEP $2;mseed[key]=$3;mcount[key]=$4;mhash[key]=$5;mmask[key]=$6;next
}
FILENAME==primary||FILENAME==supplement||FILENAME==sentinel{
 if(FNR==1)next
 key=$2 SUBSEP $3 SUBSEP $4 SUBSEP $5
 campaign[key]=$1;exact[key]=$7;expected[key]=$8;next
}
FILENAME==refs{
 if(FNR==1){delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
 pkey=$(c["f"]) SUBSEP $(c["sample"])
 rkey=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["sample"])
 if("x" $(c["position_seed"])!="x" mseed[pkey]||$(c["position_mask_sha256"])!=mhash[pkey]||refseen[rkey]++)exit 2
 reference[rkey]=1;++refrows;next
}
FNR==1{delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
{
 profile=$(c["profile"]);field=$(c["field"]);f=$(c["f"]);delta=$(c["Delta"]);sample=$(c["sample"]);K=$(c["K"])
 jkey=profile SUBSEP field SUBSEP f SUBSEP delta
 if(!(jkey in campaign)||$(c["campaign"])!=campaign[jkey]||K!=f+1-delta||K<10||
    $(c["n"])!=3*f+1||$(c["h"])!=2*f+1||sample<0||sample>=100||
    $(c["restart_budget"])!=40||$(c["restarts_executed"])!=40||
    $(c["max_residual_dimension"])!=exact[jkey]||$(c["max_directions"])!=70000)exit 2
 ikey=jkey SUBSEP sample;if(instseen[ikey]++)exit 2;++observed[jkey]
 pkey=f SUBSEP sample
 if("x" $(c["honest_set_seed"])!="x" mseed[pkey]||mcount[pkey]!=2*f+1)exit 2
 n=split(mmask[pkey],pos," ");sys=0;for(i=1;i<=n;i++)sys+=pos[i]<K
 offset=profile=="canonical"?0:(profile=="low-repair"?K:8388608)
 expected_sys=profile=="canonical"?sys:0
 if($(c["systematic_count"])!=expected_sys||$(c["repair_count"])!=2*f+1-expected_sys||
    $(c["honest_esi_min"])!=pos[1]+offset||$(c["honest_esi_max"])!=pos[n]+offset)exit 2
 rkey=$(c["campaign"]) SUBSEP profile SUBSEP field SUBSEP f SUBSEP delta SUBSEP sample
 if(!(rkey in reference))exit 2
 if(profile!="shifted-repair"){
  pair=field SUBSEP f SUBSEP delta SUBSEP sample
  if(pair in searchseed && "x" searchseed[pair]!="x" $(c["search_seed"]))exit 2
  searchseed[pair]=$(c["search_seed"]);++paircount[pair]
 }
 if(!($(c["success"])==0||$(c["success"])==1))exit 2
 successes+=$(c["success"]);paths+=$(c["restarts_executed"]);++rows
}
END{
 if(rows!=47500||paths!=1900000||refrows!=47500)exit 2
 for(key in expected)if(observed[key]!=expected[key])exit 2
 for(key in paircount)if(paircount[key]!=2)exit 2
 if(length(paircount)!=23500)exit 2
 print "INSTANCE VERIFICATION PASS: rows=" rows " paths=" paths " successes=" successes > "/dev/stderr"
}

