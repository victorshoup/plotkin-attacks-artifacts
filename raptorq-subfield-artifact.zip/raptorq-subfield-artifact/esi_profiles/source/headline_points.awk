BEGIN{FS=OFS=","}
FILENAME==comparison{
 if(FNR==1){for(i=1;i<=NF;i++)a[$i]=i;next}
 key=$(a["field"]) SUBSEP $(a["f"]) SUBSEP $(a["Delta"])
 row[key]=$0;next
}
FNR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
$(c["profile"])=="shifted-repair"{
 key=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]);shift[key]=$(c["successes"])
}
END{
 print "field,f,Delta,K,full_domain_successes,canonical_successes,low_repair_successes,shifted_repair_successes,canonical_minus_full,low_repair_minus_full,shifted_repair_minus_full,canonical_minus_low_repair,shifted_repair_minus_low_repair"
 for(key in shift){if(!(key in row))exit 2;split(row[key],v,",")
 print v[2],v[3],v[4],v[5],v[6],v[7],v[8],shift[key],v[9],v[10],shift[key]-v[6],v[11],shift[key]-v[8]}
}
