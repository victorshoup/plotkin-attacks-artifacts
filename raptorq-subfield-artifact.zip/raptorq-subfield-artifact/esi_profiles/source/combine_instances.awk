BEGIN { FS=OFS="," }
FILENAME==primary || FILENAME==supplement || FILENAME==sentinel {
    if (FNR==1) next
    campaign[$2 SUBSEP $3 SUBSEP $4 SUBSEP $5]=$1
    next
}
FNR==1 {
    delete c
    for(i=1;i<=NF;i++)c[$i]=i
    if(!header){print "campaign," $0;header=1}
    next
}
{
    key=$(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
    if(!(key in campaign))exit 2
    print campaign[key],$0
}
