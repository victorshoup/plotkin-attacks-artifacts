BEGIN{FS=OFS=","}
FILENAME==baseline{
 if(FNR==1){delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
 key=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 bw[key]=$(c["witnesses"]);bt[key]=$(c["mean_total_saving"]);br[key]=$(c["mean_raw_LT_saving"]);bl[key]=$(c["mean_restriction_loss"]);next
}
FILENAME==points{
 if(FNR==1){delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
 key=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 campaign[key]=$(c["campaign"]);field[key]=$(c["field"]);f[key]=$(c["f"]);delta[key]=$(c["Delta"]);K[key]=$(c["K"])
 basekey[key]=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]);seen[key]=1;next
}
FNR==1{delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
$(c["success"])==1 && $(c["profile"])!="shifted-repair"{
 key=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 p=$(c["profile"]);n[key SUBSEP p]=$(c["candidates"]);t[key SUBSEP p]=$(c["mean_total_saving"]);r[key SUBSEP p]=$(c["mean_raw_LT_saving"]);l[key SUBSEP p]=$(c["mean_restriction_loss"]);seen[key]=1
}
END{
 print "campaign,field,f,Delta,K,full_domain_witnesses,full_mean_total_saving,full_mean_raw_LT_saving,full_mean_restriction_loss,canonical_witnesses,canonical_mean_total_saving,canonical_mean_raw_LT_saving,canonical_mean_restriction_loss,low_repair_witnesses,low_repair_mean_total_saving,low_repair_mean_raw_LT_saving,low_repair_mean_restriction_loss"
 for(key in seen){b=basekey[key];can=key SUBSEP "canonical";low=key SUBSEP "low-repair"
 printf "%s,%d,%d,%d,%d,%d,%s,%s,%s,%d,%s,%s,%s,%d,%s,%s,%s\n",campaign[key],field[key],f[key],delta[key],K[key],bw[b]+0,(b in bw?bt[b]:""),(b in bw?br[b]:""),(b in bw?bl[b]:""),n[can]+0,(can in n?t[can]:""),(can in n?r[can]:""),(can in n?l[can]:""),n[low]+0,(low in n?t[low]:""),(low in n?r[low]:""),(low in n?l[low]:"")}
}
