BEGIN{FS=OFS=","}
FILENAME==d0||FILENAME==positive||FILENAME==deep{
 if(FNR==1){delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
 key=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 full[key]=$(c["rq_successes"]);fullK[key]=$(c["K"]);next
}
FNR==1{delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
$(c["profile"])=="canonical"||$(c["profile"])=="low-repair"{
 key=$(c["campaign"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 base=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
 campaign[key]=$(c["campaign"]);field[key]=$(c["field"]);f[key]=$(c["f"]);delta[key]=$(c["Delta"]);K[key]=$(c["K"])
 value[key SUBSEP $(c["profile"])]=$(c["successes"]);basekey[key]=base;seen[key]=1
}
END{
 print "campaign,field,f,Delta,K,full_domain_successes,canonical_successes,low_repair_successes,canonical_minus_full,low_repair_minus_full,canonical_minus_low_repair,full_domain_fraction,canonical_fraction,low_repair_fraction"
 for(key in seen){b=basekey[key];if(!(b in full)||K[key]!=fullK[b])exit 2;can=value[key SUBSEP "canonical"];low=value[key SUBSEP "low-repair"]
 printf "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.6f,%.6f,%.6f\n",campaign[key],field[key],f[key],delta[key],K[key],full[b],can,low,can-full[b],low-full[b],can-low,full[b]/100,can/100,low/100}
}

