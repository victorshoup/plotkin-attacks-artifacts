BEGIN{FS=OFS=","}
NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
{
 key=$(c["campaign"]) SUBSEP $(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["success"])
 campaign[key]=$(c["campaign"]);profile[key]=$(c["profile"]);field[key]=$(c["field"])
 f[key]=$(c["f"]);delta[key]=$(c["Delta"]);K[key]=$(c["K"]);outcome[key]=$(c["success"])
 n[key]++;zero[key]+=$(c["zero_count"]);total[key]+=$(c["total_saving"])
 raw[key]+=$(c["raw_LT_saving"]);restriction[key]+=$(c["restriction_loss"])
 if($(c["total_saving"])>maxtotal[key])maxtotal[key]=$(c["total_saving"])
 if($(c["raw_LT_saving"])>maxraw[key])maxraw[key]=$(c["raw_LT_saving"])
 if($(c["restriction_loss"])>maxrestriction[key])maxrestriction[key]=$(c["restriction_loss"])
 if($(c["restricted_rank_identity_ok"])==0)ridfail[key]++
 if($(c["intersection_identity_ok"])>=0){icheck[key]++;if($(c["intersection_identity_ok"])==0)ifail[key]++}
}
END{
 print "campaign,profile,field,f,Delta,K,success,candidates,mean_zero_count,mean_total_saving,mean_raw_LT_saving,mean_restriction_loss,max_total_saving,max_raw_LT_saving,max_restriction_loss,restricted_identity_failures,intersection_checks,intersection_identity_failures"
 for(key in n)printf "%s,%s,%d,%d,%d,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%d,%d,%d,%d,%d,%d\n",campaign[key],profile[key],field[key],f[key],delta[key],K[key],outcome[key],n[key],zero[key]/n[key],total[key]/n[key],raw[key]/n[key],restriction[key]/n[key],maxtotal[key],maxraw[key],maxrestriction[key],ridfail[key],icheck[key],ifail[key]
}

