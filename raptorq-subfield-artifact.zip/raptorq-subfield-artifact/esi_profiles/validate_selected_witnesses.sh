#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
CC=${CC:-cc}
export CC
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1
NANORQ=${NANORQ_CHECKOUT:-"$ARTIFACT/source/nanorq"}
PINNED=6295a9525893b9a757dd57431db76fc6ecceafac
test "$(cat "$NANORQ/PINNED_COMMIT")" = "$PINNED"
BUILD_DIR=${VALIDATION_BUILD_DIR:-"$HERE/build"}
SELECTED_DIR=${SELECTED_OUTPUT_DIR:-"$HERE/witnesses/selected"}
OUTPUT_DIR=${VALIDATION_OUTPUT_DIR:-"$HERE/validation"}
RAW_INPUT=${RAW_INPUT_ROOT:-"$HERE/raw"}
MASK_INPUT=${POSITION_MASK_INPUT:-"$HERE/position_masks/masks.csv"}
mkdir -p "$BUILD_DIR" "$SELECTED_DIR" "$OUTPUT_DIR"

if test ! -f "$NANORQ/libnanorq.a"; then
    make -C "$NANORQ" -j 2 libnanorq.a > "$OUTPUT_DIR/nanorq_build.log" 2>&1
fi
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    -I"$NANORQ/include" -I"$NANORQ/deps" \
    "$ARTIFACT/source/current_empirical/nanorq_witness_audit.c" \
    "$NANORQ/libnanorq.a" -o "$BUILD_DIR/nanorq_witness_audit" \
    2> "$OUTPUT_DIR/nanorq_checker_build_warnings.txt"
if test -s "$OUTPUT_DIR/nanorq_checker_build_warnings.txt"; then
    echo "COMPILER WARNINGS (nonfatal): $OUTPUT_DIR/nanorq_checker_build_warnings.txt" >&2
    cat "$OUTPUT_DIR/nanorq_checker_build_warnings.txt" >&2
fi

CSV="$OUTPUT_DIR/selected_witnesses.csv"
LOG="$OUTPUT_DIR/nanorq_validation.log"
echo "campaign,profile,field,f,Delta,K,sample,selection_rule,witness_file,witness_sha256,nanorq_commit,internal_full_audit,nanorq_audit,result" > "$CSV"
{
    echo "Selected-witness validation"
    echo "nanorq commit: $PINNED"
    echo "compiler: $CC"
    "$CC" --version
} > "$LOG"

while IFS=, read -r campaign profile field f delta point_id; do
    test -z "$campaign" && continue
    test "$campaign" = campaign && continue
    case "$campaign" in
        delta0|positive|deep) root=primary ;;
        headline) root=headline ;;
        sentinel) root=sentinel ;;
        *) exit 2 ;;
    esac
    point="$RAW_INPUT/$root/$point_id"
    sample=$(awk -F, 'NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
        $(c["success"])==1{print $(c["sample"]);exit}' "$point/instances.csv")
    K=$((f + 1 - delta))
    if test -z "$sample"; then
        printf '%s,%s,%s,%s,%s,%s,,lowest_successful_sample,,,,not_run,not_run,no_success\n' \
            "$campaign" "$profile" "$field" "$f" "$delta" "$K" >> "$CSV"
        echo "NO SUCCESS: $profile q=$field f=$f Delta=$delta" >> "$LOG"
        continue
    fi
    source="$point/witnesses/witness_q${field}_f${f}_delta${delta}_sample${sample}.txt"
    test -s "$source"
    destination_dir="$SELECTED_DIR/$profile"
    mkdir -p "$destination_dir"
    destination="$destination_dir/${source##*/}"
    cp "$source" "$destination"
    relative="witnesses/selected/$profile/${source##*/}"
    hash=$(shasum -a 256 "$destination" | awk '{print $1}')

    TEMP=$(mktemp -d /tmp/rq-profile-selected-XXXXXX)
    "$BUILD_DIR/witness_structure_profile" "$destination" "$sample" \
        > "$TEMP/recomputed_structure.csv"
    { head -n 1 "$point/zero_set_structure.csv"; awk -F, -v s="$sample" \
        'NR>1&&$6==s{print}' "$point/zero_set_structure.csv"; } \
        > "$TEMP/saved_structure.csv"
    cmp "$TEMP/recomputed_structure.csv" "$TEMP/saved_structure.csv"
    awk -F, -v profile="$profile" -v f="$f" -v sample="$sample" \
        'NR==1{next}$1==f&&$2==sample{mask=$6}
         END{if(mask=="")exit 2;print mask}' \
        "$MASK_INPUT" > "$TEMP/mask"
    sed -n 's/^honest_ESIs=//p' "$destination" > "$TEMP/esis"
    awk -v profile="$profile" -v K="$K" '
        NR==FNR{mask=$0;next}
        END{n=split(mask,p," ");m=split($0,e," ");if(n!=m)exit 2
            off=profile=="canonical"?0:(profile=="low-repair"?K:8388608)
            for(i=1;i<=n;i++)if(e[i]!=p[i]+off)exit 2}' \
        "$TEMP/mask" "$TEMP/esis"
    {
        echo
        echo "$profile q=$field f=$f Delta=$delta sample=$sample"
        "$BUILD_DIR/nanorq_witness_audit" "$destination"
        echo "INTERNAL FULL AUDIT PASS: source/intermediate/ESIs/zero-set/weight/rank identities"
    } >> "$LOG" 2>&1
    rm -rf "$TEMP"
    printf '%s,%s,%s,%s,%s,%s,%s,lowest_successful_sample,%s,%s,%s,pass,pass,pass\n' \
        "$campaign" "$profile" "$field" "$f" "$delta" "$K" "$sample" \
        "$relative" "$hash" "$PINNED" >> "$CSV"
done < "$HERE/config/witness_validation_points.csv"

expected=$(awk -F, 'NR>1&&$1!=""{n++}END{print n+0}' \
    "$HERE/config/witness_validation_points.csv")
test "$(($(wc -l < "$CSV") - 1))" = "$expected"
validated=$(grep -c ',pass$' "$CSV" || true)
test "$(grep -c '^NANORQ FULL WITNESS PASS:' "$LOG" || true)" = "$validated"
test "$(grep -c '^INTERNAL FULL AUDIT PASS:' "$LOG" || true)" = "$validated"
echo "SELECTED WITNESS VALIDATION PASS: $validated validated; $((expected-validated)) no-success targets"
