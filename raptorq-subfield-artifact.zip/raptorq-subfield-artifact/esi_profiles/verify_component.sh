#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
SOURCE="$HERE/source"
APPENDIX_SOURCE="$ARTIFACT/source/current_empirical"
BASELINE="$ARTIFACT/empirical/summaries"
PAPER="$ARTIFACT/paper_data/esi_profiles"
NANORQ=${NANORQ_CHECKOUT:-"$ARTIFACT/source/nanorq"}
CC=${CC:-cc}
export CC
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1
TEMP=$(mktemp -d /tmp/rq-profile-verify-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/bin" "$TEMP/config" "$TEMP/masks" "$TEMP/summaries" \
    "$TEMP/paper" "$TEMP/validation" "$TEMP/selected" \
    "$TEMP/validation_build"

test "$(shasum -a 256 "$APPENDIX_SOURCE/rq_empirical.c" | awk '{print $1}')" = 20629b77690e845da4c6bc464712ea656a4b5208ecdb7c4681e9862dad0c14c9
test "$(shasum -a 256 "$APPENDIX_SOURCE/rq_tables.h" | awk '{print $1}')" = bbe8e36937a0fa1ce7869799ad93934ed891d9ee03f1f1e817262607f650eedc
test "$(shasum -a 256 "$SOURCE/rq_profile_campaign.c" | awk '{print $1}')" = c11781697b183391dfccf560575962feb28678238cfc2564299572b9da9a4398
test "$(shasum -a 256 "$BASELINE/delta0.csv" | awk '{print $1}')" = 07900e2e1df4ed46b654f79e5fd5ab6222dc5dd99d40c3cac7e564023f0949f0
test "$(shasum -a 256 "$BASELINE/positive_grid.csv" | awk '{print $1}')" = e01c4987893a3cee35b7397b906427a07b114cd930cff20e0315f26d6443889c
test "$(shasum -a 256 "$BASELINE/gf256_deep_tail.csv" | awk '{print $1}')" = ee005d2dfd96cd3a81a5c07df5844b3ef35c9fc2decb1664d8e998585cc1d1d1
test "$(shasum -a 256 "$BASELINE/zero_set_structure_aggregate.csv" | awk '{print $1}')" = acea7bf3c22e267365339a000e902793212e4cf02db2d8f0ec6453e7d0e19dc5
test "$(cat "$NANORQ/PINNED_COMMIT")" = 6295a9525893b9a757dd57431db76fc6ecceafac
grep -q '^MASTER_SEED=202609060101$' "$HERE/config/master.conf"
grep -q '^SEED_SCHEMA=4$' "$HERE/config/master.conf"

for source in rq_profile_campaign position_mask_generator witness_structure_profile repair_locality; do
    "$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic -I"$APPENDIX_SOURCE" \
        "$SOURCE/$source.c" -o "$TEMP/bin/$source" \
        2> "$TEMP/$source.warnings"
    if test -s "$TEMP/$source.warnings"; then
        echo "COMPILER WARNINGS (nonfatal): $TEMP/$source.warnings" >&2
        cat "$TEMP/$source.warnings" >&2
    fi
done
"$TEMP/bin/rq_profile_campaign" --selftest > "$TEMP/selftest.log" 2>&1
grep -q '^SELFTEST PASS:' "$TEMP/selftest.log"

CONFIG_OUTPUT_DIR="$TEMP/config" "$HERE/generate_config.sh" > /dev/null
for file in primary_jobs.csv headline_supplement_jobs.csv sentinel_jobs.csv; do
    cmp "$HERE/config/$file" "$TEMP/config/$file"
done
POSITION_MASK_OUTPUT="$TEMP/masks/masks.csv" \
POSITION_MASK_GENERATOR="$TEMP/bin/position_mask_generator" \
    "$HERE/build_position_masks.sh" > /dev/null
cmp "$HERE/position_masks/masks.csv" "$TEMP/masks/masks.csv"

"$TEMP/bin/repair_locality" "$HERE/config/primary_jobs.csv" \
    "$TEMP/repair_prefix_locality_raw.csv" 202609060101
cmp "$HERE/raw/repair_prefix_locality_raw.csv" \
    "$TEMP/repair_prefix_locality_raw.csv"

awk -v masks="$HERE/position_masks/masks.csv" \
    -v primary="$HERE/config/primary_jobs.csv" \
    -v supplement="$HERE/config/headline_supplement_jobs.csv" \
    -v sentinel="$HERE/config/sentinel_jobs.csv" \
    -v refs="$HERE/audit/position_mask_references.csv" \
    -f "$SOURCE/verify_instances.awk" \
    "$HERE/position_masks/masks.csv" "$HERE/config/primary_jobs.csv" \
    "$HERE/config/headline_supplement_jobs.csv" "$HERE/config/sentinel_jobs.csv" \
    "$HERE/audit/position_mask_references.csv" \
    "$HERE/summaries/instance_results.csv"

awk -v instances="$HERE/summaries/instance_results.csv" \
    -f "$SOURCE/verify_structure.awk" \
    "$HERE/summaries/instance_results.csv" \
    "$HERE/summaries/zero_set_structure.csv"

SUMMARY_OUTPUT_DIR="$TEMP/summaries" PAPER_OUTPUT_DIR="$TEMP/paper" \
    "$HERE/analyze.sh" > "$TEMP/analyze.log"
for file in instance_results.csv zero_set_structure.csv point_summary.csv \
    zero_set_rank_aggregate.csv profile_comparison_all.csv delta0_markers.csv \
    witness_weight_split.csv paired_profile_outcomes.csv \
    canonical_witness_systematic_summary.csv; do
    cmp "$HERE/summaries/$file" "$TEMP/summaries/$file"
done
for file in delta0_profile_comparison.csv positive_profile_comparison.csv \
    gf256_deep_profile_comparison.csv profile_headline_points.csv \
    systematic_count_effect.csv zero_set_rank_profile_comparison.csv \
    projective_profile_comparison.csv repair_prefix_locality.csv; do
    cmp "$PAPER/$file" "$TEMP/paper/$file"
done

awk -F, 'NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
 {if($(c["weight_systematic"])+$(c["weight_repair"])!=$(c["weight"])||
     $(c["zero_systematic"])+$(c["zero_repair"])!=2*$(c["f"])+1-$(c["weight"])||
     $(c["source_difference_weight"])<1)exit 2;++n}
 END{if(n!=16973)exit 2}' "$HERE/summaries/witness_weight_split.csv"
awk -F, 'NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
 $(c["profile"])=="canonical"{if($(c["z_score"]) < -4 || $(c["z_score"]) > 4)exit 2;++n}
 END{if(n!=235)exit 2}' "$HERE/summaries/point_summary.csv"

for root in primary headline sentinel; do
    test "$(cat "$HERE/raw/$root.worker_concurrency/active")" = 0
    test "$(cat "$HERE/raw/$root.worker_concurrency/maximum")" -le 2
done
test "$(($(wc -l < "$HERE/raw/primary.worker_concurrency/events.csv") - 1))" = 932
test "$(($(wc -l < "$HERE/raw/headline.worker_concurrency/events.csv") - 1))" = 8
test "$(($(wc -l < "$HERE/raw/sentinel.worker_concurrency/events.csv") - 1))" = 10
test "$(find "$HERE/raw/primary" "$HERE/raw/headline" "$HERE/raw/sentinel" -name esi_sets.csv -type f | wc -l | tr -d ' ')" = 0

cp -R "$NANORQ" "$TEMP/nanorq"
cp "$TEMP/bin/witness_structure_profile" \
    "$TEMP/validation_build/witness_structure_profile"
NANORQ_CHECKOUT="$TEMP/nanorq" SELECTED_OUTPUT_DIR="$TEMP/selected" \
VALIDATION_OUTPUT_DIR="$TEMP/validation" \
VALIDATION_BUILD_DIR="$TEMP/validation_build" \
    "$HERE/validate_selected_witnesses.sh" > "$TEMP/selected.stdout"
cmp "$HERE/validation/selected_witnesses.csv" \
    "$TEMP/validation/selected_witnesses.csv"
diff -ru "$HERE/witnesses/selected" "$TEMP/selected"

warning_count=$(cat "$TEMP"/*.warnings "$TEMP/validation"/*warnings.txt 2>/dev/null | wc -l | tr -d ' ')
echo "FULL ESI-PROFILE COMPONENT VERIFICATION PASS: instances=47500 paths=1900000 selected_witnesses=11 warnings=$warning_count"
