#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
SOURCE="$HERE/source"
BASELINE="$ARTIFACT/empirical/summaries"
RAW_INPUT=${RAW_INPUT_ROOT:-"$HERE/raw"}
RAW_PREFIX=${RAW_ARTIFACT_PREFIX:-"$HERE/"}
SUMMARY_OUTPUT=${SUMMARY_OUTPUT_DIR:-"$HERE/summaries"}
PAPER_OUTPUT=${PAPER_OUTPUT_DIR:-"$ARTIFACT/paper_data/esi_profiles"}
mkdir -p "$SUMMARY_OUTPUT" "$PAPER_OUTPUT"
TEMP=$(mktemp -d /tmp/rq-profile-analysis-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
export LC_ALL=C

awk -v primary="$HERE/config/primary_jobs.csv" \
    -v supplement="$HERE/config/headline_supplement_jobs.csv" \
    -v sentinel="$HERE/config/sentinel_jobs.csv" \
    -f "$SOURCE/combine_instances.awk" \
    "$HERE/config/primary_jobs.csv" "$HERE/config/headline_supplement_jobs.csv" \
    "$HERE/config/sentinel_jobs.csv" "$RAW_INPUT"/primary/*/instances.csv \
    "$RAW_INPUT"/headline/*/instances.csv "$RAW_INPUT"/sentinel/*/instances.csv \
    > "$SUMMARY_OUTPUT/instance_results.csv"
test "$(($(wc -l < "$SUMMARY_OUTPUT/instance_results.csv") - 1))" = 47500

awk -v primary="$HERE/config/primary_jobs.csv" \
    -v supplement="$HERE/config/headline_supplement_jobs.csv" \
    -v sentinel="$HERE/config/sentinel_jobs.csv" \
    -f "$SOURCE/combine_structure.awk" \
    "$HERE/config/primary_jobs.csv" "$HERE/config/headline_supplement_jobs.csv" \
    "$HERE/config/sentinel_jobs.csv" \
    "$RAW_INPUT"/primary/*/zero_set_structure.csv \
    "$RAW_INPUT"/headline/*/zero_set_structure.csv \
    "$RAW_INPUT"/sentinel/*/zero_set_structure.csv \
    > "$SUMMARY_OUTPUT/zero_set_structure.csv"

awk -f "$SOURCE/summarize_points.awk" \
    "$SUMMARY_OUTPUT/instance_results.csv" > "$TEMP/point.unsorted"
{ head -n 1 "$TEMP/point.unsorted"; tail -n +2 "$TEMP/point.unsorted" | sort -t, -k1,1 -k2,2 -k3,3n -k4,4n -k5,5n; } \
    > "$SUMMARY_OUTPUT/point_summary.csv"

awk -f "$SOURCE/systematic_effect.awk" \
    "$SUMMARY_OUTPUT/instance_results.csv" > "$TEMP/systematic.unsorted"
{ head -n 1 "$TEMP/systematic.unsorted"; tail -n +2 "$TEMP/systematic.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n -k8,8n; } \
    > "$PAPER_OUTPUT/systematic_count_effect.csv"

awk -f "$SOURCE/aggregate_structure.awk" \
    "$SUMMARY_OUTPUT/zero_set_structure.csv" > "$TEMP/structure.unsorted"
{ head -n 1 "$TEMP/structure.unsorted"; tail -n +2 "$TEMP/structure.unsorted" | sort -t, -k1,1 -k2,2 -k3,3n -k4,4n -k5,5n -k7,7n; } \
    > "$SUMMARY_OUTPUT/zero_set_rank_aggregate.csv"

awk -f "$SOURCE/aggregate_projective.awk" \
    "$SUMMARY_OUTPUT/instance_results.csv" > "$TEMP/projective.unsorted"
{ head -n 1 "$TEMP/projective.unsorted"; tail -n +2 "$TEMP/projective.unsorted" | sort -t, -k1,1 -k2,2 -k3,3n -k4,4n -k5,5n -k7,7; } \
    > "$PAPER_OUTPUT/projective_profile_comparison.csv"

awk -v d0="$BASELINE/delta0.csv" \
    -v positive="$BASELINE/positive_grid.csv" \
    -v deep="$BASELINE/gf256_deep_tail.csv" \
    -f "$SOURCE/profile_comparison.awk" \
    "$BASELINE/delta0.csv" \
    "$BASELINE/positive_grid.csv" \
    "$BASELINE/gf256_deep_tail.csv" \
    "$SUMMARY_OUTPUT/point_summary.csv" > "$TEMP/comparison.unsorted"
{ head -n 1 "$TEMP/comparison.unsorted"; tail -n +2 "$TEMP/comparison.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n; } \
    > "$SUMMARY_OUTPUT/profile_comparison_all.csv"

for campaign in delta0 positive deep; do
    case "$campaign" in
        delta0) output=delta0_profile_comparison.csv ;;
        positive) output=positive_profile_comparison.csv ;;
        deep) output=gf256_deep_profile_comparison.csv ;;
    esac
    awk -F, -v campaign="$campaign" 'NR==1||$1==campaign' \
        "$SUMMARY_OUTPUT/profile_comparison_all.csv" > "$PAPER_OUTPUT/$output"
done

awk -v comparison="$SUMMARY_OUTPUT/profile_comparison_all.csv" \
    -f "$SOURCE/headline_points.awk" \
    "$SUMMARY_OUTPUT/profile_comparison_all.csv" "$SUMMARY_OUTPUT/point_summary.csv" \
    > "$TEMP/headline.unsorted"
{ head -n 1 "$TEMP/headline.unsorted"; tail -n +2 "$TEMP/headline.unsorted" | sort -t, -k1,1n -k2,2n -k3,3n; } \
    > "$PAPER_OUTPUT/profile_headline_points.csv"

awk -f "$SOURCE/delta0_markers.awk" \
    "$SUMMARY_OUTPUT/profile_comparison_all.csv" > "$TEMP/markers.unsorted"
{ head -n 1 "$TEMP/markers.unsorted"; tail -n +2 "$TEMP/markers.unsorted" | sort -t, -k1,1n -k2,2; } \
    > "$SUMMARY_OUTPUT/delta0_markers.csv"

awk -v baseline="$BASELINE/zero_set_structure_aggregate.csv" \
    -v points="$SUMMARY_OUTPUT/profile_comparison_all.csv" \
    -f "$SOURCE/rank_profile_comparison.awk" \
    "$BASELINE/zero_set_structure_aggregate.csv" \
    "$SUMMARY_OUTPUT/profile_comparison_all.csv" \
    "$SUMMARY_OUTPUT/zero_set_rank_aggregate.csv" > "$TEMP/rank.unsorted"
{ head -n 1 "$TEMP/rank.unsorted"; tail -n +2 "$TEMP/rank.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n; } \
    > "$PAPER_OUTPUT/zero_set_rank_profile_comparison.csv"

awk -f "$SOURCE/locality_summary.awk" \
    "$RAW_INPUT/repair_prefix_locality_raw.csv" > "$TEMP/locality.unsorted"
{ head -n 1 "$TEMP/locality.unsorted"; tail -n +2 "$TEMP/locality.unsorted" | sort -t, -k1,1n -k2,2n; } \
    > "$PAPER_OUTPUT/repair_prefix_locality.csv"

RAW_INPUT_ROOT="$RAW_INPUT" RAW_ARTIFACT_PREFIX="$RAW_PREFIX" \
WITNESS_SPLIT_OUTPUT="$SUMMARY_OUTPUT/witness_weight_split.csv" \
    "$HERE/summarize_witnesses.sh"

awk -f "$SOURCE/paired_outcomes.awk" \
    "$SUMMARY_OUTPUT/instance_results.csv" > "$TEMP/paired.unsorted"
{ head -n 1 "$TEMP/paired.unsorted"; tail -n +2 "$TEMP/paired.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n; } \
    > "$SUMMARY_OUTPUT/paired_profile_outcomes.csv"

awk -f "$SOURCE/canonical_witness_systematic.awk" \
    "$SUMMARY_OUTPUT/witness_weight_split.csv" > "$TEMP/canonical-witness.unsorted"
{ head -n 1 "$TEMP/canonical-witness.unsorted"; tail -n +2 "$TEMP/canonical-witness.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n; } \
    > "$SUMMARY_OUTPUT/canonical_witness_systematic_summary.csv"

echo "ANALYSIS PASS: 47500 instances"
