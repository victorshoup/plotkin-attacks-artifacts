#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUTPUT=${WITNESS_SPLIT_OUTPUT:-"$HERE/summaries/witness_weight_split.csv"}
RAW_INPUT=${RAW_INPUT_ROOT:-"$HERE/raw"}
ARTIFACT_PREFIX=${RAW_ARTIFACT_PREFIX:-"$HERE/"}
TEMP=$(mktemp -d /tmp/rq-profile-witnesses-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
find "$RAW_INPUT/primary" "$RAW_INPUT/headline" "$RAW_INPUT/sentinel" \
    -path '*/witnesses/*.txt' -type f -print | LC_ALL=C sort > "$TEMP/files"
echo "campaign,profile,field,f,Delta,K,sample,honest_systematic,honest_repair,weight,weight_systematic,weight_repair,zero_systematic,zero_repair,source_difference_weight,witness_file" > "$OUTPUT"
xargs -n 256 awk -v artifact_prefix="$ARTIFACT_PREFIX" \
    -f "$HERE/source/witness_split.awk" \
    < "$TEMP/files" >> "$OUTPUT"
echo "WITNESS SPLIT PASS: $(($(wc -l < "$OUTPUT") - 1)) witnesses"
