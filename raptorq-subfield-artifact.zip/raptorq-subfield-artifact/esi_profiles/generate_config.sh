#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUTPUT=${CONFIG_OUTPUT_DIR:-"$HERE/config"}
mkdir -p "$OUTPUT"

awk 'BEGIN {
    OFS=",";
    print "campaign,profile,field,f,Delta,K,exact_d,samples,point_id";
    profile[1]="canonical"; profile[2]="low-repair";
    q[1]=4; q[2]=16; q[3]=256;
    exact[4]=8; exact[16]=5; exact[256]=3;
    for (p=1; p<=2; ++p) {
        for (f=32; f<=45; ++f)
            emit("delta0",profile[p],4,f,0);
        for (f=20; f<=35; ++f)
            emit("delta0",profile[p],16,f,0);
        for (f=9; f<=20; ++f)
            emit("delta0",profile[p],256,f,0);
    }
    split("24 32 40 48 64 80 96", fs, " ");
    split("1 2 4 6 8 12 16 24 32 40", ds, " ");
    for (p=1; p<=2; ++p)
        for (qi=1; qi<=3; ++qi)
            for (fi=1; fi<=7; ++fi)
                for (di=1; di<=10; ++di)
                    if (fs[fi]+1-ds[di] >= 10)
                        emit("positive",profile[p],q[qi],fs[fi],ds[di]);
    split("64 80 96", deepf, " ");
    split("48 56 61 64 68", deepd, " ");
    for (p=1; p<=2; ++p)
        for (fi=1; fi<=3; ++fi)
            for (di=1; di<=5; ++di)
                if (deepf[fi]+1-deepd[di] >= 10)
                    emit("deep",profile[p],256,deepf[fi],deepd[di]);
}
function emit(campaign,profile,field,f,delta, K,id) {
    K=f+1-delta;
    id=campaign "_" profile "_q" field "_f" f "_d" delta;
    print campaign,profile,field,f,delta,K,exact[field],100,id;
}' > "$OUTPUT/primary_jobs.csv"

awk 'BEGIN {
    OFS=",";
    print "campaign,profile,field,f,Delta,K,exact_d,samples,point_id";
    emit(4,64,14,8);
    emit(16,80,8,5);
    emit(256,64,4,3);
    emit(256,96,24,3);
    emit(256,96,31,3);
}
function emit(field,f,delta,exact, K,id) {
    K=f+1-delta;
    id="sentinel_shifted-repair_q" field "_f" f "_d" delta;
    print "sentinel","shifted-repair",field,f,delta,K,exact,100,id;
}' > "$OUTPUT/sentinel_jobs.csv"

awk 'BEGIN {
    OFS=",";
    print "campaign,profile,field,f,Delta,K,exact_d,samples,point_id";
    profile[1]="canonical"; profile[2]="low-repair";
    for (p=1; p<=2; ++p) {
        emit(profile[p],4,64,14,8);
        emit(profile[p],256,96,31,3);
    }
}
function emit(profile,field,f,delta,exact, K,id) {
    K=f+1-delta;
    id="headline_" profile "_q" field "_f" f "_d" delta;
    print "headline",profile,field,f,delta,K,exact,100,id;
}' > "$OUTPUT/headline_supplement_jobs.csv"

echo "CONFIG GENERATION PASS"
