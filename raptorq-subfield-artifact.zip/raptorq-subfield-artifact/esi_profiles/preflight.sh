#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
APPENDIX_SOURCE="$ARTIFACT/source/current_empirical"
BASELINE="$ARTIFACT/empirical/summaries"
. "$HERE/config/master.conf"

test "$(shasum -a 256 "$APPENDIX_SOURCE/rq_empirical.c" | awk '{print $1}')" = \
    20629b77690e845da4c6bc464712ea656a4b5208ecdb7c4681e9862dad0c14c9
test "$(shasum -a 256 "$APPENDIX_SOURCE/rq_tables.h" | awk '{print $1}')" = \
    bbe8e36937a0fa1ce7869799ad93934ed891d9ee03f1f1e817262607f650eedc
test "$(shasum -a 256 "$APPENDIX_SOURCE/witness_structure.c" | awk '{print $1}')" = \
    08dfa94273146576fae9ef48531defca75ef7e506d2541a56c532ddfae54cd35
test "$(shasum -a 256 "$APPENDIX_SOURCE/nanorq_witness_audit.c" | awk '{print $1}')" = \
    39842ff2f2d1dcf38390f8d21bed767b444a29d9812d71d3ae54d331c7cfd7f9

awk -F, '
    FNR==1 {next}
    {
        if ($6 != $4+1-$5 || $8 != 100 ||
            !(($2=="canonical")||($2=="low-repair"))) exit 2
        if (($3==4 && $7!=8)||($3==16 && $7!=5)||($3==256 && $7!=3)) exit 2
        key=$1 SUBSEP $3 SUBSEP $4 SUBSEP $5
        if (seen[key SUBSEP $2]++) exit 2
        ++pair[key]; ++campaign[$1]; ++profile[$2]; ++rows; instances+=$8
    }
    END {
        if (rows!=466 || instances!=46600 || campaign["delta0"]!=84 ||
            campaign["positive"]!=360 || campaign["deep"]!=22 ||
            profile["canonical"]!=233 || profile["low-repair"]!=233) exit 2
        for (key in pair) if (pair[key]!=2) exit 2
        if (length(pair)!=233) exit 2
    }
' "$HERE/config/primary_jobs.csv"

awk -F, 'NR==1{next} {
    if($1!="sentinel"||$2!="shifted-repair"||$6!=$4+1-$5||$8!=100)exit 2
    if(seen[$3 SUBSEP $4 SUBSEP $5]++)exit 2; ++n; instances+=$8
} END{if(n!=5||instances!=500)exit 2}' "$HERE/config/sentinel_jobs.csv"

awk -F, 'NR==1{next} {
    if($1!="headline"||!(($2=="canonical")||($2=="low-repair"))||
       $6!=$4+1-$5||$8!=100)exit 2
    if(seen[$2 SUBSEP $3 SUBSEP $4 SUBSEP $5]++)exit 2
    ++n;instances+=$8
} END{if(n!=4||instances!=400)exit 2}' \
    "$HERE/config/headline_supplement_jobs.csv"

awk -F, '
    FILENAME != jobs {
        if (FNR==1) {delete c; for(i=1;i<=NF;++i)c[$i]=i; next}
        key=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
        successes[key]=$(c["rq_successes"]); samples[key]=$(c["samples"])
        next
    }
    FNR==1 {next}
    {
        key=$3 SUBSEP $4 SUBSEP $5
        if (!(key in successes) || samples[key]!=100) exit 2
        found[key]=1
    }
    END {if(length(found)!=233)exit 2}
' jobs="$HERE/config/primary_jobs.csv" \
    "$BASELINE/delta0.csv" \
    "$BASELINE/positive_grid.csv" \
    "$BASELINE/gf256_deep_tail.csv" \
    "$HERE/config/primary_jobs.csv"

echo "PREFLIGHT PASS: primary=46600 instances/1864000 paths; headline supplement=400/16000; shifted sentinels=500/20000"
