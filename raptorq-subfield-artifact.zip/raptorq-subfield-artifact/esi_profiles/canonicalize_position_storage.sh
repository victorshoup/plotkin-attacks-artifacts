#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
test -s "$HERE/audit/position_mask_references.csv"
test "$(($(wc -l < "$HERE/audit/position_mask_references.csv") - 1))" = 47500
count=$(find "$HERE/raw/primary" "$HERE/raw/headline" "$HERE/raw/sentinel" \
    -name esi_sets.csv -type f | wc -l | tr -d ' ')
test "$count" = 475
duplicate_bytes=$(find "$HERE/raw/primary" "$HERE/raw/headline" "$HERE/raw/sentinel" \
    -name esi_sets.csv -type f -exec wc -c {} + | \
    awk '$2!="total"{sum+=$1}END{print sum+0}')
mask_bytes=$(wc -c < "$HERE/position_masks/masks.csv" | tr -d ' ')
find "$HERE/raw/primary" "$HERE/raw/headline" "$HERE/raw/sentinel" \
    -name esi_sets.csv -type f -delete
test "$(find "$HERE/raw/primary" "$HERE/raw/headline" "$HERE/raw/sentinel" \
    -name esi_sets.csv -type f | wc -l | tr -d ' ')" = 0
{
    echo "POSITION STORAGE CANONICALIZATION PASS"
    echo "removed_point_level_esi_files=$count"
    echo "removed_uncompressed_bytes=$duplicate_bytes"
    echo "retained_distinct_position_masks=4100"
    echo "retained_mask_file_bytes=$mask_bytes"
    echo "retained_hash_references=47500"
} > "$HERE/audit/position_storage_canonicalization.txt"
echo "POSITION STORAGE CANONICALIZATION PASS: removed $count audited point-level copies ($duplicate_bytes bytes); retained 4100 canonical masks and 47500 hash references"
