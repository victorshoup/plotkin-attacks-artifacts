#!/bin/bash
set -euo pipefail

if test "$#" -ne 2; then
    echo "usage: $0 JOB_MANIFEST.csv OUTPUT_ROOT" >&2
    exit 2
fi
MANIFEST=$1
OUTPUT_ROOT=$2
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$HERE/config/master.conf"
EFFECTIVE_JOBS=${JOBS_OVERRIDE:-$JOBS}
test "$EFFECTIVE_JOBS" = 2 || { echo "JOBS must be exactly 2" >&2; exit 2; }
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1

if test -e "$OUTPUT_ROOT"; then
    test -d "$OUTPUT_ROOT"
    test -z "$(find "$OUTPUT_ROOT" -mindepth 1 -maxdepth 1 -print -quit)" || {
        echo "output directory is not empty: $OUTPUT_ROOT" >&2; exit 2;
    }
else
    mkdir -p "$OUTPUT_ROOT"
fi
AUDIT_DIR="${OUTPUT_ROOT}.worker_concurrency"
mkdir -p "$AUDIT_DIR"
printf '0\n' > "$AUDIT_DIR/active"
printf '0\n' > "$AUDIT_DIR/maximum"
printf 'unix_time,event,pid,point_id,active_workers\n' > "$AUDIT_DIR/events.csv"
export WORKER_AUDIT_DIR="$AUDIT_DIR"

JOBS_FILE="${OUTPUT_ROOT}.jobs.txt"
awk -F, -v output="$OUTPUT_ROOT" 'NR>1 {
    print output,$1,$2,$3,$4,$5,$6,$7,$8,$9
}' "$MANIFEST" > "$JOBS_FILE"

start=$(date +%s)
xargs -P 2 -n 10 "$HERE/run_point.sh" < "$JOBS_FILE"
end=$(date +%s)
printf 'wall_seconds=%s\n' "$((end-start))" > "${OUTPUT_ROOT}.runtime.txt"
test "$(cat "$AUDIT_DIR/active")" = 0
test "$(cat "$AUDIT_DIR/maximum")" -le 2
echo "BATCH PASS: manifest=$MANIFEST wall_seconds=$((end-start)) max_workers=$(cat "$AUDIT_DIR/maximum")"

