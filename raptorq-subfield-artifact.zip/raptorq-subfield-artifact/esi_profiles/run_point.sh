#!/bin/bash
set -euo pipefail

if test "$#" -ne 10; then
    echo "usage: $0 OUTPUT_ROOT CAMPAIGN PROFILE FIELD F DELTA K EXACT_D SAMPLES POINT_ID" >&2
    exit 2
fi
OUTPUT_ROOT=$1
CAMPAIGN=$2
PROFILE=$3
FIELD=$4
F=$5
DELTA=$6
K=$7
EXACT_D=$8
POINT_SAMPLES=$9
POINT_ID=${10}
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$HERE/config/master.conf"

test "$K" = "$((F + 1 - DELTA))"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1

AUDIT_DIR=${WORKER_AUDIT_DIR:?WORKER_AUDIT_DIR is required}
LOCK="$AUDIT_DIR/lock"
ACTIVE=0
lock_audit() { while ! mkdir "$LOCK" 2>/dev/null; do sleep 0.01; done; }
unlock_audit() { rmdir "$LOCK"; }
leave_worker() {
    test "$ACTIVE" = 1 || return 0
    lock_audit
    active=$(cat "$AUDIT_DIR/active")
    active=$((active - 1))
    printf '%s\n' "$active" > "$AUDIT_DIR/active"
    printf '%s,leave,%s,%s,%s\n' "$(date +%s)" "$$" "$POINT_ID" "$active" >> "$AUDIT_DIR/events.csv"
    ACTIVE=0
    unlock_audit
}
lock_audit
active=$(cat "$AUDIT_DIR/active")
active=$((active + 1))
maximum=$(cat "$AUDIT_DIR/maximum")
test "$active" -le 2 || { unlock_audit; echo "STOP: more than two CPU workers" >&2; exit 2; }
test "$maximum" -ge "$active" || maximum=$active
printf '%s\n' "$active" > "$AUDIT_DIR/active"
printf '%s\n' "$maximum" > "$AUDIT_DIR/maximum"
printf '%s,enter,%s,%s,%s\n' "$(date +%s)" "$$" "$POINT_ID" "$active" >> "$AUDIT_DIR/events.csv"
ACTIVE=1
unlock_audit
trap leave_worker EXIT

POINT_DIR="$OUTPUT_ROOT/$POINT_ID"
test ! -e "$POINT_DIR"
mkdir -p "$POINT_DIR/witnesses"
{
    echo "campaign=$CAMPAIGN"
    echo "profile=$PROFILE"
    echo "field=$FIELD"
    echo "f=$F"
    echo "Delta=$DELTA"
    echo "K=$K"
    echo "samples=$POINT_SAMPLES"
    echo "greedy_paths=$GREEDY_PATHS"
    echo "master_seed=$MASTER_SEED"
    echo "seed_schema=$SEED_SCHEMA"
    echo "max_residual_d=$EXACT_D"
    echo "max_directions=$MAX_DIRECTIONS"
    echo "early_stop=0"
} > "$POINT_DIR/run.conf"

start=$(date +%s)
"$HERE/build/rq_profile_campaign" \
    --field "$FIELD" --f "$F" --delta "$DELTA" \
    --samples "$POINT_SAMPLES" --sample-start 0 \
    --restarts "$GREEDY_PATHS" --early-stop 0 \
    --max-residual-d "$EXACT_D" --max-directions "$MAX_DIRECTIONS" \
    --profile "$PROFILE" --seed "$MASTER_SEED" --seed-schema "$SEED_SCHEMA" \
    --out "$POINT_DIR/instances.csv" \
    --esi-out "$POINT_DIR/esi_sets.csv" \
    --structure-out "$POINT_DIR/zero_set_structure.csv" \
    --witness-dir "$POINT_DIR/witnesses" \
    > "$POINT_DIR/stdout.log" 2> "$POINT_DIR/stderr.log"
end=$(date +%s)
printf 'wall_seconds=%s\n' "$((end-start))" > "$POINT_DIR/runtime.txt"

test "$(($(wc -l < "$POINT_DIR/instances.csv") - 1))" = "$POINT_SAMPLES"
test "$(($(wc -l < "$POINT_DIR/esi_sets.csv") - 1))" = "$POINT_SAMPLES"
echo "POINT PASS: $POINT_ID samples=$POINT_SAMPLES wall_seconds=$((end-start))"

