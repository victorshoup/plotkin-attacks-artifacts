#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
. "$HERE/config/master.conf"
TEMP=$(mktemp -d /tmp/rq-profile-prelaunch-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
LOG="$HERE/validation/prelaunch_audit.log"
exec > "$LOG" 2>&1

awk '/^static search_result search_explicit_word/{p=1}
     /^static uint8_t \*source_difference_from_coefficients/{p=0}
     p' "$ARTIFACT/source/current_empirical/rq_empirical.c" > "$TEMP/search.appendix"
awk '/^static search_result search_explicit_word/{p=1}
     /^static uint8_t \*source_difference_from_coefficients/{p=0}
     p' "$HERE/source/rq_profile_campaign.c" > "$TEMP/search.campaign"
cmp "$TEMP/search.appendix" "$TEMP/search.campaign"
echo "SEARCH FUNCTION IDENTITY PASS: $(shasum -a 256 "$TEMP/search.campaign" | awk '{print $1}')"

awk -F, -v masks="$HERE/position_masks/masks.csv" '
    FILENAME==masks {
        if(FNR==1)next
        key=$1 SUBSEP $2; seed[key]=$3; count[key]=$4; mask[key]=$6; next
    }
    FNR==1 {delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
    {
        key=$(c["f"]) SUBSEP $(c["sample"])
        if($(c["honest_set_seed"])!=seed[key] || $(c["h"])!=count[key] ||
           $(c["position_mask"])!=mask[key])exit 2
        n=split(mask[key],pos," "); split($(c["honest_ESIs"]),esi," ")
        offset=$(c["profile"])=="canonical" ? 0 : $(c["K"])
        for(i=1;i<=n;i++)if(esi[i]!=pos[i]+offset)exit 2
        pair=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["sample"])
        if(pair in paired && paired[pair]!=mask[key])exit 2
        paired[pair]=mask[key]; ++rows
    }
    END{if(rows!=16)exit 2}
' "$HERE/position_masks/masks.csv" \
    "$HERE"/validation/runtime_pilot/raw/*/esi_sets.csv
echo "PILOT POSITION PAIRING PASS: 16 instances"

for profile in canonical low-repair shifted-repair; do
    mkdir "$TEMP/san-$profile"
    ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 \
    UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    "$HERE/build/rq_profile_campaign_san" --field 256 --f 9 --delta 0 \
        --samples 1 --restarts 40 --early-stop 0 --max-residual-d 3 \
        --max-directions 70000 --profile "$profile" --seed "$MASTER_SEED" \
        --seed-schema 4 --out "$TEMP/san-$profile/instances.csv" \
        --esi-out "$TEMP/san-$profile/esi.csv" \
        --structure-out "$TEMP/san-$profile/structure.csv" \
        --witness-dir "$TEMP/san-$profile/witnesses"
done
echo "SANITIZER PROFILE SPOTS PASS: canonical low-repair shifted-repair"

for run in a b; do
    mkdir "$TEMP/$run"
    "$HERE/build/rq_profile_campaign" --field 256 --f 64 --delta 4 \
        --samples 1 --restarts 40 --early-stop 0 --max-residual-d 3 \
        --max-directions 70000 --profile low-repair --seed "$MASTER_SEED" \
        --seed-schema 4 --out "$TEMP/$run/instances.csv" \
        --esi-out "$TEMP/$run/esi.csv" \
        --structure-out "$TEMP/$run/structure.csv" \
        --witness-dir "$TEMP/$run/witnesses"
    awk -F, 'BEGIN{OFS=","} NR==1{
        for(i=1;i<=NF;i++)if($i!="construction_ms"&&$i!="matrix_ms"&&$i!="search_ms")keep[i]=1
    } {out="";for(i=1;i<=NF;i++)if(keep[i])out=out (out==""?"":OFS) $i;print out}' \
        "$TEMP/$run/instances.csv" > "$TEMP/$run/scientific.csv"
done
cmp "$TEMP/a/scientific.csv" "$TEMP/b/scientific.csv"
cmp "$TEMP/a/esi.csv" "$TEMP/b/esi.csv"
cmp "$TEMP/a/structure.csv" "$TEMP/b/structure.csv"
diff -ru "$TEMP/a/witnesses" "$TEMP/b/witnesses"
echo "OUTPUT-ORDER/REPEAT DETERMINISM PASS"
echo "PRELAUNCH AUDIT PASS"
