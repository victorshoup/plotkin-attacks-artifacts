#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/../.." && pwd)
MAPPING="$HERE/full_domain_baseline_mapping.csv"

count=0
while IFS=, read -r field f delta paper_ref source_file source_row successes samples; do
    test "$field" = field && continue
    paper_file=${paper_ref%:*}
    paper_row=${paper_ref##*:}
    awk -F, -v row="$paper_row" -v q="$field" -v f="$f" -v d="$delta" \
        -v successes="$successes" '
        NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
        NR==row{if($(c["field"])!=q||$(c["f"])!=f||
            $(c["Delta"])!=d||$(c["full_domain_successes"])!=successes)exit 2;
            found=1}
        END{if(!found)exit 2}' "$ARTIFACT/$paper_file"
    awk -F, -v row="$source_row" -v q="$field" -v f="$f" -v d="$delta" \
        -v successes="$successes" -v samples="$samples" '
        NR==1{for(i=1;i<=NF;i++)c[$i]=i;next}
        NR==row{if($(c["field"])!=q||$(c["f"])!=f||
            $(c["Delta"])!=d||$(c["rq_successes"])!=successes||
            $(c["samples"])!=samples)exit 2;found=1}
        END{if(!found)exit 2}' "$ARTIFACT/$source_file"
    count=$((count + 1))
done < "$MAPPING"

test "$count" = 238
echo "FULL-DOMAIN BASELINE MAPPING PASS: $count exact paper rows mapped to retained main empirical rows"
