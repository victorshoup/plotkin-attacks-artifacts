# Scientific summary

This experiment compares observed finite-search success under full-domain ESI
sampling with random assignment of the canonical prefix `0,...,3f`. The
low-repair and shifted-repair profiles are explanatory controls. A failed
40-path search is not evidence that no low-weight word exists.

## Main results

The Delta-zero transitions move little. The entries below are the first sampled
`f` with any, at least 5/100, and at least 10/100 observed successes:

| field | full-domain | canonical | low-repair |
|---:|:---:|:---:|:---:|
| GF(4) | 36 / 38 / 38 | 36 / 38 / 39 | 38 / 38 / 39 |
| GF(16) | 20 / 27 / 30 | 22 / 27 / 30 | 22 / 29 / 29 |
| GF(256) | 9 / 9 / 9 | 9 / 9 / 9 | 9 / 9 / 9 |

These descriptive markers shift by at most two sampled `f` values, so the
canonical profile does not materially move the measured Delta-zero transition.

Across the 60-point positive-Delta grid, the result is mixed rather than a
uniform strengthening or weakening:

| field | full successes | canonical | low-repair | canonical versus full by point (higher/equal/lower) |
|---:|---:|---:|---:|:---:|
| GF(4) | 2,676 | 2,665 | 2,662 | 4 / 51 / 5 |
| GF(16) | 1,432 | 1,442 | 1,460 | 11 / 43 / 6 |
| GF(256) | 2,253 | 2,092 | 2,181 | 7 / 28 / 25 |

GF(4) and GF(16) are broadly stable in aggregate. GF(256) is lower overall
under canonical sampling, but strongly point-dependent: for example,
GF(256) `(64,16)` changes from 2/100 full-domain to 33/100 canonical, while
`(48,8)` changes from 43/100 to 9/100. The profile effect therefore cannot be
summarized as monotone or uniformly harder.

The deep GF(256) region remains visible, but sparsely. At `(96,61)`, the counts
are 6/100 full-domain, 9/100 canonical, and 18/100 low-repair. At `(96,56)`
they are 3/100, 1/100, and 3/100. Most of the other nine deep points are zero
or at most 2/100. Thus the notable deep island survives; the data do not support
a broad deep-region claim.

Canonical and low-repair are also mixed under the paired masks. On the positive
grid, canonical is higher/equal/lower at 21/132/27 field-points; at the
instance level there are 4,415 paired failures, 1,317 paired successes, 125
canonical-only successes, and 143 low-repair-only successes in GF(16), while
GF(256) has 3,558 / 1,831 / 261 / 350 respectively. Removing systematic ESIs
does not produce a consistent direction of change.

At the five sentinels, `(full, canonical, low, shifted)` success counts are:

| field and point | counts |
|:---|:---:|
| GF(4) `(64,14)` | 93 / 87 / 81 / 92 |
| GF(16) `(80,8)` | 18 / 22 / 24 / 16 |
| GF(256) `(64,4)` | 65 / 48 / 49 / 51 |
| GF(256) `(96,24)` | 59 / 47 / 56 / 46 |
| GF(256) `(96,31)` | 21 / 44 / 37 / 13 |

Low-repair and shifted-repair agree closely at two GF(256) probes but differ
substantially at GF(4) `(64,14)` and GF(256) `(96,31)`. Five probes do not
support a single contiguity-versus-location explanation.

## Explanatory diagnostics

The repair-locality diagnostic covers 71 distinct `(f,K)` pairs. The low repair
window's raw binary rank and duplicate-pair count are inside the range of all
16 stratified random windows at every point; low and shifted raw ranks are
identical at all 71 points. Its mean LT degree is above the 16-window maximum at
12/71 points and never below the minimum. This is modest evidence of a
high-degree peculiarity in part of the low prefix, but no evidence here of a
raw-rank or duplicate-row anomaly.

The canonical systematic-coordinate sampler matches its exact hypergeometric
expectation: the largest absolute pointwise mean z-score is 2.785 over 235
canonical points. Among the 48 mixed-success positive-grid points, successful
samples have a lower mean systematic count than failures at 30 points and a
higher mean at 18. The tendency is not consistent, especially in GF(256)
(12 versus 11). These descriptive data do not support a general claim that
more systematic honest coordinates make the finite search harder.

Among 8,353 successful canonical witnesses, the number of forced-zero
systematic honest coordinates has median 21 and mean 21.0. By field, the
median/mean is 23/24.1 for GF(4), 25/23.9 for GF(16), and 14/16.5 for GF(256).
All witness identities `w=w_sys+w_repair` and the corresponding zero-count
identity pass mechanically.

The complete-zero-set decomposition does not change qualitatively. Restriction
loss remains overwhelmingly dominant in GF(4) and GF(16). In GF(256), the
raw-LT share of total saving is 43.5% full-domain, 37.2% canonical, and 43.7%
low-repair across successful witnesses at the tested points: a noticeable
quantitative shift, not a different structural mechanism. Initial projective
statistics are nearly identical between canonical and low-repair within each
field; no causal interpretation is assigned.

## Conservative conclusion

The strongest supported statement is that the canonical profile deserves
separate paper treatment because it produces a materially different,
point-dependent GF(256) landscape. It does not remove the attacks, does not
materially move the Delta-zero transitions, and leaves the central observation
of RaptorQ-specific GF(256) deep behavior intact. Full-domain sampling is broadly
representative for GF(4)/GF(16) on this grid, but is not an adequate numerical
surrogate for every canonical-prefix GF(256) point.

All 11 requested first-success witnesses pass the pinned independent `nanorq`
decoder audit and the complete internal source/intermediate/ESI/zero-set/weight
audit.
