#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
PROFILE_SOURCE="$HERE/source"
APPENDIX_SOURCE="$ARTIFACT/source/current_empirical"
CC=${CC:-cc}
export CC
mkdir -p "$HERE/build" "$HERE/validation"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1

"$CC" -O3 -std=c11 -Wall -Wextra -Wpedantic \
    -I"$APPENDIX_SOURCE" "$PROFILE_SOURCE/rq_profile_campaign.c" \
    -o "$HERE/build/rq_profile_campaign" \
    2> "$HERE/validation/build_warnings.txt"
"$CC" -O2 -g -std=c11 -Wall -Wextra -Wpedantic \
    -fsanitize=address,undefined -fno-omit-frame-pointer \
    -I"$APPENDIX_SOURCE" "$PROFILE_SOURCE/rq_profile_campaign.c" \
    -o "$HERE/build/rq_profile_campaign_san" \
    2> "$HERE/validation/sanitizer_build_warnings.txt"
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    "$PROFILE_SOURCE/position_mask_generator.c" \
    -o "$HERE/build/position_mask_generator" \
    2> "$HERE/validation/position_mask_build_warnings.txt"
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    "$PROFILE_SOURCE/witness_structure_profile.c" \
    -o "$HERE/build/witness_structure_profile" \
    2> "$HERE/validation/witness_structure_build_warnings.txt"
"$CC" -O2 -std=c11 -Wall -Wextra -Wpedantic \
    "$PROFILE_SOURCE/repair_locality.c" \
    -o "$HERE/build/repair_locality" \
    2> "$HERE/validation/repair_locality_build_warnings.txt"

"$HERE/build/rq_profile_campaign" --selftest \
    > "$HERE/validation/selftest.log" 2>&1
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    "$HERE/build/rq_profile_campaign_san" --selftest \
    > "$HERE/validation/sanitizer_selftest.log" 2>&1
grep -q '^SELFTEST PASS:' "$HERE/validation/selftest.log"
grep -q '^SELFTEST PASS:' "$HERE/validation/sanitizer_selftest.log"

{
    printf 'compiler_command=%s\n' "$CC"
    "$CC" --version | sed -n '1,5p'
    uname -a
} > "$HERE/validation/build_environment.txt"

warning_count=$(cat "$HERE"/validation/*_warnings.txt | wc -l | tr -d ' ')
for warning_file in "$HERE"/validation/*_warnings.txt; do
    if test -s "$warning_file"; then
        echo "COMPILER WARNINGS (nonfatal): $warning_file" >&2
        cat "$warning_file" >&2
    fi
done
echo "BUILD PASS: compiler exited successfully; warnings=$warning_count; ASan/UBSan selftest pass"
