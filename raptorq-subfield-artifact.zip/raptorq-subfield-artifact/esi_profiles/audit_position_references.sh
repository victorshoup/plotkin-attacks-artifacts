#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUTPUT=${POSITION_REFERENCE_OUTPUT:-"$HERE/audit/position_mask_references.csv"}
MASK_INPUT=${POSITION_MASK_INPUT:-"$HERE/position_masks/masks.csv"}
RAW_INPUT=${RAW_INPUT_ROOT:-"$HERE/raw"}
mkdir -p "$(dirname -- "$OUTPUT")"
awk -F, -v OFS=, -v masks="$MASK_INPUT" \
    -v primary="$HERE/config/primary_jobs.csv" \
    -v supplement="$HERE/config/headline_supplement_jobs.csv" \
    -v sentinel="$HERE/config/sentinel_jobs.csv" '
    FILENAME==masks {
        if(FNR==1)next
        key=$1 SUBSEP $2;seed[key]=$3;count[key]=$4;hash[key]=$5;mask[key]=$6;next
    }
    FILENAME==primary || FILENAME==supplement || FILENAME==sentinel {
        if(FNR==1)next
        key=$2 SUBSEP $3 SUBSEP $4 SUBSEP $5
        campaign[key]=$1; expected[key]=$8; next
    }
    FNR==1 {delete c;for(i=1;i<=NF;i++)c[$i]=i;next}
    {
        pkey=$(c["f"]) SUBSEP $(c["sample"])
        jkey=$(c["profile"]) SUBSEP $(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"])
        if(!(jkey in campaign)||$(c["honest_set_seed"])!=seed[pkey]||
           $(c["h"])!=count[pkey]||$(c["position_mask"])!=mask[pkey])exit 2
        n=split(mask[pkey],pos," ");m=split($(c["honest_ESIs"]),esi," ")
        if(n!=m||n!=count[pkey])exit 2
        profile=$(c["profile"]);offset=profile=="canonical"?0:(profile=="low-repair"?$(c["K"]):8388608)
        for(i=1;i<=n;i++)if(esi[i]!=pos[i]+offset)exit 2
        ++observed[jkey]
        pair=$(c["field"]) SUBSEP $(c["f"]) SUBSEP $(c["Delta"]) SUBSEP $(c["sample"])
        if(profile!="shifted-repair"){
            if(pair in paired && paired[pair]!=mask[pkey])exit 2
            paired[pair]=mask[pkey];++pairrefs[pair]
        }
        print campaign[jkey],profile,$(c["field"]),$(c["f"]),$(c["Delta"]),$(c["K"]),$(c["sample"]),seed[pkey],hash[pkey]
        ++rows
    }
    END{
        if(rows!=47500)exit 2
        for(key in expected)if(observed[key]!=expected[key])exit 2
        for(key in pairrefs)if(pairrefs[key]!=2)exit 2
        if(length(pairrefs)!=23500)exit 2
    }
' "$MASK_INPUT" "$HERE/config/primary_jobs.csv" \
    "$HERE/config/headline_supplement_jobs.csv" \
    "$HERE/config/sentinel_jobs.csv" \
    "$RAW_INPUT"/primary/*/esi_sets.csv "$RAW_INPUT"/headline/*/esi_sets.csv \
    "$RAW_INPUT"/sentinel/*/esi_sets.csv \
    | { echo "campaign,profile,field,f,Delta,K,sample,position_seed,position_mask_sha256"; cat; } \
    > "$OUTPUT"
test "$(($(wc -l < "$OUTPUT") - 1))" = 47500
echo "POSITION REFERENCE AUDIT PASS: 47500 references; 23500 canonical/low pairs"
