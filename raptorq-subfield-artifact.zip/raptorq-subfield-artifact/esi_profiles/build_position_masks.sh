#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$HERE/config/master.conf"
OUTPUT=${POSITION_MASK_OUTPUT:-"$HERE/position_masks/masks.csv"}
GENERATOR=${POSITION_MASK_GENERATOR:-"$HERE/build/position_mask_generator"}
TEMP=$(mktemp -d /tmp/rq-profile-masks-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$(dirname -- "$OUTPUT")"

{
    f=9
    while test "$f" -le 45; do
        "$GENERATOR" "$f" "$SAMPLES" "$MASTER_SEED"
        f=$((f + 1))
    done
    for f in 48 64 80 96; do
        "$GENERATOR" "$f" "$SAMPLES" "$MASTER_SEED"
    done
} > "$TEMP/raw.csv"

echo "f,sample,position_seed,position_count,position_mask_sha256,position_mask" > "$OUTPUT"
while IFS=, read -r f sample seed count mask; do
    hash=$(printf '%s\n' "$mask" | shasum -a 256 | awk '{print $1}')
    printf '%s,%s,%s,%s,%s,%s\n' "$f" "$sample" "$seed" "$count" "$hash" "$mask" >> "$OUTPUT"
done < "$TEMP/raw.csv"

test "$(($(wc -l < "$OUTPUT") - 1))" = 4100
echo "POSITION MASK PASS: 4100 canonical masks"
