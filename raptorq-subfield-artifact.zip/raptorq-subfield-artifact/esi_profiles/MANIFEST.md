# ESI-profile component manifest

The artifact top-level `CHECKSUMS.txt` is the sole authoritative checksum
universe. This file is a human-readable component map.

- `README.md`: profiles, saved verification, storage, and reproduction.
- `SUMMARY.md`: quantitative scientific findings.
- `PROVENANCE.md`: immutable inputs, source identity, seed, execution, and
  revision-3 integration.
- `config/`: master parameters, exact job manifests, and witness targets.
- `position_masks/masks.csv`: one mask for each of 4,100 `(f,sample)` pairs.
- `raw/primary/`: 466 canonical/low-repair point-profile jobs.
- `raw/headline/`: four labeled headline-supplement jobs.
- `raw/sentinel/`: five shifted-repair sentinel jobs.
- `raw/repair_prefix_locality_raw.csv`: locality control measurements.
- `summaries/`: all combined instance, structural, aggregate, paired-profile,
  and canonical-witness derived records.
- `witnesses/selected/`: deterministic requested first-success witnesses.
- `validation/`: sanitizer/pilot/source-diff/independent-witness evidence.
- `source/`: profile-specific C, shell, and AWK scientific workflow source.
- `audit/`: input/source identity, position-mask references, concurrency,
  storage canonicalization, and exact full-domain baseline mapping.
- `verify_component.sh`: complete saved component verification, called by the
  top-level verifier.
- `reproduce_profiles.sh --full`: expensive profile-search reproduction.

The shared Appendix search source, full-domain summaries, and independent
oracle are respectively `../source/current_empirical/`, `../empirical/summaries/`,
and `../source/nanorq/`. Paper-facing profile tables are in
`../paper_data/esi_profiles/`.
