#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT=$(CDPATH= cd -- "$HERE/.." && pwd)
mode=${1:-}
test "$mode" = --full || {
    echo "usage: $0 --full" >&2
    exit 2
}

OUTPUT=${PROFILE_REPRODUCTION_ROOT:-"$ARTIFACT/build/esi_profile_reproduction"}
test ! -e "$OUTPUT" || {
    echo "reproduction output already exists: $OUTPUT" >&2
    exit 2
}
mkdir -p "$OUTPUT/raw" "$OUTPUT/position_masks" "$OUTPUT/summaries" \
    "$OUTPUT/paper_data" "$OUTPUT/audit" "$OUTPUT/witnesses" \
    "$OUTPUT/validation"

export JOBS_OVERRIDE=2
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1 OMP_THREAD_LIMIT=1

"$HERE/preflight.sh"
"$HERE/build.sh"
"$HERE/prelaunch_audit.sh"
POSITION_MASK_OUTPUT="$OUTPUT/position_masks/masks.csv" \
    "$HERE/build_position_masks.sh"
cmp "$HERE/position_masks/masks.csv" "$OUTPUT/position_masks/masks.csv"

"$HERE/build/repair_locality" "$HERE/config/primary_jobs.csv" \
    "$OUTPUT/raw/repair_prefix_locality_raw.csv" 202609060101
"$HERE/run_batch.sh" "$HERE/config/primary_jobs.csv" "$OUTPUT/raw/primary"
"$HERE/run_batch.sh" "$HERE/config/headline_supplement_jobs.csv" \
    "$OUTPUT/raw/headline"
"$HERE/run_batch.sh" "$HERE/config/sentinel_jobs.csv" "$OUTPUT/raw/sentinel"

RAW_INPUT_ROOT="$OUTPUT/raw" \
POSITION_MASK_INPUT="$OUTPUT/position_masks/masks.csv" \
POSITION_REFERENCE_OUTPUT="$OUTPUT/audit/position_mask_references.csv" \
    "$HERE/audit_position_references.sh"

RAW_INPUT_ROOT="$OUTPUT/raw" RAW_ARTIFACT_PREFIX="$OUTPUT/" \
SUMMARY_OUTPUT_DIR="$OUTPUT/summaries" \
PAPER_OUTPUT_DIR="$OUTPUT/paper_data" "$HERE/analyze.sh"
for file in delta0_profile_comparison.csv positive_profile_comparison.csv \
    gf256_deep_profile_comparison.csv profile_headline_points.csv \
    systematic_count_effect.csv zero_set_rank_profile_comparison.csv \
    projective_profile_comparison.csv repair_prefix_locality.csv; do
    cmp "$ARTIFACT/paper_data/esi_profiles/$file" \
        "$OUTPUT/paper_data/$file"
done

mkdir -p "$OUTPUT/validation_build"
cp "$HERE/build/witness_structure_profile" \
    "$OUTPUT/validation_build/witness_structure_profile"
RAW_INPUT_ROOT="$OUTPUT/raw" \
POSITION_MASK_INPUT="$OUTPUT/position_masks/masks.csv" \
SELECTED_OUTPUT_DIR="$OUTPUT/witnesses/selected" \
VALIDATION_OUTPUT_DIR="$OUTPUT/validation" \
VALIDATION_BUILD_DIR="$OUTPUT/validation_build" \
    "$HERE/validate_selected_witnesses.sh"

echo "FULL ESI-PROFILE REPRODUCTION PASS: 47500 instances and 1900000 paths"
echo "output=$OUTPUT"
