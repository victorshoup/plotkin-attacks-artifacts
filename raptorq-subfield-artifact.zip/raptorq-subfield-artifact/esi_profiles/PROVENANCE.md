# Provenance and execution record

## Immutable inputs

The authoritative input is
`raptorq-subfield-appendix-artifact-rev2.zip`, 100,184,607 bytes, SHA-256
`bf2c03393ebfcc6203557bba8f6eb022a782e29eaea03acfd0c38cac8699091b`,
recorded source commit `50172ed8fae05fe729bda30edadfc95412e29775`.
The earlier diagnostic is
`raptorq-consecutive-profile-diagnostic-2026-09-06.zip`, 5,055,310 bytes,
SHA-256
`c6535f950614e43d17d639352e06f4ed22f9482f3bf13bf0e579d2252d4618ee`.
Both were treated as read-only. Exact member hashes are in
`audit/immutable_input_hashes.txt`.

The Appendix `rq_empirical.c` snapshot is SHA-256
`20629b77690e845da4c6bc464712ea656a4b5208ecdb7c4681e9862dad0c14c9`;
`rq_tables.h` is
`bbe8e36937a0fa1ce7869799ad93934ed891d9ee03f1f1e817262607f650eedc`.
The complete finite-search function is byte-identical in the campaign and
Appendix sources, with SHA-256
`315ec1c4c8338e8146db864a16e33623f016a8c5421c3bc919500026b9a6f7d6`.
`validation/campaign_source_diff.patch` records every surrounding change:
exact-uniform profile sampling, profile labels, pre-search projective
measurements, and complete-zero-set output for both successful and failed best
candidates. The greedy search, exact enumeration, field arithmetic, candidate
ordering, and success criterion were not tuned.

## Determinism and workload

Master seed: `202609060101`; seed schema: 4. No occurrence of this seed was
found in the existing workspace outside this campaign. The position seed is

```text
master XOR f*0x9e3779b97f4a7c15 XOR sample*0x85ebca6b27d4eb2f
```

and is independent of field, Delta, K, and profile. Search seeds use the final
Appendix formula and are identical for paired canonical/low-repair instances.
All 4,100 position masks were generated once with exact rejection sampling;
each contains `2f+1` distinct sorted positions in `0,...,3f` and carries a hash
of the space-separated list plus LF.

Preflight proved 42 Delta-zero field points, 180 positive-grid field points,
and 11 GF(256) deep points. Two new profiles and 100 samples give exactly the
required 46,600 primary instances and 1,864,000 paths. Four separately labeled
jobs cover canonical/low-repair at GF(4) `(64,14)` and GF(256) `(96,31)`, which
the primary grid omits but the witness/headline specification requires. Five
shifted-repair jobs are the requested sentinels. The exact total is therefore
47,500 new instances and 1,900,000 paths. No matched-random or adaptive grid was
run.

Every instance uses 40 complete paths, no early stop, the canonical first path,
random tie choice only among maximum projective classes thereafter, 70,000
maximum directions, and exact residual thresholds `(8,5,3)` for GF(4),
GF(16), and GF(256).

## Pre-launch validation

The optimized build and all helpers were warning-clean. The ordinary and
ASan/UBSan self-tests passed; Apple ASan does not support leak detection, so
`detect_leaks=0` was recorded while address and undefined-behavior checks
remained active. One-sample, 40-path sanitizer spots passed all three profiles.
The 16-instance runtime pilot mechanically passed position-mask pairing and
observed maximum worker concurrency two. A repeated GF(256) low-repair instance
was byte-identical after removing only three timing columns; its ESI,
complete-zero-set, and witness files were byte-identical without normalization.

The pilot accumulated 2,351.461 ms of search time over 16 instances and
projected 3,424 seconds (57.1 minutes) for the primary search at two workers,
or 68.5 minutes with a 20% guard.

## Commands

Preflight and build:

```sh
./esi_profiles/generate_config.sh
./esi_profiles/preflight.sh
./esi_profiles/build.sh
./esi_profiles/build_position_masks.sh
./esi_profiles/prelaunch_audit.sh
```

The integrated full reproduction command is listed in `README.md`. All run wrappers force
the common OpenMP, BLAS, Accelerate, NumExpr, and related thread variables to
one, launch exactly `xargs -P 2`, and maintain an independently locked worker
event log that aborts above two.

The locality diagnostic used no attack search. For each of 71 distinct `(f,K)`
pairs it measured the complete low-repair and shifted windows plus 16
deterministic stratified pseudorandom legal repair windows.

## Execution result

The primary search completed 46,600 instances and 1,864,000 paths in 3,535
seconds. The separately labeled headline supplement completed 400 instances and
16,000 paths in 55 seconds. The five shifted sentinels completed 500 instances
and 20,000 paths in 76 seconds. Total saved search work was therefore 47,500
instances, 1,900,000 paths, and 3,666 seconds (61 minutes 6 seconds) of batch
wall time. The worker event logs record maxima of two, two, and two with zero
active workers at completion.

The combined instance verifier passed all 47,500 rows and all 1,900,000 paths.
The structure verifier passed 44,100 valid-best-candidate rows; every successful
witness is present and all complete-zero-set rank identities pass. There are
16,973 successful witnesses. All applicable GF(256) precode-intersection
identities pass. The pinned independent `nanorq` audit passed all 11 requested
first-success witnesses.

## Position-mask storage

`position_masks/masks.csv` contains exactly 4,100 distinct `(f,sample)` masks,
occupying 1,190,856 bytes uncompressed. After the 47,500-row reference audit
passed, 475 redundant point-level `esi_sets.csv` files occupying 39,093,230
bytes were deleted. No scientific information was removed: canonical lists are
the masks, low-repair lists add `K`, and shifted-repair lists add `2^23`.
`audit/position_storage_canonicalization.txt` records the operation.

## Discrepancies and fixes

No scientific stop-condition discrepancy occurred. During final packaging, the
selected-witness wrapper treated a trailing blank configuration line as an
unknown campaign and also counted that line as an expected witness. The wrapper
was changed to skip blank records and count only nonempty data rows. This bug
affected only wrapper exit status after all audits had run; it did not alter a
witness, campaign result, scientific source, or validation outcome. The repaired
wrapper then reported 11 validations passed and zero missing-success targets.

The standalone campaign's first final fresh-extraction verification then caught absolute authoring-tree
paths in `summaries/witness_weight_split.csv`. The summary generator was changed
to emit artifact-relative witness paths and all dependent summaries were
regenerated. The numerical columns were unchanged. The faulty pre-release ZIP
was superseded before delivery; the final ZIP passed a complete fresh-extraction
verification.

## Revision 3 integration

The standalone campaign ZIP was imported byte-for-byte for scientific content.
Its duplicated Appendix source, baseline summaries, `rq_tables.h`, and complete
`nanorq` snapshot were omitted only after full hash comparison; integrated
wrappers reference the shared authoritative copies. Wrapper-only changes also
make `${CC:-cc}` selection consistent and treat nonempty compiler-warning logs
as visible but nonfatal. The scientific campaign source was not changed.

The eight authoritative profile tables now live under
`../paper_data/esi_profiles/`. `audit/full_domain_baseline_mapping.csv` maps all
238 published rows containing full-domain values to exact retained main rows.
The top-level checksum manifest is the only authoritative checksum universe.
