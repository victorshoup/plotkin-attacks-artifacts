#!/bin/bash
set -euo pipefail

EMPIRICAL_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARTIFACT_DIR=$(CDPATH= cd -- "$EMPIRICAL_DIR/.." && pwd)
BUILD_DIR="$ARTIFACT_DIR/build"
CONFIG_DIR="$EMPIRICAL_DIR/config"

# shellcheck source=/dev/null
. "$CONFIG_DIR/master.conf"

if test "$#" != 6; then
    echo "usage: $0 rq|random field f Delta sample output-directory" >&2
    exit 2
fi

ensemble=$1
field=$2
f=$3
delta=$4
sample=$5
output_directory=$6

case "$field" in
    4) exact_d=$GF4_EXACT_D ;;
    16) exact_d=$GF16_EXACT_D ;;
    256) exact_d=$GF256_EXACT_D ;;
    *) echo "field must be 4, 16, or 256" >&2; exit 2 ;;
esac
case "$ensemble" in rq|random) ;; *) echo "ensemble must be rq or random" >&2; exit 2 ;; esac
case "$sample" in ''|*[!0-9]*) echo "sample must be a nonnegative integer" >&2; exit 2 ;; esac

if test ! -x "$BUILD_DIR/rq_empirical" || test ! -x "$BUILD_DIR/random_empirical"; then
    JOBS_OVERRIDE=2 "$ARTIFACT_DIR/reproduce_all.sh" --quick
fi
mkdir -p "$output_directory"

common=(--field "$field" --f "$f" --delta "$delta" --samples 1
    --sample-start "$sample" --restarts "$GREEDY_PATHS"
    --seed "$MASTER_SEED" --max-residual-d "$exact_d"
    --max-directions "$MAX_DIRECTIONS" --trace-mode full
    --trace-summary-out "$output_directory/path_summary.csv"
    --trace-out "$output_directory/path_steps.csv")

if test "$ensemble" = rq; then
    "$BUILD_DIR/rq_empirical" "${common[@]}" --seed-schema "$ARTIFACT_SCHEMA" \
        --sampler "$SAMPLER" --early-stop 0 \
        --out "$output_directory/instances.csv" \
        --esi-out "$output_directory/esi_sets.csv" \
        --structure-out "$output_directory/zero_set_structure.csv" \
        --witness-dir "$output_directory/witnesses"
else
    "$BUILD_DIR/random_empirical" "${common[@]}" \
        --out "$output_directory/instances.csv"
fi

gzip -n -9 "$output_directory/path_steps.csv"
echo "REGENERATED FULL TRACE: $ensemble q=$field f=$f Delta=$delta sample=$sample"
