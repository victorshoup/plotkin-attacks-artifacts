# Claim and evidence map

Every empirical search statement below refers to the documented finite search.
Search failure is never promoted to a coding-theoretic nonexistence claim.

| Claim | Status | Retained evidence | Verification without full campaign |
|---|---|---|---|
| For every standardized `K`, `kappa4=1` at `K=30` and `max(0,K-3*H_HDPC)` otherwise | Exact exhaustive finite computation | `dimensions/gf4/` | checksum and rev3 identity by default; `verify_artifact.sh --exact` reruns an independent C certificate and compares it byte-for-byte with the frozen revision-3 tables |
| For every standardized `K`, `kappa16=max(0,K-H_HDPC)` | Exact exhaustive finite computation | `dimensions/gf16/` | checksum and rev3 identity by default; `verify_artifact.sh --exact` reruns the C certificate |
| Exact GF(4) Delsarte contradiction begins at `f=72` | Exact rational computation | `delsarte/` | `verify_artifact.sh` verifies all nine exact certificates |
| Delta-zero observed transition markers | Empirical aggregate | `empirical/summaries/delta0.csv`; `paper_data/delta0_transition.csv` | `analyze_existing.sh` regenerates the paper table byte-for-byte |
| Positive-overhead full-domain heat maps | Empirical aggregate | `empirical/summaries/positive_grid.csv`; `paper_data/positive_heatmap_gf*.csv` | `analyze_existing.sh` regenerates all heat-map CSVs byte-for-byte |
| Matched-random comparisons | Empirical search plus analytic benchmark | `empirical/summaries/comparison.csv`; `paper_data/matched_random_summary.csv` | `analyze_existing.sh` regenerates the paper table byte-for-byte |
| GF(256) deep-tail disappear/reappear behavior | Empirical aggregate | `empirical/summaries/gf256_deep_tail.csv`; `paper_data/gf256_deep_tail.csv` | `analyze_existing.sh` regenerates the paper table byte-for-byte |
| Complete-zero-set rank decomposition summaries | Exact identities on successful empirical witnesses, aggregated | `empirical/summaries/zero_set_structure_aggregate.csv`; `paper_data/zero_set_rank_summary.csv` | `analyze_existing.sh` regenerates the paper table byte-for-byte |
| Breadth-versus-depth sensitivity | Paired empirical diagnostic | `paper_data/search_sensitivity.csv`; `paper_data/search_sensitivity_paired.csv` | aggregate is regenerated; all 1,000 paired rows are retained and mechanically checked |
| Five selected full-domain witnesses encode the claimed differences and zero sets | Independent finite validation | `empirical/witnesses/selected/`; `empirical/validation/nanorq_validation.csv` | `verify_artifact.sh` rebuilds pinned `nanorq` and replays all five |

## ESI-profile findings

| Claim | Status | Retained evidence | Verification without full campaign |
|---|---|---|---|
| Canonical-prefix Delta-zero transition changes little relative to full-domain sampling | Empirical aggregate | `paper_data/esi_profiles/delta0_profile_comparison.csv`; compact profile summaries | regenerated from retained `profile_comparison_all.csv` |
| GF(4) and GF(16) positive-overhead behavior remains broadly similar | Empirical aggregate | `paper_data/esi_profiles/positive_profile_comparison.csv` | regenerated from retained compact comparison table |
| GF(256) profile effects are substantial and nonmonotone in direction | Empirical aggregate | positive/deep profile comparison CSVs | regenerated from retained compact comparison table |
| Full-domain values used in profile comparisons map to exact retained main aggregate rows | Exact bookkeeping | `esi_profiles/audit/full_domain_baseline_mapping.csv` | `verify_artifact.sh` checks all 238 mappings |
| Profile position masks are reproducible from the frozen seed and source | Deterministic finite computation | `esi_profiles/position_masks/masks.csv` | `verify_artifact.sh` regenerates all masks byte-for-byte |
| Eleven selected profile witnesses are valid RaptorQ difference witnesses | Independent finite validation | `esi_profiles/witnesses/selected/`; `esi_profiles/validation/selected_witnesses.csv` | `verify_artifact.sh` rebuilds pinned `nanorq` and replays all eleven |

## Omitted raw records

Revision 3 contained 451,400 full-domain instances, 47,500 profile instances, and their recorded greedy paths.
Those raw records are not shipped in this slim derivative.
Their source, seeds, configuration, exact paper-facing aggregates, and selected witnesses are retained.
Their original paths and SHA-256 values are committed by `provenance/REMOVED_REV3_FILES.csv.gz`.
A complete rerun is available through `reproduce_all.sh --full` and is not required for ordinary artifact verification.
