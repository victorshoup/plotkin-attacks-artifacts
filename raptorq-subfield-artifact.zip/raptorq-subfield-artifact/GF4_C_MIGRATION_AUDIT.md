# GF(4) exact-dimension certificate: C migration audit

**Date:** 9 September 2026.

**Scope:** Replace the active Rust/Cargo replay requirement for the exhaustive GF(4) dimension certificate with an independent C implementation, without changing the frozen scientific outputs.

## Frozen result

Revision 3 ships two exact GF(4) dimension tables:

- `dimensions/gf4/gf4_kprime_dimensions_rust.csv`;
- `dimensions/gf4/gf4_band_min_dimensions_rust.csv`.

Their historical filenames are retained to preserve byte-level identity with revision 3.

The certified statement is
\[
\kappa_4=1\quad\text{at }K=30,
\]
and
\[
\kappa_4=\max(0,K-3H_{\mathrm{HDPC}})
\]
for every other RFC-valid `K`.

## New C implementation

`dimensions/gf4/source/gf4_dimension_cert.c` is a rank-only certifier parallel to the existing GF(16) C certificate.

It reuses the frozen RFC parameter tables, LDPC/padding-row construction, HDPC construction, and GF(256) arithmetic from `source/current_empirical/rq_empirical.c`.

Binary LDPC and padding rows are first reduced over GF(2).
Each HDPC equation is decomposed into four GF(4) coordinate equations because `[GF(256):GF(4)]=4`.
The remaining rank calculation is performed over GF(4) with a two-bit-plane representation.

The certifier checks all 477 standardized full `K'` endpoints and all 477 maximum-padding band endpoints.
It also checks all four values `K=27,28,29,30` in the unique exceptional `K'=30` band and six independent interior spots.

## Differential validation against revision 3

The new C implementation reproduced both frozen revision-3 tables **byte-for-byte**.

This was checked with GCC 14.2.0 and independently with Clang 17.0.0.
Both compilers produced zero certificate failures and the same two frozen tables.

The active verifier `dimensions/gf4/verify_gf4_dimensions_c.sh` also compiles the generic empirical `dimension_inventory.c` implementation and independently checks every `K=1,...,97` against the exact formula, including the `K=30` exception.

The C replay takes about 10 seconds for the complete 477+477 endpoint calculation on the construction sandbox.

## Trust boundary

The historical Rust source remains in `dimensions/gf4/source/` only because it is part of the frozen revision-3 provenance record.
It is no longer invoked by `verify_artifact.sh`.

`./verify_artifact.sh --exact` now requires only a C compiler and Python for the exact GF(4), GF(16), and Delsarte checks.
No Rust/Cargo toolchain is required for the active publication-verification path.

No paper-facing data, frozen GF(4) result table, empirical aggregate, witness, seed, or configuration changed in this migration.
