#!/bin/bash
set -euo pipefail

ARTIFACT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EMPIRICAL_DIR="$ARTIFACT_DIR/empirical"
SOURCE_DIR="$ARTIFACT_DIR/source/current_empirical"
CONFIG_DIR="$EMPIRICAL_DIR/config"
BUILD_DIR="$ARTIFACT_DIR/build"
VALIDATION_DIR="$EMPIRICAL_DIR/validation"
ROOT_DIR=$(CDPATH= cd -- "$ARTIFACT_DIR/.." && pwd)
SELF="$ARTIFACT_DIR/reproduce_all.sh"
CC=${CC:-cc}
export CC

# shellcheck source=/dev/null
. "$CONFIG_DIR/master.conf"
DIAGNOSTIC_SUBSET="$CONFIG_DIR/${DIAGNOSTIC_TRACE_SUBSET#config/}"
EFFECTIVE_JOBS=${JOBS_OVERRIDE:-$JOBS}
case "$EFFECTIVE_JOBS" in
    2) ;;
    *) echo "JOBS must be exactly 2; values above 2 are forbidden" >&2; exit 2 ;;
esac

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export BLIS_NUM_THREADS=1
export GOTO_NUM_THREADS=1
export OMP_THREAD_LIMIT=1

COMMON_CFLAGS='-O2 -std=c11 -Wall -Wextra -Wpedantic'
SANITIZER_CFLAGS='-O1 -g -std=c11 -Wall -Wextra -Wpedantic -fsanitize=address,undefined'
if test -d "$ARTIFACT_DIR/source/nanorq"; then
    DEFAULT_NANORQ="$ARTIFACT_DIR/source/nanorq"
else
    DEFAULT_NANORQ="$ROOT_DIR/nanorq"
fi
NANORQ_CHECKOUT=${NANORQ_CHECKOUT:-"$DEFAULT_NANORQ"}
PINNED_NANORQ=6295a9525893b9a757dd57431db76fc6ecceafac
WORKER_AUDIT_DIR="$VALIDATION_DIR/worker_concurrency"
WORKER_AUDIT_ACTIVE=0

worker_lock()
{
    mkdir -p "$WORKER_AUDIT_DIR"
    while ! mkdir "$WORKER_AUDIT_DIR/lock" 2>/dev/null; do sleep 0.01; done
}

worker_unlock()
{
    rmdir "$WORKER_AUDIT_DIR/lock"
}

worker_enter()
{
    worker_lock
    active=0
    test ! -s "$WORKER_AUDIT_DIR/active" || active=$(cat "$WORKER_AUDIT_DIR/active")
    active=$((active + 1))
    maximum=0
    test ! -s "$WORKER_AUDIT_DIR/maximum" || maximum=$(cat "$WORKER_AUDIT_DIR/maximum")
    test "$active" -le 2 || {
        echo "STOP: observed more than two CPU-intensive workers" >&2
        worker_unlock
        exit 2
    }
    test "$active" -le "$maximum" || maximum=$active
    printf '%s\n' "$active" > "$WORKER_AUDIT_DIR/active"
    printf '%s\n' "$maximum" > "$WORKER_AUDIT_DIR/maximum"
    test -e "$WORKER_AUDIT_DIR/events.csv" || \
        echo "unix_time,event,pid,worker_kind,active_workers" > \
            "$WORKER_AUDIT_DIR/events.csv"
    printf '%s,enter,%s,%s,%s\n' "$(date +%s)" "$$" "$1" "$active" >> \
        "$WORKER_AUDIT_DIR/events.csv"
    WORKER_AUDIT_ACTIVE=1
    worker_unlock
}

worker_leave()
{
    test "$WORKER_AUDIT_ACTIVE" = 1 || return 0
    worker_lock
    active=$(cat "$WORKER_AUDIT_DIR/active")
    active=$((active - 1))
    printf '%s\n' "$active" > "$WORKER_AUDIT_DIR/active"
    printf '%s,leave,%s,%s,%s\n' "$(date +%s)" "$$" "${1:-worker}" "$active" >> \
        "$WORKER_AUDIT_DIR/events.csv"
    WORKER_AUDIT_ACTIVE=0
    worker_unlock
}

exact_d()
{
    case "$1" in
        4) echo "$GF4_EXACT_D" ;;
        16) echo "$GF16_EXACT_D" ;;
        256) echo "$GF256_EXACT_D" ;;
        *) echo "invalid field: $1" >&2; return 2 ;;
    esac
}

check_configured_workload()
{
    delta0_points=$((DELTA0_F_MAX - DELTA0_F_MIN + 1))
    positive_points=$(awk 'END { print NR - 1 }' "$CONFIG_DIR/positive_grid.csv")
    deep_tail_points=$(awk 'END { print NR - 1 }' "$CONFIG_DIR/deep_tail_grid.csv")
    sensitivity_points=$(awk 'END { print NR - 1 }' "$CONFIG_DIR/deeper_grid.csv")
    test "$delta0_points" = 37
    test "$positive_points" = 690
    test "$deep_tail_points" = 71
    test "$sensitivity_points" = 5
    delta0_instances=$((delta0_points * SAMPLES_DELTA0 * 3 * 2))
    positive_instances=$((positive_points * SAMPLES_POSITIVE * 3 * 2))
    deep_tail_instances=$((deep_tail_points * SAMPLES_POSITIVE * 2))
    main_instances=$((delta0_instances + positive_instances + deep_tail_instances))
    sensitivity_instances=$((sensitivity_points * SAMPLES_POSITIVE * 2))
    main_paths=$((main_instances * GREEDY_PATHS))
    sensitivity_paths=$sensitivity_instances
    total_instances=$((main_instances + sensitivity_instances))
    total_paths=$((main_paths + sensitivity_paths))
    test "$delta0_instances" = 22200
    test "$positive_instances" = 414000
    test "$deep_tail_instances" = 14200
    test "$main_instances" = 450400
    test "$main_paths" = 18016000
    test "$sensitivity_instances" = 1000
    test "$total_instances" = 451400
    test "$total_paths" = 18017000
    {
        echo "delta0_points=$delta0_points"
        echo "positive_points=$positive_points"
        echo "deep_tail_points=$deep_tail_points"
        echo "sensitivity_points=$sensitivity_points"
        echo "delta0_instances=$delta0_instances"
        echo "positive_instances=$positive_instances"
        echo "deep_tail_instances=$deep_tail_instances"
        echo "main_instances=$main_instances"
        echo "sensitivity_instances=$sensitivity_instances"
        echo "total_empirical_instances=$total_instances"
        echo "main_greedy_paths=$main_paths"
        echo "sensitivity_canonical_paths=$sensitivity_paths"
        echo "total_greedy_paths=$total_paths"
    } > "$VALIDATION_DIR/workload_counts.txt"
}

preflight()
{
    mkdir -p "$BUILD_DIR" "$VALIDATION_DIR"
    check_configured_workload
    case "$TRACE_MODE" in
        summary|diagnostic) ;;
        full)
            echo "STOP: production TRACE_MODE=full is forbidden" >&2
            exit 2
            ;;
        *) echo "STOP: invalid TRACE_MODE=$TRACE_MODE" >&2; exit 2 ;;
    esac
    awk -v f0_min="$DELTA0_F_MIN" -v f0_max="$DELTA0_F_MAX" \
        -v samples_delta0="$SAMPLES_DELTA0" \
        -v samples_positive="$SAMPLES_POSITIVE" \
        -f "$SOURCE_DIR/verify_diagnostic_subset.awk" \
        "$CONFIG_DIR/positive_grid.csv" "$DIAGNOSTIC_SUBSET" || {
        echo "STOP: invalid predetermined diagnostic trace subset" >&2
        exit 2
    }
    THREAD_PATTERN='pthread_create|thrd_create|omp[[:space:]_]|openmp|dispatch_(async|apply)|std::thread|clone[[:space:]]*\(|fork[[:space:]]*\(|posix_spawn'
    {
        echo "process-level worker limit: $EFFECTIVE_JOBS"
        echo "worker implementation: single-threaded C"
        echo "pattern: $THREAD_PATTERN"
        echo "inspected artifact CPU-bound sources:"
        find "$SOURCE_DIR" "$ARTIFACT_DIR/dimensions/gf16/source" \
            -type f \( -name '*.c' -o -name '*.h' \) -print | LC_ALL=C sort
    } > "$VALIDATION_DIR/thread_scan.txt"
    if find "$SOURCE_DIR" "$ARTIFACT_DIR/dimensions/gf16/source" \
        -type f \( -name '*.c' -o -name '*.h' \) -print0 |
        xargs -0 grep -Eni "$THREAD_PATTERN" >> "$VALIDATION_DIR/thread_scan.txt"; then
        echo "STOP: artifact source contains an internal thread/process primitive" >&2
        exit 1
    fi
    echo "inspected imported GF(4) Rust certificate sources:" >> "$VALIDATION_DIR/thread_scan.txt"
    find "$ARTIFACT_DIR/dimensions/gf4/source" -type f -name '*.rs' -print |
        LC_ALL=C sort >> "$VALIDATION_DIR/thread_scan.txt"
    if find "$ARTIFACT_DIR/dimensions/gf4/source" -type f -name '*.rs' -print0 |
        xargs -0 grep -Eni 'rayon|std::thread|thread::spawn|available_parallelism|Command::new' \
        >> "$VALIDATION_DIR/thread_scan.txt"; then
        echo "STOP: imported GF(4) certificate source contains internal concurrency" >&2
        exit 1
    fi
    if test -d "$NANORQ_CHECKOUT"; then
        echo "inspected pinned nanorq C sources:" >> "$VALIDATION_DIR/thread_scan.txt"
        find "$NANORQ_CHECKOUT" -type f \( -name '*.c' -o -name '*.h' \) -print |
            LC_ALL=C sort >> "$VALIDATION_DIR/thread_scan.txt"
        if find "$NANORQ_CHECKOUT" -type f \( -name '*.c' -o -name '*.h' \) -print0 |
            xargs -0 grep -Eni "$THREAD_PATTERN" >> "$VALIDATION_DIR/thread_scan.txt"; then
            echo "STOP: nanorq contains an internal thread/process primitive" >&2
            exit 1
        fi
    fi
    echo "result: no internal thread/process creation primitives found" >> "$VALIDATION_DIR/thread_scan.txt"
    {
        echo "JOBS=$EFFECTIVE_JOBS"
        env | LC_ALL=C sort | awk '/^(OMP_NUM_THREADS|OPENBLAS_NUM_THREADS|MKL_NUM_THREADS|VECLIB_MAXIMUM_THREADS|NUMEXPR_NUM_THREADS|BLIS_NUM_THREADS|GOTO_NUM_THREADS|OMP_THREAD_LIMIT)=/'
    } > "$VALIDATION_DIR/concurrency_environment.txt"
}

build_all()
{
    mkdir -p "$BUILD_DIR"
    if test ! -f "$NANORQ_CHECKOUT/libnanorq.a" && \
       test -f "$NANORQ_CHECKOUT/Makefile"; then
        make -C "$NANORQ_CHECKOUT" -j "$EFFECTIVE_JOBS" libnanorq.a
    fi
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/rq_empirical.c" -o "$BUILD_DIR/rq_empirical"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/random_empirical.c" -o "$BUILD_DIR/random_empirical"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/random_code_regression.c" -o "$BUILD_DIR/random_code_regression"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/dimension_inventory.c" -o "$BUILD_DIR/dimension_inventory"
    awk -F, 'NR > 1 && $2 == "rq" {print $3, $4, $5}' \
        "$DIAGNOSTIC_SUBSET" | while read -r field f delta; do
            inventory=$($BUILD_DIR/dimension_inventory "$field" "$f" "$delta")
            kappa=${inventory##*,}
            limit=$(exact_d "$field")
            test "$kappa" -gt "$limit" || {
                echo "STOP: diagnostic trace point has no greedy steps: $inventory" >&2
                exit 2
            }
        done
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/first_moment.c" -lm -o "$BUILD_DIR/first_moment"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/analyze_results.c" -lm \
        -o "$BUILD_DIR/analyze_results"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/plot_results.c" -lm \
        -o "$BUILD_DIR/plot_results"
    "$CC" $COMMON_CFLAGS "$SOURCE_DIR/witness_structure.c" -o "$BUILD_DIR/witness_structure"
    if test -f "$NANORQ_CHECKOUT/libnanorq.a"; then
        if test -d "$NANORQ_CHECKOUT/.git"; then
            actual_commit=$(git -C "$NANORQ_CHECKOUT" rev-parse HEAD)
            test "$actual_commit" = "$PINNED_NANORQ"
            test -z "$(git -C "$NANORQ_CHECKOUT" status --short)"
        else
            test "$(cat "$NANORQ_CHECKOUT/PINNED_COMMIT")" = "$PINNED_NANORQ"
        fi
        "$CC" $COMMON_CFLAGS -I"$NANORQ_CHECKOUT/include" -I"$NANORQ_CHECKOUT/deps" \
            "$SOURCE_DIR/audit_regression.c" "$NANORQ_CHECKOUT/libnanorq.a" \
            -o "$BUILD_DIR/audit_regression"
        "$CC" $COMMON_CFLAGS -I"$NANORQ_CHECKOUT/include" -I"$NANORQ_CHECKOUT/deps" \
            "$SOURCE_DIR/nanorq_witness_audit.c" "$NANORQ_CHECKOUT/libnanorq.a" \
            -o "$BUILD_DIR/nanorq_witness_audit"
    fi
}

run_regressions()
{
    "$BUILD_DIR/rq_empirical" --selftest
    "$BUILD_DIR/random_code_regression"
    if test -x "$BUILD_DIR/audit_regression"; then
        "$BUILD_DIR/audit_regression"
    fi

    "$CC" $SANITIZER_CFLAGS "$SOURCE_DIR/rq_empirical.c" -o "$BUILD_DIR/rq_empirical_san"
    ASAN_OPTIONS=detect_leaks=0 "$BUILD_DIR/rq_empirical_san" --selftest
    "$CC" $SANITIZER_CFLAGS "$SOURCE_DIR/random_code_regression.c" \
        -o "$BUILD_DIR/random_code_regression_san"
    ASAN_OPTIONS=detect_leaks=0 "$BUILD_DIR/random_code_regression_san"
}

record_environment()
{
    {
        echo "artifact schema: $ARTIFACT_SCHEMA"
        echo "source baseline git commit: $BASELINE_GIT_COMMIT"
        if git -C "$ROOT_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
            echo "containing checkout git commit: $(git -C "$ROOT_DIR" rev-parse HEAD)"
            echo "containing checkout git status:"
            git -C "$ROOT_DIR" status --short
        else
            echo "containing checkout: none (standalone extracted artifact)"
        fi
        echo "compiler:"
        "$CC" --version
        echo "kernel: $(uname -srm)"
        if command -v sw_vers >/dev/null 2>&1; then sw_vers; fi
        if test -d "$NANORQ_CHECKOUT"; then
            if test -d "$NANORQ_CHECKOUT/.git"; then
                echo "nanorq commit: $(git -C "$NANORQ_CHECKOUT" rev-parse HEAD)"
                echo "nanorq status:"
                git -C "$NANORQ_CHECKOUT" status --short
            else
                echo "nanorq embedded source commit: $(cat "$NANORQ_CHECKOUT/PINNED_COMMIT")"
            fi
        fi
    } > "$VALIDATION_DIR/environment.txt"
}

run_actual_point()
{
    field=$1; f=$2; delta=$3; samples=$4; paths=$5; directory=$6
    point_seed=${7:-$MASTER_SEED}
    retain_witnesses=${8:-1}
    limit=${9:-$(exact_d "$field")}
    direction_cap=${10:-$MAX_DIRECTIONS}
    trace_mode=${11:-summary}
    diagnostic_sample=${12:--1}
    mkdir -p "$directory"
    # Bash 3.2 with nounset treats expansion of an empty array as unbound.
    # The harmless repeated option keeps this array nonempty in no-witness runs.
    witness_arguments=(--early-stop 0)
    if test "$retain_witnesses" = 1; then
        mkdir -p "$directory/witnesses"
        witness_arguments+=(--witness-dir "$directory/witnesses")
    fi
    trace_arguments=(--trace-mode "$trace_mode" \
        --trace-summary-out "$directory/path_summary.csv")
    case "$trace_mode" in
        summary) ;;
        diagnostic)
            trace_arguments+=(--trace-out "$directory/path_steps.csv" \
                --diagnostic-sample "$diagnostic_sample")
            ;;
        full)
            trace_arguments+=(--trace-out "$directory/path_steps.csv")
            ;;
        *) echo "invalid trace mode: $trace_mode" >&2; return 2 ;;
    esac
    "$BUILD_DIR/rq_empirical" --field "$field" --f "$f" --delta "$delta" \
        --samples "$samples" --sample-start 0 --restarts "$paths" \
        --sampler "$SAMPLER" --seed "$point_seed" \
        --seed-schema "${POINT_SEED_SCHEMA:-$ARTIFACT_SCHEMA}" \
        --max-residual-d "$limit" --max-directions "$direction_cap" \
        --early-stop 0 --out "$directory/instances.csv" \
        --esi-out "$directory/esi_sets.csv" \
        --structure-out "$directory/zero_set_structure.csv" \
        "${trace_arguments[@]}" \
        "${witness_arguments[@]}"
    awk -v exact_d="$limit" -f "$SOURCE_DIR/verify_instances.awk" \
        "$directory/instances.csv"
    awk -f "$SOURCE_DIR/verify_structure.awk" "$directory/zero_set_structure.csv"
    awk -v ensemble=rq -v exact_d="$limit" \
        -f "$SOURCE_DIR/verify_path_summary.awk" \
        "$directory/instances.csv" "$directory/path_summary.csv"
    if test -f "$directory/path_steps.csv"; then
        awk -v ensemble=rq -v exact_d="$limit" -v trace_mode="$trace_mode" \
            -v diagnostic_sample="$diagnostic_sample" \
            -f "$SOURCE_DIR/verify_path_steps.awk" \
            "$directory/instances.csv" "$directory/path_steps.csv"
    fi
}

run_random_point()
{
    field=$1; f=$2; delta=$3; samples=$4; paths=$5; directory=$6
    limit=${7:-$(exact_d "$field")}
    direction_cap=${8:-$MAX_DIRECTIONS}
    trace_mode=${9:-summary}
    diagnostic_sample=${10:--1}
    mkdir -p "$directory"
    trace_arguments=(--trace-mode "$trace_mode" \
        --trace-summary-out "$directory/path_summary.csv")
    case "$trace_mode" in
        summary) ;;
        diagnostic)
            trace_arguments+=(--trace-out "$directory/path_steps.csv" \
                --diagnostic-sample "$diagnostic_sample")
            ;;
        full)
            trace_arguments+=(--trace-out "$directory/path_steps.csv")
            ;;
        *) echo "invalid trace mode: $trace_mode" >&2; return 2 ;;
    esac
    "$BUILD_DIR/random_empirical" --field "$field" --f "$f" --delta "$delta" \
        --samples "$samples" --sample-start 0 --restarts "$paths" \
        --seed "$MASTER_SEED" --max-residual-d "$limit" \
        --max-directions "$direction_cap" --out "$directory/instances.csv" \
        "${trace_arguments[@]}"
    awk -v exact_d="$limit" -f "$SOURCE_DIR/verify_instances.awk" \
        "$directory/instances.csv"
    awk -v ensemble=random -v exact_d="$limit" \
        -f "$SOURCE_DIR/verify_path_summary.awk" \
        "$directory/instances.csv" "$directory/path_summary.csv"
    if test -f "$directory/path_steps.csv"; then
        awk -v ensemble=random -v exact_d="$limit" -v trace_mode="$trace_mode" \
            -v diagnostic_sample="$diagnostic_sample" \
            -f "$SOURCE_DIR/verify_path_steps.awk" \
            "$directory/instances.csv" "$directory/path_steps.csv"
    fi
}

run_smoke()
{
    smoke="$VALIDATION_DIR/smoke"
    mkdir -p "$smoke"
    find "$smoke" -mindepth 1 -delete
    for field in 4 16 256; do
        run_actual_point "$field" 40 0 1 2 "$smoke/rq_q${field}" \
            "$MASTER_SEED" 1 "$(exact_d "$field")" "$MAX_DIRECTIONS" diagnostic 0
        run_random_point "$field" 40 0 1 2 "$smoke/random_q${field}" \
            "$(exact_d "$field")" "$MAX_DIRECTIONS" diagnostic 0
    done
    awk -v expected_fields=3 -f "$SOURCE_DIR/verify_esi_pairing.awk" \
        "$smoke"/rq_q*/esi_sets.csv | LC_ALL=C sort -t, -k1,1n -k2,2n -k3,3n \
        > "$smoke/paired_esi_audit.csv"
    {
        cat "$smoke"/rq_q*/path_steps.csv
        cat "$smoke"/random_q*/path_steps.csv
    } | awk -f "$SOURCE_DIR/projective_summary.awk" | \
        LC_ALL=C sort -t, -k1,1 -k2,2n -k3,3n \
        > "$smoke/projective_summary.csv"
    witness=$(find "$smoke/rq_q256/witnesses" -type f -name '*.txt' -print | head -1 || true)
    if test -n "$witness" && test -x "$BUILD_DIR/nanorq_witness_audit"; then
        "$BUILD_DIR/nanorq_witness_audit" "$witness" \
            > "$smoke/nanorq_validation.log" 2>&1
    fi
    echo "SMOKE PASS"
}

if test "${1:-}" = "--worker-profile"; then
    test "$#" = 5
    worker_enter profile
    trap 'worker_leave profile' EXIT
    ensemble=$2; field=$3; f=$4; delta=$5
    directory="$VALIDATION_DIR/profile/${ensemble}_q${field}_f${f}_d${delta}"
    if test "$ensemble" = rq; then
        run_actual_point "$field" "$f" "$delta" 3 "$GREEDY_PATHS" \
            "$directory" "$MASTER_SEED" 1 "$(exact_d "$field")" \
            "$MAX_DIRECTIONS" full
    else
        run_random_point "$field" "$f" "$delta" 3 "$GREEDY_PATHS" \
            "$directory" "$(exact_d "$field")" "$MAX_DIRECTIONS" full
    fi
    exit
fi

if test "${1:-}" = "--worker-storage-profile"; then
    test "$#" = 5
    ensemble=$2; field=$3; f=$4; delta=$5
    directory="$VALIDATION_DIR/storage_profile/${ensemble}_q${field}_f${f}_d${delta}"
    if test "$ensemble" = rq; then
        run_actual_point "$field" "$f" "$delta" "$SAMPLES_POSITIVE" \
            "$GREEDY_PATHS" "$directory" "$MASTER_SEED" 0 \
            "$(exact_d "$field")" "$MAX_DIRECTIONS" summary
    else
        run_random_point "$field" "$f" "$delta" "$SAMPLES_POSITIVE" \
            "$GREEDY_PATHS" "$directory" "$(exact_d "$field")" \
            "$MAX_DIRECTIONS" summary
    fi
    exit
fi

if test "${1:-}" = "--worker-prior"; then
    test "$#" = 5
    field=$2; f=$3; delta=$4; samples=$5
    directory="$VALIDATION_DIR/prior_reproduction/q${field}_f${f}_d${delta}"
    POINT_SEED_SCHEMA=3 run_actual_point "$field" "$f" "$delta" "$samples" \
        "$GREEDY_PATHS" "$directory" 2026090300 0
    exit
fi

run_prior_reproduction()
{
    prior="$VALIDATION_DIR/prior_reproduction"
    frozen="$ROOT_DIR/validation/subfield_appendix_diagnostic_2026-09-03"
    frozen_rank="$ROOT_DIR/validation/subfield_raw_lt_rank_diagnostic_2026-09-04"
    test -d "$frozen"
    test -d "$frozen_rank"
    mkdir -p "$prior"
    find "$prior" -mindepth 1 -delete
    worklist="$prior/worklist.txt"
    awk -F, 'NR > 1 {print $1, $2, $3, $4}' "$CONFIG_DIR/prior_points.csv" \
        > "$worklist"
    xargs -n 4 -P "$EFFECTIVE_JOBS" "$SELF" --worker-prior < "$worklist"

    {
        echo "field,f,Delta,samples,success_mismatches,first_success_mismatches,kappa_mismatches,retained_weight_changes,retained_residual_dimension_changes"
        while IFS=, read -r field f delta samples expected relative; do
            test "$field" = field && continue
            new="$prior/q${field}_f${f}_d${delta}/instances.csv"
            observed=$(awk -F, 'NR > 1 {successes += $26} END {print successes + 0}' "$new")
            test "$observed" = "$expected"
            awk -v field="$field" -v f="$f" -v delta="$delta" \
                -f "$SOURCE_DIR/compare_frozen_search.awk" \
                "$frozen/$relative" "$new"
        done < "$CONFIG_DIR/prior_points.csv"
    } > "$prior/search_comparison.csv"

    {
        echo "field,K,kappa"
        for csv in "$prior"/q*/instances.csv; do
            awk -F, 'NR == 2 {print $1 "," $6 "," $12}' "$csv"
        done | LC_ALL=C sort -t, -k1,1n -k2,2n -u
    } > "$prior/kappa_reproduction.csv"
    awk -F, 'NR > 1 {
        key=$1 "," $2; expected[key]=$3
    }
    END {
        required["4,36"]=6; required["4,39"]=9; required["4,51"]=21;
        required["16,23"]=13; required["16,28"]=18; required["16,73"]=63;
        required["256,10"]=10; required["256,61"]=61;
        for (key in required) if (!(key in expected) || expected[key] != required[key]) exit 1
    }' "$prior/kappa_reproduction.csv"

    witness_root="$frozen_rank/witnesses/selected"
    : > "$prior/nanorq_validation.log"
    echo "ensemble,field,f,Delta,K,sample,zero_count,rank_B_Z,rank_G_Z,total_saving,raw_LT_saving,restriction_loss,rank_precode,rank_stacked,intersection_dimension,restricted_rank_identity_ok,intersection_identity_ok" \
        > "$prior/witness_structure.csv"
    while read -r name sample; do
        witness="$witness_root/$name.txt"
        "$BUILD_DIR/witness_structure" "$witness" "$sample" | tail -n +2 \
            >> "$prior/witness_structure.csv"
        if test -x "$BUILD_DIR/nanorq_witness_audit"; then
            "$BUILD_DIR/nanorq_witness_audit" "$witness" \
                >> "$prior/nanorq_validation.log" 2>&1
        fi
    done <<'WITNESSES'
witness_q4_f64_delta14_sample0 0
witness_q16_f80_delta8_sample0 0
witness_q256_f64_delta4_sample6 6
witness_q256_f96_delta31_sample19 19
WITNESSES
    awk -f "$SOURCE_DIR/verify_structure.awk" "$prior/witness_structure.csv"
    awk -F, 'NR > 1 {
        key=$2 "," $3 "," $4 "," $6
        observed[key]=$7 "," $8 "," $9
    }
    END {
        expected["4,64,14,0"]="69,20,69"
        expected["16,80,8,0"]="81,62,81"
        expected["256,64,4,6"]="65,60,64"
        expected["256,96,31,19"]="100,65,70"
        for (key in expected) if (observed[key] != expected[key]) exit 1
    }' "$prior/witness_structure.csv"
    if test -x "$BUILD_DIR/nanorq_witness_audit"; then
        test "$(grep -c '^NANORQ FULL WITNESS PASS:' "$prior/nanorq_validation.log")" = 4
    fi
    echo "PRIOR REPRODUCTION PASS"
}

run_profile()
{
    profile="$VALIDATION_DIR/profile"
    mkdir -p "$profile"
    find "$profile" -mindepth 1 -delete
    worklist="$profile/worklist.txt"
    awk -F, 'NR > 1 {print "rq", $1, $2, $3; print "random", $1, $2, $3}' \
        "$CONFIG_DIR/profile_points.csv" > "$worklist"
    start=$(date +%s)
    xargs -n 4 -P "$EFFECTIVE_JOBS" "$SELF" --worker-profile < "$worklist"
    finish=$(date +%s)
    {
        echo "ensemble,field,f,Delta,samples,total_search_ms,mean_search_ms,total_instance_cpu_ms,mean_instance_cpu_ms,full_trace_rows,full_trace_bytes,summary_rows,summary_bytes"
        while read -r ensemble field f delta; do
            directory="$profile/${ensemble}_q${field}_f${f}_d${delta}"
            awk -F, -v ensemble="$ensemble" -v field="$field" -v f="$f" -v delta="$delta" '
                FNR == 1 { for (i=1;i<=NF;++i) c[$i]=i; next }
                {
                    ++n
                    search += $(c["search_ms"])
                    total += $(c["search_ms"])
                    total += ensemble == "rq" ? $(c["matrix_ms"]) : $(c["generation_ms"])
                }
                END { printf "%s,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,", ensemble,field,f,delta,n,search,search/n,total,total/n }
            ' "$directory/instances.csv"
            trace_rows=$(($(wc -l < "$directory/path_steps.csv") - 1))
            trace_bytes=$(wc -c < "$directory/path_steps.csv" | tr -d ' ')
            summary_rows=$(($(wc -l < "$directory/path_summary.csv") - 1))
            summary_bytes=$(wc -c < "$directory/path_summary.csv" | tr -d ' ')
            printf '%d,%d,%d,%d\n' "$trace_rows" "$trace_bytes" \
                "$summary_rows" "$summary_bytes"
        done < "$worklist"
    } > "$profile/timing.csv"
    echo "$((finish - start))" > "$profile/wall_seconds.txt"
    echo "PROFILE PASS: $((finish - start)) wall seconds with JOBS=$EFFECTIVE_JOBS"
}

if test "${1:-}" = "--worker-runtime-deeper"; then
    test "$#" = 7
    ensemble=$2; field=$3; f=$4; delta=$5; limit=$6; direction_cap=$7
    directory="$VALIDATION_DIR/runtime_pilot/deeper/${ensemble}_q${field}_f${f}_d${delta}"
    if test "$ensemble" = rq; then
        run_actual_point "$field" "$f" "$delta" 1 1 "$directory" \
            "$MASTER_SEED" 0 "$limit" "$direction_cap" summary
    else
        run_random_point "$field" "$f" "$delta" 1 1 "$directory" \
            "$limit" "$direction_cap" summary
    fi
    exit
fi

run_runtime_pilot()
{
    run_profile
    pilot="$VALIDATION_DIR/runtime_pilot"
    mkdir -p "$pilot/deeper"
    find "$pilot/deeper" -mindepth 1 -delete
    worklist="$pilot/deeper_worklist.txt"
    : > "$worklist"
    while IFS=, read -r field f delta limit direction_cap reason; do
        test "$field" = field && continue
        echo "rq $field $f $delta $limit $direction_cap"
        echo "random $field $f $delta $limit $direction_cap"
    done < "$CONFIG_DIR/deeper_grid.csv" >> "$worklist"
    xargs -n 6 -P "$EFFECTIVE_JOBS" "$SELF" --worker-runtime-deeper < "$worklist"

    {
        echo "ensemble,field,f,Delta,exact_d,instance_cpu_ms"
        while read -r ensemble field f delta limit direction_cap; do
            csv="$pilot/deeper/${ensemble}_q${field}_f${f}_d${delta}/instances.csv"
            awk -F, -v ensemble="$ensemble" -v field="$field" -v f="$f" \
                -v delta="$delta" -v limit="$limit" '
                NR == 1 { for (i=1;i<=NF;++i) c[$i]=i; next }
                {
                    total=$(c["search_ms"])
                    total += ensemble == "rq" ? $(c["matrix_ms"]) : $(c["generation_ms"])
                    printf "%s,%d,%d,%d,%d,%.3f\n", ensemble,field,f,delta,limit,total
                }
            ' "$csv"
        done < "$worklist"
    } > "$pilot/sensitivity_timing.csv"

    awk -F, '
        NR > 1 { key=$1 SUBSEP $2; sum[key]+=$9; count[key]++ }
        END {
            fields[1]=4; fields[2]=16; fields[3]=256
            ensembles[1]="rq"; ensembles[2]="random"
            for (e=1;e<=2;++e) for (q=1;q<=3;++q) {
                key=ensembles[e] SUBSEP fields[q]
                if (count[key] != 3) exit 1
                instances = fields[q] == 256 ? 79800 : 72700
                total += (sum[key]/count[key]) * instances
            }
            printf "%.3f\n", total
        }
    ' "$VALIDATION_DIR/profile/timing.csv" > "$pilot/main_projected_cpu_ms.txt"
    awk -F, 'NR > 1 { sum += $6 } END { printf "%.3f\n", sum * 100 }' \
        "$pilot/sensitivity_timing.csv" > "$pilot/sensitivity_projected_cpu_ms.txt"
    main_ms=$(cat "$pilot/main_projected_cpu_ms.txt")
    sensitivity_ms=$(cat "$pilot/sensitivity_projected_cpu_ms.txt")
    awk -v main_ms="$main_ms" -v sensitivity_ms="$sensitivity_ms" '
        BEGIN {
            cpu_ms=main_ms+sensitivity_ms
            wall=cpu_ms/1000/2
            guarded=wall*1.20
            print "pilot_design=3_samples_at_18_rq_random_main_shapes_plus_1_sample_at_10_sensitivity_shapes"
            print "planned_main_instances=450400"
            print "planned_sensitivity_instances=1000"
            print "planned_total_instances=451400"
            print "planned_main_greedy_paths=18016000"
            print "planned_sensitivity_canonical_paths=1000"
            print "planned_total_greedy_paths=18017000"
            printf "projected_cpu_seconds=%.3f\n", cpu_ms/1000
            printf "projected_two_core_wall_seconds=%.3f\n", wall
            printf "guarded_two_core_wall_seconds_20pct=%.3f\n", guarded
            printf "projected_two_core_wall_hours=%.3f\n", wall/3600
            printf "guarded_two_core_wall_hours_20pct=%.3f\n", guarded/3600
            print (guarded <= 86400 ? "runtime_gate=PASS" : "runtime_gate=STOP_OVER_24_HOURS")
            if (guarded > 86400) exit 3
        }
    ' > "$pilot/runtime_projection.txt"
    cat "$pilot/runtime_projection.txt"
}

run_storage_profile()
{
    profile="$VALIDATION_DIR/storage_profile"
    mkdir -p "$profile"
    find "$profile" -mindepth 1 -delete
    worklist="$profile/worklist.txt"
    awk -F, 'NR > 1 {print "rq", $1, $2, $3; print "random", $1, $2, $3}' \
        "$CONFIG_DIR/profile_points.csv" > "$worklist"
    start=$(date +%s)
    xargs -n 4 -P "$EFFECTIVE_JOBS" "$SELF" --worker-storage-profile \
        < "$worklist"
    finish=$(date +%s)
    {
        echo "ensemble,field,f,Delta,instances,dimension_rows,instances_bytes,instances_gzip_bytes,path_summary_bytes,path_summary_gzip_bytes,esi_bytes,esi_gzip_bytes"
        while read -r ensemble field f delta; do
            directory="$profile/${ensemble}_q${field}_f${f}_d${delta}"
            instances=$(($(wc -l < "$directory/instances.csv") - 1))
            dimension_rows=$(($(wc -l < "$directory/path_summary.csv") - 1))
            instances_bytes=$(wc -c < "$directory/instances.csv" | tr -d ' ')
            instances_gzip_bytes=$(gzip -n -9 -c "$directory/instances.csv" | wc -c | tr -d ' ')
            summary_bytes=$(wc -c < "$directory/path_summary.csv" | tr -d ' ')
            summary_gzip_bytes=$(gzip -n -9 -c "$directory/path_summary.csv" | wc -c | tr -d ' ')
            esi_bytes=0
            esi_gzip_bytes=0
            if test -f "$directory/esi_sets.csv"; then
                esi_bytes=$(wc -c < "$directory/esi_sets.csv" | tr -d ' ')
                esi_gzip_bytes=$(gzip -n -9 -c "$directory/esi_sets.csv" | wc -c | tr -d ' ')
            fi
            printf '%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n' \
                "$ensemble" "$field" "$f" "$delta" "$instances" \
                "$dimension_rows" "$instances_bytes" \
                "$instances_gzip_bytes" "$summary_bytes" \
                "$summary_gzip_bytes" "$esi_bytes" "$esi_gzip_bytes"
        done < "$worklist"
    } > "$profile/compressed_sizes.csv"
    echo "$((finish - start))" > "$profile/wall_seconds.txt"
    echo "STORAGE PROFILE PASS: $((finish - start)) wall seconds with JOBS=$EFFECTIVE_JOBS"
}

if test "${1:-}" = "--worker-main"; then
    test "$#" = 6
    worker_enter main
    trap 'worker_leave main' EXIT
    phase=$2; ensemble=$3; field=$4; f=$5; delta=$6
    case "$phase" in
        delta0) samples=$SAMPLES_DELTA0 ;;
        positive|deep_tail) samples=$SAMPLES_POSITIVE ;;
        *) echo "invalid main phase" >&2; exit 2 ;;
    esac
    directory="$EMPIRICAL_DIR/raw/$phase/$ensemble/q${field}_f${f}_d${delta}"
    diagnostic_sample=$(awk -F, -v phase="$phase" -v ensemble="$ensemble" \
        -v field="$field" -v f="$f" -v delta="$delta" '
        NR > 1 && $1 == phase && $2 == ensemble && $3 == field &&
            $4 == f && $5 == delta { print $6 }
    ' "$DIAGNOSTIC_SUBSET")
    trace_mode=summary
    if test "$TRACE_MODE" = diagnostic && test -n "$diagnostic_sample"; then
        trace_mode=diagnostic
    fi
    if test "$ensemble" = rq; then
        run_actual_point "$field" "$f" "$delta" "$samples" \
            "$GREEDY_PATHS" "$directory" "$MASTER_SEED" 0 \
            "$(exact_d "$field")" "$MAX_DIRECTIONS" \
            "$trace_mode" "${diagnostic_sample:--1}"
    else
        run_random_point "$field" "$f" "$delta" "$samples" \
            "$GREEDY_PATHS" "$directory" "$(exact_d "$field")" \
            "$MAX_DIRECTIONS" "$trace_mode" "${diagnostic_sample:--1}"
    fi
    gzip -n -9 "$directory/path_summary.csv"
    if test -f "$directory/path_steps.csv"; then
        gzip -n -9 "$directory/path_steps.csv"
    fi
    exit
fi

if test "${1:-}" = "--worker-deeper"; then
    test "$#" = 8
    worker_enter sensitivity
    trap 'worker_leave sensitivity' EXIT
    ensemble=$2; field=$3; f=$4; delta=$5; limit=$6; direction_cap=$7
    samples=$8
    directory="$EMPIRICAL_DIR/raw/deeper/$ensemble/q${field}_f${f}_d${delta}_exact${limit}"
    if test "$ensemble" = rq; then
        run_actual_point "$field" "$f" "$delta" "$samples" 1 \
            "$directory" "$MASTER_SEED" 0 "$limit" "$direction_cap" summary
    else
        run_random_point "$field" "$f" "$delta" "$samples" 1 \
            "$directory" "$limit" "$direction_cap" summary
    fi
    gzip -n -9 "$directory/path_summary.csv"
    exit
fi

generate_main_summaries()
{
    mkdir -p "$EMPIRICAL_DIR/summaries"
    {
        echo "ensemble,field,f,Delta,K,kappa,samples,successes,success_fraction,successful_weight_min,successful_weight_median,successful_weight_max,best_failed_weight,successful_projective_saving_median,first_success_path_median"
        for phase in delta0 positive deep_tail; do
            for ensemble in rq random; do
                for csv in "$EMPIRICAL_DIR/raw/$phase/$ensemble"/*/instances.csv; do
                    awk -v ensemble="$ensemble" \
                        -f "$SOURCE_DIR/summarize_instances.awk" "$csv"
                done
            done
        done
    } | {
        IFS= read -r header
        echo "$header"
        LC_ALL=C sort -t, -k1,1 -k2,2n -k3,3n -k4,4n
    } > "$EMPIRICAL_DIR/summaries/search_success.csv"

    {
        echo "ensemble,field,f,Delta,K,sample,zero_count,rank_B_Z,rank_G_Z,total_saving,raw_LT_saving,restriction_loss,rank_precode,rank_stacked,intersection_dimension,restricted_rank_identity_ok,intersection_identity_ok"
        for csv in "$EMPIRICAL_DIR/raw/delta0/rq"/*/zero_set_structure.csv \
                   "$EMPIRICAL_DIR/raw/positive/rq"/*/zero_set_structure.csv \
                   "$EMPIRICAL_DIR/raw/deep_tail/rq"/*/zero_set_structure.csv; do
            tail -n +2 "$csv"
        done
    } > "$EMPIRICAL_DIR/summaries/zero_set_structure.csv"
    awk -f "$SOURCE_DIR/verify_structure.awk" \
        "$EMPIRICAL_DIR/summaries/zero_set_structure.csv"

    if test -n "$(find "$EMPIRICAL_DIR/raw" -type f -name esi_sets.csv -print -quit)"; then
        awk -v expected_fields=3 -f "$SOURCE_DIR/verify_esi_pairing.awk" \
            "$EMPIRICAL_DIR/raw/delta0/rq"/*/esi_sets.csv \
            "$EMPIRICAL_DIR/raw/positive/rq"/*/esi_sets.csv \
            "$EMPIRICAL_DIR/raw/deep_tail/rq"/*/esi_sets.csv | {
                IFS= read -r header
                echo "$header"
                LC_ALL=C sort -t, -k1,1n -k2,2n
            } > "$EMPIRICAL_DIR/summaries/paired_esi_audit.csv"
    else
        test -s "$EMPIRICAL_DIR/summaries/paired_esi_audit.csv"
        "$SOURCE_DIR/audit_esi_dedup.sh"
    fi

    trace_list="$VALIDATION_DIR/main_path_summary_files.txt"
    (cd "$EMPIRICAL_DIR" && find raw/delta0 raw/positive raw/deep_tail \
        -type f -name 'path_summary.csv.gz' | LC_ALL=C sort) > "$trace_list"
    while IFS= read -r trace; do gzip -dc "$EMPIRICAL_DIR/$trace"; done < "$trace_list" |
        awk -f "$SOURCE_DIR/aggregate_path_summaries.awk" | {
            IFS= read -r header
            echo "$header"
            LC_ALL=C sort -t, -k1,1 -k2,2n -k3,3n
        } > "$EMPIRICAL_DIR/summaries/projective_by_dimension.csv"
}

run_full_main()
{
    test "$TRACE_MODE" != full || {
        echo "STOP: full tracing is forbidden for the production grid" >&2
        exit 2
    }
    for phase in delta0 positive deep_tail; do
        mkdir -p "$EMPIRICAL_DIR/raw/$phase/rq" "$EMPIRICAL_DIR/raw/$phase/random"
        find "$EMPIRICAL_DIR/raw/$phase/rq" "$EMPIRICAL_DIR/raw/$phase/random" \
            -mindepth 1 -delete
    done
    worklist="$VALIDATION_DIR/full_main_worklist.txt"
    : > "$worklist"
    f=$DELTA0_F_MIN
    while test "$f" -le "$DELTA0_F_MAX"; do
        for field in 4 16 256; do
            echo "delta0 rq $field $f 0"
            echo "delta0 random $field $f 0"
        done
        f=$((f + 1))
    done >> "$worklist"
    while IFS=, read -r f delta note; do
        test "$f" = f && continue
        for field in 4 16 256; do
            echo "positive rq $field $f $delta"
            echo "positive random $field $f $delta"
        done
    done < "$CONFIG_DIR/positive_grid.csv" >> "$worklist"
    while IFS=, read -r f delta note; do
        test "$f" = f && continue
        echo "deep_tail rq 256 $f $delta"
        echo "deep_tail random 256 $f $delta"
    done < "$CONFIG_DIR/deep_tail_grid.csv" >> "$worklist"
    start=$(date +%s)
    xargs -n 5 -P "$EFFECTIVE_JOBS" "$SELF" --worker-main < "$worklist"
    finish=$(date +%s)
    echo "$((finish - start))" > "$VALIDATION_DIR/full_main_wall_seconds.txt"
    generate_main_summaries
}

run_deeper_diagnostics()
{
    mkdir -p "$EMPIRICAL_DIR/raw/deeper/rq" "$EMPIRICAL_DIR/raw/deeper/random"
    find "$EMPIRICAL_DIR/raw/deeper/rq" "$EMPIRICAL_DIR/raw/deeper/random" \
        -mindepth 1 -delete
    worklist="$VALIDATION_DIR/deeper_worklist.txt"
    : > "$worklist"
    while IFS=, read -r field f delta limit direction_cap reason; do
        test "$field" = field && continue
        echo "rq $field $f $delta $limit $direction_cap $SAMPLES_POSITIVE"
        echo "random $field $f $delta $limit $direction_cap $SAMPLES_POSITIVE"
    done < "$CONFIG_DIR/deeper_grid.csv" >> "$worklist"
    start=$(date +%s)
    xargs -n 7 -P "$EFFECTIVE_JOBS" "$SELF" --worker-deeper < "$worklist"
    finish=$(date +%s)
    echo "$((finish - start))" > "$VALIDATION_DIR/deeper_wall_seconds.txt"
    generate_deeper_summary
}

generate_deeper_summary()
{
    {
        echo "ensemble,field,f,Delta,K,kappa,samples,successes,success_fraction,successful_weight_min,successful_weight_median,successful_weight_max,best_failed_weight,successful_projective_saving_median,first_success_path_median"
        for ensemble in rq random; do
            for csv in "$EMPIRICAL_DIR/raw/deeper/$ensemble"/*/instances.csv; do
                awk -v ensemble="$ensemble" \
                    -f "$SOURCE_DIR/summarize_instances.awk" "$csv"
            done
        done
    } | {
        IFS= read -r header
        echo "$header"
        LC_ALL=C sort -t, -k1,1 -k2,2n -k3,3n -k4,4n
    } > "$EMPIRICAL_DIR/summaries/deeper_search_success.csv"
}

generate_analysis_products()
{
    mkdir -p "$EMPIRICAL_DIR/figures"
    "$BUILD_DIR/analyze_results" \
        "$EMPIRICAL_DIR/summaries/search_success.csv" \
        "$EMPIRICAL_DIR/summaries/deeper_search_success.csv" \
        "$EMPIRICAL_DIR/summaries/projective_by_dimension.csv" \
        "$CONFIG_DIR/deeper_grid.csv" "$EMPIRICAL_DIR/summaries"
    awk -f "$SOURCE_DIR/summarize_structure.awk" \
        "$EMPIRICAL_DIR/summaries/zero_set_structure.csv" | {
            IFS= read -r header
            echo "$header"
            LC_ALL=C sort -t, -k1,1n -k2,2n -k3,3n
        } > "$EMPIRICAL_DIR/summaries/zero_set_structure_aggregate.csv"
    "$BUILD_DIR/plot_results" \
        "$EMPIRICAL_DIR/summaries/delta0.csv" \
        "$EMPIRICAL_DIR/summaries/positive_grid.csv" \
        "$EMPIRICAL_DIR/summaries/projective_comparison.csv" \
        "$EMPIRICAL_DIR/figures"
    "$SOURCE_DIR/verify_search_sensitivity.sh"
    "$SOURCE_DIR/generate_paper_data.sh"
    "$SOURCE_DIR/audit_outputs.sh" "$EMPIRICAL_DIR" \
        > "$VALIDATION_DIR/output_audit.txt"
    cat "$VALIDATION_DIR/output_audit.txt"
}

reproduce_exact_components()
{
    "$ARTIFACT_DIR/dimensions/gf4/verify_gf4_dimensions.sh"
    "$ARTIFACT_DIR/dimensions/gf16/verify_gf16_certificate.sh"
    (
        cd "$ARTIFACT_DIR/delsarte"
        python3 generate_delsarte_certificates.py
        python3 verify_delsarte_certificates.py
    )
}

mode=${1:---quick}
case "$mode" in
    --quick)
        preflight
        build_all
        run_regressions
        record_environment
        echo "QUICK VERIFICATION PASS"
        ;;
    --smoke)
        preflight
        build_all
        run_regressions
        record_environment
        run_smoke
        ;;
    --profile)
        preflight
        build_all
        run_regressions
        record_environment
        run_profile
        ;;
    --runtime-pilot)
        preflight
        build_all
        run_regressions
        record_environment
        run_prior_reproduction
        run_runtime_pilot
        ;;
    --storage-profile)
        preflight
        build_all
        run_regressions
        record_environment
        run_storage_profile
        ;;
    --prior-check)
        preflight
        build_all
        run_regressions
        record_environment
        run_prior_reproduction
        ;;
    --analyze-existing)
        build_all
        generate_main_summaries
        generate_deeper_summary
        generate_analysis_products
        echo "EXISTING RAW-DATA ANALYSIS PASS"
        ;;
    --selected-witnesses)
        build_all
        "$SOURCE_DIR/select_witness_samples.sh"
        "$SOURCE_DIR/regenerate_selected_witnesses.sh" | \
            tee "$VALIDATION_DIR/selected_witness_replay.log"
        ;;
    --validate-witnesses)
        build_all
        "$SOURCE_DIR/validate_selected_witnesses.sh" "$NANORQ_CHECKOUT"
        ;;
    --full)
        reproduce_exact_components
        preflight
        build_all
        run_regressions
        record_environment
        run_prior_reproduction
        run_runtime_pilot
        run_full_main
        run_deeper_diagnostics
        generate_analysis_products
        "$SOURCE_DIR/select_witness_samples.sh"
        "$SOURCE_DIR/regenerate_selected_witnesses.sh" | \
            tee "$VALIDATION_DIR/selected_witness_replay.log"
        "$SOURCE_DIR/validate_selected_witnesses.sh" "$NANORQ_CHECKOUT"
        "$SOURCE_DIR/canonicalize_esi_storage.sh"
        "$ARTIFACT_DIR/esi_profiles/reproduce_profiles.sh" --full
        echo "FULL UNIFIED APPENDIX A REPRODUCTION PASS"
        ;;
    --verify-artifacts)
        build_all
        run_regressions
        test -s "$ARTIFACT_DIR/CHECKSUMS.txt"
        (cd "$ARTIFACT_DIR" && shasum -a 256 -c CHECKSUMS.txt)
        ;;
    *)
        echo "usage: $0 --quick|--smoke|--prior-check|--profile|--runtime-pilot|--storage-profile|--analyze-existing|--selected-witnesses|--validate-witnesses|--full|--verify-artifacts" >&2
        exit 2
        ;;
esac
