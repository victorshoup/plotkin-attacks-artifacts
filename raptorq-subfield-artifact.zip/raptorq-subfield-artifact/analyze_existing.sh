#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TEMP=$(mktemp -d /tmp/rq-slim-analysis-XXXXXX)
trap 'rm -rf "$TEMP"' EXIT
export LC_ALL=C

# Rebuild every main paper-facing table that depends only on retained compact
# aggregate summaries.
mkdir -p "$TEMP/main/source/current_empirical" "$TEMP/main/empirical/summaries" \
    "$TEMP/main/paper_data"
cp "$HERE/source/current_empirical/generate_paper_data.sh" \
    "$TEMP/main/source/current_empirical/generate_paper_data.sh"
for file in delta0.csv gf256_deep_tail.csv comparison.csv projective_comparison.csv \
    zero_set_structure_aggregate.csv deeper_enumeration.csv positive_grid.csv; do
    cp "$HERE/empirical/summaries/$file" "$TEMP/main/empirical/summaries/$file"
done
(
    cd "$TEMP/main"
    ./source/current_empirical/generate_paper_data.sh >/dev/null
)
for file in delta0_transition.csv gf256_deep_tail.csv matched_random_summary.csv \
    projective_summary.csv zero_set_rank_summary.csv search_sensitivity.csv \
    positive_heatmap_gf4.csv positive_heatmap_gf16.csv \
    positive_heatmap_gf256.csv dimension_vs_empirical_transition.csv; do
    cmp "$HERE/paper_data/$file" "$TEMP/main/paper_data/$file"
done

# The paired search-sensitivity table is deliberately retained directly because
# its 1,000 rows are already a compact per-sample record.
awk -F, '
    NR==1 {for(i=1;i<=NF;i++)c[$i]=i; next}
    {
        ++n
        if ($(c["matrix_seed_equal"]) != 1 ||
            $(c["canonical_minimum_monotonicity_ok"]) != 1) bad=1
        if ($(c["deeper_weight"]) + 0 > $(c["main_canonical_weight"]) + 0) bad=1
    }
    END {if (bad || n != 1000) exit 2}
' "$HERE/paper_data/search_sensitivity_paired.csv"

# Rebuild the profile-comparison tables that depend only on the retained compact
# profile summaries and the retained full-domain aggregates.
mkdir -p "$TEMP/profile"
for campaign in delta0 positive deep; do
    case "$campaign" in
        delta0) output=delta0_profile_comparison.csv ;;
        positive) output=positive_profile_comparison.csv ;;
        deep) output=gf256_deep_profile_comparison.csv ;;
    esac
    awk -F, -v campaign="$campaign" 'NR==1||$1==campaign' \
        "$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
        > "$TEMP/profile/$output"
    cmp "$HERE/paper_data/esi_profiles/$output" "$TEMP/profile/$output"
done

awk -v comparison="$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
    -f "$HERE/esi_profiles/source/headline_points.awk" \
    "$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
    "$HERE/esi_profiles/summaries/point_summary.csv" \
    > "$TEMP/profile/headline.unsorted"
{
    head -n 1 "$TEMP/profile/headline.unsorted"
    tail -n +2 "$TEMP/profile/headline.unsorted" | sort -t, -k1,1n -k2,2n -k3,3n
} > "$TEMP/profile/profile_headline_points.csv"
cmp "$HERE/paper_data/esi_profiles/profile_headline_points.csv" \
    "$TEMP/profile/profile_headline_points.csv"

awk -v baseline="$HERE/empirical/summaries/zero_set_structure_aggregate.csv" \
    -v points="$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
    -f "$HERE/esi_profiles/source/rank_profile_comparison.awk" \
    "$HERE/empirical/summaries/zero_set_structure_aggregate.csv" \
    "$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
    "$HERE/esi_profiles/summaries/zero_set_rank_aggregate.csv" \
    > "$TEMP/profile/rank.unsorted"
{
    head -n 1 "$TEMP/profile/rank.unsorted"
    tail -n +2 "$TEMP/profile/rank.unsorted" | sort -t, -k1,1 -k2,2n -k3,3n -k4,4n
} > "$TEMP/profile/zero_set_rank_profile_comparison.csv"
cmp "$HERE/paper_data/esi_profiles/zero_set_rank_profile_comparison.csv" \
    "$TEMP/profile/zero_set_rank_profile_comparison.csv"

awk -f "$HERE/esi_profiles/source/delta0_markers.awk" \
    "$HERE/esi_profiles/summaries/profile_comparison_all.csv" \
    > "$TEMP/profile/markers.unsorted"
{
    head -n 1 "$TEMP/profile/markers.unsorted"
    tail -n +2 "$TEMP/profile/markers.unsorted" | sort -t, -k1,1n -k2,2
} > "$TEMP/profile/delta0_markers.csv"
cmp "$HERE/esi_profiles/summaries/delta0_markers.csv" \
    "$TEMP/profile/delta0_markers.csv"

echo "COMPACT EXISTING-DATA ANALYSIS PASS: retained aggregates reproduce paper-facing tables"
