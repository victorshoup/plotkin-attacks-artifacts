# raptorq-rbc-attack

Empirical verification of an **adversarial-subset attack on standardized RaptorQ (RFC 6330)**
as used for data-availability in Byzantine reliable broadcast (`n = 3f+1`, quorum
certificates of `2f+1` signatures).

The short version: a fountain code guarantees recovery from a *random* set of `f+1` symbols,
but a Byzantine sender/scheduler that sees the public symbol assignment can pick a *specific*
`f+1` honest symbols that **do not** reconstruct the message — even when that is *more* symbols
than the source dimension `K`. This code finds such a bad subset from RFC 6330's own matrices
and confirms it against a **real, independent RaptorQ decoder** (cberner's `raptorq` crate),
which reports "cannot decode."

See **[REPORT.md](REPORT.md)** for the full write-up (model, method, all findings, the
attack-failure boundary, and the proof that the ambiguity-space dimension is exactly
`K − 7H`). This README is just build-and-run.

## Requirements

- A recent stable **Rust** toolchain (developed on 1.93; install via <https://rustup.rs>).
- **No network needed** after the toolchain is installed: the vendored RaptorQ crate has no
  external dependencies under the feature we use.

## Quickstart

```bash
cargo run -p rq-attack --release
```

Runs the end-to-end attack for several `(f, K)`, repeated 25× each, and prints statistics.
Every run should end each block with `RESULT: ATTACK CONFIRMED (all reps)`.

## What you can run

| command | what it does | time |
|---|---|---|
| `cargo run -p rq-attack --release` | end-to-end attack + statistics (25 reps/size) | ~1 s |
| `cargo run -p rq-attack --release -- run 100` | same, 100 reps/size | ~2 s |
| `cargo run -p rq-attack --release -- sweep` | `dim(Z)` vs `K−7H`, block sizes `H = 10..12` | <1 s |
| `cargo run -p rq-attack --release -- sweep-big` | `dim(Z)` table, `H = 13..16` (big matrices) | ~seconds |
| `cargo run -p rq-attack --release -- certify` | **proof:** `dim(Z)=max(0,K'−7H)` for all 477 RFC sizes | ~1.5 s |
| `cargo run -p rq-attack --release -- certify-full 60000` | **proof:** same for every source dim `K` (per band) | ~3 s |
| `cargo test --release` | unit tests + cross-check against the real matrices | <1 s |

## Expected output (excerpt)

```
f=150  K=100  n=451  K'=101  H=10  kappa=30   (feed f+1=151 symbols)
  regime: 7H+floor(log2(2f+2)) = 78;  K > bound: true   (Delta = f+1-K = 51)
  witness-search trials over 25 reps:  min=1 mean=1.84 median=2 max=4 std=0.97
    success prob  p_hat(direct,20k)=0.4978 ...  bound 1/(2f+2)=0.0033  =>  150x looser than reality
  random-reception baseline: 0.000% of random (f+1)-subsets are bad ...; real decoder: 0/200 undecodable
  decoder confirmations over 25 reps:  bad->None 25/25,  good->recovered 25/25,  encoder-agrees 25/25
  RESULT: ATTACK CONFIRMED (all reps)
```

Here the adversary hands the real decoder **151** valid authenticated symbols (51 more than
`K=100`) and it still cannot decode, while every random 151-subset decodes.

```
$ cargo run -p rq-attack --release -- certify
checked 477 block sizes; failures = 0; of these 461 are in the attack regime K'>7H ...
PROVEN (by exhaustion over the standard): dim(Z) = max(0, K'-7H) for every RaptorQ block size.
```

## How it works (one paragraph)

RaptorQ's precode has `S` binary LDPC relations and `H` GF(256) HDPC relations. For a *binary*
source difference, each HDPC relation bit-expands to 8 GF(2) equations, so the whole
"ambiguity" question collapses to a single GF(2) kernel `Z` of dimension `κ = K − 7H`. Among
the `2f+1` honest encoding rows we search for a low-weight witness `x` with `wt(Bx) ≤ f`,
which exposes a bad `(f+1)`-subset. We then encode a real message and feed exactly those
`f+1` symbols to the real decoder (→ `None`), cross-checking with a second valid source block
that encodes identically on the subset. Full details in [REPORT.md](REPORT.md).

## Layout

```
rq-attack/src/gf2la.rs      bit-packed GF(2) linear algebra (kernel, rank)
rq-attack/src/rqmatrix.rs   RFC 6330 matrices -> binary ambiguity space Z, honest rows, B
rq-attack/src/main.rs       experiment harness, certificates, CLI
rq-attack/kprimes.txt       the 477 K' from RFC 6330 Table 2 (embedded at compile time)
vendor/raptorq/             modified cberner raptorq v2.0.1 (see vendor/raptorq/MODIFICATIONS.md)
```

## License and attribution

- Original code in `rq-attack/` is under **Apache-2.0** (`LICENSE`); you may relicense your
  own code as you wish.
- `vendor/raptorq/` is a modified copy of the **`raptorq`** crate v2.0.1 by Christopher Berner
  (<https://github.com/cberner/raptorq>), redistributed under its **Apache-2.0** license. The
  modifications only expose internal matrices and are listed in
  [`vendor/raptorq/MODIFICATIONS.md`](vendor/raptorq/MODIFICATIONS.md); no
  encoding/decoding behavior was changed.
- `kprimes.txt` lists Table 2 values from RFC 6330 (Luby et al., 2011).

This artifact accompanies a companion theory paper (in preparation); it is self-contained and
does not require it.
