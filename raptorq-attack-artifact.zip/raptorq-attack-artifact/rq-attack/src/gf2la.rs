//! Minimal bit-packed GF(2) linear algebra.
//!
//! A vector in F_2^n is stored as `Vec<u64>` (little-endian bit order: coordinate
//! `j` is bit `j % 64` of word `j / 64`). Addition is XOR. This is all the linear
//! algebra the adversarial-subset experiment needs: kernel/nullspace (to build the
//! binary ambiguity space Z), plus inner products / mat-vec over GF(2).

/// Number of u64 words needed to hold `n` bits.
pub fn words_for(n: usize) -> usize {
    n.div_ceil(64)
}

/// A dense GF(2) row-vector of a fixed bit length.
pub type BitVec = Vec<u64>;

#[inline]
pub fn zeros(n: usize) -> BitVec {
    vec![0u64; words_for(n)]
}

#[inline]
pub fn get_bit(v: &[u64], j: usize) -> bool {
    (v[j >> 6] >> (j & 63)) & 1 == 1
}

#[inline]
pub fn set_bit(v: &mut [u64], j: usize, b: bool) {
    let mask = 1u64 << (j & 63);
    if b {
        v[j >> 6] |= mask;
    } else {
        v[j >> 6] &= !mask;
    }
}

/// dst ^= src  (both same word length)
#[inline]
pub fn xor_into(dst: &mut [u64], src: &[u64]) {
    for (d, &s) in dst.iter_mut().zip(src.iter()) {
        *d ^= s;
    }
}

/// Hamming weight of a bit-vector.
#[inline]
pub fn weight(v: &[u64]) -> usize {
    v.iter().map(|w| w.count_ones() as usize).sum()
}

/// Parity (weight mod 2) of the bitwise AND of two equal-length vectors,
/// i.e. the GF(2) inner product <a, b>.
#[inline]
pub fn dot(a: &[u64], b: &[u64]) -> bool {
    let mut acc = 0u64;
    for (&x, &y) in a.iter().zip(b.iter()) {
        acc ^= x & y;
    }
    acc.count_ones() & 1 == 1
}

/// Kernel (null space) of the GF(2) matrix whose rows are `rows`, each of bit
/// length `ncols`. Returns a basis of `{ x in F_2^ncols : M x = 0 }` as a list of
/// bit-vectors of length `ncols`. `rows` is consumed (row-reduced in place).
///
/// Standard reduced row echelon form: for each pivot column we clear that column
/// from every other row, then each free column yields one basis vector.
pub fn kernel_basis(mut rows: Vec<BitVec>, ncols: usize) -> Vec<BitVec> {
    let nrows = rows.len();
    // pivot_row_for_col[c] = Some(r) if column c is a pivot with pivot row r.
    let mut pivot_row_for_col: Vec<Option<usize>> = vec![None; ncols];
    let mut pivot_cols: Vec<usize> = Vec::new();
    let mut r = 0usize;
    for c in 0..ncols {
        if r == nrows {
            break;
        }
        // Find a row at index >= r with a 1 in column c.
        let mut sel = None;
        for i in r..nrows {
            if get_bit(&rows[i], c) {
                sel = Some(i);
                break;
            }
        }
        let Some(i) = sel else { continue };
        rows.swap(r, i);
        // Eliminate column c from every other row (full RREF).
        for k in 0..nrows {
            if k != r && get_bit(&rows[k], c) {
                let (lo, hi) = if k < r {
                    (k, r)
                } else {
                    (r, k)
                };
                let (left, right) = rows.split_at_mut(hi);
                if lo == k {
                    xor_into(&mut left[lo], &right[0]);
                } else {
                    xor_into(&mut right[0], &left[lo]);
                }
            }
        }
        pivot_row_for_col[c] = Some(r);
        pivot_cols.push(c);
        r += 1;
    }

    // Each free column -> one null-space basis vector.
    let mut basis = Vec::new();
    for f in 0..ncols {
        if pivot_row_for_col[f].is_some() {
            continue;
        }
        let mut v = zeros(ncols);
        set_bit(&mut v, f, true);
        for &pc in &pivot_cols {
            let pr = pivot_row_for_col[pc].unwrap();
            if get_bit(&rows[pr], f) {
                set_bit(&mut v, pc, true);
            }
        }
        basis.push(v);
    }
    basis
}

/// Rank over GF(2) of a set of rows (each `ncols` bits). Does not consume input.
pub fn rank(rows: &[BitVec], ncols: usize) -> usize {
    let mut m: Vec<BitVec> = rows.to_vec();
    let nrows = m.len();
    let mut r = 0usize;
    for c in 0..ncols {
        if r == nrows {
            break;
        }
        let mut sel = None;
        for i in r..nrows {
            if get_bit(&m[i], c) {
                sel = Some(i);
                break;
            }
        }
        let Some(i) = sel else { continue };
        m.swap(r, i);
        for k in (r + 1)..nrows {
            if get_bit(&m[k], c) {
                let (left, right) = m.split_at_mut(k);
                xor_into(&mut right[0], &left[r]);
            }
        }
        r += 1;
    }
    r
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rowvec(bits: &[usize], ncols: usize) -> BitVec {
        let mut v = zeros(ncols);
        for &b in bits {
            set_bit(&mut v, b, true);
        }
        v
    }

    // Verify that every returned basis vector is actually in the kernel, that the
    // basis is independent, and that its size equals ncols - rank.
    fn check_kernel(rows: Vec<BitVec>, ncols: usize) {
        let basis = kernel_basis(rows.clone(), ncols);
        // Each basis vector b satisfies M b = 0.
        for bv in &basis {
            for row in &rows {
                assert!(!dot(row, bv), "basis vector not in kernel");
            }
        }
        // Dimension check: |basis| == ncols - rank(M).
        let rk = rank(&rows, ncols);
        assert_eq!(basis.len(), ncols - rk, "nullity mismatch");
        // Independence: rank(basis) == |basis|.
        assert_eq!(rank(&basis, ncols), basis.len(), "basis not independent");
    }

    #[test]
    fn kernel_of_zero_matrix_is_full() {
        let rows = vec![zeros(5)];
        let basis = kernel_basis(rows, 5);
        assert_eq!(basis.len(), 5);
    }

    #[test]
    fn kernel_simple() {
        // x0 + x1 = 0, x2 + x3 = 0 ; free: one per pivot pair, plus x4.
        let ncols = 5;
        let rows = vec![rowvec(&[0, 1], ncols), rowvec(&[2, 3], ncols)];
        check_kernel(rows, ncols);
    }

    #[test]
    fn kernel_full_rank_is_trivial() {
        // Identity-like 4x4 => only the zero vector; empty basis.
        let ncols = 4;
        let rows = vec![
            rowvec(&[0], ncols),
            rowvec(&[1], ncols),
            rowvec(&[2], ncols),
            rowvec(&[3], ncols),
        ];
        let basis = kernel_basis(rows, ncols);
        assert!(basis.is_empty());
    }

    #[test]
    fn kernel_dependent_rows() {
        let ncols = 6;
        let r1 = rowvec(&[0, 2, 4], ncols);
        let r2 = rowvec(&[1, 3], ncols);
        let r3 = {
            // r3 = r1 + r2 (dependent) -> should not raise rank
            let mut v = r1.clone();
            xor_into(&mut v, &r2);
            v
        };
        check_kernel(vec![r1, r2, r3], ncols);
    }
}
