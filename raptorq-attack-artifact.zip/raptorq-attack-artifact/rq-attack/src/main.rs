//! Verifying the adversarial-subset attack of "R10 and RaptorQ in Reliable Broadcast".
//!
//! For n = 3f+1 parties (>= 2f+1 honest), a public assignment of authenticated RaptorQ
//! encoding symbols cannot support the "any f+1 honest symbols reconstruct" guarantee once
//! K > 7H + floor(log2(2f+2)). We: (1) build the binary ambiguity space Z from cberner's
//! own RFC 6330 constraint matrix, (2) find, among the 2f+1 honest rows, a bad (f+1)-subset
//! S via a random low-weight witness, and (3) hand the corresponding f+1 encoding symbols to
//! cberner's real decoder and confirm it reports "cannot decode" (None), while a good
//! (f+1)-subset of the same honest pool decodes. The bad set is also confirmed independently
//! by encoding two distinct valid source blocks that agree on every symbol of S.

mod gf2la;
mod rqmatrix;

use raptorq::{EncodingPacket, ObjectTransmissionInformation, SourceBlockDecoder, SourceBlockEncoder};

const T: usize = 8; // symbol size in octets

/// The 477 extended source-block sizes K' from RFC 6330 Table 2 (Section 5.6), embedded so
/// the certificates need no external file and run from any directory.
const KPRIMES: &str = include_str!("../kprimes.txt");

/// Tiny seedable RNG (xorshift64*), so runs are reproducible and we need no deps.
struct Rng(u64);
impl Rng {
    fn new(seed: u64) -> Self {
        Rng(seed ^ 0x9E3779B97F4A7C15)
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545F4914F6CDD1D)
    }
    fn below(&mut self, n: usize) -> usize {
        (self.next_u64() % n as u64) as usize
    }
    /// Random nonzero bit-vector of `nbits` bits.
    fn nonzero_bits(&mut self, nbits: usize) -> Vec<u64> {
        let words = gf2la::words_for(nbits);
        loop {
            let mut v = vec![0u64; words];
            for w in v.iter_mut() {
                *w = self.next_u64();
            }
            // mask off bits beyond nbits
            let rem = nbits & 63;
            if rem != 0 {
                v[words - 1] &= (1u64 << rem) - 1;
            }
            if gf2la::weight(&v) != 0 {
                return v;
            }
        }
    }
}

/// A random subset of `[0, n)` of size `size` (as sorted distinct u32), via partial shuffle.
fn random_subset(rng: &mut Rng, n: usize, size: usize) -> Vec<u32> {
    let mut pool: Vec<u32> = (0..n as u32).collect();
    for i in 0..size {
        let j = i + rng.below(n - i);
        pool.swap(i, j);
    }
    let mut s: Vec<u32> = pool[..size].to_vec();
    s.sort_unstable();
    s
}

/// Fetch the encoding packet for a given ESI from a source-block encoder.
fn packet_for(enc: &SourceBlockEncoder, esi: u32, k: usize) -> EncodingPacket {
    if (esi as usize) < k {
        enc.source_packets()[esi as usize].clone()
    } else {
        enc.repair_packets(esi - k as u32, 1).pop().unwrap()
    }
}

fn floor_log2(x: usize) -> usize {
    (usize::BITS - 1 - x.leading_zeros()) as usize
}

/// Result of one attack rep (fresh honest set H + fresh witness randomness).
struct Rep {
    trials: usize,   // random x samples until wt(Bx) <= f
    zeros: usize,    // zero coords of the winning y = Bx (bad subsets available; >= f+1)
    attack_ns: u128, // wall time of the witness search
    bad_none: bool,  // real decoder returned None on the bad (f+1)-subset
    good_some: bool, // real decoder recovered u on a good (f+1)-subset
    enc_agrees: bool,// u and u+du encode identically on S (independent confirmation)
}

/// One full attack rep against a fresh random honest set, using the shared construction.
fn attack_once(
    f: usize,
    k: usize,
    con: &rqmatrix::Construction,
    config: &ObjectTransmissionInformation,
    rng: &mut Rng,
) -> Rep {
    let n = 3 * f + 1;
    let h_honest = 2 * f + 1;
    let s_sub = f + 1;
    let p = con.params;

    let honest_esis = random_subset(rng, n, h_honest);
    let g = rqmatrix::honest_rows(k, &honest_esis);
    let b = rqmatrix::matrix_b(&g, &con.z_basis);

    // Witness search.
    let t0 = std::time::Instant::now();
    let mut trials = 0usize;
    let (x, zero_positions) = loop {
        trials += 1;
        let x = rng.nonzero_bits(con.kappa());
        let y: Vec<bool> = b.iter().map(|row| gf2la::dot(row, &x)).collect();
        let w = y.iter().filter(|&&bit| bit).count();
        if w <= f {
            let zeros: Vec<usize> = (0..h_honest).filter(|&i| !y[i]).collect();
            break (x, zeros);
        }
        assert!(trials < 1000 * (4 * f + 4), "witness search unexpectedly long");
    };
    let attack_ns = t0.elapsed().as_nanos();
    let zeros = zero_positions.len();
    let bad_esis: Vec<u32> = zero_positions[..s_sub].iter().map(|&i| honest_esis[i]).collect();

    // Independent confirmation via two valid source blocks differing by du.
    let z = rqmatrix::combine_witness(&con.z_basis, &x, p.l);
    let du = rqmatrix::source_difference(&con.gsrc, &z);
    assert!(gf2la::weight(&du) > 0);
    let mut u = vec![0u8; k * T];
    for byte in u.iter_mut() {
        *byte = (rng.next_u64() & 0xff) as u8;
    }
    let mut u2 = u.clone();
    for i in 0..k {
        if gf2la::get_bit(&du, i) {
            u2[i * T] ^= 1;
        }
    }
    let enc_u = SourceBlockEncoder::new(0, config, &u);
    let enc_u2 = SourceBlockEncoder::new(0, config, &u2);
    let enc_agrees = bad_esis
        .iter()
        .all(|&e| packet_for(&enc_u, e, k).data() == packet_for(&enc_u2, e, k).data());

    // Operational: bad subset -> real decoder should fail.
    let bad_packets: Vec<EncodingPacket> =
        bad_esis.iter().map(|&e| packet_for(&enc_u, e, k)).collect();
    let bad_none = SourceBlockDecoder::new(0, config, (k * T) as u64)
        .decode(bad_packets)
        .is_none();

    // Control: a good (f+1)-subset should decode to u (retry to avoid a chance bad one).
    let mut good_some = false;
    for _ in 0..16 {
        let idxs = random_subset(rng, h_honest, s_sub);
        let esis: Vec<u32> = idxs.iter().map(|&i| honest_esis[i as usize]).collect();
        let packets: Vec<EncodingPacket> = esis.iter().map(|&e| packet_for(&enc_u, e, k)).collect();
        if let Some(out) = SourceBlockDecoder::new(0, config, (k * T) as u64).decode(packets) {
            if out == u {
                good_some = true;
                break;
            }
        }
    }

    Rep { trials, zeros, attack_ns, bad_none, good_some, enc_agrees }
}

struct Summary {
    min: f64,
    mean: f64,
    median: f64,
    max: f64,
    std: f64,
}

fn summarize(xs: &[f64]) -> Summary {
    let n = xs.len();
    let mut s = xs.to_vec();
    s.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let mean = s.iter().sum::<f64>() / n as f64;
    let var = s.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / n as f64;
    let median = if n % 2 == 1 {
        s[n / 2]
    } else {
        0.5 * (s[n / 2 - 1] + s[n / 2])
    };
    Summary { min: s[0], mean, median, max: s[n - 1], std: var.sqrt() }
}

/// Estimate p = Pr_x[wt(Bx) <= f] directly from `samples` random nonzero x on a fresh H.
fn estimate_success_prob(f: usize, k: usize, con: &rqmatrix::Construction, rng: &mut Rng, samples: usize) -> f64 {
    let n = 3 * f + 1;
    let honest = random_subset(rng, n, 2 * f + 1);
    let g = rqmatrix::honest_rows(k, &honest);
    let b = rqmatrix::matrix_b(&g, &con.z_basis);
    let mut hits = 0usize;
    for _ in 0..samples {
        let x = rng.nonzero_bits(con.kappa());
        let w = b.iter().filter(|row| gf2la::dot(row, &x)).count();
        if w <= f {
            hits += 1;
        }
    }
    hits as f64 / samples as f64
}

/// Random-reception baseline: over `m` random (f+1)-subsets of a fresh H, the fraction that
/// are bad by the binary-ambiguity test rank(B_S) < kappa, and (over `m_real` of them) the
/// fraction the REAL decoder cannot decode. Contrast with the adversarial subset (always bad).
fn random_reception_baseline(
    f: usize,
    k: usize,
    con: &rqmatrix::Construction,
    config: &ObjectTransmissionInformation,
    rng: &mut Rng,
    m: usize,
    m_real: usize,
) -> (f64, usize, usize) {
    let n = 3 * f + 1;
    let h_honest = 2 * f + 1;
    let s_sub = f + 1;
    let honest = random_subset(rng, n, h_honest);
    let g = rqmatrix::honest_rows(k, &honest);
    let b = rqmatrix::matrix_b(&g, &con.z_basis);

    let mut bad_binary = 0usize;
    for _ in 0..m {
        let idxs = random_subset(rng, h_honest, s_sub);
        let rows: Vec<gf2la::BitVec> = idxs.iter().map(|&i| b[i as usize].clone()).collect();
        if gf2la::rank(&rows, con.kappa()) < con.kappa() {
            bad_binary += 1;
        }
    }

    // Ground-truth with the real decoder on a smaller sample.
    let mut u = vec![0u8; k * T];
    for byte in u.iter_mut() {
        *byte = (rng.next_u64() & 0xff) as u8;
    }
    let enc_u = SourceBlockEncoder::new(0, config, &u);
    let mut real_undecodable = 0usize;
    for _ in 0..m_real {
        let idxs = random_subset(rng, h_honest, s_sub);
        let esis: Vec<u32> = idxs.iter().map(|&i| honest[i as usize]).collect();
        let packets: Vec<EncodingPacket> = esis.iter().map(|&e| packet_for(&enc_u, e, k)).collect();
        if SourceBlockDecoder::new(0, config, (k * T) as u64)
            .decode(packets)
            .is_none()
        {
            real_undecodable += 1;
        }
    }

    (bad_binary as f64 / m as f64, real_undecodable, m_real)
}

fn run_stats(f: usize, k: usize, reps: usize, seed: u64) {
    assert!(k <= f + 1, "need K <= f+1 so f+1 symbols could decode");
    let con = rqmatrix::construct(k);
    let p = con.params;
    let kappa = con.kappa();
    assert!(kappa > 0, "no binary ambiguity for K={k} (K<=7H); pick larger K");
    let n = 3 * f + 1;
    let bound = 7 * p.h + floor_log2(2 * f + 2);
    let config = ObjectTransmissionInformation::new((k * T) as u64, T as u16, 1, 1, 1);
    let mut rng = Rng::new(seed);

    let reps_data: Vec<Rep> = (0..reps).map(|_| attack_once(f, k, &con, &config, &mut rng)).collect();

    let trials: Vec<f64> = reps_data.iter().map(|r| r.trials as f64).collect();
    let zeros: Vec<f64> = reps_data.iter().map(|r| r.zeros as f64).collect();
    let us: Vec<f64> = reps_data.iter().map(|r| r.attack_ns as f64 / 1e3).collect();
    let ts = summarize(&trials);
    let zs = summarize(&zeros);
    let tus = summarize(&us);
    let bad_none = reps_data.iter().filter(|r| r.bad_none).count();
    let good_some = reps_data.iter().filter(|r| r.good_some).count();
    let enc_ok = reps_data.iter().filter(|r| r.enc_agrees).count();
    let p_emp = reps as f64 / trials.iter().sum::<f64>(); // ~ success prob from geometric mean

    let p_direct = estimate_success_prob(f, k, &con, &mut rng, 20_000);
    let (base_bin, base_real_bad, base_real_m) =
        random_reception_baseline(f, k, &con, &config, &mut rng, 5000, 200);

    println!("f={f}  K={k}  n={n}  K'={}  H={}  kappa={kappa}   (feed f+1={} symbols)", p.kprime, p.h, f + 1);
    println!(
        "  regime: 7H+floor(log2(2f+2)) = {bound};  K > bound: {}   (Delta = f+1-K = {})",
        k > bound,
        (f + 1) - k
    );
    println!(
        "  witness-search trials over {reps} reps:  min={} mean={:.2} median={} max={} std={:.2}",
        ts.min as usize, ts.mean, ts.median as usize, ts.max as usize, ts.std
    );
    let bound_2f = 1.0 / (2.0 * f as f64 + 2.0);
    println!(
        "    success prob  p_hat(direct,20k)={:.4}  (geometric {:.4});  bound 1/(2f+2)={:.4}  =>  {:.0}x looser than reality",
        p_direct, p_emp, bound_2f, p_direct / bound_2f
    );
    println!(
        "    bad-subset supply: winning y has mean {:.1} zero coords (>= f+1={} needed, so many bad subsets available)",
        zs.mean, f + 1
    );
    println!("    attack time/rep (us):  min={:.1} mean={:.1} max={:.1}", tus.min, tus.mean, tus.max);
    println!(
        "  random-reception baseline: {:.3}% of random (f+1)-subsets are bad (binary test, 5000 samples); real decoder: {}/{} undecodable",
        100.0 * base_bin, base_real_bad, base_real_m
    );
    println!(
        "  decoder confirmations over {reps} reps:  bad->None {}/{},  good->recovered {}/{},  encoder-agrees {}/{}",
        bad_none, reps, good_some, reps, enc_ok, reps
    );
    let pass = bad_none == reps && good_some == reps && enc_ok == reps;
    println!("  RESULT: {}\n", if pass { "ATTACK CONFIRMED (all reps)" } else { "FAILED" });
}

/// Sweep dim(Z) across source-block sizes spanning the H transitions and report the gap
/// against the paper's lower bound K - 7H. gap == 0 everywhere means the 7H loss is tight:
/// the HDPC bit-expansion contributes a full 8H independent GF(2) constraints.
fn sweep_ambiguity(ks: &[usize]) {
    println!("=== dim(Z) vs the K - 7H lower bound ===");
    println!(
        "{:>7} {:>7} {:>4} {:>7} {:>10} {:>10} {:>6} {:>9}",
        "K", "K'", "H", "L", "rows(M)", "dim(Z)", "K-7H", "gap"
    );
    for &k in ks {
        let (p, nullity, rank, rows) = rqmatrix::ambiguity_dim(k);
        let lb = p.k as isize - 7 * p.h as isize;
        let gap = nullity as isize - lb;
        let full_rank = rank == rows;
        println!(
            "{:>7} {:>7} {:>4} {:>7} {:>10} {:>10} {:>6} {:>9}{}",
            p.k,
            p.kprime,
            p.h,
            p.l,
            rows,
            nullity,
            lb,
            gap,
            if full_rank { "  (M full rank)" } else { "  (M RANK-DEFICIENT)" }
        );
    }
    println!();
}

fn main() {
    if std::env::args().any(|a| a == "certify") {
        // Exhaustive certificate: K' takes only the ~477 values in RFC 6330 Table 2, so
        // checking rank[LDPC ; 8H HDPC-bit] == S+8H for every one PROVES dim(Z)=K'-7H
        // exactly for every standardized full block (K=K').
        let list = KPRIMES; // the 477 RFC 6330 Table-2 extended sizes, embedded at compile time
        let kprimes: Vec<usize> = list.split_whitespace().filter_map(|t| t.parse().ok()).collect();
        println!(
            "=== Exhaustive core certificate over all {} standardized K' (RFC Table 2) ===",
            kprimes.len()
        );
        println!("check: dim Z = L - rank[LDPC ; 8H HDPC bit-planes] == max(0, K'-7H)\n");
        let mut fails = 0usize;
        let mut tight = 0usize; // # sizes in the attack regime K' > 7H (dim Z = K'-7H > 0)
        for &kp in &kprimes {
            let (p, rank, s8h) = rqmatrix::core_rank(kp);
            let dim_z = p.l - rank; // rank <= L always
            let expected = (p.k as i64 - 7 * p.h as i64).max(0) as usize;
            // Equivalent predicate: rank == min(S+8H, L).
            debug_assert_eq!(rank, s8h.min(p.l));
            if dim_z != expected {
                fails += 1;
                println!(
                    "  FAIL K'={} H={} L={} : dim Z = {} , expected max(0,K'-7H) = {}",
                    kp, p.h, p.l, dim_z, expected
                );
            } else if expected > 0 {
                tight += 1;
            }
        }
        println!(
            "checked {} block sizes; failures = {}; of these {} are in the attack regime K'>7H (dim Z = K'-7H > 0)",
            kprimes.len(),
            fails,
            tight
        );
        println!(
            "{}",
            if fails == 0 {
                "PROVEN (by exhaustion over the standard): dim(Z) = max(0, K'-7H) for every RaptorQ block size."
            } else {
                "COUNTEREXAMPLE(S) FOUND above."
            }
        );
        return;
    }

    if std::env::args().any(|a| a == "certify-full") {
        // Certify dim(Z) = max(0, K-7H) for EVERY source dim K (not just K=K'), by the
        // saturation argument: if [ core ; G_ENC(ISIs 7H..K'-1) ] has rank L, then the
        // padding rows for any K>=7H are independent of the core, so gap=0 for all K.
        // One rank-L check per K'. Capped since it is an L x L elimination.
        let cap: usize = std::env::args()
            .skip_while(|a| a != "certify-full")
            .nth(1)
            .and_then(|a| a.parse().ok())
            .unwrap_or(1100);
        let list = KPRIMES;
        let kprimes: Vec<usize> = list
            .split_whitespace()
            .filter_map(|t| t.parse().ok())
            .filter(|&kp: &usize| kp <= cap)
            .collect();
        // The full K' list (unfiltered) so we know each band's predecessor.
        let all: Vec<usize> = list.split_whitespace().filter_map(|t| t.parse().ok()).collect();
        println!(
            "=== Full certificate (every source dim K): per-band check for {} standardized K' <= {} ===",
            kprimes.len(),
            cap
        );
        println!("for each band, test smallest K = K'_prev+1 (maximal real padding): dim Z == max(0,K-7H)\n");
        let mut fails = 0usize;
        let mut worst_pad = 0usize;
        for (i, &kp) in all.iter().enumerate() {
            if kp > cap {
                break;
            }
            let prev = if i == 0 { 0 } else { all[i - 1] };
            let kmin = prev + 1;
            worst_pad = worst_pad.max(kp - kmin);
            let (p, dimz) = rqmatrix::band_dimz(kp, kmin);
            let expected = (kmin as i64 - 7 * p.h as i64).max(0) as usize;
            if dimz != expected {
                fails += 1;
                println!(
                    "  FAIL band K'={} (K in {}..{}), H={}: at K={} dim Z={} expected {}",
                    kp, kmin, kp, p.h, kmin, dimz, expected
                );
            }
        }
        println!(
            "checked bands up to K'={}; failures = {}; largest real padding tested = {}\n{}",
            cap,
            fails,
            worst_pad,
            if fails == 0 {
                "PROVEN for these sizes: dim(Z) = max(0, K-7H) for EVERY valid source dim K."
            } else {
                "COUNTEREXAMPLE(S) FOUND above."
            }
        );
        return;
    }

    if std::env::args().any(|a| a == "sweep-big") {
        // One representative per remaining H value, up to the RFC 6330 maximum K'=56403.
        // These build an L x L (~57k) constraint matrix, so they are slower/heavier.
        let ks = [20778, 30654, 40398, 50511, 56403];
        sweep_ambiguity(&ks);
        return;
    }

    if std::env::args().any(|a| a == "sweep") {
        // H=10 (K'<=1049), H=11 (>=1050), H=12 (>=10899). Within a fixed K' band, dim(Z)
        // should track K one-for-one (padding rows change with K, H fixed).
        let ks = [
            100, 300, 700, 1000, 1040, // H=10
            1050, 1500, 3000, 6000, 10000, // H=11
            10899, // H=12
        ];
        sweep_ambiguity(&ks);
        return;
    }

    // Repeated end-to-end experiment with per-parameter statistics.
    // Optional: `run <REPS>` to override the repetition count.
    let reps: usize = std::env::args()
        .skip_while(|a| a != "run")
        .nth(1)
        .and_then(|a| a.parse().ok())
        .unwrap_or(25);

    // (f, K). Need K > 7H (~70 for these sizes) for a nonzero ambiguity space, and K <= f+1.
    let cases = [(80usize, 80usize), (100, 90), (127, 100), (150, 100)];

    println!("=== RaptorQ adversarial-subset attack: repeated end-to-end verification ({reps} reps/size) ===\n");
    for (idx, &(f, k)) in cases.iter().enumerate() {
        run_stats(f, k, reps, 0xC0FFEE ^ (idx as u64).wrapping_mul(2654435761));
    }
}
