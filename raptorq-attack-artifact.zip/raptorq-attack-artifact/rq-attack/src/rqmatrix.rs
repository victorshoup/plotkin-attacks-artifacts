//! Bridge from cberner's RFC 6330 internals to the binary attack objects.
//!
//! The paper's reduction: over one octet position, valid RaptorQ source differences
//! in intermediate-symbol coordinates form W = ker_{F256}(P ; G_PAD), where P are the
//! precode rows (S LDPC over F2, H HDPC over F256) and G_PAD are the K'-K zero-padding
//! rows. The *binary* ambiguity space is Z = W ∩ F2^L. Because a binary vector z makes
//! each HDPC row's F256 value an F2-linear function of the bits of z (landing in
//! F2^8), each HDPC equation expands to 8 GF(2) equations (bit b uses bit b of each
//! coefficient). So Z is a single GF(2) kernel of the stacked system
//!     [ LDPC (S) ; HDPC-expanded (8H) ; G_PAD (K'-K) ]  over L columns,
//! giving nullity kappa >= L - S - 8H - (K'-K) = K - 7H, matching the paper.
//!
//! All matrices come straight from cberner's own `generate_constraint_matrix` /
//! `generate_encoding_rows`, so the rows are byte-identical to what its decoder solves.

use raptorq::{
    extended_source_block_symbols, generate_constraint_matrix, generate_encoding_rows,
    generate_hdpc_rows, num_hdpc_symbols, num_intermediate_symbols, num_ldpc_symbols,
    num_lt_symbols, num_pi_symbols, BinaryMatrix, DenseBinaryMatrix,
};

use crate::gf2la::{self, BitVec};

#[derive(Clone, Copy, Debug)]
pub struct Params {
    pub k: usize,      // source symbols
    pub kprime: usize, // extended source symbols K'
    pub s: usize,      // LDPC symbols
    pub h: usize,      // HDPC symbols
    pub l: usize,      // intermediate symbols = K' + S + H
}

pub fn params(k: usize) -> Params {
    let ku = k as u32;
    Params {
        k,
        kprime: extended_source_block_symbols(ku) as usize,
        s: num_ldpc_symbols(ku) as usize,
        h: num_hdpc_symbols(ku) as usize,
        l: num_intermediate_symbols(ku) as usize,
    }
}

/// ESI -> ISI: source symbols map identically; repair symbols (ESI >= K) shift by the
/// K'-K padding symbols, exactly as cberner's decoder does when it assembles ISIs.
pub fn esi_to_isi(esi: u32, p: &Params) -> u32 {
    if (esi as usize) < p.k {
        esi
    } else {
        esi + (p.kprime - p.k) as u32
    }
}

fn read_row(m: &DenseBinaryMatrix, row: usize, ncols: usize) -> BitVec {
    let mut v = gf2la::zeros(ncols);
    for j in 0..ncols {
        if m.get(row, j).byte() != 0 {
            gf2la::set_bit(&mut v, j, true);
        }
    }
    v
}

/// Everything derived once per source-block size K.
pub struct Construction {
    pub params: Params,
    /// Basis of the binary ambiguity space Z ⊆ F2^L (each vector has L bits).
    pub z_basis: Vec<BitVec>,
    /// The K source rows G_SRC (each L bits); source difference of z is dot(G_SRC_i, z).
    pub gsrc: Vec<BitVec>,
}

impl Construction {
    pub fn kappa(&self) -> usize {
        self.z_basis.len()
    }
}

/// Report on dim(Z) without building the null-space basis: returns
/// (params, nullity = dim Z, rank(M), number of rows of M). Since nullity is always
/// >= L - rows = K - 7H, equality (rank == rows) means the stacked binary constraint
/// system is full row rank -- i.e. the 8 bit-planes of the H HDPC rows are GF(2)-
/// independent of each other and of the LDPC/padding rows.
pub fn ambiguity_dim(k: usize) -> (Params, usize, usize, usize) {
    let (p, m, _gsrc) = build_system(k, false);
    let rank = gf2la::rank(&m, p.l);
    (p, p.l - rank, rank, m.len())
}

/// Assemble the stacked GF(2) constraint system whose kernel is Z, plus the K source
/// rows G_SRC (used to turn a z into a concrete source difference). Shared by
/// `construct` and `ambiguity_dim`.
fn build_system(k: usize, want_gsrc: bool) -> (Params, Vec<BitVec>, Vec<BitVec>) {
    let p = params(k);
    let l = p.l;

    // Full square constraint matrix A for ISIs 0..K'-1:
    //   rows 0..S            : LDPC (binary)
    //   rows S..S+H          : HDPC placeholder (returned separately as octets)
    //   rows S+H..S+H+K      : G_SRC  (the K real source rows)
    //   rows S+H+K..S+H+K'   : G_PAD  (the K'-K padding rows)
    let indices: Vec<u32> = (0..p.kprime as u32).collect();
    let (bin, hdpc) = generate_constraint_matrix::<DenseBinaryMatrix>(k as u32, &indices);
    debug_assert_eq!(bin.height(), l);
    debug_assert_eq!(bin.width(), l);
    debug_assert_eq!(hdpc.height(), p.h);

    // Stack the GF(2) constraint system whose kernel is Z.
    let mut m: Vec<BitVec> = Vec::with_capacity(p.s + 8 * p.h + (p.kprime - p.k));

    // LDPC rows (already binary).
    for r in 0..p.s {
        m.push(read_row(&bin, r, l));
    }

    // HDPC rows, each expanded into 8 binary equations (bit-slice of the F256 coeffs).
    for i in 0..p.h {
        let mut rows8: Vec<BitVec> = (0..8).map(|_| gf2la::zeros(l)).collect();
        for j in 0..l {
            let coeff = hdpc.get(i, j).byte();
            if coeff == 0 {
                continue;
            }
            for (b, row) in rows8.iter_mut().enumerate() {
                if (coeff >> b) & 1 == 1 {
                    gf2la::set_bit(row, j, true);
                }
            }
        }
        for row in rows8 {
            m.push(row);
        }
    }

    // G_PAD rows.
    for r in (p.s + p.h + p.k)..(p.s + p.h + p.kprime) {
        m.push(read_row(&bin, r, l));
    }

    // G_SRC rows for computing the induced source difference (only when requested).
    let mut gsrc = Vec::new();
    if want_gsrc {
        gsrc.reserve(p.k);
        for r in (p.s + p.h)..(p.s + p.h + p.k) {
            gsrc.push(read_row(&bin, r, l));
        }
    }

    (p, m, gsrc)
}

/// Build Z (and G_SRC) from cberner's constraint matrix for the full extended block.
pub fn construct(k: usize) -> Construction {
    let (p, m, gsrc) = build_system(k, true);
    let z_basis = gf2la::kernel_basis(m, p.l);
    Construction {
        params: p,
        z_basis,
        gsrc,
    }
}

/// The "core" GF(2) constraint system [ LDPC (S) ; HDPC-bit-expanded (8H) ] for source
/// dimension k, built WITHOUT the L×L matrix: LDPC rows are reconstructed directly from
/// RFC 6330 section 5.3.3.3 (identical to cberner's `generate_constraint_matrix`), HDPC
/// comes from `generate_hdpc_rows`. This is the K=K' (no-padding) case; its rank governs
/// whether dim(Z) hits the K - 7H floor. Cheap even at K'=56403.
pub fn core_system(k: usize) -> (Params, Vec<BitVec>) {
    let p = params(k);
    let l = p.l;
    let ku = k as u32;
    let w = num_lt_symbols(ku) as usize;
    let pp = num_pi_symbols(ku) as usize;
    let s = p.s;
    let b = w - s;

    let mut rows: Vec<BitVec> = (0..s).map(|_| gf2la::zeros(l)).collect();
    // G_LDPC,1 (circulant, 3 ones per column)
    for i in 0..b {
        let a = 1 + i / s;
        let mut bb = i % s;
        gf2la::set_bit(&mut rows[bb], i, true);
        bb = (bb + a) % s;
        gf2la::set_bit(&mut rows[bb], i, true);
        bb = (bb + a) % s;
        gf2la::set_bit(&mut rows[bb], i, true);
    }
    // I_S
    for i in 0..s {
        gf2la::set_bit(&mut rows[i], i + b, true);
    }
    // G_LDPC,2
    for i in 0..s {
        gf2la::set_bit(&mut rows[i], (i % pp) + w, true);
        gf2la::set_bit(&mut rows[i], ((i + 1) % pp) + w, true);
    }

    // HDPC rows, each bit-sliced into 8 GF(2) equations.
    let hdpc = generate_hdpc_rows(p.kprime, s, p.h);
    for i in 0..p.h {
        let mut rows8: Vec<BitVec> = (0..8).map(|_| gf2la::zeros(l)).collect();
        for j in 0..l {
            let c = hdpc.get(i, j).byte();
            if c == 0 {
                continue;
            }
            for (bit, row) in rows8.iter_mut().enumerate() {
                if (c >> bit) & 1 == 1 {
                    gf2la::set_bit(row, j, true);
                }
            }
        }
        rows.extend(rows8);
    }
    (p, rows)
}

/// Rank of the core system; equals S+8H iff dim(Z)=K-7H at K=K' for this block size.
pub fn core_rank(k: usize) -> (Params, usize, usize) {
    let (p, rows) = core_system(k);
    let rank = gf2la::rank(&rows, p.l);
    (p, rank, p.s + 8 * p.h)
}

/// dim(Z) for source dimension `kmin` inside the band whose extended size is `kprime`
/// (i.e. kprime = extended(kmin)). Builds the core plus the real padding rows
/// G_ENC(ISIs kmin..kprime-1). Checking the smallest K of a band (maximal real padding)
/// certifies the whole band: if these padding rows are all independent of the core, so is
/// every subset {K..kprime-1} for larger K in the band.
pub fn band_dimz(kprime: usize, kmin: usize) -> (Params, usize) {
    let (p, mut rows) = core_system(kprime);
    let isis: Vec<u32> = (kmin as u32..p.kprime as u32).collect();
    rows.extend(honest_rows(kprime, &isis)); // identity ESI->ISI since all < kprime
    let rank = gf2la::rank(&rows, p.l);
    (p, p.l - rank)
}

/// Binary encoding rows g_X ∈ F2^L for a list of honest ESIs (mapped to ISIs).
pub fn honest_rows(k: usize, esis: &[u32]) -> Vec<BitVec> {
    let p = params(k);
    let isis: Vec<u32> = esis.iter().map(|&e| esi_to_isi(e, &p)).collect();
    let g = generate_encoding_rows::<DenseBinaryMatrix>(k as u32, &isis);
    (0..g.height()).map(|r| read_row(&g, r, p.l)).collect()
}

/// B = G · Z0 over GF(2): B has one row per honest symbol, kappa columns.
/// B[i][t] = <g_i, z_t>. A nonzero x ∈ F2^kappa with (B x)_i = 0 means honest symbol i
/// cannot distinguish the source pair (u, u + G_SRC·z) where z = Σ x_t z_t.
pub fn matrix_b(honest_g: &[BitVec], z_basis: &[BitVec]) -> Vec<BitVec> {
    let kappa = z_basis.len();
    honest_g
        .iter()
        .map(|g| {
            let mut row = gf2la::zeros(kappa);
            for (t, z) in z_basis.iter().enumerate() {
                if gf2la::dot(g, z) {
                    gf2la::set_bit(&mut row, t, true);
                }
            }
            row
        })
        .collect()
}

/// z = Σ_{t: x_t=1} z_t  ∈ F2^L, given a kappa-bit witness x.
pub fn combine_witness(z_basis: &[BitVec], x: &[u64], l: usize) -> BitVec {
    let mut z = gf2la::zeros(l);
    for (t, zt) in z_basis.iter().enumerate() {
        if gf2la::get_bit(x, t) {
            gf2la::xor_into(&mut z, zt);
        }
    }
    z
}

/// Source difference δu ∈ F2^K induced by z: coordinate i is <G_SRC_i, z>.
pub fn source_difference(gsrc: &[BitVec], z: &[u64]) -> BitVec {
    let k = gsrc.len();
    let mut du = gf2la::zeros(k);
    for (i, row) in gsrc.iter().enumerate() {
        if gf2la::dot(row, z) {
            gf2la::set_bit(&mut du, i, true);
        }
    }
    du
}

#[cfg(test)]
mod tests {
    use super::*;

    // The fast `core_system` reconstructs LDPC + HDPC directly. Confirm its rows are
    // byte-identical to the S LDPC + 8H HDPC-bit rows produced by the full-matrix path
    // (`build_system`, which reads cberner's `generate_constraint_matrix`).
    #[test]
    fn core_system_matches_full_matrix() {
        for &k in &[10usize, 30, 101, 200, 500, 1050] {
            let (p, core) = core_system(k);
            let (_p2, full, _g) = build_system(k, false);
            // build_system stacks LDPC (S) then 8H HDPC then padding; with k=k there is
            // padding only if k<k'. Compare the leading S + 8H rows.
            let n = p.s + 8 * p.h;
            assert_eq!(core.len(), n, "core row count for k={k}");
            for r in 0..n {
                assert_eq!(core[r], full[r], "row {r} differs for k={k}");
            }
        }
    }
}
